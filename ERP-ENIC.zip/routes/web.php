<?php

use App\Events\NotifyProcessed;
use App\Exports\MaterialsForProductsExport;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AgentController;
use App\Http\Controllers\Admin\AttendanceController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ContainerController;
use App\Http\Controllers\Admin\CustomsClearanceController;
use App\Http\Controllers\Admin\DeliveryController;
use App\Http\Controllers\Admin\ExpertController;
use App\Http\Controllers\Admin\FactoryCustomController;
use App\Http\Controllers\Admin\FileStorageController;
use App\Http\Controllers\Admin\ForecastManagerController;
use App\Http\Controllers\Admin\ForecastProductController;
use App\Http\Controllers\Admin\LearningProcessController;
use App\Http\Controllers\Admin\MaterialController;
use App\Http\Controllers\Admin\MenuController;
use App\Http\Controllers\Admin\NoteController;
use App\Http\Controllers\Admin\NotificationController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\PartnerController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ProductionController;
use App\Http\Controllers\Admin\PurchaseOrderController;
use App\Http\Controllers\Admin\PurchasingManagerController;
use App\Http\Controllers\Admin\RepairOrderController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\ShipmentController;
use App\Http\Controllers\Admin\StockController;
use App\Http\Controllers\Admin\SupplierController;
use App\Http\Controllers\Admin\SystemController;
use App\Http\Controllers\Admin\TagController;
use App\Http\Controllers\Admin\TaskController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\WarehouseController;
use App\Http\Controllers\Admin\WarehousingManagerController;
use App\Http\Controllers\Home\HomeController;
use App\Models\Role;
use Illuminate\Http\Request as Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;

Auth::routes();


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware('auth')->group(function () {

  Route::prefix('/admin/system')->group(function () {
    Route::get('/', [SystemController::class, 'index']);
    Route::get('/home', [SystemController::class, 'home']);
    Route::post('/home/update/setting/{id}', [SystemController::class, 'updateSettingHome']);


    Route::get('/lang', [SystemController::class, 'lang']);
    Route::get('/lang/delete/{id}', [SystemController::class, 'deleteLang']);
    Route::post('/save/lang', [SystemController::class, 'saveLang']);

    Route::get('/embedhtml', [SystemController::class, 'embedhtml'])->name('embedhtml');
    Route::get('/theme', [SystemController::class, 'theme'])->name('theme');
    Route::post('/embedhtml/update/{id}', [SystemController::class, 'updateEmbedhtml']);
    Route::post('/theme/update/{id}', [SystemController::class, 'updateTheme']);
    Route::get('/gallery', [SystemController::class, 'gallery']);
  });



  Route::get('/admin', [HomeController::class, 'index']);
  Route::get('/dashboard', [AdminController::class, 'dashboard']);

  /* Danh mục */

  Route::prefix('/admin/category')->group(function () {

    Route::get('/add', [CategoryController::class, 'add'])->name('category.add');
    Route::get('/list', [CategoryController::class, 'categoryList'])->name('category.list');
    Route::post('/save', [CategoryController::class, 'save']);
    Route::get('/edit/{id}', [CategoryController::class, 'edit']);
    Route::get('/delete/{id}', [CategoryController::class, 'delete']);
    Route::post('/update/{id}', [CategoryController::class, 'update']);

    Route::get('/view-import-excel', [CategoryController::class, 'importExcel'])->name('category.import_excel');
    Route::post('/uploadPreview', [CategoryController::class, 'uploadPreview'])->name('category.upload.FileExcel');
    Route::post('/ImportFileExcel', [CategoryController::class, 'ImportFileExcel'])->name('category.upload.ImportFileExcel');

    Route::get('/export-category', [CategoryController::class, 'export'])->name('category.export');
  });
  /* Tag */

  Route::prefix('/admin/tag')->group(function () {
    Route::get('/add', [TagController::class, 'add'])->middleware('can:add_post');
    Route::get('/list', [TagController::class, 'list'])->middleware('can:add_post');
    Route::post('/save', [TagController::class, 'save']);
    Route::get('/edit/{id}', [TagController::class, 'edit'])->middleware('can:add_post');
    Route::get('/delete/{id}', [TagController::class, 'delete'])->middleware('can:add_post');
    Route::post('/update/{id}', [TagController::class, 'update']);
  });

  // Menus
  Route::prefix('/admin/menu')->group(function () {
    Route::get('/list', [MenuController::class, 'index']);
    Route::get('/create', [MenuController::class, 'create']);
    Route::get('/edit/{id}', [MenuController::class, 'edit']);
    Route::post('/update/{id}', [MenuController::class, 'update']);
    Route::post('/save', [MenuController::class, 'save']);
    Route::get('/delete/{id}', [MenuController::class, 'delete']);
  });


  /* User */
  Route::get('/admin/user/add', [UserController::class, 'add'])->middleware('can:add_user')->name('user_add');
  Route::get('/admin/user/list', [UserController::class, 'list'])->middleware('can:list_user')->name('user_list');
  Route::post('/admin/save/user', [UserController::class, 'save'])->middleware('can:add_user');
  Route::get('/admin/user/edit/{id}', [UserController::class, 'edit'])->middleware('can:edit_user');
  Route::get('/admin/user/delete/{id}', [UserController::class, 'delete'])->middleware('can:delete_user');
  Route::post('/admin/update/user/{id}', [UserController::class, 'update'])->middleware('can:edit_user');

  /* Role */
  Route::get('/admin/role/add', [RoleController::class, 'add'])->middleware('can:add_role')->name('role.add');
  Route::get('/admin/role/list', [RoleController::class, 'list'])->middleware('can:list_role')->name('role.list');
  Route::post('/admin/save/role', [RoleController::class, 'save'])->middleware('can:add_role');
  Route::get('/admin/role/edit/{id}', [RoleController::class, 'edit'])->middleware('can:edit_role');
  Route::get('/admin/role/delete/{id}', [RoleController::class, 'delete'])->middleware('can:delete_role');
  Route::post('/admin/update/role/{id}', [RoleController::class, 'update'])->middleware('can:edit_role');

  /* Infor user */

  Route::get('/admin/user/info', [AdminController::class, 'infoUser']);
  Route::post('/update-admin-info/{id}', [AdminController::class, 'update']);


  /* Module Sản Phẩm */


  Route::prefix('/admin/product')->group(function () {
    Route::get('/add', [ProductController::class, 'add'])->middleware('can:add_product')->name('product.add');
    Route::get('/edit/{id}', [ProductController::class, 'edit'])->middleware('can:edit_product')->name('product.edit');
    Route::get('/delete/{id}', [ProductController::class, 'delete'])->middleware('can:delete_product')->name('product.delete');


    Route::post('/save', [ProductController::class, 'save'])->middleware('can:list_product')->name('product.save');
    Route::post('/update/{id}', [ProductController::class, 'update'])->middleware('can:list_product')->name('product.update');
    Route::get('view-import-excel', [ProductController::class, 'importExcel'])->middleware('can:list_product')->name('product.import_excel');
    Route::post('/uploadPreview', [ProductController::class, 'uploadPreview'])->middleware('can:list_product')->name('upload.FileExcel');

    Route::get('/list', [ProductController::class, 'list'])->middleware('can:list_product')->name('product.list');
    Route::post('/ImportFileExcel', [ProductController::class, 'ImportFileExcel'])->middleware('can:import_excel_product')->name('upload.ImportFileExcel');
    Route::get('/ExportFileExcel', [ProductController::class, 'export'])->middleware('can:export_excel_product')->name('product.export.FileExcel');
  });

  /* Module Mua Hàng Purchase Order  13/1/2025 */

  Route::prefix('/admin/purchase-order')->group(function () {
    Route::get('/add', [PurchaseOrderController::class, 'create'])->middleware('can:add_purchase')->name('purchaseorder.add');
    Route::get('/edit/{id}', [PurchaseOrderController::class, 'edit'])->middleware('can:edit_purchase')->name('purchaseorder.edit');
    Route::get('/delete/{id}', [PurchaseOrderController::class, 'delete'])->middleware('can:delete_purchase')->name('purchaseorder.delete');
    Route::get('/list', [PurchaseOrderController::class, 'index'])->middleware('can:list_purchase')->name('purchaseorder.index');
    Route::post('/save', [PurchaseOrderController::class, 'store'])->middleware('can:add_purchase')->name('purchase_orders.store');
    Route::post('/update/{id}', [PurchaseOrderController::class, 'update'])->middleware('can:edit_purchase')->name('purchaseorder.update');
    Route::get('suppliers/search', [PurchaseOrderController::class, 'search'])->name('suppliers.search');
    Route::get('/list_products', [ProductController::class, 'listProducts'])->name('list_products');
    Route::get('/export-excel/{id}', [PurchaseOrderController::class, 'export'])->middleware('can:excel_purchase')->name('purchaseorder.export');
    Route::post('purchase-orders/check-skus', [PurchaseOrderController::class, 'checkSkus'])->name('purchase-orders.check-skus');

    Route::get('/orders/items', [PurchaseOrderController::class, 'showOrderItems'])->middleware('can:list_purchase')->name('purchaseorder.allitems');

    Route::get('/orders/filter', [PurchaseOrderController::class, 'filter'])->name('orders.filter');


    Route::post('/purchase-orders/calculate-expected-date', [PurchaseOrderController::class, 'calculateExpectedDate'])
      ->name('purchase-orders.calculate-expected-date');
  });

  /* Module Nhà Cung Cấp Supplier 13/01/2025 */

  Route::prefix('/admin/supplier')->group(function () {
    Route::get('/add', [SupplierController::class, 'create'])->middleware('can:add_supplier')->name('supplier.add');
    Route::get('/edit/{id}', [SupplierController::class, 'edit'])->middleware('can:edit_supplier')->name('supplier.edit');
    Route::get('/delete/{id}', [SupplierController::class, 'delete'])->middleware('can:delete_supplier')->name('supplier.delete');
    Route::get('/list', [SupplierController::class, 'index'])->middleware('can:list_supplier')->name('supplier.index');
    Route::post('/store-process', [SupplierController::class, 'store'])->middleware('can:add_supplier')->name('suppliers.store');
    Route::post('/update/{id}', [SupplierController::class, 'update'])->middleware('can:edit_supplier')->name('supplier.update');
    Route::get('/list_products', [ProductController::class, 'listProducts'])->name('list_products');

    Route::get('/view-import-excel', [SupplierController::class, 'importExcel'])->middleware('can:list_supplier')->name('supplier.import');
    Route::post('/uploadPreview', [SupplierController::class, 'uploadPreview'])->middleware('can:list_supplier')->name('supplier.FileExcel');
    Route::post('/ImportFileExcel', [SupplierController::class, 'ImportFileExcel'])->middleware('can:list_supplier')->name('supplier.ImportFileExcel');
  });

  /* Module Xưởng Sản Xuất */

  Route::prefix('/admin/production')->group(function () {
    Route::get('/add', [ProductionController::class, 'add'])->middleware('can:add_production')->name('production.add');
    Route::get('/edit/{id}', [ProductionController::class, 'edit'])->middleware('can:edit_production')->name('production.edit');
    Route::get('/delete/{id}', [ProductionController::class, 'delete'])->middleware('can:delete_production')->name('production.delete');
    Route::get('/list', [ProductionController::class, 'index'])->middleware('can:list_production')->name('production.index');
    Route::post('/store-process', [ProductionController::class, 'store'])->middleware('can:add_production')->name('production.store');
    Route::post('/update/{id}', [ProductionController::class, 'update'])->middleware('can:edit_production')->name('production.update');
    Route::get('/show/{id}', [ProductionController::class, 'show'])->middleware('can:list_production')->name('production.show');


    Route::post('/product-process-purchase', [ProductionController::class, 'startProduction'])->middleware('can:list_production')->name('productions.startProduction');

    Route::post('/productions/update-quantity/{id}', [ProductionController::class, 'updateQuantity'])->middleware('can:list_production')->name('productions.updateQuantity');

    Route::post('/factory/delivery', [ProductionController::class, 'factoryDelivery'])->middleware('can:list_production')->name('factory.delivery');

    Route::get('/delivery', [ProductionController::class, 'delivery'])->middleware('can:list_production')->name('production.delivery');

    Route::get('/purchase-order/preview/{id}', [ProductionController::class, 'previewPDF'])->middleware('can:list_production')->name('purchase-order.preview');
  });



  /* Module Vật Tư Sản Xuất*/

  Route::prefix('/admin/material')->group(function () {
    Route::get('/add', [MaterialController::class, 'add'])->middleware('can:add_material')->name('material.add'); /* Vật tư theo sản phẩm */
    Route::get('/list', [MaterialController::class, 'index'])->middleware('can:list_material')->name('material.index');
    Route::post('/save', [MaterialController::class, 'save'])->middleware('can:add_material')->name('materials.store');
    Route::get('/edit/{id}', [MaterialController::class, 'edit'])->middleware('can:update_material')->name('material.edit');
    Route::get('/delete/{id}', [MaterialController::class, 'delete'])->middleware('can:delete_material')->name('material.delete');
    Route::post('/update/{id}', [MaterialController::class, 'update'])->middleware('can:update_material')->name('material.update');

    Route::get('/view-import-excel', [MaterialController::class, 'importExcel'])->middleware('can:import_export_material')->name('material.import_excel');
    Route::post('/uploadPreview', [MaterialController::class, 'uploadPreview'])->middleware('can:import_export_material')->name('material.upload.FileExcel');
    Route::post('/ImportFileExcel', [MaterialController::class, 'ImportFileExcel'])->middleware('can:import_export_material')->name('material.upload.ImportFileExcel');

    Route::get('/export-material', [MaterialController::class, 'export'])->middleware('can:import_export_material')->name('material.export');

    Route::get('/get-sizes-by-tier', [MaterialController::class, 'getSizesByTier'])->middleware('can:import_export_material')->name('sizes.by.tier');
    Route::get('/styles/by-tier-size', [MaterialController::class, 'getStylesByTierAndSize'])->middleware('can:import_export_material')->name('styles.by.tier.size');
    Route::get('/get-colors-by-tier-and-size', [MaterialController::class, 'getColorsByTierAndSize'])->middleware('can:import_export_material')->name('colors.by.tier.size.style');
    Route::get('/get-products', [MaterialController::class, 'getProducts'])->middleware('can:import_export_material')->name('products.filtered');

    Route::post('/get-materials', [MaterialController::class, 'getMaterials'])->middleware('can:import_export_material')->name('materials.get');

    Route::get('/list-material-product', [MaterialController::class, 'listMaterialProduct'])->middleware('can:import_export_material')->name('listMaterialProduct');

    Route::post('/materials/update', [MaterialController::class, 'updateMaterials'])->name('materials.update');

    /*  */
    Route::get('/view-import-excel-list-material-product', [MaterialController::class, 'viewImportExcelListMaterial'])->middleware('can:import_export_material')->name('importExcelListMaterial');
    Route::post('/uploadPreviewListMaterialProduct', [MaterialController::class, 'uploadPreviewListMaterialProduct'])->middleware('can:import_export_material')->name('material.uploadPreviewListMaterialProduct');
    Route::post('/ImportFileExcelListMaterialProduct', [MaterialController::class, 'ImportFileExcelListMaterialProduct'])->middleware('can:import_export_material')->name('material.ImportFileExcelListMaterialProduct');

    // Route::get('/exportExcelListMaterial', function (Request $request) {
    //   return Excel::download(new MaterialsForProductsExport($request->all()), 'materials.xlsx');
    // })->name('exportExcelListMaterial');

  });
  Route::get('/exportExcelListMaterial', [MaterialController::class, 'exportExcel'])->middleware('can:import_export_material')->name('exportExcelListMaterial');

  Route::get('/materials/filter', [MaterialController::class, 'filter'])->name('materials.filter');


  /* Module Giao Hàng Nhận Hàng */
  Route::prefix('/admin/delivery')->group(function () {
    Route::get('/index', [DeliveryController::class, 'index'])->middleware('can:list_delivery')->name('delivery.index');
    Route::get('/show', [DeliveryController::class, 'show'])->middleware('can:list_delivery')->name('delivery.show');
    Route::post('/order-ship', [DeliveryController::class, 'orderShip'])->middleware('can:process_delivery')->name('order.ship');
    Route::post('/process-order-ship', [DeliveryController::class, 'processOrder'])->middleware('can:process_delivery')->name('processOrder');
    Route::get('/show-delivery', [DeliveryController::class, 'showdelivery'])->middleware('can:list_delivery')->name('delivery.showdelivery');
    Route::get('/order-received', [DeliveryController::class, 'orderReceived'])->middleware('can:list_delivery')->name('delivery.orderReceived');
    Route::get('/export-orders', [DeliveryController::class, 'exportOrders'])->middleware('can:export_excel_delivery')->name('export.orders');
  });

  /* Module Task */

  Route::prefix('/admin/task')->group(function () {

    Route::get('/tasks', [TaskController::class, 'index'])->name('tasks.index');
    Route::get('/tasks/create', [TaskController::class, 'create'])->name('tasks.create');
    Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
  });


  /* Module Ghi Chú */
  Route::prefix('/admin/note')->group(function () {

    Route::get('/index', [NoteController::class, 'index'])->name('notes.index');
    Route::get('/create', [NoteController::class, 'create'])->name('notes.create');
    Route::get('/edit/{id}', [NoteController::class, 'edit'])->name('notes.editNote');
    Route::post('/store', [NoteController::class, 'store'])->name('notes.store');
    Route::get('/delete{id}', [NoteController::class, 'delete'])->name('notes.delete');
    Route::post('/update/{id}', [NoteController::class, 'update'])->name('notes.update');
    Route::get('/google-sheet', [NoteController::class, 'googlesheet'])->name('notes.googlesheet');
  });


  /* Module quản lý nhân viên kho*/

  Route::prefix('/admin/warehousing-manager')->group(function () {
    Route::get('/create', [WarehousingManagerController::class, 'create'])->middleware('can:add_employee')->name('warehousingmanager.create');
    Route::get('/index', [WarehousingManagerController::class, 'index'])->middleware('can:list_employee')->name('warehousingmanager.index');
    Route::get('/edit/{id}', [WarehousingManagerController::class, 'edit'])->middleware('can:update_employee')->name('warehousingmanager.edit');
    Route::get('/delete/{id}', [WarehousingManagerController::class, 'delete'])->middleware('can:delete_employee')->name('warehousingmanager.delete');
    Route::post('/save', [WarehousingManagerController::class, 'save'])->middleware('can:add_employee')->name('warehousingmanager.save');
    Route::post('/update/{id}', [WarehousingManagerController::class, 'update'])->middleware('can:update_employee')->name('warehousingmanager.update');
  });


  /* Nhân Viên Thu Mua */

  Route::prefix('/admin/purchaser')->group(function () {
    Route::get('/create', [PurchasingManagerController::class, 'create'])->middleware('can:add_employee')->name('purchaser.create');
    Route::get('/index', [PurchasingManagerController::class, 'index'])->middleware('can:list_employee')->name('purchaser.index');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'edit'])->middleware('can:update_employee')->name('purchaser.edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'delete'])->middleware('can:delete_employee')->name('purchaser.delete');
    Route::post('/save', [PurchasingManagerController::class, 'save'])->middleware('can:add_employee')->name('purchaser.save');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'update'])->middleware('can:update_employee')->name('purchaser.update');

    Route::get('/view/{id}', [PurchasingManagerController::class, 'view'])->middleware('can:list_employee')->name('purchaser.view');
  });


  /* Nhân Viên Dự Toán */
  Route::prefix('/admin/fore-cast-manager')->group(function () {
    Route::get('/create', [ForecastManagerController::class, 'create'])->middleware('can:add_employee')->name('forecaster.create');
    Route::get('/index', [ForecastManagerController::class, 'index'])->middleware('can:list_employee')->name('forecaster.index');
    Route::get('/edit/{id}', [ForecastManagerController::class, 'edit'])->middleware('can:update_employee')->name('forecaster.edit');
    Route::get('/delete/{id}', [ForecastManagerController::class, 'delete'])->middleware('can:delete_employee')->name('forecaster.delete');
    Route::post('/save', [ForecastManagerController::class, 'save'])->middleware('can:add_employee')->name('forecaster.save');
    Route::post('/update/{id}', [ForecastManagerController::class, 'update'])->middleware('can:update_employee')->name('forecaster.update');
  });






  /* Module sử chữa | Bảo Hành */
  Route::prefix('/admin/repair_orders')->group(function () {
    Route::get('/index', [RepairOrderController::class, 'index'])->name('repairorders.index');
    Route::get('/create', [RepairOrderController::class, 'create'])->name('repairorders.create');
    Route::get('/edit/{id}', [RepairOrderController::class, 'edit'])->name('repairorders.edit');
    Route::post('/store', [RepairOrderController::class, 'store'])->name('repairorders.store');
    Route::get('/delete{id}', [RepairOrderController::class, 'delete'])->name('repairorders.delete');
    Route::post('/update/{id}', [RepairOrderController::class, 'update'])->name('repairorders.update');
  });


  /* Module Order */

  Route::prefix('/admin/order')->group(function () {

    /* Chưa triển khai */
    Route::get('/index', [OrderController::class, 'index'])->middleware('can:add_order')->name('order.index');
    Route::get('/order-preview', [OrderController::class, 'preview'])->middleware('can:add_order')->name('orders.preview');
    Route::get('/edit/{id}', [OrderController::class, 'edit'])->middleware('can:add_order')->name('order.edit');
    Route::get('/delete/{id}', [OrderController::class, 'delete'])->middleware('can:add_order')->name('order.delete');
    Route::post('/save', [OrderController::class, 'save'])->middleware('can:add_order')->name('order.save');
    Route::post('/update/{id}', [OrderController::class, 'update'])->middleware('can:add_order')->name('order.update');
    Route::post('/orders/process', [OrderController::class, 'process'])->middleware('can:add_order')->name('orders.process');


    /* Đang triển khai */

    /* Route tạo order purchase */
    Route::get('/import', [OrderController::class, 'import'])->middleware('can:add_order')->name('orders.import');
    /* preview order purchase */
    Route::post('/preview-ajax', [OrderController::class, 'previewAjax'])->middleware('can:process_order')->name('orders.preview.ajax');


    Route::post('/get-supplier-deposit', [OrderController::class, 'getDeposit'])->name('orders.getDeposit');

    /* Preview File Excel */
    Route::post('/preview-order-ajax', [OrderController::class, 'previewOrder'])->middleware('can:process_order')->name('orders.previewOrder.ajax');
    //  Preview File PDF Đơn đặt hàng
    Route::get('/export-pdf', [OrderController::class, 'exportPdf'])->middleware('can:process_order')->name('orders.export.pdf');

    /* Tạo mới 1 đơn mua hàng  */
    Route::post('/orderCreateNew', [OrderController::class, 'orderCreateNew'])->middleware('can:process_order')->name('orders.createNew');
    /* Danh sách đơn hàng theo user */
    Route::get('/user', [OrderController::class, 'getOrdersByUser'])->middleware('can:detail_order')->name('orders.getOrdersByUser');
    Route::get('/user/{status?}', [OrderController::class, 'getOrdersByUser'])->name('orders.getOrdersByUser');
    /* Chi tiết đơn hàng */
    Route::get('/detail-order/{id}', [OrderController::class, 'detailOrder'])->middleware('can:detail_order')->name('detailOrder');
    Route::get('/delete-detail-order/{id}', [OrderController::class, 'deleteDetailOrder'])->middleware('can:detail_order')->name('deleteDetailOrder');
    /* Cập nhật thông tin của đơn hàng  tách load ( detail) */
    Route::post('/updateOrderDetail', [OrderController::class, 'updateOrderDetail'])->middleware('can:update_order')->name('updateOrderDetail');
    Route::post('/update-order', [OrderController::class, 'updateOrder'])->middleware('can:update_order')->name('update.order');
    /* Cập nhật trạng thái đơn hàng */
    Route::get('/update-status-order', [OrderController::class, 'updateStatusOrder'])->middleware('can:update_order')->name('updateStatusOrder');
    /* Kiểm tra tư động đơn hàng */
    Route::get('/check-date-order', [OrderController::class, 'checkDateOrder'])->middleware('can:check_auto_order')->name('checkDateOrder');


    Route::post('/order-deposit-confirm', [OrderController::class, 'confirmDeposit'])->name('order.deposit.confirm');

    Route::post('/order-payment-confirm', [OrderController::class, 'orderPayment'])->name('order.payment.confirm');

    Route::post('/import-costs', [OrderController::class, 'importCosts'])->name('import.costs.store');


    Route::post('/update-payment-history', [OrderController::class, 'updatePaymentHistory'])->name('updatePaymentHistoryAjax');

    Route::post('/update-import-cost', [OrderController::class, 'updateImportCost'])->name('updateImportCostAjax');
    Route::post('/delete-import-cost', [OrderController::class, 'deleteImportCost'])->name('deleteImportCostAjax');
    Route::post('/delete-all-import-costs', [OrderController::class, 'deleteAllImportCost'])->name('deleteAllImportCostsAjax');

    Route::post('/order/add-product', [OrderController::class, 'addProduct'])->name('order.add.product');
    Route::get('/product/search', [OrderController::class, 'search'])->name('product.search');


    /* Chức năng lịch hiển thị dự kiến sản xuất dự kiến hàng về thực tế */

    Route::get('/calendar', [OrderController::class, 'calendar'])->name('order.calendar');
  });


  /* Notification */
  Route::prefix('/admin/notification')->group(function () {
    Route::get('/index', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('/{id}/mark-as-read', [NotificationController::class, 'markAsRead'])->name('notifications.markAsRead');
    Route::post('/delete/{id}', [NotificationController::class, 'destroy'])->name('notifications.destroy');
  });

  /* Partners */

  Route::prefix('/admin/partner')->group(function () {
    Route::get('/create', [PartnerController::class, 'create'])->name('partners.create');
    Route::get('/index', [PartnerController::class, 'index'])->name('partners.index');
    Route::get('/show/{id}', [PartnerController::class, 'show'])->name('partners.show');

    Route::get('/edit/{id}', [PartnerController::class, 'edit'])->name('partners.edit');
    Route::get('/delete/{id}', [PartnerController::class, 'delete'])->name('partners.delete');
    Route::post('/save', [PartnerController::class, 'store'])->name('partners.store');
    Route::post('/update/{id}', [PartnerController::class, 'update'])->name('partners.update');
  });


  /* Shipments */

  Route::prefix('/admin/shipments')->group(function () {
    Route::get('/create', [ShipmentController::class, 'create'])->name('shipments.create');
    Route::get('/index', [ShipmentController::class, 'index'])->name('shipments.index');
    Route::get('/show/{id}', [ShipmentController::class, 'show'])->name('shipments.show');
    Route::get('/edit/{id}', [ShipmentController::class, 'edit'])->name('shipments.edit');
    Route::get('/delete/{id}', [ShipmentController::class, 'delete'])->name('shipments.delete');
    Route::post('/save', [ShipmentController::class, 'store'])->name('shipments.store');
    Route::post('/update/{id}', [ShipmentController::class, 'update'])->name('shipments.update');
  });
  /* Containers */

  Route::prefix('/admin/container')->group(function () {
    Route::get('/create', [ContainerController::class, 'create'])->name('containers.create');
    Route::get('/index', [ContainerController::class, 'index'])->name('containers.index');
    Route::get('/show/{id}', [ContainerController::class, 'show'])->name('containers.show');
    Route::get('/edit/{id}', [ContainerController::class, 'edit'])->name('containers.edit');
    Route::get('/delete/{id}', [ContainerController::class, 'delete'])->name('containers.delete');
    Route::post('/save', [ContainerController::class, 'store'])->name('containers.store');
    Route::post('/update/{id}', [ContainerController::class, 'update'])->name('containers.update');
  });
  /* Customs Clearance */

  Route::prefix('/admin/customs_clearance')->group(function () {
    Route::get('/create', [CustomsClearanceController::class, 'create'])->name('customs_clearance.create');
    Route::get('/index', [CustomsClearanceController::class, 'index'])->name('customs_clearance.index');
    Route::get('/show/{id}', [CustomsClearanceController::class, 'show'])->name('customs_clearance.show');
    Route::get('/edit/{id}', [CustomsClearanceController::class, 'edit'])->name('customs_clearance.edit');
    Route::get('/delete/{id}', [CustomsClearanceController::class, 'delete'])->name('customs_clearance.delete');
    Route::post('/save', [CustomsClearanceController::class, 'store'])->name('customs_clearance.store');
    Route::post('/update/{id}', [CustomsClearanceController::class, 'update'])->name('customs_clearance.update');
  });

  Route::get('/admin/all-admin-approve', [AdminController::class, 'adminApprove'])->middleware('can:add_post')->name('adminApprove');

  Route::get('layout-test', function (Request $request) {
    return view('layouts.layout_factory');
  });


  /* Hàng Tồn Kho */

  Route::prefix('warehouse')->name('warehouse.')->group(function () {
    Route::get('/', [WarehouseController::class, 'index'])->name('index');
    Route::post('/confirm/{id}', [WarehouseController::class, 'confirmDraft'])->name('confirmDraft');
    Route::post('/confirm-all', [WarehouseController::class, 'confirmAll'])->name('confirmAll');
    Route::get('/history', [WarehouseController::class, 'historyIndex'])->name('historyIndex');
  });


  /* MODULE DỰ ĐOÁN */
  // SẢN PHẨM

  Route::prefix('forecast-product')->name('forecastProduct.')->group(function () {
    Route::get('/', [ForecastProductController::class, 'index'])->name('index');
    Route::get('/view-import-excel', [ForecastProductController::class, 'importExcel'])->middleware('can:import_export_material')->name('import_excel');
    Route::post('/uploadPreview', [ForecastProductController::class, 'uploadPreview'])->middleware('can:import_export_material')->name('uploadPreview');
    Route::post('/ImportFileExcel', [ForecastProductController::class, 'ImportFileExcel'])->middleware('can:import_export_material')->name('ImportFileExcel');
    Route::get('/export-material', [ForecastProductController::class, 'export'])->middleware('can:import_export_material')->name('export');
    Route::get('/update-status/{id}', [ForecastProductController::class, 'updateStatus'])->name('updateStatus');
    Route::get('/edit/{id}', [ForecastProductController::class, 'edit'])->name('edit');
    Route::post('/update/{id}', [ForecastProductController::class, 'update'])->name('update');
  });


  /* Nhân Viên Thu Mua */


  /* Module 1 Quản Lý Thông Tin Nhà Cung Cấp */

  Route::prefix('supplier-management')->name('supplierManagement.')->group(function () {
    Route::get('/', [PurchasingManagerController::class, 'listSupplier'])->name('index');
    Route::get('/create', [PurchasingManagerController::class, 'createSupplier'])->name('add');
    Route::post('/save', [PurchasingManagerController::class, 'saveSupplier'])->name('store');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'editSupplier'])->name('edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'deleteSupplier'])->name('delete');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'updateSupplier'])->name('update');
    Route::get('/view-import-excel', [PurchasingManagerController::class, 'importExcel'])->name('import');
    Route::post('/uploadPreview', [PurchasingManagerController::class, 'uploadPreview'])->name('FileExcel');
    Route::post('/ImportFileExcel', [PurchasingManagerController::class, 'ImportFileExcel'])->name('ImportFileExcel');
  });

  /* Module 2 Quản Lý Sản Phẩm */

  Route::prefix('products-management')->name('productManagement.')->group(function () {
    Route::get('/', [PurchasingManagerController::class, 'listProduct'])->name('index');
    Route::get('/create', [PurchasingManagerController::class, 'createProduct'])->name('add');
    Route::post('/save', [PurchasingManagerController::class, 'saveProduct'])->name('store');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'editProduct'])->name('edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'deleteProduct'])->name('delete');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'updateProduct'])->name('updateProduct');

    /* Ajax lấy dữ liệu của product_variant theo category select */
    Route::get('/get-variants-by-category', [PurchasingManagerController::class, 'getVariantsByCategory'])->name('getVariantsByCategory');

    Route::get('/get-models-by-variant', [PurchasingManagerController::class, 'getModelsByVariant'])->name('getModelsByVariant');

    /* Ai tư vấn  */
    Route::post('/process-ai', [PurchasingManagerController::class, 'processAi'])->name('processAi');

    Route::post('/chat/create-session', [PurchasingManagerController::class, 'createSession'])->name('create-session');

    Route::post('/chat/save-message', [PurchasingManagerController::class, 'saveMessage'])->name('save-message');
  });



  /* Module Quản lý Mẫu ( Phân Loại ) Sản Phẩm */
  Route::prefix('product-variants-management')->name('product-variants.')->group(function () {
    Route::get('/', [PurchasingManagerController::class, 'listProductVariants'])->name('index');
    Route::get('/create', [PurchasingManagerController::class, 'createProductVariants'])->name('create');
    Route::post('/save', [PurchasingManagerController::class, 'saveProductVariants'])->name('save');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'editProductVariants'])->name('edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'deleteProductVariants'])->name('delete');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'updateProductVariants'])->name('update');
  });


  /* Model Version */
  /* Module Quản lý Mẫu ( Phân Loại ) Sản Phẩm */
  Route::prefix('model-version')->name('model-versions.')->group(function () {
    Route::get('/', [PurchasingManagerController::class, 'listModelVersion'])->name('index');
    Route::get('/create', [PurchasingManagerController::class, 'createModelVersion'])->name('create');
    Route::post('/save', [PurchasingManagerController::class, 'saveModelVersion'])->name('save');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'editModelVersion'])->name('edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'deleteModelVersion'])->name('delete');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'updateModelVersion'])->name('update');
  });




  /* Nhập Hàng */

  Route::prefix('purchase-orders-management')->name('purchaseOrdersManagement.')->group(function () {
    Route::get('/', [WarehouseController::class, 'listOrder'])->name('index');
    Route::get('/create', [WarehouseController::class, 'createOrder'])->name('add');
    // Route::post('/save', [PurchasingManagerController::class, 'saveProduct'])->name('store');
    Route::get('/edit/{id}', [PurchasingManagerController::class, 'editProduct'])->name('edit');
    Route::get('/delete/{id}', [PurchasingManagerController::class, 'deleteSupplier'])->name('delete');
    Route::post('/update/{id}', [PurchasingManagerController::class, 'updateProduct'])->name('updateProduct');
    Route::post('/save-supplier', [PurchasingManagerController::class, 'storeSupplier'])->name('supplierSave');
    Route::get('/suppliers/details', [PurchasingManagerController::class, 'getDetailSupplier'])->name('getDetailSupplier');
  });


  Route::get('/purchaser/search-products', [WarehouseController::class, 'searchProducts'])->name('purchaser.search-products');

  /* Quản Lý File */

  Route::get('/folder-manager', [PurchasingManagerController::class, 'folderManager'])->name('folderManager');



  // Route::prefix('file-storage')->name('file-storage.')->group(function () {
  //   Route::get('/', [FileStorageController::class, 'index'])->name('index');
  //   Route::get('/folder/{path?}', [FileStorageController::class, 'folder'])->name('folder');
  //   Route::post('/create-folder', [FileStorageController::class, 'createFolder'])->name('create-folder');
  //   Route::post('/upload', [FileStorageController::class, 'upload'])->name('upload');
  //   Route::post('/create-file', [FileStorageController::class, 'createFile'])->name('create-file');
  //   Route::delete('/delete', [FileStorageController::class, 'delete'])->name('delete');
  //   Route::get('/preview/{id}', [FileStorageController::class, 'preview'])->name('preview');
  //   Route::get('/download/{id}', [FileStorageController::class, 'download'])->name('download');
  // });




  // File Storage Routes
  Route::prefix('file-storage')->name('file-storage.')->group(function () {
    Route::get('/', [FileStorageController::class, 'index'])->name('index');
    Route::get('folder/{path?}', [FileStorageController::class, 'folder'])->name('folder');
    Route::post('create-folder', [FileStorageController::class, 'createFolder'])->name('create-folder');
    Route::post('upload', [FileStorageController::class, 'upload'])->name('upload');
    Route::post('create-file', [FileStorageController::class, 'createFile'])->name('create-file');
    Route::post('delete', [FileStorageController::class, 'delete'])->name('delete');
    Route::get('preview/{id}', [FileStorageController::class, 'preview'])->name('preview');
    Route::get('download/{id}', [FileStorageController::class, 'download'])->name('download');

    // Advanced functionality routes
    Route::post('rename', [FileStorageController::class, 'rename'])->name('rename');
    Route::post('move', [FileStorageController::class, 'move'])->name('move');
    Route::post('share', [FileStorageController::class, 'share'])->name('share');
    Route::get('share/{token}', [FileStorageController::class, 'accessSharedFile'])->name('access-shared');
    Route::post('validate-share-password', [FileStorageController::class, 'validateSharePassword'])->name('validate-share-password');
  });
});

Route::post('/file-shares/update', [FileStorageController::class, 'updateFileShare'])
  ->name('file-shares.update')
  ->middleware('auth');




/* Frontend */
Route::get('/', [AdminController::class, 'dashboard']);







// Laravel Route
// Thêm vào file routes/web.php
Route::get('/quay-vong-may-man', function () {
  return view('lucky-wheel'); // Đảm bảo file lucky-wheel.blade.php được đặt trong thư mục resources/views
})->name('lucky-wheel');


Route::get('/phan-chia-truc-nhat', function () {
  return view('division_of_duty'); // Đảm bảo file lucky-wheel.blade.php được đặt trong thư mục resources/views
})->name('division_of_duty');
