@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1 class="mt-3">Danh sách Lô hàng</h1>
        <a href="{{ route('shipments.create') }}" class="btn btn-primary my-3">Thêm Lô hàng mới</a>

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <table class="table table-bordered" id="table1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Mã vận đơn</th>
                    <th>Khách hàng</th>
                    <th>Cảng đi</th>
                    <th>Cảng đến</th>
                    <th>Trạng thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($shipments as $shipment)
                    <tr>
                        <td>{{ $shipment->id }}</td>
                        <td>{{ $shipment->tracking_number }}</td>
                        <td>{{ $shipment->customer->name ?? 'N/A' }}</td>
                        <td>{{ $shipment->origin_port }}</td>
                        <td>{{ $shipment->destination_port }}</td>
                        <td>{{ $shipment->status }}</td>
                        <td>
                            <a href="{{ route('shipments.show', ['id' => $shipment->id]) }}"
                                class="btn btn-info btn-sm">Xem</a>
                            <a href="{{ route('shipments.edit', ['id' => $shipment->id]) }}"
                                class="btn btn-warning btn-sm">Sửa</a>
                            <a onclick="return confirm('Bạn có chắc muốn xóa?')"
                                href="{{ route('shipments.delete', ['id' => $shipment->id]) }}"
                                class="btn btn-danger btn-sm">Xoá</a>

                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

    
    </div>
@endsection
