@extends('layouts.admin')

@section('content')
    <style>
        /* Định dạng container chung */
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-top: 2rem;
        }

        /* Tùy chỉnh tiêu đề */
        h1 {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1.5rem;
            color: #333;
        }

        /* Custom Accordion */
        .accordion .card {
            border: none;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .accordion .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 1rem;
            border-bottom: none;
        }

        .accordion .card-header .btn-link {
            color: #fff;
            text-decoration: none;
            font-size: 1.125rem;
            font-weight: 500;
        }

        .accordion .card-body {
            background-color: #f8f9fa;
            padding: 1.5rem;
        }

        /* Form elements */
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #555;
        }

        .form-control {
            border-radius: 4px;
            box-shadow: none;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Button styles */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            font-weight: bold;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        /* Responsive spacing for form groups */
        .form-group {
            margin-bottom: 1.25rem;
        }
    </style>


    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif


    <div class="container">
        <h1 class="mb-4">Thêm Lô hàng mới</h1>
        <form action="{{ route('shipments.store') }}" method="POST">
            @csrf
            <div class="accordion" id="shipmentAccordion">
                <!-- Khối Thông tin cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic"
                                aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Mã vận đơn</label>
                                <input type="text" name="tracking_number" value="{{ old('tracking_number') }}"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Khách hàng</label>
                                <select name="customer_id" class="form-control" required>
                                    @foreach ($partners as $partner)
                                        @if ($partner->role == 'customer')
                                            <option value="{{ $partner->id }}">{{ $partner->name }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Cảng đi</label>
                                <input type="text" name="origin_port" value="{{ old('origin_port') }}"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Cảng đến</label>
                                <input type="text " name="destination_port" value="{{ old('destination_port') }}"
                                    class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin tàu & Lịch trình -->
                <div class="card">
                    <div class="card-header" id="headingVessel">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseVessel" aria-expanded="false" aria-controls="collapseVessel">
                                Thông tin tàu & lịch trình
                            </button>
                        </h2>
                    </div>
                    <div id="collapseVessel" class="collapse" aria-labelledby="headingVessel"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Tên Tàu</label>
                                <input type="text" name="vessel_name" value="{{ old('vessel_name') }}"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Số Chuyến Đi</label>
                                <input type="text" name="voyage_number" value="{{ old('voyage_number') }}"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Ngày khởi hành</label>
                                <input type="date" name="departure_date" value="{{ old('departure_date') }}"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label>ETA (Ngày đến dự kiến)</label>
                                <input type="date" name="estimated_arrival" value="{{ old('estimated_arrival') }}"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Ngày đến thực tế</label>
                                <input type="date" name="actual_arrival" value="{{ old('actual_arrival') }}"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Trạng thái</label>
                                <select name="status" class="form-control" required>
                                    <option value="Đang xử lý">Đang xử lý</option>
                                    <option value="Đang vận chuyển">Đang vận chuyển</option>
                                    <option value="Đã đến cảng">Đã đến cảng</option>
                                    <option value="Thông quan">Thông quan</option>
                                    <option value="Giao hàng thành công">Giao hàng thành công</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Loại lô hàng</label>
                                <select name="shipment_type" class="form-control" required>
                                    <option value="FCL">FCL (Full Container Load)</option>
                                    <option value="LCL">LCL (Less than Container Load)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin hàng hóa -->
                <div class="card">
                    <div class="card-header" id="headingCargo">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseCargo" aria-expanded="false" aria-controls="collapseCargo">
                                Thông tin hàng hóa
                            </button>
                        </h2>
                    </div>
                    <div id="collapseCargo" class="collapse" aria-labelledby="headingCargo"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Mô tả hàng hóa</label>
                                <textarea  name="cargo_description" value="{{ old('cargo_description') }}" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Tổng trọng lượng (kg)</label>
                                <input type="number" value="{{ old('total_weight') }}" step="0.01"
                                    name="total_weight" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Tổng thể tích (m3)</label>
                                <input type="number" value="{{ old('total_volume') }}" step="0.01"
                                    name="total_volume" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success mt-3">Tạo Lô hàng</button>
        </form>
    </div>
@endsection
