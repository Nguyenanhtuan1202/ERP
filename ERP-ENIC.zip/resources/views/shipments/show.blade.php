@extends('layouts.admin')

@section('content')
<style>
    /* Container chính */
    .shipment-container {
        max-width: 100%;
        margin: 2rem auto;
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    /* Tiêu đề */
    .shipment-title {
        text-align: center;
        font-size: 2rem;
        font-weight: bold;
        margin-bottom: 30px;
        color: #333;
    }

    /* Grid layout cho thông tin */
    .shipment-card {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    /* Các khối thông tin */
    .shipment-item {
        background: #f7f7f7;
        padding: 15px;
        border-radius: 5px;
        border-left: 4px solid #007bff;
        transition: transform 0.2s;
    }

    .shipment-item:hover {
        transform: translateY(-3px);
    }

    .shipment-item strong {
        display: block;
        margin-bottom: 5px;
        color: #555;
        font-size: 0.9rem;
    }

    .shipment-item p {
        margin: 0;
        font-size: 1rem;
        color: #333;
    }

    /* Hành động */
    .shipment-actions {
        margin-top: 30px;
        text-align: center;
    }

    .shipment-actions a {
        margin: 0 10px;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        transition: background 0.2s;
    }

    .btn-warning {
        background: #ffc107;
        color: #fff;
    }

    .btn-warning:hover {
        background: #e0a800;
    }

    .btn-secondary {
        background: #6c757d;
        color: #fff;
    }

    .btn-secondary:hover {
        background: #5a6268;
    }

    @media (max-width: 576px) {
        .shipment-card {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="shipment-container">
    <h1 class="shipment-title">Chi tiết Lô hàng</h1>
    <div class="shipment-card">
        <div class="shipment-item">
            <strong>Mã vận đơn:</strong>
            <p>{{ $shipment->tracking_number ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Khách hàng:</strong>
            <p>{{ $shipment->customer->name ?? 'N/A' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Cảng đi:</strong>
            <p>{{ $shipment->origin_port ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Cảng đến:</strong>
            <p>{{ $shipment->destination_port ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Tên Tàu:</strong>
            <p>{{ $shipment->vessel_name ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Số Chuyến Đi:</strong>
            <p>{{ $shipment->voyage_number ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Ngày khởi hành:</strong>
            <p>{{ $shipment->departure_date ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>ETA:</strong>
            <p>{{ $shipment->estimated_arrival ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Ngày đến thực tế:</strong>
            <p>{{ $shipment->actual_arrival ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Trạng thái:</strong>
            <p>{{ $shipment->status ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Loại lô hàng:</strong>
            <p>{{ $shipment->shipment_type ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Mô tả hàng hóa:</strong>
            <p>{{ $shipment->cargo_description ?? '' }}</p>
        </div>
        <div class="shipment-item">
            <strong>Tổng trọng lượng:</strong>
            <p>{{ $shipment->total_weight ?? '' }} kg</p>
        </div>
        <div class="shipment-item">
            <strong>Tổng thể tích:</strong>
            <p>{{ $shipment->total_volume ?? '' }} m<sup>3</sup></p>
        </div>
    </div>
    <div class="shipment-actions">
        <a href="{{ route('shipments.edit', ['id' => $shipment->id]) }}" class="btn btn-warning">Chỉnh sửa</a>
        <a href="{{ route('shipments.index') }}" class="btn btn-secondary">Quay lại</a>
    </div>
</div>
@endsection
