@extends('layouts.admin')

@section('content')
    <style>
        /* Định dạng container chung */
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-top: 2rem;
        }

        /* Tùy chỉnh tiêu đề */
        h1 {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1.5rem;
            color: #333;
        }

        /* Custom Accordion */
        .accordion .card {
            border: none;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .accordion .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 1rem;
            border-bottom: none;
        }

        .accordion .card-header .btn-link {
            color: #fff;
            text-decoration: none;
            font-size: 1.125rem;
            font-weight: 500;
        }

        .accordion .card-body {
            background-color: #f8f9fa;
            padding: 1.5rem;
        }

        /* Form elements */
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #555;
        }

        .form-control {
            border-radius: 4px;
            box-shadow: none;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Button styles */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            font-weight: bold;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
        }

        .btn-primary
        {
          background-color: #0f74a0;
            border-color: #0f74a0;
            font-weight: bold;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        /* Responsive spacing for form groups */
        .form-group {
            margin-bottom: 1.25rem;
        }
    </style>

    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif
    <div class="container">
        <h1 class="mb-4">Chỉnh sửa Lô hàng</h1>
        <form action="{{ route('shipments.update', ['id' => $shipment->id]) }}" method="POST">
            @csrf
            <div class="accordion" id="shipmentAccordion">
                <!-- Khối Thông tin cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic"
                                aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Mã vận đơn</label>
                                <input type="text" name="tracking_number" class="form-control"
                                    value="{{ old('tracking_number', $shipment->tracking_number ?? "") }}" required>
                            </div>
                            <div class="form-group">
                                <label>Khách hàng</label>
                                <select name="customer_id" class="form-control" required>
                                    @foreach ($customers as $customer)
                                        <option value="{{ $customer->id }}"
                                            {{ $shipment->customer_id == $customer->id ? 'selected' : '' }}>
                                            {{ $customer->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Cảng đi</label>
                                <input type="text" name="origin_port" class="form-control"
                                    value="{{ old('origin_port', $shipment->origin_port ?? "") }}" required>
                            </div>
                            <div class="form-group">
                                <label>Cảng đến</label>
                                <input type="text" name="destination_port" class="form-control"
                                    value="{{ old('destination_port', $shipment->destination_port ?? "") }}" required>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin tàu & lịch trình -->
                <div class="card">
                    <div class="card-header" id="headingVessel">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseVessel" aria-expanded="false" aria-controls="collapseVessel">
                                Thông tin tàu & lịch trình
                            </button>
                        </h2>
                    </div>
                    <div id="collapseVessel" class="collapse" aria-labelledby="headingVessel"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Tên Tàu</label>
                                <input type="text" name="vessel_name" class="form-control"
                                    value="{{ old('vessel_name', $shipment->vessel_name ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>Số Chuyến Đi</label>
                                <input type="text" name="voyage_number" class="form-control"
                                    value="{{ old('voyage_number', $shipment->voyage_number ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>Ngày khởi hành</label>
                                <input type="date" name="departure_date" class="form-control"
                                    value="{{ old('departure_date', $shipment->departure_date ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>ETA (Ngày đến dự kiến)</label>
                                <input type="date" name="estimated_arrival" class="form-control"
                                    value="{{ old('estimated_arrival', $shipment->estimated_arrival ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>Ngày đến thực tế</label>
                                <input type="date" name="actual_arrival" class="form-control"
                                    value="{{ old('actual_arrival', $shipment->actual_arrival ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>Trạng thái</label>
                                <select name="status" class="form-control" required>
                                    <option value="Đang xử lý" {{ $shipment->status == 'Đang xử lý' ? 'selected' : '' }}>
                                        Đang
                                        xử lý</option>
                                    <option value="Đang vận chuyển"
                                        {{ $shipment->status == 'Đang vận chuyển' ? 'selected' : '' }}>Đang vận chuyển
                                    </option>
                                    <option value="Đã đến cảng" {{ $shipment->status == 'Đã đến cảng' ? 'selected' : '' }}>
                                        Đã
                                        đến cảng</option>
                                    <option value="Thông quan" {{ $shipment->status == 'Thông quan' ? 'selected' : '' }}>
                                        Thông quan</option>
                                    <option value="Giao hàng thành công"
                                        {{ $shipment->status == 'Giao hàng thành công' ? 'selected' : '' }}>Giao hàng thành
                                        công</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Loại lô hàng</label>
                                <select name="shipment_type" class="form-control" required>
                                    <option value="FCL" {{ $shipment->shipment_type == 'FCL' ? 'selected' : '' }}>FCL
                                        (Full Container Load)</option>
                                    <option value="LCL" {{ $shipment->shipment_type == 'LCL' ? 'selected' : '' }}>LCL
                                        (Less than Container Load)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin hàng hóa -->
                <div class="card">
                    <div class="card-header" id="headingCargo">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseCargo" aria-expanded="false" aria-controls="collapseCargo">
                                Thông tin hàng hóa
                            </button>
                        </h2>
                    </div>
                    <div id="collapseCargo" class="collapse" aria-labelledby="headingCargo"
                        data-parent="#shipmentAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Mô tả hàng hóa</label>
                                <textarea name="cargo_description" class="form-control">{{ old('cargo_description', $shipment->cargo_description ?? "") }}</textarea>
                            </div>
                            <div class="form-group">
                                <label>Tổng trọng lượng (kg)</label>
                                <input type="number" step="0.01" name="total_weight" class="form-control"
                                    value="{{ old('total_weight', $shipment->total_weight ?? "") }}">
                            </div>
                            <div class="form-group">
                                <label>Tổng thể tích (m3)</label>
                                <input type="number" step="0.01" name="total_volume" class="form-control"
                                    value="{{ old('total_volume', $shipment->total_volume ?? "") }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success mt-3">Cập nhật Lô hàng</button>
            <a href="{{ route('shipments.show', ['id' => $shipment->id]) }}" class="btn btn-primary mt-3"> Xem Chi Tiết</a>
        </form>
    </div>
@endsection
