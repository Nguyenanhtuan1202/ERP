<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập - ERP ENIC</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        :root {
            --primary-color: #0CAF60;
            --secondary-color: #edb200;
            --text-color: #333;
            --light-bg: #f8f9fa;
            --white: #ffffff;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--light-bg);
        }

        .container-fluid {
            padding: 0;
            margin: 0;
        }

        .box__custom {
            position: relative;
            display: flex;
            min-height: 100vh;
            background: linear-gradient(120deg, #f8f9fa 50%, var(--primary-color) 50%);
            overflow: hidden;
        }

        .left-panel,
        .right-panel {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            position: relative;
            z-index: 2;
        }

        .left-panel img,
        .right-panel img {
            max-width: 90%;
            height: auto;
            filter: drop-shadow(0 10px 15px rgba(0, 0, 0, 0.1));
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-15px);
            }

            100% {
                transform: translateY(0px);
            }
        }

        .center-panel {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 3;
        }

        .login-card {
            width: 100%;
            max-width: 450px;
            background: var(--white);
            border-radius: 20px;
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
        }

        .login-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: var(--secondary-color);
            padding: 25px 0;
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: "";
            position: absolute;
            width: 150%;
            height: 200%;
            background: rgba(255, 255, 255, 0.2);
            top: -100%;
            left: -25%;
            transform: rotate(35deg);
            transition: var(--transition);
        }

        .card-header:hover::before {
            transform: rotate(35deg) translateY(-20%);
        }

        .card-header p {
            color: var(--white);
            font-weight: 700;
            font-size: 28px;
            text-align: center;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .card-body {
            padding: 40px 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-size: 16px;
            font-weight: 600;
            color: var(--text-color);
        }

        .form-control {
            width: 100%;
            height: 55px;
            padding: 0 20px;
            font-size: 16px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            background-color: #f8f8f8 !important;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(237, 178, 0, 0.2);
        }

        .form-check {
            display: flex;
            align-items: center;
            margin-top: 5px;
        }

        .form-check-input {
            width: 18px;
            height: 18px;
            margin-right: 10px;
            cursor: pointer;
        }

        .form-check-label {
            font-size: 15px;
            cursor: pointer;
            user-select: none;
        }

        .btn-primary {
            display: inline-block;
            background: var(--secondary-color);
            color: white;
            font-weight: 600;
            font-size: 16px;
            padding: 12px 35px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 5px 15px rgba(237, 178, 0, 0.3);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-primary:hover {
            background: #d9a000;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(237, 178, 0, 0.4);
        }

        .btn-primary:active {
            transform: translateY(1px);
        }

        .invalid-feedback {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 5px;
            display: block;
        }

        .box__customright {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Responsive styles */
        @media (max-width: 992px) {
            .box__custom {
                flex-direction: column;
                background: var(--light-bg);
            }

            .left-panel {
                display: none;
            }

            .center-panel {
                order: 1;
                padding: 2rem 1rem;
            }

            .right-panel {
                display: none;
            }

            .login-card {
                max-width: 100%;
            }
        }

        /* Animation for background */
        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .animated-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(-45deg, #0CAF60, #089e52, #33c982, #089e52);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            z-index: 1;
            opacity: 0.8;
        }

        /* CSS cho canvas */
        #particleCanvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
        }

        /* Đảm bảo các phần tử UI nằm trên canvas */
        .row.justify-content-center.box__custom {
            position: relative;
            z-index: 1;
        }

        /* Thêm hiệu ứng cho form đăng nhập */
        .login-card {
            backdrop-filter: blur(5px);
            background-color: rgba(255, 255, 255, 0.85);
            transition: all 0.5s ease;
        }

        .login-card:hover {
            transform: translateY(-8px) scale(1.01);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
        }

        /* Hiệu ứng input focus nâng cao */
        .form-control {
            transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .form-control:focus {
            transform: scale(1.02);
        }

        /* Hiệu ứng nút nhấp nháy nhẹ */
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(237, 178, 0, 0.7);
            }

            70% {
                box-shadow: 0 0 0 10px rgba(237, 178, 0, 0);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(237, 178, 0, 0);
            }
        }

        .btn-primary {
            animation: pulse 2s infinite;
        }

        /* Thêm hiệu ứng loading */
        .loading-bar {
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            width: 0%;
            z-index: 1000;
            transition: width 0.4s ease;
        }

        /* Hiệu ứng cho hình ảnh */
        .left-panel img,
        .right-panel img {
            filter: drop-shadow(0 10px 15px rgba(0, 0, 0, 0.1));
            transition: all 0.5s ease;
        }

        .left-panel img:hover,
        .right-panel img:hover {
            filter: drop-shadow(0 15px 25px rgba(0, 0, 0, 0.2)) hue-rotate(15deg);
            transform: scale(1.05) translateY(-10px);
        }
    </style>
</head>

<body>
    <canvas id="particleCanvas"></canvas>
    <div class="container-fluid">
        <div class="row justify-content-center box__custom">
            <div class="animated-bg"></div>

            <div class="col-md-4 left-panel">
                <img src="{{ asset('erp/theme-1.svg') }}" alt="ERP ENIC Illustration">
            </div>

            <div class="col-md-4 center-panel">
                <div class="login-card">
                    <div class="card-header">
                        <p>ERP ENIC</p>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('login') }}">
                            {{ csrf_field() }}

                            <div class="form-group">
                                <label for="email">Nhập Email</label>
                                <input id="email" type="email"
                                    class="form-control @error('email') is-invalid @enderror" name="email"
                                    value="{{ old('email') }}" required autocomplete="email" autofocus
                                    placeholder="example@enic.com">
                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>Email hoặc mật khẩu không chính xác</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="password">Nhập {{ __('Password') }}</label>
                                <input id="password" type="password"
                                    class="form-control @error('password') is-invalid @enderror" name="password"
                                    required autocomplete="current-password" placeholder="••••••••">
                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                        {{ old('remember') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }} Đăng Nhập
                                    </label>
                                </div>
                            </div>

                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-4 right-panel">
                <img src="{{ asset('erp/theme-2.svg') }}" alt="ERP ENIC Features">
            </div>
        </div>
    </div>

    <script>
        // Hiệu ứng nút đăng nhập
        document.querySelector('.btn-primary').addEventListener('mouseover', function() {
            this.style.transform = 'translateY(-3px)';
        });

        document.querySelector('.btn-primary').addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });

        // Hiệu ứng input focus
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'translateY(-5px)';
                this.style.boxShadow = '0 0 0 3px rgba(237, 178, 0, 0.2)';
            });

            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });


        // Thêm thanh loading ở đầu trang
        const loadingBar = document.createElement('div');
        loadingBar.className = 'loading-bar';
        document.body.appendChild(loadingBar);

        // Hiệu ứng loading khi trang tải
        window.addEventListener('load', () => {
            setTimeout(() => {
                loadingBar.style.width = '100%';
                setTimeout(() => {
                    loadingBar.style.opacity = '0';
                }, 600);
            }, 10);
        });

        // Hiệu ứng hạt với Canvas
        (function setupParticles() {
            const canvas = document.getElementById('particleCanvas');
            const ctx = canvas.getContext('2d');

            // Đảm bảo canvas có kích thước đúng
            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }

            window.addEventListener('resize', resizeCanvas);
            resizeCanvas();

            // Thiết lập mảng hạt
            let particles = [];
            const particlesCount = Math.floor(window.innerWidth / 20); // Số lượng hạt phụ thuộc vào kích thước màn hình
            const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim();
            const secondaryColor = getComputedStyle(document.documentElement).getPropertyValue('--secondary-color')
                .trim();

            // Tạo màu rgba từ mã hex
            function hexToRgba(hex, alpha) {
                const r = parseInt(hex.slice(1, 3), 16);
                const g = parseInt(hex.slice(3, 5), 16);
                const b = parseInt(hex.slice(5, 7), 16);
                return `rgba(${r}, ${g}, ${b}, ${alpha})`;
            }

            // Dùng màu mặc định nếu không lấy được biến CSS
            const colors = [
                primaryColor.startsWith('#') ? primaryColor : '#0CAF60',
                secondaryColor.startsWith('#') ? secondaryColor : '#edb200'
            ];

            // Tạo hạt
            for (let i = 0; i < particlesCount; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 5 + 2,
                    color: colors[Math.floor(Math.random() * colors.length)],
                    speedX: Math.random() * 1 - 0.5,
                    speedY: Math.random() * 1 - 0.5,
                    opacity: Math.random() * 0.5 + 0.1
                });
            }

            // Cập nhật và vẽ hạt
            function drawParticles() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                particles.forEach(p => {
                    // Di chuyển hạt
                    p.x += p.speedX;
                    p.y += p.speedY;

                    // Nếu hạt ra khỏi màn hình, đưa về phía bên kia
                    if (p.x < 0) p.x = canvas.width;
                    if (p.x > canvas.width) p.x = 0;
                    if (p.y < 0) p.y = canvas.height;
                    if (p.y > canvas.height) p.y = 0;

                    // Vẽ hạt
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);

                    const rgbaColor = hexToRgba(p.color, p.opacity);
                    ctx.fillStyle = rgbaColor;
                    ctx.fill();
                });

                // Vẽ đường nối giữa các hạt gần nhau
                ctx.strokeStyle = hexToRgba(colors[0], 0.1);
                ctx.lineWidth = 0.5;

                for (let i = 0; i < particles.length; i++) {
                    for (let j = i + 1; j < particles.length; j++) {
                        const dx = particles[i].x - particles[j].x;
                        const dy = particles[i].y - particles[j].y;
                        const distance = Math.sqrt(dx * dx + dy * dy);

                        if (distance < 100) {
                            ctx.beginPath();
                            ctx.moveTo(particles[i].x, particles[i].y);
                            ctx.lineTo(particles[j].x, particles[j].y);
                            ctx.stroke();
                        }
                    }
                }

                requestAnimationFrame(drawParticles);
            }

            drawParticles();
        })();

        // Hiệu ứng hover 3D cho card đăng nhập
        document.querySelector('.login-card').addEventListener('mousemove', function(e) {
            const card = this;
            const cardRect = card.getBoundingClientRect();
            const cardCenterX = cardRect.left + cardRect.width / 2;
            const cardCenterY = cardRect.top + cardRect.height / 2;

            // Tính toán vị trí chuột tương đối với trung tâm card
            const mouseX = e.clientX - cardCenterX;
            const mouseY = e.clientY - cardCenterY;

            // Tính toán góc nghiêng
            const rotateY = 10 * mouseX / (cardRect.width / 2);
            const rotateX = -10 * mouseY / (cardRect.height / 2);

            // Áp dụng hiệu ứng
            card.style.transform =
                `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;

            // Hiệu ứng ánh sáng
            const shine =
                `radial-gradient(circle at ${e.clientX - cardRect.left}px ${e.clientY - cardRect.top}px, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 60%)`;
            card.style.backgroundImage = shine;
        });

        document.querySelector('.login-card').addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.backgroundImage = 'none';
        });

        // Hiệu ứng input đặc biệt
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                // Tạo ripple effect
                const parent = this.parentElement;
                const ripple = document.createElement('div');
                ripple.className = 'input-ripple';
                ripple.style.position = 'absolute';
                ripple.style.width = '20px';
                ripple.style.height = '20px';
                ripple.style.backgroundColor = 'rgba(237, 178, 0, 0.4)';
                ripple.style.borderRadius = '50%';
                ripple.style.transform = 'scale(0)';
                ripple.style.left = '10px';
                ripple.style.top = '50%';
                ripple.style.marginTop = '-10px';
                ripple.style.transition = 'all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)';

                parent.style.position = 'relative';
                parent.appendChild(ripple);

                setTimeout(() => {
                    ripple.style.transform = 'scale(20)';
                    ripple.style.opacity = '0';
                    setTimeout(() => {
                        parent.removeChild(ripple);
                    }, 600);
                }, 10);
            });
        });

        // Hiệu ứng typing cho tiêu đề
        document.addEventListener('DOMContentLoaded', function() {
            const headerText = document.querySelector('.card-header p');
            const originalText = headerText.innerText;
            headerText.innerText = '';

            let i = 0;
            const typingEffect = setInterval(() => {
                if (i < originalText.length) {
                    headerText.innerText += originalText.charAt(i);
                    i++;
                } else {
                    clearInterval(typingEffect);
                }
            }, 100);
        });

        // Hiệu ứng nút nhấn
        document.querySelector('.btn-primary').addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.95) translateY(2px)';
        });

        document.querySelector('.btn-primary').addEventListener('mouseup', function() {
            this.style.transform = 'scale(1) translateY(0)';
        });

        // Thêm hiệu ứng focus cho form khi click vào background
        document.addEventListener('click', function(e) {
            const loginCard = document.querySelector('.login-card');
            const isClickInside = loginCard.contains(e.target);

            if (!isClickInside) {
                // Click outside của form
                loginCard.classList.add('pulse-attention');
                setTimeout(() => {
                    loginCard.classList.remove('pulse-attention');
                }, 1000);
            }
        });

        // Thêm class định nghĩa css
        const style = document.createElement('style');
        style.textContent = `
  @keyframes pulse-attention {
    0% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); }
    50% { box-shadow: 0 10px 30px rgba(12, 175, 96, 0.4); }
    100% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); }
  }
  
  .pulse-attention {
    animation: pulse-attention 1s ease;
  }
  
  .input-ripple {
    pointer-events: none;
  }
`;
        document.head.appendChild(style);
    </script>
</body>

</html>
