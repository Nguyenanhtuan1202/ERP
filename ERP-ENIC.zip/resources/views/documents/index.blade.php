@extends('layouts.admin')

@section('content')
<div class="container">
  <h1>Danh sách Chứng từ</h1>
  <a href="{{ route('documents.create') }}" class="btn btn-primary mb-3">Thêm Chứng từ mới</a>
  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Loại chứng từ</th>
        <th>File</th>
        <th>Hành động</th>
      </tr>
    </thead>
    <tbody>
      @foreach($documents as $document)
        <tr>
          <td>{{ $document->id }}</td>
          <td>{{ $document->document_type }}</td>
          <td>{{ $document->file_path }}</td>
          <td>
            <a href="{{ route('documents.show', $document->id) }}" class="btn btn-info btn-sm">Xem</a>
            <a href="{{ route('documents.edit', $document->id) }}" class="btn btn-warning btn-sm">Sửa</a>
            <form action="{{ route('documents.destroy', $document->id) }}" method="POST" style="display:inline-block">
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>

  {{ $documents->links() }}
</div>
@endsection
