@extends('layouts.admin')

@section('content')
    <div style="padding: 10px 30px" class="">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">
                        <h3 class="title__highlight">
                            <i class="fas fa-desktop"></i> Danh sách cần duyệt
                        </h3>


                        @if (session('status'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('status') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif

                        @if (session('error'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Lỗi',
                                        text: '{{ session('error') }}',
                                        icon: 'error',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#d33',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif

                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                <thead class="thead__custom">
                                    <tr>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            STT</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            ID Chuyên Gia</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Hình Ảnh</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Họ Tên</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            SDT</th>

                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Cấp Chuyên Gia</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Nhóm Chuyên Gia</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Ngày Tham Gia</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Quản Lý</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @php
                                        $temp = 0;
                                    @endphp

                                    @foreach ($data['list_expert'] as $item)
                                        @php
                                            $temp++;
                                        @endphp
                                        <tr>

                                            <td class="align-middle text-center ">
                                                {{ $temp }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                <span
                                                    style="color: #dc3545; display: block; font-size: 20px; font-weight: bold; padding-right: 10px">

                                                    @if ($item->id_hs == '' || $item->id_hs == null)
                                                        <form style="display: flex; gap: 10px; align-items: center"
                                                            method="GET"
                                                            action="{{ url('admin/expert/updateId/' . $item->id ?? '') }}">
                                                            <input
                                                                style="height: 40px;font-size: 15px; width: 80px;border-radius: 5px;outline: none;border: 1px solid #111; "
                                                                type="tel" name="id_hs" value=""
                                                                placeholder="Nhập id">
                                                            <button
                                                                style="height: 40px; font-size: 14px; background-color: #0cbd34; border: none; color: #fff; width: 65px; border-radius: 5px;">Update</button>
                                                        </form>
                                                    @else
                                                        {{ $item->id_hs ?? '' }}
                                                    @endif
                                                </span>


                                                @if ($item->file_contract == '' || $item->file_contract == null)
                                                    <span
                                                        style="font-size: 10px; display: block; font-weight: bold; color: #02647d; background-color: #ffff00; padding: 5px; border-radius: 5px;">Cần
                                                        cập nhật hồ sơ</span>
                                                @endif

                                            </td>
                                            <td class="align-middle text-center ">
                                                <img style="width: 80px; border-radius: 8px; object-fit: cover"
                                                    src="{{ asset('uploads/expert/' . $item->profile_picture ?? '') }}"
                                                    alt="">
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->fullname ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->phone ?? '' }}
                                            </td>


                                            <td class="align-middle text-center ">
                                                <span
                                                    style="font-size: 14px; font-weight: bold; color: #02647d; background-color: #ffff00; padding: 6px; border-radius: 5px;">
                                                    {{ level_expert($item->level ?? '') }}
                                                </span>
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->class ?? '' }}
                                            </td>
                                            <td class="align-middle text-center">
                                                {{ $item->date_join ?? 'Chưa cập nhật' }}
                                            </td>
                                            <td class="align-middle">



                                                @if (Auth::user()->role[0]->id != 11)
                                                    <a href="{{ url('/admin/expert/edit/' . $item->id) }}"
                                                        class="font-weight-bold" data-toggle="tooltip"
                                                        data-original-title="Edit user"
                                                        style="font-size: 12px; font-weight: bold; color: #ffffff; background-color: #007bff; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                        Xem
                                                    </a>

                                                    <a onclick="return confirm('Bạn có muốn duyệt hợp đồng chuyên gia này không ?')"
                                                        href="{{ url('admin/expert/approve/' . $item->id) }}"
                                                        class="font-weight-bold" data-toggle="tooltip"
                                                        data-original-title="approve contract"
                                                        style="font-size: 12px; display: block; margin-top: 5px;  font-weight: bold; color: #ffffff; background-color: #0d7a35; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                        Duyệt
                                                    </a>
                                                @else
                                                    <a class="font-weight-bold" data-toggle="tooltip"
                                                        data-original-title="approve contract"
                                                        style="font-size: 12px; display: block; margin-top: 5px;  font-weight: bold; color: #ffffff; background-color: #0d7a35; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                        Đang Đợi Duyệt
                                                    </a>
                                                @endif


                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
@endsection
