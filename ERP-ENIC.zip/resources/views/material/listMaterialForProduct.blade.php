@extends('layouts.enic')


@section('content')
    <div class="midde_cont" style="margin-top: 100px">
        <style>
            .container {
                margin-top: 50px;
                display: flex;
                flex-direction: column;
                gap: 20px;
            }

            .group-card {
                background: #ffffff;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                padding: 15px;
                border-left: 5px solid #3498db;
                transition: all 0.3s ease-in-out;
            }

            .group-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                cursor: pointer;
                padding: 10px 15px;
                background-color: #3498db;
                color: #fff;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            .group-header:hover {
                background-color: #2980b9;
            }

            .group-header h3 {
                margin: 0;
            }

            .group-content {
                margin-top: 15px;
                display: none;
                flex-direction: column;
                gap: 20px;
                transition: max-height 0.3s ease-in-out;
            }

            .size-color-group {
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                background: #f9f9f9;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
            }

            thead {
                background-color: #34495e;
                color: #fff;
            }

            th,
            td {
                padding: 10px;
                text-align: left;
                border: 1px solid #ddd;
            }

            .input__custom {
                width: 100%;
                border: none;
                border-bottom: 1px solid green;
                outline: none;
                background-color: unset;
                padding: 5px;
            }

            .update-button {
                margin-top: 15px;
                padding: 8px 15px;
                background-color: #2ecc71;
                color: white;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                transition: background 0.3s;
            }

            .update-button:hover {
                background-color: #27ae60;
            }

            #updateMaterials {
                border: none;
                background-color: #0caf60;
                padding: 10px 20px;
                border-radius: 8px;
                color: #fff;
                font-weight: 600;
            }

            .file-import {
                display: inline-block;
                background-color: #17a2b8;
                padding: 10px 20px;
                border-radius: 8px;
                color: #fff;
                font-weight: 600;
                margin-right: 10px;
                height: 50px;
            }

            .file-export {
                display: inline-block;
                background-color: #107444;
                padding: 10px 20px;
                border-radius: 8px;
                color: #fff;
                font-weight: 600;
                height: 50px;
            }

            .select2-container {
                width: 250px !important;
            }

            .file-export:hover,
            .file-import:hover {
                color: #fff;
            }


            /* Container của bộ lọc */
            .filter-container {
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                align-items: center;
                padding: 15px;
                background-color: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 8px;
                margin-bottom: 20px;
            }

            /* Container cho từng nhóm input */
            .filter-group {
                display: flex;
                align-items: center;
                gap: 5px;
            }

            /* Label */
            .filter-container label {
                font-weight: bold;
                color: #333;
            }

            /* Input fields */
            .filter-container .filter-input {
                padding: 8px 12px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 14px;
                transition: border-color 0.2s ease;
            }

            .filter-container .filter-input:focus {
                outline: none;
                border-color: #66afe9;
                box-shadow: 0 0 5px rgba(102, 175, 233, 0.6);
            }

            /* Button */
            .filter-container button {
                padding: 10px 20px;
                background-color: #007bff;
                border: none;
                border-radius: 4px;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }

            .filter-container button:hover {
                background-color: #0056b3;
            }




            .filter-group {
                display: flex;
                gap: 15px;
                align-items: center;
                margin-top: 10px;
            }

            /* Style cho các nút */
            .filter-group button {
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                font-size: 14px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }

            /* Nút Lọc */
            .filter-group button.apply-btn {
                background-color: #007bff;
                color: #fff;
            }

            .filter-group button.apply-btn:hover {
                background-color: #0056b3;
            }

            /* Nút Xoá bộ lọc */
            .filter-group button.reset-btn {
                background-color: #d01c1c;
                color: #fff;
            }

            .filter__info {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .filter__info-item {
                display: flex;
                flex-direction: column;
            }
        </style>

        <div class="container">


            <div class="row column_title">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000,
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif
                <div class="col-md-12">
                    <nav aria-label="breadcrumb" class="mt-3">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">DashBoard</a></li>
                            <li class="breadcrumb-item active">Danh sách Vật Tư Theo Sản Phẩm</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div style="display: flex; flex-direction: column; gap: 20px;">
                        <div class="filter__info">
                            <div class="filter__info-item">
                                <label for="tier_filter">Tier Code:</label>
                                <select id="tier_filter" name="tier_code" class="filter-input select3_init">
                                    <option value="">-- Chọn Tier Code --</option>
                                    @foreach ($data['get_tiers'] as $tier)
                                        <option value="{{ $tier->tier_code }}">
                                            {{ $tier->tier_code }} - {{ $tier->tier }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="filter__info-item">
                                <label for="style_filter">Style Code:</label>
                                <select id="style_filter" name="style_code" class="filter-input select3_init">
                                    <option value="">-- Chọn Style Code --</option>
                                    @foreach ($data['get_styles'] as $style)
                                        <option value="{{ $style->style_code }}">
                                            {{ $style->style_code }} - {{ $style->style }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="filter__info-item">
                                <label for="size_filter">Size:</label>
                                <select id="size_filter" name="size" class="filter-input select3_init">
                                    <option value="">-- Chọn Size --</option>
                                    @foreach ($data['get_sizes'] as $sizes)
                                        <option value="{{ $sizes->size ?? '' }}">
                                            {{ $sizes->size ?? '' }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>


                            <div class="filter__info-item">
                                <label for="color_filter">Color:</label>
                                <select id="color_filter" name="color" class="filter-input select3_init">
                                    <option value="">-- Chọn Color --</option>
                                    @foreach ($data['get_colors'] as $colors)
                                        <option value="{{ $colors->color ?? '' }}">
                                            {{ $colors->color ?? '' }}
                                        </option>
                                    @endforeach
                                </select>

                            </div>







                        </div>

                        <div class="filter-group">
                            <button type="button" class="apply-btn" onclick="applyFilter()">Lọc</button>
                            <button type="button" class="reset-btn" onclick="resetFilters()">Xoá bộ lọc</button>
                        </div>

                        <!-- Xuất & Nhập Excel -->
                        <div style="display: flex; gap: 10px;">
                            <a class="file-import" href="{{ route('importExcelListMaterial') }}">Nhập File Excel <i
                                    class="fas fa-file-import"></i></a>
                            <a id="exportExcelBtn" class="file-export" href="#">Xuất File Excel <i
                                    class="fas fa-file-export"></i></a>

                        </div>

                        <!-- Bảng hiển thị dữ liệu -->
                        <table border="1" style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr>
                                    <th>Tier Code</th>
                                    <th>Tier</th>
                                    <th>Style Code</th>
                                    <th>Style</th>
                                    <th>Sản phẩm</th>
                                    <th>Size</th>
                                    <th>Color</th>
                                    <th>SKU</th>
                                    <th>Vật liệu</th>
                                    <th>Số lượng</th>
                                    <th>Giá tổng</th>
                                </tr>
                            </thead>
                            <tbody id="materials_table">
                                <!-- Dữ liệu sẽ được đổ vào đây từ backend -->
                            </tbody>
                        </table>
                    </div>

                    <form id="materialsForm">
                        {{ csrf_field() }}
                        <div class="container">
                            {{-- {{dd($data['materialsGrouped'])}} --}}
                            @foreach ($data['materialsGrouped'] as $group)
                                <div class="group-card">
                                    <div class="group-header" onclick="toggleGroupContent(this)">
                                        <h3>Dòng Sản Phẩm: {{ $group['tier_name'] }}</h3>
                                        <span class="toggle-indicator">➕</span>
                                    </div>
                                    <div class="group-content" style="display: none;">
                                        @foreach ($group['details'] as $detail)
                                            <div class="size-color-group">
                                                <h4>Size: {{ $detail['size'] }} | Style: {{ $detail['style'] }} | Color:
                                                    {{ $detail['color'] }}</h4>
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Tên vật liệu</th>
                                                            <th>SKU</th>
                                                            <th>Số lượng</th>
                                                            <th>Thành tiền</th>
                                                            <th>Đơn vị</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($detail['materials'] as $key => $material)
                                                            <tr>
                                                                <td>{{ $material['name_material'] }}</td>

                                                                <td>


                                                                    <input type="hidden"
                                                                        name="data[{{ $key }}][tier_material]"
                                                                        value="{{ $group['tier_code'] ?? '' }}">
                                                                    <input type="hidden"
                                                                        name="data[{{ $key }}][size_material]"
                                                                        value="{{ $detail['size'] ?? '' }}">
                                                                    <input type="hidden"
                                                                        name="data[{{ $key }}][style_material]"
                                                                        value="{{ $material['style_code'] ?? '' }}">
                                                                    <input type="hidden"
                                                                        name="data[{{ $key }}][color_material]"
                                                                        value="{{ $detail['color'] ?? '' }}">
                                                                    <input type="hidden"
                                                                        name="data[{{ $key }}][sku_material]"
                                                                        value="{{ $material['sku_material'] ?? '' }}">
                                                                    {{ $material['sku_material'] ?? '' }}
                                                                </td>
                                                                <td>
                                                                    <input type="number" class="input__custom qty-input"
                                                                        name="data[{{ $key }}][qty_material]"
                                                                        value="{{ $material['qty_material'] ?? '' }}"
                                                                        min="0">
                                                                </td>
                                                                <td>
                                                                    <input type="number" class="input__custom price-input"
                                                                        name="data[{{ $key }}][total_price_material]"
                                                                        value="{{ $material['total_price_material'] ?? '' }}"
                                                                        min="0" step="0.01">
                                                                </td>
                                                                <td>{{ $material['unit_material'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <button type="button" class=" my-3" id="updateMaterials">Cập nhật <i
                                class="far fa-save"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        /* Làm mới dữ liệu */
        function resetFilters() {
            $('#tier_filter').val(null).trigger('change');
            $('#style_filter').val(null).trigger('change');
            $('#size_filter').val(null).trigger('change');
            $('#color_filter').val(null).trigger('change');

            // Cập nhật bảng hiển thị (nếu cần)
            $("#materials_table").html('<tr><td colspan="11" style="text-align: center;">Chưa có dữ liệu</td></tr>');
        }




        document.getElementById('exportExcelBtn').addEventListener('click', function(e) {
            e.preventDefault(); // Ngăn chặn tải lại trang

            // Lấy giá trị từ các ô lọc
            let tierCode = document.getElementById('tier_filter').value;
            let styleCode = document.getElementById('style_filter').value;
            let size = document.getElementById('size_filter').value;
            let color = document.getElementById('color_filter').value;

            // Xây dựng URL với các tham số query
            let url =
                `{{ route('exportExcelListMaterial') }}?tier_code=${tierCode}&style_code=${styleCode}&size=${size}&color=${color}`;

            // Chuyển hướng đến URL export
            window.location.href = url;
        });


        const filterRoute = @json(route('materials.filter'));

        function applyFilter() {
            const tier = document.getElementById('tier_filter').value;
            const style = document.getElementById('style_filter').value;
            const size = document.getElementById('size_filter').value;
            const color = document.getElementById('color_filter').value;

            const url = `${filterRoute}?tier=${tier}&style=${style}&size=${size}&color=${color}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    let tableContent = "";

                    if (data.length === 0) {
                        tableContent =
                            `<tr><td colspan="9" style="text-align: center;">Không tìm thấy kết quả</td></tr>`;
                    } else {
                        data.forEach(item => {
                            tableContent += `
                    <tr>
                        <td>${item.tier_code}</td>
                        <td>${item.tier}</td>
                        <td>${item.style_code}</td>
                        <td>${item.style}</td>
                        <td>${item.product_name || 'N/A'}</td>
                        <td>${item.size}</td>
                        <td>${item.color}</td>
                        <td>${item.sku}</td>
                        <td>${item.material_name || 'N/A'}</td>
                        <td>${item.quantity}</td>
                        <td>${item.total_price}</td>
                    </tr>`;
                        });
                    }

                    document.getElementById("materials_table").innerHTML = tableContent;
                })
                .catch(error => console.error("Lỗi khi tải dữ liệu:", error));
        }

        // function exportExcel() {
        //     let filters = $('#filter').val(); // Lấy các bộ lọc đã chọn
        //     let url = "{{ route('exportExcelListMaterial') }}";
        //     let queryString = "";

        //     if (filters.length > 0) {
        //         queryString = "?" + filters.map(f => f + "=1").join("&");
        //     }

        //     window.location.href = url + queryString;
        // }



        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.group-header').forEach(header => {
                header.addEventListener('click', function() {
                    const content = this.nextElementSibling;
                    content.style.display = (content.style.display === 'none' || content.style
                        .display === '') ? 'block' : 'none';
                    this.querySelector('.toggle-indicator').textContent = (content.style.display ===
                        'none') ? '➕' : '➖';
                });
            });
            document.getElementById('updateMaterials').addEventListener('click', function() {
                let tableData = [];

                document.querySelectorAll('.qty-input').forEach((input, index) => {
                    let row = {
                        tier_material: input.closest('tr').querySelector(
                            'input[name*="tier_material"]').value,
                        size_material: input.closest('tr').querySelector(
                            'input[name*="size_material"]').value,
                        style_material: input.closest('tr').querySelector(
                            'input[name*="style_material"]').value,
                        color_material: input.closest('tr').querySelector(
                            'input[name*="color_material"]').value,
                        sku_material: input.closest('tr').querySelector(
                            'input[name*="sku_material"]').value,
                        qty_material: input.value,
                        total_price_material: input.closest('tr').querySelector('.price-input')
                            .value
                    };
                    tableData.push(row);
                });

                fetch("{{ route('materials.update') }}", {
                        method: "POST",
                        headers: {
                            "X-CSRF-TOKEN": document.querySelector('input[name="_token"]').value,
                            "Content-Type": "application/json",
                            "Accept": "application/json"
                        },
                        body: JSON.stringify({
                            data: tableData
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Thông báo',
                                position: "top-end",
                                text: 'Cập nhật thành công',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 3000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        }
                    })
                    .catch(error => console.error("Lỗi:", error));
            });
        });
    </script>
@endsection
