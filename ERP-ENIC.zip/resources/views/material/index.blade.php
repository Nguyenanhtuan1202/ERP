@extends('layouts.enic')
@section('content')
    <div class="container-fluid" style="margin-top: 100px" >

        <style>
            .page-header {
                background-size: cover;
                background-position: bottom left;
                position: relative;
                border-radius: 0;
                color: #fff;
                height: 200px;
                margin-top: 60px;
            }

            .page-header:before {
                background: rgba(68, 138, 255, 0.5);
            }

            .page-header:before {
                content: "";
                background-color: rgba(0, 0, 0, 0.5);
                width: 100%;
                height: 200px;

                position: absolute;
                top: 0;
                left: 0;
            }

            .box__count-items {
                box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
                background: #fff;
                padding: 20px;
                border-radius: 8px;
                margin: 10px 10px;
            }

            .purchase__order {
                display: block;
                width: 180px;
                border: 1px solid #0CAF60;
                border-radius: 8px;
                padding: 8px 20px;
                font-weight: 600;
                color: #0CAF60;
            }

            .purchase__order:hover {
                background-color: #0CAF60;
                color: #fff;
            }

            .total__quantity {
                padding: 4px 16px;
                /* color: #fff; */
                font-weight: 500;
                border-radius: 20px;
                font-size: 16px;
                background: linear-gradient(141.55deg, #0CAF60 3.46%, #0CAF60 99.86%), #0CAF60;
                color: #fff;
                box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
            }

            .order__date {
                background-color: #ffc107;
                padding: 8px 20px;
                font-weight: 700;
                border-radius: 5px;
                font-size: 16px;
            }

            .expected_date {
                background-color: #37b1c1;
                padding: 8px 20px;
                font-weight: 700;
                border-radius: 5px;
                font-size: 16px;
                color: #fff;
            }
        </style>

        <div class="page-header" style="background-image: url('{{ asset('erp/breadcrumb-bg.jpg') }}')">
        </div>



        @if (session('status'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('status') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <div class="row align-items-center justify-content-between listPurchaseOrder" style="width: 100%;">
            <div class="col-auto">
                <div class="page-header-title">
                    <h4 class="mb-3 mt-5 ml-3" style="font-weight: bold"> Danh Sách Tất Cả Vật Liệu
                    </h4>
                </div>

            </div>
        </div>


        <div class="row align-items-center justify-content-between listPurchaseOrder mb-3" style="width: 100%;">
            <div class="col-auto">

                <div class="d-flex ml-3 mt-4">
                    <a class="addNew" style="background:#17a2b8; box-shadow:none"
                        href="{{ route('material.import_excel') }}">Nhập File Excel
                        <i class="fas fa-file-upload"></i> </a>
                    <a class="addNew" style="background: rgb(23, 145, 88);box-shadow:none"
                        href="{{ route('material.export') }}">Xuất File Excel
                        <i class="fas fa-file-download"></i> </a>
                </div>
            </div>
            <div class="col-auto mt-4">
                <div class="d-flex">
                    <a class="addNew" style="background:#00104f; box-shadow:none" href="{{ route('listMaterialProduct') }}"> <i class="fas fa-th"></i> Danh Sách
                        Vật Tư Theo
                        Sản Phẩm </a>
                    <a class="material_forproduct" href="{{ route('material.add') }}"> <i class="fas fa-th"></i> Thêm Vật Tư
                        Theo
                        Sản Phẩm </a>

                    <a class="addNew" href="{{ url('/') }}">Quay Lại Trang Chủ <i class="fas fa-undo-alt"></i></a>
                </div>
            </div>
        </div>


        <div class="card-body px-0 pt-0 pb-2">
            <div class="table-responsive p-0">
                <table class="table align-items-center mb-0 table__customs" id="table1">
                    <thead class="thead__custom">
                        <tr>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                STT</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Tên Vật Tư</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                SKU</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Hạng Mục Vật Tư</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Quy Cách</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Đơn Vị</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Tiền Vốn</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Tiền Về Kho</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 14px">
                        @php
                            $temp = 0;
                        @endphp

                        @foreach ($material_list as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr>
                                <td class="align-middle text-center ">
                                    {{ $temp }}
                                </td>
                                <td class="align-middle text-left">
                                    {{ $item->name ?? '' }}
                                </td>
                                <td class="align-middle text-center">
                                    <span class="total__quantity">{{ $item->sku ?? '' }}</span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="">{{ MaterialCategory($item->material_categories_id ?? '') }}</span>
                                </td>
                                <td class="align-middle text-left">
                                    <span class="">{{ $item->packaging ?? '' }}</span>
                                </td>
                                <td class="align-middle text-center ">
                                    {{ $item->unit ?? '' }}
                                </td>
                                <td class="align-middle text-center">
                                    <span class="">{{ $item->price_cost ?? '' }}</span>
                                </td>

                                <td class="align-middle text-center ">
                                    {{ $item->price_in_stock ?? '' }}
                                </td>
                                <td>
                                    <a href="{{ route('material.edit', ['id' => $item->id]) }}"><i
                                            class="far fa-edit"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
