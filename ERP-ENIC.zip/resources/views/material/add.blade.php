@extends('layouts.enic')


@section('content')
    <div class="midde_cont" style="margin-top: 100px">
        <div class="container-fluid">
            <div class="row column_title">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif



                @if (session('error'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Lỗi',
                                text: '{{ session('error') }}',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#d33',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


                <div class="col-md-12">
                    <div class="page_title">
                        <nav aria-label="breadcrumb" class="mt-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}">DashBoard</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('material.index') }}">Danh sách </a></li>
                                <li class="breadcrumb-item active" aria-current="page">Thêm Mới</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- row -->
            <form id="myFormCustom" action="{{ route('materials.store') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row column1">
                    <div class="col-md-12">
                        <div class="white_shd full margin_bottom_30">
                            <div class="full graph_head">
                                <div class="heading1 margin_0">
                                    <h2>Danh Sách Vật Tư Cần Để Hoàn Thiện 1 Dòng Sản Phẩm</h2>

                                    <div class="row align-items-center justify-content-between listPurchaseOrder mb-3"
                                        style="width: 100%;">
                                        <div class="col-auto">

                                            <div class="d-flex ml-3 mt-4">

                                            </div>
                                        </div>
                                        <div class="col-auto ">
                                            <div class="d-flex">
                                                <a class="list__material-for-product"
                                                    href="{{ route('listMaterialProduct') }}"><i class="fas fa-th"></i> Xem
                                                    danh sách </a>
                                            </div>
                                        </div>
                                    </div>


                                    @if (session('status'))
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            {{ session('status') }}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="full price_table padding_infor_info">
                                <div class="row">
                                    <div class="col-md-12 sider__bar-left">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('tier_code')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="tier_code">Chọn Dòng Sản Phẩm</label>
                                                    <select required name="tier_code"
                                                        class="form-control select3_init tier_code" id="tier_code">
                                                        <option>Chọn</option>
                                                        @foreach ($data['group_tiers'] as $item)
                                                            <option value="{{ $item->tier_code ?? '' }}">
                                                                {{ $item->tier ?? '' }} - {{ $item->total ?? '' }} SKU
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('size')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="arr_custom6">Kích Thước</label>
                                                    <select name="size" class="form-control select3_init size"
                                                        id="size" disabled>
                                                        <option value="">-- Chọn Size --</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('style')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="style">Loại Sản Phẩm</label>
                                                    <select name="style" class="form-control select3_init style"
                                                        id="style" disabled>
                                                        <option value="">-- Chọn Type --</option>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('color')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="arr_custom6">Màu Sắc</label>
                                                    <select name="color" class="form-control select3_init color"
                                                        id="color" disabled>
                                                        <option value="">-- Chọn Color --</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="materials">Vật Tư</label>
                                                    <select name="materials" class="form-control select3_init materials"
                                                        style="height: 40px !important" id="materials" multiple disabled>
                                                        <option value="">-- Chọn Vật Tư --</option>
                                                        <div id="error-message" style="color: red; display: none;">Vui lòng
                                                            chọn vật liệu!</div>
                                                        @foreach ($data['material'] as $item)
                                                            <option value="{{ $item->sku ?? '' }}">{{ $item->name ?? '' }}
                                                                - SKU: {{ $item->sku ?? '' }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>



                                                <div class="form-group">
                                                    <input type="text" id="materials-input" class="form-control"
                                                        placeholder="Dán các mã vật tư (cách nhau bởi dấu cách, dấu phẩy hoặc chấm phẩy)" />
                                                    <div id="error-message" style="color: red; display: none;">Vui lòng nhập
                                                        mã vật tư!</div>

                                                </div>


                                            </div>
                                            <div class="col-md-12">
                                                <table class="table table-bordered mt-3" id="product-table">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Tên sản phẩm</th>
                                                            <th>Sku</th>
                                                            <th>Size</th>
                                                            <th>Style</th>
                                                            <th>Color</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="5" class="text-center">Vui lòng chọn Dòng Sản
                                                                Phẩm, Kích Thước, Loại Sản Phẩm và Màu Sắc để hiển thị sản
                                                                phẩm.</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- Bảng hiển thị danh sách vật tư -->
                                            <div class="col-md-12 mt-3">
                                                <table class="table table-bordered" id="material-table">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Tên Vật Tư</th>
                                                            <th>SKU</th>
                                                            <th>Số Lượng</th>
                                                            <th>Thành Tiền</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="5" class="text-center">Vui lòng chọn vật tư để
                                                                hiển thị.</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn__add my-3">Thêm mới <i
                                                class="fas fa-plus"></i></button>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- end row -->
                </div>
            </form>
            <!-- footer -->
        </div>
        <!-- end dashboard inner -->
    </div>
@endsection


@section('js')
    <script>
        $(document).ready(function() {
            // Lấy danh sách size khi chọn tier_code
            $('#tier_code').on('change', function() {
                let tier_code = $(this).val();

                if (tier_code) {
                    $.ajax({
                        url: "{{ route('sizes.by.tier') }}",
                        type: "GET",
                        data: {
                            tier_code: tier_code
                        },
                        success: function(response) {
                            let sizeDropdown = $('#size');
                            sizeDropdown.empty().append(
                                '<option value="">-- Chọn Size --</option>');

                            if (response.sizes && response.sizes.length > 0) {
                                response.sizes.forEach(size => {
                                    sizeDropdown.append(
                                        `<option value="${size.size}">${size.size} - ${size.total} sản phẩm</option>`
                                    );
                                });
                                sizeDropdown.prop('disabled', false);
                            } else {
                                sizeDropdown.append(
                                    '<option value="">Không có size nào</option>');
                                sizeDropdown.prop('disabled', true);
                            }

                            $('#color').empty().append(
                                '<option value="">-- Chọn Color --</option>').prop(
                                'disabled', true);
                            $('#style').empty().append(
                                '<option value="">-- Chọn Style --</option>').prop(
                                'disabled', true);
                            updateProducts();
                        },
                        error: function() {
                            alert('Đã xảy ra lỗi! Vui lòng thử lại.');
                        }
                    });
                } else {
                    $('#size').empty().append('<option value="">-- Chọn Size --</option>').prop('disabled',
                        true);
                    $('#color').empty().append('<option value="">-- Chọn Color --</option>').prop(
                        'disabled', true);
                    $('#style').empty().append('<option value="">-- Chọn Style --</option>').prop(
                        'disabled', true);
                    updateProducts();
                }
            });

            // Lấy danh sách style khi chọn size
            $('#size').on('change', function() {
                let tier_code = $('#tier_code').val();
                let size = $(this).val();

                if (tier_code && size) {
                    $.ajax({
                        url: "{{ route('styles.by.tier.size') }}", // Route lấy danh sách style
                        type: "GET",
                        data: {
                            tier_code: tier_code,
                            size: size
                        },
                        success: function(response) {
                            let styleDropdown = $('#style');
                            styleDropdown.empty().append(
                                '<option value="">-- Chọn Style --</option>');

                            if (response.styles && response.styles.length > 0) {
                                response.styles.forEach(style => {
                                    styleDropdown.append(
                                        `<option value="${style.style_code}">${style.style} - ${style.total} sản phẩm</option>`
                                    );
                                });
                                styleDropdown.prop('disabled', false);
                            } else {
                                styleDropdown.append(
                                    '<option value="">Không có style nào</option>');
                                styleDropdown.prop('disabled', true);
                            }
                            updateProducts(); // Cập nhật danh sách sản phẩm
                        },
                        error: function() {
                            alert('Đã xảy ra lỗi! Vui lòng thử lại.');
                        }
                    });
                } else {
                    $('#style').empty().append('<option value="">-- Chọn Style --</option>').prop(
                        'disabled', true);
                    updateProducts();
                }
            });

            // Lấy danh sách color khi chọn style
            $('#style').on('change', function() {
                let tier_code = $('#tier_code').val();
                let size = $('#size').val();
                let style = $(this).val();

                if (tier_code && size && style) {
                    $.ajax({
                        url: "{{ route('colors.by.tier.size.style') }}", // Route lấy danh sách color
                        type: "GET",
                        data: {
                            tier_code: tier_code,
                            size: size,
                            style: style
                        },
                        success: function(response) {
                            let colorDropdown = $('#color');
                            colorDropdown.empty().append(
                                '<option value="">-- Chọn Color --</option>');

                            if (response.colors && response.colors.length > 0) {
                                response.colors.forEach(color => {
                                    colorDropdown.append(
                                        `<option value="${color.color}">${color.color} - ${color.total} sản phẩm</option>`
                                    );
                                });
                                colorDropdown.prop('disabled', false);
                            } else {
                                colorDropdown.append(
                                    '<option value="">Không có màu nào</option>');
                                colorDropdown.prop('disabled', true);
                            }
                            updateProducts();
                        },
                        error: function() {
                            alert('Đã xảy ra lỗi! Vui lòng thử lại.');
                        }
                    });
                } else {
                    $('#color').empty().append('<option value="">-- Chọn Color --</option>').prop(
                        'disabled', true);
                    updateProducts();
                }
            });

            // Lấy danh sách sản phẩm khi chọn color
            $('#color').on('change', function() {
                let color = $('#color').val();
                if (color) {
                    $('#materials').prop('disabled', false);
                }
                updateProducts();
            });

            // Hàm lấy danh sách sản phẩm
            function updateProducts() {
                let tier_code = $('#tier_code').val();
                let size = $('#size').val();
                let style = $('#style').val();
                let color = $('#color').val();

                $.ajax({
                    url: "{{ route('products.filtered') }}",
                    type: "GET",
                    data: {
                        tier_code: tier_code,
                        size: size,
                        style: style,
                        color: color
                    },
                    success: function(response) {
                        let productTable = $('#product-table tbody');
                        productTable.empty();

                        if (response.products && response.products.length > 0) {
                            response.products.forEach((product, index) => {
                                productTable.append(`
                            <tr>
                                <td>${index + 1}</td>
                                <td>${product.name}</td>
                                <td>${product.sku}</td>
                                <td>${product.size}</td>
                                <td>${product.style}</td>
                                <td>${product.color}</td>
                            </tr>
                        `);
                            });
                        } else {
                            productTable.append(
                                '<tr><td colspan="6" class="text-center">Không tìm thấy sản phẩm nào.</td></tr>'
                            );
                        }
                    },
                    error: function() {
                        alert('Đã xảy ra lỗi! Vui lòng thử lại.');
                    }
                });
            }
        });




        $(document).ready(function() {
            let lastMaterials = []; // Lưu danh sách SKU trước đó để tránh gọi AJAX không cần thiết

            $('#materials-input').on('input', function() {
                let rawInput = $(this).val().trim();

                // Kiểm tra nếu input trống
                if (rawInput === '') {
                    $('#error-message').show();
                    return;
                } else {
                    $('#error-message').hide();
                }

                // Tách mã SKU bằng dấu cách, dấu phẩy hoặc chấm phẩy
                let selectedMaterials = rawInput.split(/[\s,;]+/).map(sku => sku.trim()).filter(sku =>
                    sku !== "");

                // Nếu danh sách SKU không thay đổi, không gọi AJAX để tránh spam API
                if (JSON.stringify(selectedMaterials) === JSON.stringify(lastMaterials)) {
                    return;
                }
                lastMaterials = selectedMaterials; // Cập nhật danh sách SKU đã nhập

                // Gửi AJAX lấy thông tin vật tư
                $.ajax({
                    url: "{{ route('materials.get') }}",
                    type: "POST",
                    data: {
                        materials: selectedMaterials,
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(response) {
                        let materialTable = $('#material-table tbody');
                        materialTable.empty();

                        if (response.materials && response.materials.length > 0) {
                            response.materials.forEach((material, index) => {
                                materialTable.append(`
                            <tr>
                                <td>${index + 1}</td>
                                <td>${material.name}</td>
                                <td>${material.sku}</td>
                                <td>
                                    <input type="hidden" name="data[${index}][name]" value="${material.name ?? ''}" />
                                    <input type="hidden" name="data[${index}][sku]" value="${material.sku ?? ''}" />
                                    <input required type="number" name="data[${index}][quantity]" class="form-control quantity" 
                                           data-sku="${material.sku}" placeholder="Nhập số lượng" />
                                </td>
                                <td>
                                    <input required type="text" class="form-control total_price" name="data[${index}][total_price]"
                                           data-sku="${material.sku}" placeholder="Nhập thành tiền" />
                                </td>
                            </tr>
                        `);
                            });

                            // $('#materials-input').val(''); // Xóa input sau khi nhập xong
                        } else {
                            materialTable.append(
                                '<tr><td colspan="5" class="text-center">Không tìm thấy vật tư nào.</td></tr>'
                            );
                        }
                    },
                    error: function() {
                        alert('Đã xảy ra lỗi! Vui lòng thử lại.');
                    }
                });
            });
        });


        /* Chọn Vật T */

        // $(document).ready(function() {
        //     // Bắt sự kiện khi dropdown material thay đổi
        //     $('#materials').on('change', function() {
        //         let selectedMaterials = $(this).val(); // Lấy danh sách vật tư được chọn (mảng)

        //         // Gửi AJAX request để lấy thông tin vật tư
        //         $.ajax({
        //             url: "{{ route('materials.get') }}",
        //             type: "POST",
        //             data: {
        //                 materials: selectedMaterials,
        //                 _token: "{{ csrf_token() }}" // CSRF token
        //             },
        //             success: function(response) {
        //                 let materialTable = $('#material-table tbody');
        //                 materialTable.empty();

        //                 if (response.materials && response.materials.length > 0) {
        //                     response.materials.forEach((material, index) => {
        //                         materialTable.append(`
    //                         <tr>
    //                             <td>${index + 1}</td>
    //                             <td>${material.name}</td>
    //                             <td>${material.sku}</td>

    //                             <td>

    //                                   <input type="hidden" name="data[${index}][name]" class="form-control quantity" 
    //                                        data-sku="${material.sku}"  value="${material.name ?? ''}"
    //                                        placeholder="Nhập số lượng" />

    //                                   <input type="hidden" name="data[${index}][sku]" class="form-control quantity" 
    //                                        data-sku="${material.sku}" value="${material.sku ?? ''}"
    //                                        placeholder="Nhập số lượng" />


    //                                 <input required type="number" name="data[${index}][quantity]" class="form-control quantity" 
    //                                        data-sku="${material.sku}" 
    //                                        placeholder="Nhập số lượng" />
    //                             </td>
    //                             <td>
    //                                 <input required type="text" class="form-control total_price" name="data[${index}][total_price]"
    //                                        data-sku="${material.sku}" 
    //                                        placeholder="Nhập thành tiền" />
    //                             </td>
    //                         </tr>
    //                     `);
        //                     });
        //                 } else {
        //                     materialTable.append(
        //                         '<tr><td colspan="5" class="text-center">Không tìm thấy vật tư nào.</td></tr>'
        //                     );
        //                 }
        //             },
        //             error: function() {
        //                 alert('Đã xảy ra lỗi! Vui lòng thử lại.');
        //             }
        //         });
        //     });


        // });
    </script>
@endsection
