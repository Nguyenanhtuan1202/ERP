@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/material.css') }}">
@endsection
@section('content')
   
    <div class="container-fluid box__view-import" style="margin-top: 100px">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="col-md-6 guild_uploads">
            <h3>Hướng dẫn upload dữ liệu</h3>
            <a class="downloadFileImport" download href="{{ asset('import/ImportFileMaterial.xlsx') }}">Tải Xuống
                File Mẫu </a>
        </div>
        <div class="row mt-4">


            <div class="col-md-10">
                <h2>Import File Excel và Hiển Thị Thông Tin</h2>

                <form id="uploadForm" enctype="multipart/form-data" class="mt-4">
                    @csrf
                    <input type="file" class="file__uploads" name="file" id="file" required>
                    <button type="submit" class="btn__uploads">Upload <i class="fas fa-file-upload"></i></button>
                </form>




                <div id="previewTable" style="margin-top: 20px; display: none;">
                    <h2>Preview Data</h2>
                    <form id="saveForm" action="{{ route('material.upload.ImportFileExcel') }}" method="POST"
                        enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <table id="dataTable" class="table-responsive" style="height: 500px">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Sku</th>
                                    <th>Material Categories Id</th>
                                    <th>Packaging</th>
                                    <th>Price Cost</th>
                                    <th>Price In Stock</th>
                                    <th>Unit</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                        <button class="uploadsData my-3" type="submit">Lưu <i class="fas fa-cloud-upload-alt"></i></button>
                    </form>
                </div>

            </div>

        </div>

    </div>
@endsection


@section('js')
    <script>
        $('#uploadForm').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('material.upload.FileExcel') }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        let rows = response.data;
                        let tableBody = $('#dataTable tbody');
                        tableBody.empty(); // Clear existing data

                        rows.forEach((row, index) => {
                            let html = `
                    <tr class ="tr__custom__inputimport">
                        <td><input class="custom__inputimport" colspan="2" type="text" name="data[${index}][name]" value="${row.name ?? ''}"></td>
                        <td><input class="custom__inputimport" type="text" name="data[${index}][sku]" value="${row.sku ?? ''}"></td>
                         <td><input class="custom__inputimport" type="text" name="data[${index}][material_categories_id]" value="${row.material_categories_id ?? ''}"></td>
                        <td><input class="custom__inputimport" type="text" name="data[${index}][packaging]" value="${row.packaging ?? ''}"></td>
                        <td><input class="custom__inputimport" type="text" name="data[${index}][price_cost]" value="${row.price_cost ?? ''}"></td>
                    <td><input class="custom__inputimport" type="text" name="data[${index}][price_in_stock]" value="${row.price_in_stock ?? ''}"></td>
                    <td><input class="custom__inputimport" type="text" name="data[${index}][unit]" value="${row.unit ?? ''}"></td>
                        </tr>
                    `;
                            tableBody.append(html);
                        });

                        $('#previewTable').show();
                    } else {
                        alert(response.message);
                    }
                }
            });
        });
    </script>
@endsection
