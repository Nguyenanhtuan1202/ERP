@extends('layouts.master')

@section('content')
    <div class="site-wrapper-reveal">

        <div class="error-404-area">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12">
                        <div class="error-404-content text-center">
                            <div class="banner" data-aos="fade-up">
                                <img src="/public/frontend/assets/images/banners/error-404.png" alt="">
                            </div>
                            <div class="error-text" data-aos="fade-up">
                                <h2>Xin lỗi, chúng tôi không tìm thấy trang mà bạn cần!..</h2>
                                <div class="button-box mt-30" data-aos="fade-up">
                                    <a href="{{ url('/') }}" class="btn-large btn-primary"><i
                                            class="icofont-long-arrow-left mr-2"></i>Trở về trang chủ </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="error-area-shap">
                <img src="/public/frontend/assets/images/shap/error-shap.png" alt="">
            </div>
        </div>

    </div>
@endsection
