<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Access Denied</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #ff4b1f, #1fddff);
            font-family: 'Arial', sans-serif;
            overflow: hidden;
        }

        .container {
            text-align: center;
            color: #fff;
        }

        h1 {
            font-size: 72px;
            margin: 0;
            text-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
            animation: glow 2s infinite;
        }

        h2 {
            font-size: 24px;
            margin: 20px 0;
            text-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        .go-back {
            display: inline-block;
            margin-top: 20px;
            padding: 15px 30px;
            font-size: 18px;
            color: #fff;
            text-decoration: none;
            border-radius: 25px;
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            transition: background 0.3s, box-shadow 0.3s;
        }

        .go-back:hover {
            background: rgba(255, 255, 255, 0.4);
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.5);
        }

        .go-back span {
            display: inline-block;
            transition: transform 0.3s;
        }

        .go-back:hover span {
            transform: translateX(-5px);
        }

        .sparkle {
            position: absolute;
            width: 5px;
            height: 5px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #fff, 0 0 40px #ff4b1f, 0 0 50px #ff4b1f;
            animation: sparkle 1.5s infinite;
            pointer-events: none;
        }

        @keyframes glow {
            0% { text-shadow: 0 0 15px rgba(0, 0, 0, 0.3); }
            50% { text-shadow: 0 0 30px rgba(0, 0, 0, 0.6); }
            100% { text-shadow: 0 0 15px rgba(0, 0, 0, 0.3); }
        }

        @keyframes sparkle {
            0% { transform: scale(0); opacity: 1; }
            50% { transform: scale(1.5); opacity: 0.5; }
            100% { transform: scale(0); opacity: 0; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Access Denied</h1>
        <h2>You do not have permission to access this page.</h2>
        <a href="javascript:history.back()" class="go-back"><span>Go Back</span></a>
    </div>

    <script>
        const body = document.body;

        function createSparkle(x, y) {
            const sparkle = document.createElement('div');
            sparkle.classList.add('sparkle');
            sparkle.style.left = `${x}px`;
            sparkle.style.top = `${y}px`;
            body.appendChild(sparkle);

            setTimeout(() => {
                sparkle.remove();
            }, 1500);
        }

        document.addEventListener('mousemove', (e) => {
            createSparkle(e.clientX, e.clientY);
        });
    </script>
</body>
</html>
