@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1 class="mt-3">Chỉnh sửa Đối tác</h1>
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <form action="{{ route('partners.update', ['id' => $partner->id]) }}" method="POST">
            {{ csrf_field() }}
            <div class="form-group">
                <label>Tên</label>
                <input type="text" name="name" class="form-control" value="{{ old('name', $partner->name) }}" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="{{ old('email', $partner->email) }}"
                    required>
            </div>

            <div class="form-group">
                <label>Vai trò</label>
                <select name="role" class="form-control" required>
                    <option value="customer" {{ $partner->role == 'customer' ? 'selected' : '' }}>Khách hàng</option>
                    <option value="carrier" {{ $partner->role == 'carrier' ? 'selected' : '' }}>Hãng tàu</option>
                    <option value="accountant" {{ $partner->role == 'accountant' ? 'selected' : '' }}>Kế toán</option>
                    <option value="customs_officer" {{ $partner->role == 'customs_officer' ? 'selected' : '' }}>Nhân viên
                        hải
                        quan</option>
                    <option value="warehouse_staff" {{ $partner->role == 'warehouse_staff' ? 'selected' : '' }}>Nhân viên
                        kho
                    </option>
                    <option value="logistics_agent" {{ $partner->role == 'logistics_agent' ? 'selected' : '' }}>Đại lý
                        logistics</option>
                    <option value="admin" {{ $partner->role == 'admin' ? 'selected' : '' }}>Admin</option>
                </select>
            </div>

            <div class="form-group">
                <label>Số điện thoại</label>
                <input type="text" name="phone" class="form-control" value="{{ old('phone', $partner->phone) }}">
            </div>

            <div class="form-group">
                <label>Địa chỉ</label>
                <input type="text" name="address" class="form-control" value="{{ old('address', $partner->address) }}">
            </div>

            <button type="submit" class="btn btn-success mt-2">Cập nhật đối tác</button>
        </form>
    </div>
@endsection
