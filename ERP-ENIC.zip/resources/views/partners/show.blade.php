@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1 class="mt-3">Chi tiết Đối tác</h1>
        <div class="card">

            @php
                $roleMapping = [
                    'customer' => 'Khách hàng',
                    'carrier' => 'Hãng tàu',
                    'accountant' => 'Kế toán',
                    'customs_officer' => 'Nhân viên hải quan',
                    'warehouse_staff' => 'Nhân viên kho',
                    'logistics_agent' => 'Đại lý logistics',
                    'admin' => 'Admin',
                ];
            @endphp

            <div class="card-body">
                <h3>{{ $partner->name }}</h3>
                <p>Email: {{ $partner->email }}</p>
                <p>Vai trò: {{ $roleMapping[$partner->role] ?? $partner->role }}</p>
                <p>Số điện thoại: {{ $partner->phone }}</p>
                <p>Địa chỉ: {{ $partner->address }}</p>
                <a href="{{ route('partners.edit', ['id' => $partner->id]) }}" class="btn btn-warning">Chỉnh sửa</a>
                <a href="{{ route('partners.index') }}" class="btn btn-secondary">Quay lại</a>
            </div>
        </div>
    </div>
@endsection
