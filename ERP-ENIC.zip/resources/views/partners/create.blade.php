@extends('layouts.admin')

@section('content')
    <div class="container-fluid mt-3">
        <h1>Thêm Đối tác mới</h1>

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <form action="{{ route('partners.store') }}" method="POST">
            {{ csrf_field() }}
            <div class="form-group">
                @error('name')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Tên</label>
                <input type="text" name="name" value="{{old('name')}}" class="form-control" required>
            </div>

            <div class="form-group">
                @error('email')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Email</label>
                <input type="email" name="email" value="{{old('email')}}" class="form-control" required>
            </div>

            <div class="form-group">
                @error('role')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Vai trò</label>
                <select name="role" class="form-control" required>
                    <option value="customer">Khách hàng</option>
                    <option value="carrier">Hãng tàu</option>
                    <option value="accountant">Kế toán</option>
                    <option value="customs_officer">Nhân viên hải quan</option>
                    <option value="warehouse_staff">Nhân viên kho</option>
                    <option value="logistics_agent">Đại lý logistics</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <div class="form-group">
                <label>Số điện thoại</label>
                <input type="text" name="phone" value="{{old('phone')}}" class="form-control">
            </div>

            <div class="form-group">
                <label>Địa chỉ</label>
                <input type="text" name="address" value="{{old('address')}}" class="form-control">
            </div>

            <button type="submit" class="btn btn-success mt-2">Tạo đối tác</button>
        </form>
    </div>
@endsection
