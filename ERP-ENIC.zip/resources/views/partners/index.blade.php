@extends('layouts.admin')
@section('content')
    <div class="container-fluid mt-3">
        <h1>Danh sách Đối tác</h1>
        <a href="{{ route('partners.create') }}" class="btn btn-primary mb-3">Thêm đối tác mới</a>
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <table class="table table-bordered" id="table1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Email</th>
                    <th>Vai trò</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $roleMapping = [
                        'customer' => 'Khách hàng',
                        'carrier' => 'Hãng tàu',
                        'accountant' => 'Kế toán',
                        'customs_officer' => 'Nhân viên hải quan',
                        'warehouse_staff' => 'Nhân viên kho',
                        'logistics_agent' => 'Đại lý logistics',
                        'admin' => 'Admin',
                    ];
                @endphp

                @foreach ($partners as $partner)
                    <tr>
                        <td>{{ $partner->id }}</td>
                        <td>{{ $partner->name }}</td>
                        <td>{{ $partner->email }}</td>
                        <td>{{ $roleMapping[$partner->role] ?? $partner->role }}</td>
                        <td>
                            <a href="{{ route('partners.show', ['id' => $partner->id]) }}" class="btn btn-info btn-sm">Xem</a>
                            <a href="{{ route('partners.edit', ['id' => $partner->id]) }}"
                                class="btn btn-warning btn-sm">Sửa</a>
                            <a href="{{ route('partners.delete', ['id' => $partner->id]) }}"
                                class="btn btn-danger btn-sm">Xoá</a>
                        </td>
                    </tr>
                @endforeach

            </tbody>
        </table>

     
    @endsection
