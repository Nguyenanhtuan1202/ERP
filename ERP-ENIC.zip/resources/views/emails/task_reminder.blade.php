<!DOCTYPE html>
<html>

<head>
    <title>Nhắc nhở công việc</title>
</head>

<body>
    <h2>Xin chào, {{ $task->user->name }}</h2>
    <p>Bạn có một công việc quan trọng:</p>
    <p><strong>{{ $task->title }}</strong></p>
    <p>{{ $task->description }}</p>
    <p>Thời gian: {{ $task->reminder_time }}</p>
</body>

</html>
