@extends('layouts.layout_factory')

@section('content')
    <div class="container mt-5">
        <h2 class="mb-4">Danh sách ghi chú</h2>

        <a class="add__notes" href="{{ route('notes.create') }}"> <i class="fas fa-edit"></i> Thêm Mới</a>

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif
        @if ($notes->isEmpty())
            <p>Không có ghi chú nào.</p>
        @else
            <div class="notes-list">
                @foreach ($notes as $note)
                    <div class="card note-card mb-3">
                        <div class="card-body">
                            <div class="note-header d-flex justify-content-between">
                                <span class="note-id">#{{ $note->id }}</span>
                                <span class="note-date">{{ $note->created_at->format('H:i d/m/Y') }}</span>
                            </div>
                            <div class="note-content mt-2">
                                {{ $note->content }}
                            </div>
                            <div class="note-actions mt-3 text-end">
                                <a href="{{ route('notes.editNote', ['id' => $note->id]) }}" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Sửa
                                </a>
                                <form action="{{ route('notes.delete', ['id' => $note->id]) }}" method="GET"
                                    class="d-inline-block"
                                    onsubmit="return confirm('Bạn có chắc chắn muốn xóa ghi chú này?')">
                                    @csrf

                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i> Xóa
                                    </button>
                                </form>
                                <button type="button" class="btn btn-sm btn-info expand-note-btn"
                                    onclick="toggleExpand(this)">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="note-extra mt-3" style="display: none;">
                                <!-- Phần chi tiết của ghi chú, bạn có thể bổ sung thêm các trường khác nếu cần -->
                                <p><strong>Nội dung chi tiết:</strong></p>
                                <p>{{ $note->content }}</p>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection

@section('js')
    <script>
        // Hàm hiển thị/ẩn phần chi tiết của ghi chú
        function toggleExpand(btn) {
            let noteExtra = btn.closest('.card').querySelector('.note-extra');
            if (noteExtra.style.display === 'none' || noteExtra.style.display === '') {
                noteExtra.style.display = 'block';
                btn.innerHTML = '<i class="fas fa-chevron-up"></i>';
            } else {
                noteExtra.style.display = 'none';
                btn.innerHTML = '<i class="fas fa-chevron-down"></i>';
            }
        }
    </script>
@endsection

<style>
    .notes-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .note-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        transition: box-shadow 0.3s;
    }

    .note-card:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .note-header {
        font-size: 0.9rem;
        color: #777;
    }

    .note-content {
        font-size: 14px;
        color: #333;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
    }

    .note-actions .btn {
        margin-right: 5px;
    }

    .note-extra {
        background-color: #f9f9f9;
        padding: 10px;
        border-radius: 4px;
        font-size: 0.95rem;
        color: #555;
    }

    .add__notes {
        display: inline-block;
        margin-bottom: 10px;
        background-color: #0caf60;
        padding: 8px 14px;
        border-radius: 5px;
        font-weight: 400;
        color: #fff;
        font-weight: 700;
    }

    .add__notes:hover {
        color: #fff;
    }
</style>
