@extends('layouts.layout_factory')

@section('content')
    <div class="container-fluid mt-5 box__container-notes">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <h2 class="pt-3">Tạo ghi chú mới</h2>
        <p id="current-time"></p>

        <form action="{{ route('notes.store') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group">
                @error('content')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label for="content">Nội dung:</label>
                <textarea class="form-control" name="content" cols="30" rows="3"></textarea>
            </div>

            <div class="box__fix-bottom">
                <button type="button" class="icon-btn" onclick="toggleBox('image-box')">📷</button>
                <button type="button" class="icon-btn" onclick="toggleBox('video-box')">🎥</button>
                <button type="button" class="icon-btn" onclick="toggleBox('audio-box')">🎙️</button>
                <button type="button" class="icon-btn" onclick="toggleBox('draw-box')">✍️</button>
                <button type="button" class="icon-btn remove-btn" onclick="hideAllFeatures()">❌</button>
                <button type="submit" class="btn mt-2 btn__save">Lưu <i class="far fa-save"></i></button>
            </div>

            <!-- Hộp chức năng cho ảnh -->
            <div id="image-box" class="feature-box">
                @error('image')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Chọn ảnh:</label>
                <input type="file" name="image[]" multiple id="imageInput" accept="image/*">
                <div id="imagePreviewContainer" class="preview-container"></div>
            </div>

            <!-- Hộp chức năng cho video -->
            <div id="video-box" class="feature-box">
                @error('video')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Chọn video:</label>
                <input type="file" name="video[]" multiple id="videoInput" accept="video/*">
                <div id="videoPreviewContainer" class="preview-container"></div>
            </div>

            <!-- Hộp chức năng ghi âm -->
            <div id="audio-box" class="feature-box">
                @error('audio_data')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Ghi âm:</label>
                <button type="button" id="startRecording">🎤 Bắt đầu</button>
                <button type="button" id="stopRecording" disabled>⏹️ Dừng</button>
                <audio id="audio-preview" controls></audio>
                <input type="hidden" name="audio_data" id="audio_data">
            </div>

            <!-- Hộp chức năng vẽ ghi chú -->
            <div id="draw-box" class="feature-box">
                @error('drawing_data')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
                <label>Vẽ ghi chú:</label>
                <canvas id="drawingCanvas"></canvas>
                <div class="drawing-controls">
                    <label>Màu:</label>
                    <input type="color" id="colorPicker" value="#000000">
                    <label>Độ dày:</label>
                    <input type="range" id="penSize" min="1" max="10" value="2">
                </div>
                <div class="drawing-buttons">
                    <button class="button__tool" type="button" onclick="undoDraw()">↩️ Hoàn tác</button>
                    <button class="button__tool" type="button" onclick="clearCanvas()">🗑️ Xóa</button>
                    <button class="button__tool"type="button" onclick="saveDrawing()">💾 Lưu vẽ</button>
                </div>
                <input type="hidden" name="drawing_data" id="drawing_data">
            </div>
        </form>
    </div>
@endsection

@section('js')
    <script>
        // Cập nhật thời gian thực
        function updateTime() {
            let now = new Date();
            let formattedTime =
                `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} ngày ${now.getDate().toString().padStart(2, '0')} tháng ${(now.getMonth() + 1).toString().padStart(2, '0')}, ${now.getFullYear()}`;
            document.getElementById('current-time').innerText = formattedTime;
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Hiển thị hộp chức năng (ẩn các box khác)
        function toggleBox(id) {
            document.querySelectorAll('.feature-box').forEach(box => box.style.display = 'none');
            document.getElementById(id).style.display = 'block';
        }


        // Nút xoá tiện ích: Ẩn tất cả các feature-box
        function hideAllFeatures() {
            document.querySelectorAll('.feature-box').forEach(box => box.style.display = 'none');
        }


        // Preview ảnh (nhiều ảnh)
        document.getElementById("imageInput").addEventListener("change", function(event) {
            const container = document.getElementById("imagePreviewContainer");
            container.innerHTML = "";
            Array.from(event.target.files).forEach(file => {
                let reader = new FileReader();
                reader.onload = function(e) {
                    let img = document.createElement("img");
                    img.src = e.target.result;
                    img.classList.add("preview-img");
                    container.appendChild(img);
                };
                reader.readAsDataURL(file);
            });
        });

        // Preview video (nhiều video)
        document.getElementById("videoInput").addEventListener("change", function(event) {
            const container = document.getElementById("videoPreviewContainer");
            container.innerHTML = "";
            Array.from(event.target.files).forEach(file => {
                let reader = new FileReader();
                reader.onload = function(e) {
                    let video = document.createElement("video");
                    video.src = e.target.result;
                    video.controls = true;
                    video.classList.add("preview-video");
                    container.appendChild(video);
                };
                reader.readAsDataURL(file);
            });
        });

        // Ghi âm giọng nói sử dụng MediaRecorder
        let mediaRecorder;
        let audioChunks = [];
        document.getElementById("startRecording").addEventListener("click", async () => {
            let stream = await navigator.mediaDevices.getUserMedia({
                audio: true
            });
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            mediaRecorder.start();
            mediaRecorder.ondataavailable = event => audioChunks.push(event.data);
            document.getElementById("startRecording").disabled = true;
            document.getElementById("stopRecording").disabled = false;
        });
        document.getElementById("stopRecording").addEventListener("click", () => {
            mediaRecorder.stop();
            mediaRecorder.onstop = () => {
                let audioBlob = new Blob(audioChunks, {
                    type: "audio/mp3"
                });
                let audioUrl = URL.createObjectURL(audioBlob);
                document.getElementById("audio-preview").src = audioUrl;
                document.getElementById("audio_data").value = audioUrl;
                document.getElementById("startRecording").disabled = false;
                document.getElementById("stopRecording").disabled = true;
            };
        });

        // Chức năng vẽ ghi chú
        let canvas = document.getElementById("drawingCanvas");
        let ctx = canvas.getContext("2d");
        let drawing = false;
        let paths = [];
        let currentPath = [];
        canvas.width = 400;
        canvas.height = 300;
        canvas.style.border = "1px solid #000";
        ctx.lineWidth = 2;
        ctx.lineCap = "round";
        ctx.strokeStyle = "#000";

        // Xử lý vẽ bằng chuột
        canvas.addEventListener("mousedown", (event) => startDrawing(event.clientX, event.clientY));
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mousemove", (event) => draw(event.clientX, event.clientY));
        // Xử lý vẽ trên cảm ứng
        canvas.addEventListener("touchstart", (event) => {
            let touch = event.touches[0];
            startDrawing(touch.clientX, touch.clientY);
        });
        canvas.addEventListener("touchend", stopDrawing);
        canvas.addEventListener("touchmove", (event) => {
            let touch = event.touches[0];
            draw(touch.clientX, touch.clientY);
        });

        function startDrawing(x, y) {
            drawing = true;
            currentPath = [];
            ctx.beginPath();
            ctx.moveTo(x - canvas.offsetLeft, y - canvas.offsetTop);
        }

        function stopDrawing() {
            drawing = false;
            if (currentPath.length > 0) {
                paths.push([...currentPath]);
            }
        }

        function draw(x, y) {
            if (!drawing) return;
            let posX = x - canvas.offsetLeft;
            let posY = y - canvas.offsetTop;
            currentPath.push({
                x: posX,
                y: posY,
                color: ctx.strokeStyle,
                size: ctx.lineWidth
            });
            ctx.lineTo(posX, posY);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(posX, posY);
        }

        function clearCanvas() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            paths = [];
        }

        function undoDraw() {
            if (paths.length > 0) {
                paths.pop();
                redrawCanvas();
            }
        }

        function redrawCanvas() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            paths.forEach(path => {
                ctx.beginPath();
                path.forEach(point => {
                    ctx.strokeStyle = point.color;
                    ctx.lineWidth = point.size;
                    ctx.lineTo(point.x, point.y);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(point.x, point.y);
                });
            });
        }
        document.getElementById("colorPicker").addEventListener("change", function() {
            ctx.strokeStyle = this.value;
        });
        document.getElementById("penSize").addEventListener("input", function() {
            ctx.lineWidth = this.value;
        });
        // Lưu bản vẽ dưới dạng base64 và thông báo cho người dùng
        function saveDrawing() {
            let imageData = canvas.toDataURL("image/png");
            document.getElementById("drawing_data").value = imageData;
            alert("Bản vẽ đã được lưu!");
        }
    </script>
@endsection

<style>
    .box__container-notes {
        background-color: #fffcf7;
        padding: 5px;
        height: 100vh;
    }

    .box__container-notes h2 {
        color: #333;
    }

    .box__container-notes textarea.form-control {
        background-color: transparent;
        border: 1px solid #ddd;
        outline: none;
        color: #111;
    }

    .box__fix-bottom {
        position: fixed;
        bottom: 70px;
        left: 0;
        width: 100%;
        background-color: #fffcf7;
        padding: 10px 15px;
        display: flex;
        justify-content: space-around;
        align-items: center;
        z-index: 999;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
    }

    .icon-btn {
        background: none;
        border: none;
        font-size: 16px;
        cursor: pointer;
    }

    .feature-box {
        display: none;
        padding: 10px;
        background: #fff;
        margin-top: -10px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    .btn__save {
        background-color: #28a745 !important;
        border: none;
        color: #fff !important;
        padding: 5px 10px;
        margin-bottom: 10px;
        font-size: 14px;
    }

    .preview-container {
        margin-top: 10px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .preview-img {
        width: 100px;
        border: 1px solid #ddd;
        border-radius: 5px;
        object-fit: cover;
        height: 100px;
    }

    .preview-video {
        width: 150px;
        height: auto;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .drawing-controls {
        margin-top: 10px;

    }

    .drawing-buttons {
        margin-top: 10px;
        display: flex;
        gap: 10px;
    }

    .box__container-notes canvas {
        height: auto;
        width: 100%;
        border: none !important;
    }

    .button__tool {
        font-size: 14px;
        border: none;
        background-color: transparent;
    }

    #startRecording {
        background-color: transparent;
        border: 2px solid #ffc107;
        padding: 5px 10px;
        border-radius: 5px;
        margin-bottom: 7px;
    }

    #stopRecording {
        background-color: transparent;
        border: 2px solid #111;
        padding: 5px 10px;
        border-radius: 5px;
        margin-bottom: 7px;
    }
</style>
