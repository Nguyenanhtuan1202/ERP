@if ($paginator->hasPages())
    <nav role="navigation" aria-label="{{ __('Pagination Navigation') }}"
        class="flex items-center justify-between text-[14px] font-OpenSansRegular ">
        <div class=" m-auto">
            <div class="relative z-0 inline-flex space-x-3 items-center paginate__wrapper">
                {{-- Previous Page Link --}}
                @if ($paginator->onFirstPage())
                    <span aria-disabled="true" aria-label="{{ __('pagination.previous') }}">
                        <span
                            class="items-center justify-center min-w-[40px] min-h-[40px] bg-[#E4E4E4] text-[#0771B1] rounded-full hidden" style="display: none">
                            <i class="fas fa-angle-left "></i>
                        </span>
                    </span>
                @else
                    <a href="{{ $paginator->previousPageUrl() }}" rel="prev"
                        class=" flex items-center justify-center min-w-[40px] icon__pre group min-h-[40px] bg-[#EFF8FF] text-[18px] font-medium leading-6 text-[#111] rounded-[3px] hover:bg-[#061f36]"
                        aria-label="{{ __('pagination.previous') }}">
                        <svg style="fill: #fff" class="fill-[#263c82] group-hover:fill-[#fff]" xmlns="http://www.w3.org/2000/svg" width="6.693" height="11.166"
                            viewBox="0 0 6.693 11.166">
                            <g id="Group_16977" data-name="Group 16977" transform="translate(6.693 11.166) rotate(180)">
                                <path style="fill: #fff" id="Path_48656" data-name="Path 48656"
                                    d="M5.508,11.166a1.453,1.453,0,0,1-.836-.489q-2.044-2.058-4.1-4.1a1.135,1.135,0,0,0-.132-.114A1.118,1.118,0,0,1,.424,4.694a1.637,1.637,0,0,0,.164-.142l4.2-4.2A1.079,1.079,0,0,1,6.57,1.527a1.519,1.519,0,0,1-.267.367q-1.788,1.8-3.585,3.587a1.321,1.321,0,0,1-.124.093,1.189,1.189,0,0,1,.13.094q1.81,1.807,3.618,3.616a1.058,1.058,0,0,1,.3,1.127,1.036,1.036,0,0,1-.84.736c-.024.005-.048.013-.072.019Z"
                                    transform="translate(6.693 11.166) rotate(180)" />
                            </g>
                        </svg>
                    </a>
                @endif

                {{-- Pagination Elements --}}
                @foreach ($elements as $element)
                    {{-- "Three Dots" Separator --}}
                    @if (is_string($element))
                        <span aria-disabled="true">
                            <span
                                class="relative inline-flex space-x-3 items-center px-4 py-2 -ml-px text-gray-700 bg-white border border-gray-300 cursor-default leading-5">{{ $element }}</span>
                        </span>
                    @endif

                    {{-- Array Of Links --}}
                    @if (is_array($element))
                        @foreach ($element as $page => $url)
                            @if ($page == $paginator->currentPage())
                                <span aria-current="page">
                                    <span
                                        class="flex items-center paginate__pre justify-center min-w-[40px] min-h-[40px] font-medium text-[18px] text-[#fff] bg-[#061f36] rounded-[3px]">
                                        {{ $page }}
                                    </span>
                                </span>
                            @else
                                <span>
                                    <a href="{{ $url }}"
                                        class="flex items-center paginate__next justify-center min-w-[40px] min-h-[40px] font-medium  bg-[#EFF8FF] text-[18px]  leading-6 text-[#111] hover:text-[#ffffff] hover:bg-[#061f36] rounded-[3px]"
                                        aria-label="{{ __('Go to page :page', ['page' => $page]) }}">
                                        {{ $page }}
                                    </a>
                                </span>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                {{-- Next Page Link --}}
                @if ($paginator->hasMorePages())
                    <a href="{{ $paginator->nextPageUrl() }}" rel="next"
                        class="flex items-center justify-center group min-w-[40px] icon__next min-h-[40px] bg-[#EFF8FF]  text-[18px] font-medium  hover:bg-[#061f36]  leading-6 text-[#111] rounded-[3px] "
                        aria-label="{{ __('pagination.next') }}">
                        <svg style="fill:#fff" class="fill-[#fff] group-hover:fill-[#fff] " xmlns="http://www.w3.org/2000/svg" width="6.693" height="11.166" viewBox="0 0 6.693 11.166">
                            <g id="Group_16978" data-name="Group 16978" transform="translate(6.693 11.166) rotate(180)">
                              <path style="fill:#fff" id="Path_48655" data-name="Path 48655" d="M5.508,11.166a1.453,1.453,0,0,1-.836-.489q-2.044-2.058-4.1-4.1a1.135,1.135,0,0,0-.132-.114A1.118,1.118,0,0,1,.424,4.694a1.637,1.637,0,0,0,.164-.142l4.2-4.2A1.079,1.079,0,0,1,6.57,1.527a1.519,1.519,0,0,1-.267.367q-1.788,1.8-3.585,3.587a1.321,1.321,0,0,1-.124.093,1.189,1.189,0,0,1,.13.094q1.81,1.807,3.618,3.616a1.058,1.058,0,0,1,.3,1.127,1.036,1.036,0,0,1-.84.736c-.024.005-.048.013-.072.019Z" transform="translate(0 0)"/>
                            </g>
                          </svg>
                    </a>
                @else
                    <span aria-disabled="true" aria-label="{{ __('pagination.next') }}">
                        <span
                            class="hidden items-center justify-center min-w-[40px] min-h-[40px] bg-[#93CEF2] text-[#7ABD39] rounded-full"
                            aria-hidden="true">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    </span>
                @endif
            </div>
        </div>
        </div>
    </nav>
@endif
