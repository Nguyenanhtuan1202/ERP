@extends('layouts.enic')
@section('content')
    <div id="content" class="container-fluid">

        <style>
            .box__process-date {
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                background-color: #f9f9f9;
                margin-bottom: 20px;
            }

            .form-check {
                margin-bottom: 15px;
            }

            .form-check-label {
                margin-left: 10px;
            }

            .form-control.mt-2 {
                margin-top: 10px;
            }

            .btn__process-date {
                cursor: pointer;
            }

            .quantity__ex {
                background-color: #048ea4;
                color: #fff;
                padding: 5px 10px;
                border-radius: 3px;
                margin-left: 10px;
            }

            .product__production {
                background-color: #972f6e;
                padding: 5px 10px;
                color: #fff;
                border-radius: 5px;
            }

            .product__complete {
                background-color: #28a745;
                padding: 5px 10px;
                color: #fff;
                border-radius: 5px;
                font-weight: 600;
            }

            .sku__text {
                border: 1px solid #28a745;
                padding: 8px 20px;
                border-radius: 6px;
                font-weight: 500;
                font-size: 15px;
                width: 160px;
                display: block;
                color: #111;
            }

            .sku__text:hover {
                background-color: #28a745;
                color: #fff;
            }

            .thead__custom {
                font-size: 13px;
                text-align: center;
            }

            .table__custom tr td.product__name {
                vertical-align: middle;
                font-size: 15px !important;
            }

            .tooltip-inner {
                background: #04322d;
                color: #fff;
                opacity: 1 !important;

                /* Màu nền của tooltip */
                color: #fff !important;
                /* Màu chữ */
                font-size: 16px;
                font-weight: 500;
                padding: 10px;
                /* Khoảng cách nội dung */
                border-radius: 8px;
                /* Bo góc */
                text-align: center;
                /* Canh giữa */
                /* Hiệu ứng bóng */
            }

            .tooltip-arrow {
                border-top-color: #0CAF60 !important;
                /* Màu của mũi tên tooltip */
            }

            .tooltip_show:hover i {
                color: #0CAF60;
            }

            .production__completesNew {
                background-color: #0CAF60;
                color: #fff;
                font-size: 30px;
                text-align: center;
                border-radius: 30px;
                width: 55px;
                height: 55px;
                display: flex;
                justify-content: center;
                align-content: center;
                align-items: center;
            }

            .production__completesNew i {
                color: #fff;
            }

            .production__completesNew i:hover {
                color: #fff;
            }

            .box__production__completesNew {
                display: flex;
                justify-content: center;
                align-items: center;
            }
        </style>


        <div class="card  mt-5">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">

            </div>
            <div class="card-body">



                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


                @if (session('messageSuccess'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('messageSuccess') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                <div class="analytic">

                    <button class="btn btn-success mb-3 btn__process-date">Tiến Hành Sản Xuất <i
                            class="fas fa-chevron-down"></i></button>


                    <button class="btn btn-primary ml-3 mb-3 btn__view-process"> <i class="fas fa-th"></i> Xem quá trình sản
                        xuất
                    </button>


                    <button class="btn btn-warning ml-3 mb-3 btn__product-completed"> <i class="fas fa-th"></i> Sản Phẩm
                        Hoàn
                        Thành</button>
                    <div id="productionForm" class="box__process-date" style="display: none;">
                        <form id="productionForm" method="POST" action="{{ route('productions.startProduction') }}">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <label for="productionDate">Ngày Thực Hiện</label>
                                <input type="date" name="production_date" id="productionDate" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label for="sku">Nhập vào mã SKU và Số Lượng cần làm</label>
                                @foreach ($purchaseOrder as $item)
                                    <div class="form-check">
                                        <input type="hidden" name="po_id" value="{{ $item->purchase_order_id ?? '' }}">
                                        <input type="checkbox" class="form-check-input" name="sku[]"
                                            id="sku{{ $item->id }}" value="{{ $item->sku }}">
                                        <label class="form-check-label" for="sku{{ $item->id }}">{{ $item->sku }}
                                            <span class="quantity__ex">Số Lượng Còn Lại:

                                                @if ($item->qty_reality == 0)
                                                    {{ $item->quantity - $item->products_production }}
                                                @else
                                                    {{ $item->quantity - $item->qty_reality }}
                                                @endif

                                            </span>
                                        </label>
                                        <input type="number" class="form-control mt-2"
                                            name="quantity[{{ $item->sku }}]" placeholder="Số Lượng Sản Xuất"
                                            min="1"
                                            max="@if ($item->qty_reality == 0) {{ $item->quantity - $item->products_production }}
                                            @else
                                            {{ $item->quantity - $item->qty_reality ?? '' }} @endif"
                                            data-max="
                                            @if ($item->qty_reality == 0) {{ $item->quantity - $item->products_production }}
                                            @else
                                            {{ $item->quantity - $item->qty_reality ?? '' }} @endif
                                            ">
                                    </div>
                                @endforeach


                            </div>
                            <div id="error-message" class="alert alert-danger" style="display: none;"></div>
                            <button type="submit" class="btn btn-primary">Bắt Đầu Sản Xuất</button>
                        </form>
                    </div>




                    {{-- List Product completed --}}

                    <div class="list__product-completed">


                    </div>

                    <style>
                        /* Bảng */
                        .box__process-view table {
                            max-width: 100%;
                            border-collapse: collapse;
                            margin-bottom: 20px;
                            font-size: 0.95rem;
                        }

                        .box__process-view thead tr {
                            background-color: #4CAF50;
                            color: #ffffff;
                            text-transform: uppercase;
                            letter-spacing: 0.03em;
                        }

                        .box__process-view th,
                        .box__process-view td {
                            padding: 15px;
                            text-align: center;
                            border: 1px solid #ddd;
                            white-space: nowrap;
                            font-size: 14px;
                        }

                        .box__process-view tbody tr:nth-child(even) {
                            background-color: #f9f9f9;
                        }

                        .box__process-view tbody tr:hover {
                            background-color: #f1f1f1;
                            transition: background-color 0.3s ease;
                        }

                        /* Trạng thái */
                        .box__process-view .status {
                            padding: 6px 12px;
                            border-radius: 5px;
                            font-size: 0.85rem;
                            font-weight: bold;
                            text-transform: capitalize;
                            display: inline-block;
                        }

                        .box__process-view .status.in-progress {
                            background-color: #FFC107;
                            color: #fff;
                        }

                        .box__process-view .status.pending {
                            background-color: #17A2B8;
                            color: #fff;
                        }

                        .box__process-view .status.completed {
                            background-color: #28A745;
                            color: #fff;
                        }

                        /* Nút */
                        .box__process-view button {
                            padding: 8px 16px;
                            margin: 5px;
                            border: none;
                            border-radius: 6px;
                            cursor: pointer;
                            font-size: 0.9rem;
                            font-weight: 500;
                            transition: all 0.3s ease;
                        }

                        .box__process-view button.edit-btn {
                            background-color: #007bff;
                            color: #fff;
                        }

                        .box__process-view button.edit-btn:hover {
                            background-color: #0056b3;
                        }

                        .box__process-view button.update-status-btn {
                            background-color: #28a745;
                            color: #fff;
                        }

                        .box__process-view button.update-status-btn:hover {
                            background-color: #1e7e34;
                        }

                        .update__quatity-real {
                            border: none;
                            border-bottom: 1px solid #dc3545;
                            outline: none;
                            font-size: 14px;
                            background-color: transparent;
                            color: #060606;
                        }

                        .qty__forcaste {
                            background-color: #17a2b8;
                            padding: 5px 10px;
                            border-radius: 5px;
                            font-weight: 600;
                            color: #fff;
                        }

                        .qty_noproduction {
                            background-color: #c61212;
                            padding: 5px 10px;
                            border-radius: 5px;
                            font-weight: 600;
                            color: #fff;
                        }

                        .qty__realitys {
                            background-color: #07075e;
                            padding: 5px 20px;
                            border-radius: 5px;
                            font-weight: 600;
                            color: #fff;
                        }

                        /* Tạo màu nền xen kẽ giữa các nhóm SKU */
                        .group-sku-odd {
                            background-color: #f9f9f9;

                            /* Màu nền nhạt */
                        }

                        .group-sku-odd {
                            border-bottom: 3px solid #111;
                        }

                        .group-sku-even {
                            background-color: #ffffff;
                            /* Màu nền trắng */
                        }

                        /* Tạo đường viền để phân cách rõ */
                        .group-row td {
                            border-bottom: 2px solid #ddd;
                            /* Đường viền dưới nhóm */
                        }

                        /* Style cho ô chứa SKU */
                        .sku-cell {
                            font-weight: bold;
                            background-color: #e0f7fa;
                            /* Màu nền nhấn mạnh */
                            text-align: center;
                        }
                    </style>


                    <div class="box__process-view" style="display: none">
                        <table id="ordersTable" class=" table  table-responsive">
                            <thead>
                                <tr>
                                    <th>SKU</th>
                                    <th>Ngày Bắt Đầu Làm</th>
                                    <th>Quá Trình Sản Xuất</th>
                                    <th>SL Hoàn Thành</th>
                                    <th>Ghi Chú</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Hàng mẫu -->
                                @php
                                    $temp = 0;
                                @endphp


                                @forelse ($groupedData as $sku => $items)
                                    @php
                                        $rowCount = $items->count();
                                        $groupClass = $loop->iteration % 2 === 0 ? 'group-sku-even' : 'group-sku-odd';

                                        $total = 0; // Khởi tạo tổng số lượng đã sản xuất
                                    @endphp
                                    @foreach ($items as $index => $item)
                                        @php
                                            $total += $item->quantity_completed;
                                        @endphp
                                        <tr class="group-row {{ $groupClass }}">
                                            @if ($index === 0)
                                                <!-- Hiển thị SKU một lần -->
                                                <td class="sku-cell" rowspan="{{ $rowCount }}">{{ $sku }}
                                                </td>
                                            @endif

                                            <td class="text-center">{{ $item->production_date ?? '' }}</td>

                                            @if ($item->quantity_production == 0)
                                                <td>
                                                    <i style="color: #fff" class="fas fa-check-double"></i> Đã sản xuất
                                                    xong

                                                </td>
                                            @else
                                                <td class="text-center">
                                                    <span
                                                        class="qty__forcaste">{{ $item->quantity_production ?? '' }}</span>
                                                    <form id="updateQuantityForm" method="POST"
                                                        action="{{ route('productions.updateQuantity', [$item->id]) }}">
                                                        {{ csrf_field() }}
                                                        <input type="hidden" name="po_id"
                                                            value="{{ $item->purchase_order_id ?? '' }}">
                                                        <input type="hidden" name="c_id" value="{{ $item->id ?? '' }}">
                                                        <input type="hidden" name="purchase_order_item_id"
                                                            value="{{ $item->purchase_order_item_id ?? '' }}">
                                                        <input type="hidden" name="sku"
                                                            value="{{ $item->sku ?? '' }}">
                                                        <input type="tel" class="update__quatity-real"
                                                            name="products_production" value="" min="0"
                                                            max="{{ $item->quantity_production ?? '' }}"
                                                            placeholder="Cập nhật SL đã sản xuất xong">

                                                        <span class="error-message" style="color: red; display: none;">Vui
                                                            lòng nhập giá trị hợp lệ.</span>

                                                        <button type="submit" class="btn btn-primary">Cập Nhật</button>
                                                    </form>
                                                </td>
                                            @endif

                                            <td class="text-center">
                                                <span class="product__complete">
                                                    @if ($item->quantity_production == 0)
                                                        <i style="color: #fff" class="fas fa-check-double"></i>
                                                    @endif
                                                    {{ $item->quantity_completed ?? 0 }}
                                                </span>
                                            </td>
                                            <td>
                                                <textarea name="note" id="">{{ $item->note ?? '' }}</textarea>
                                            </td>

                                        </tr>
                                    @endforeach
                                @empty
                                    <tr>
                                        <td colspan="5">Chưa có sản phẩm nào đang sản xuất</td>
                                    </tr>
                                @endforelse

                            </tbody>
                        </table>
                    </div>


                </div>

                <table class="table table__custom">
                    <thead class="thead__custom">
                        <tr>
                            <th>STT</th>
                            <th>Mã SKU</th>
                            <th>Tên Sản Phẩm</th>
                            <th>Số Lượng Đặt</th>
                            {{-- <th>Số Lượng Đang Sản Xuất</th> --}}
                            <th>Số Lượng Hoàn Thành</th>
                            <th>Cập Nhật <i style="color: rgb(34, 135, 34); font-size: 18px;"
                                    class="fas fa-check-circle"></i></th>
                            <th>Đơn Giá</th>
                            <th>Thành Tiền</th>
                            <th>Ngày Dự Kiến Hoàn Thành</th>
                            <th>Trạng Thái</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        {{-- @php
                            $temp = 0;
                        @endphp

                        @foreach ($purchaseOrder as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr>
                                <td>{{ $temp }}</td>
                                <td class="text-center">
                                    <!-- Mã SKU là một liên kết mở modal -->
                                    <a class="sku__text">
                                        {{ $item->sku }}
                                    </a>
                                </td>
                                <td class="text-center product__name">{{ $item->product->name }}</td>
                                <td class="text-center"> <span class="qty__realitys">{{ $item->quantity }}</span> </td>





                                <td class="text-center"><span class="product__complete">
                                        {{ $item->qty_reality ?? 0 }}</span> </td>
                                <td>
                                    @if ($item->qty_reality == $item->quantity)
                                        <div class="box__production__completesNew"><a class="production__completesNew"><i
                                                    class="far fa-check-circle "></i></a></div>
                                    @else
                                        <a class="tooltip_show"
                                            onclick="return confirm('Bạn có chắc chắn sản phẩm đã sản xuất hết số lượng không ? ')"
                                            href="{{ route('production.show', ['id' => $item->purchase_order_id ?? '', 'sku' => $item->sku, 'qty' => $item->quantity]) }}"
                                            data-toggle="tooltip" data-placement="top"
                                            title="Nhấn Vào Nếu Sản Phẩm Đã Sản Xuất Xong"
                                            style="color: #111; font-size: 30px; text-align: center; display: block"><i
                                                class="far fa-check-circle "></i></a>
                                    @endif


                                </td>
                                <td class="text-center">{{ number_format($item->unit_price) }}</td>
                                <td class="text-center">{{ number_format($item->subtotal) }}</td>
                                <td class="text-center">{{ date('d-m-Y', strtotime($item->expected_date ?? '')) }}</td>
                                <td class="text-center">
                                    @if ($item->status == 'Đã hoàn thành')
                                        <span style="padding:6px 12px; font-size: 13px;"
                                            class="badge badge-success">{{ $item->status ?? '' }}</span>
                                    @else
                                        <span style="padding:6px 12px; font-size: 13px;"
                                            class="badge badge-warning">{{ $item->status ?? '' }}</span>
                                    @endif
                                </td>


                                <td class="text-center" title="Lên lịch hoạt động để giúp bạn hoàn thành công việc.">
                                    <button type="button" class="btn plan__work" data-toggle="modal"
                                        data-target="#planWorkModal-{{ $item->id }}">
                                        <i class="fas fa-th"></i>
                                    </button>

                                    <!-- Plan Work Modal -->
                                    <div class="modal fade" id="planWorkModal-{{ $item->id }}" tabindex="-1"
                                        role="dialog" aria-labelledby="planWorkModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-center" style="width: 100%;"
                                                        id="planWorkModalLabel">Cập Nhật Quá Trình Sản
                                                        Xuất</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form id="planWorkForm">
                                                        {{ csrf_field() }}

                                                        @if ($item->quantity == $item->qty_reality)
                                                            <div>

                                                                <div class="confirmation-container">
                                                                    <div class="checkmark-container">
                                                                        <svg class="checkmark"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 52 52">
                                                                            <circle class="checkmark-circle"
                                                                                cx="26" cy="26" r="25"
                                                                                fill="none" />
                                                                            <path class="checkmark-check" fill="none"
                                                                                stroke="#4CAF50" stroke-width="5"
                                                                                d="M14 27l7 7 16-16" />
                                                                        </svg>
                                                                    </div>

                                                                    <p> Mã SKU <strong>{{ $item->sku ?? '' }}</strong> đã
                                                                        sản xuất xong </p </div>


                                                                    <div class="box__production__completesNew mt-5">
                                                                        <a class="tooltip_show production__completesNew"
                                                                            onclick="return confirm('Bạn có chắc chắn khôi phục lại dữ liệu không ? ')"
                                                                            href="{{ route('production.show', ['id' => $item->purchase_order_id ?? '', 'sku' => $item->sku, 'qty' => $item->quantity, 'status' => 'reset']) }}"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="Nhấn Vào Đây Nếu Muốn Cập Nhật Lại Sản Phẩm"
                                                                            style="color: #111; font-size: 30px; text-align: center; display: block"><i
                                                                                class="fas fa-undo-alt "></i></a>
                                                                    </div>



                                                                </div>
                                                            @else
                                                                <input type="hidden" name="sku"
                                                                    value="{{ $item->sku ?? '' }}">
                                                                <input type="hidden" name="purchase_order_id"
                                                                    value="{{ $item->purchase_order_id ?? '' }}">
                                                                <div class="form-group">
                                                                    <label for="task">Nhấn Dấu Tích</label>
                                                                    <span>Số lượng đặt hàng
                                                                        {{ $item->quantity ?? '' }}</span>
                                                                    <span>Số Lượng Hoàn Thành
                                                                        {{ $item->qty_reality ?? '' }}</span>
                                                                    <input type="checkbox" class="form-control"
                                                                        id="task" name="completePo" placeholder="">
                                                                </div>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Lưu</button>
                                                        @endif


                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        @endforeach --}}
                    </tbody>
                </table>


            </div>
        </div>
    </div>
@endsection


@section('js')
    <script>
        document.querySelectorAll('.update__quatity-real').forEach(input => {
            input.addEventListener('input', function() {
                const max = parseInt(this.getAttribute('max'), 10);
                const min = parseInt(this.getAttribute('min'), 10);
                const value = parseInt(this.value, 10);

                if (value > max || value < min) {
                    this.nextElementSibling.style.display = 'block'; // Hiện thông báo lỗi
                    this.setCustomValidity("Vui lòng nhập số lượng nhỏ hơn hoặc bằng" + max);
                } else {
                    this.nextElementSibling.style.display = 'none'; // Ẩn thông báo lỗi
                    this.setCustomValidity("");
                }
            });
        });


        $(function() {
            $('[data-toggle="tooltip"]').tooltip(); // Kích hoạt tooltip


            $(".btn__process-date").on("click", function() {
                $(".box__process-view, .list__product-completed").hide(); // Hide other sections
                $(".box__process-date").toggle(); // Toggle the current section
            });

            $('.btn__view-process').on("click", function() {
                $(".box__process-date, .list__product-completed").hide(); // Hide other sections
                $(".box__process-view").toggle(); // Toggle the current section
            });

            $('.btn__product-completed').on("click", function() {
                $(".box__process-date, .box__process-view").hide(); // Hide other sections
                $(".list__product-completed").toggle(); // Toggle the current section
            });


            $(document).ready(function() {
                // Khi submit form
                $('#productionForm').submit(function(event) {
                    let isValid = true; // Đánh dấu form hợp lệ
                    let errorMessages = []; // Lưu trữ lỗi

                    // Lặp qua từng SKU được chọn
                    $('input[name="sku[]"]:checked').each(function() {
                        const sku = $(this).val(); // Lấy giá trị SKU
                        const quantityInput = $(
                            `input[name="quantity[${sku}]"]`); // Trường số lượng tương ứng
                        const quantity = parseInt(quantityInput.val(),
                            10); // Lấy giá trị số lượng
                        const maxQuantity = parseInt(quantityInput.data('max'),
                            10); // Lấy số lượng tối đa

                        // Kiểm tra số lượng nhập vào
                        if (!quantity || quantity <= 0 || quantity > maxQuantity) {
                            isValid = false;
                            errorMessages.push(
                                `Vui lòng nhập số lượng hợp lệ cho SKU ${sku} (tối đa ${maxQuantity}).`
                            );
                            quantityInput.focus(); // Đưa con trỏ vào trường lỗi đầu tiên
                            return false; // Thoát khỏi vòng lặp nếu phát hiện lỗi
                        }
                    });

                    // Kiểm tra nếu không có SKU nào được chọn
                    if ($('input[name="sku[]"]:checked').length === 0) {
                        isValid = false;
                        errorMessages.push('Vui lòng chọn ít nhất một mã SKU.');
                    }

                    // Hiển thị lỗi nếu có
                    if (!isValid) {
                        event.preventDefault(); // Ngăn gửi form
                        $('#error-message').html(errorMessages.join('<br>'))
                            .show(); // Hiển thị danh sách lỗi
                    } else {
                        $('#error-message').hide(); // Ẩn thông báo lỗi nếu không có lỗi
                    }
                });

                // Ẩn trường `quantity` nếu SKU chưa chọn
                $('input[name="sku[]"]').on('change', function() {
                    const sku = $(this).val();
                    const quantityInput = $(`input[name="quantity[${sku}]"]`);
                    if ($(this).is(':checked')) {
                        quantityInput.prop('disabled', false); // Bật trường số lượng
                    } else {
                        quantityInput.prop('disabled', true).val(''); // Tắt và xóa giá trị
                    }
                });

                // Đảm bảo trạng thái đúng khi tải trang
                $('input[name="sku[]"]').each(function() {
                    const sku = $(this).val();
                    const quantityInput = $(`input[name="quantity[${sku}]"]`);
                    if ($(this).is(':checked')) {
                        quantityInput.prop('disabled', false);
                    } else {
                        quantityInput.prop('disabled', true);
                    }
                });

                // Ẩn thông báo lỗi khi nhập liệu
                $('input[name^="quantity"]').on('input', function() {
                    $('#error-message').hide();
                });
            });


            // $('#updateQuantityForm').submit(function(event) {
            //     event.preventDefault();

            //     const formData = $(this).serialize();

            //     $.ajax({
            //         url: $(this).attr('action'),
            //         method: 'POST',
            //         data: formData,
            //         success: function(response) {
            //             Swal.fire({
            //                 title: 'Thông báo',
            //                 text: response.message,
            //                 icon: 'success',
            //                 confirmButtonText: 'OK',
            //                 confirmButtonColor: '#3085d6',
            //                 background: '#fff',
            //                 timer: 5000,
            //                 timerProgressBar: true,
            //             });
            //         },
            //         error: function(xhr) {
            //             Swal.fire({
            //                 title: 'Lỗi',
            //                 text: xhr.responseJSON.message,
            //                 icon: 'error',
            //                 confirmButtonText: 'OK',
            //                 confirmButtonColor: '#d33',
            //                 background: '#fff',
            //             });
            //         }
            //     });
            // });


        });
    </script>
@endsection
