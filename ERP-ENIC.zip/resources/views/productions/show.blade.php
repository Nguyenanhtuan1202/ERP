@extends('layouts.layout_factory')

@section('css')
    <link rel="stylesheet" href="{{ asset('css/production.css') }}">
@endsection
@section('content')
    <div id="content" class="container-fluid">
        <div class="card  mt-5">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">

            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col-md-4">
                        <a class="backPage mb-3" style="display: inline-block" href="{{ route('production.index') }}">Quay
                            Lại
                            <i class="fas fa-undo-alt"></i></a>
                        <h4 class="mb-5 title__list-po">

                            <span style="font-weight: 600">Mã Đơn {{ $purchaseOrderNew->total_quantity ?? '' }} | </span>
                            <span style="color: #0CAF60; font-weight: 700;">{{ $purchaseOrderNew->po_id ?? '' }}
                            </span>

                        </h4>

                    </div>

                    <div class="col-md-5 mb-3">
                        <div class="guild_uploads">
                            <h3 class="">Lưu ý:</h3>
                            <p style="color: #111 ">- Nếu ngày dự kiến hoàn thành <strong style="color: red">(chữ màu đỏ)
                                </strong> => đơn hàng cần
                                làm gấp để kịp giao.</p>
                            <p style="color: #111">- Cần nhập chính xác <strong> số lượng </strong> trước khi giao hàng qua
                                kho.</p>

                        </div>
                    </div>


                </div>


                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


                @if (session('messageSuccess'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('messageSuccess') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                <form action="{{ route('factory.delivery') }}" method="POST" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <table class="table table__custom table-responsive" id="table1">
                        <thead class="thead__custom">
                            <tr>
                                <th>STT</th>
                                <th>Mã SKU</th>
                                <th>Tên Sản Phẩm</th>
                                <th>Số Lượng Đặt</th>
                                <th>Số Lượng Hoàn Thành</th>
                                <th>Số Lượng Giao</th>
                                <th>Ngày Dự Kiến Giao Hàng</th>
                                <th>Trạng Thái</th>
                                <th>Nhắc Nhở</th>

                            </tr>
                        </thead>
                        <tbody>

                            {{ csrf_field() }}
                            @php
                                $temp = 0;
                            @endphp

                            @foreach ($purchaseOrder as $item)
                                @php
                                    $temp++;
                                @endphp



                                <tr class="{{ $item->is_delivery == 1 ? 'is__delivery' : '' }}">
                                    <td>{{ $temp }}</td>
                                    <td class="text-center">
                                        <!-- Mã SKU là một liên kết mở modal -->
                                        <a class="sku__text">
                                            {{ $item->sku }}
                                        </a>
                                    </td>
                                    <td class="text-center product__name">{{ $item->product->name }}</td>
                                    <td class="text-center"> <span class="qty__realitys">{{ $item->quantity }}</span> </td>

                                    <td class="text-center"><span
                                            class="{{ $item->qty_reality >= $item->quantity ? 'product__complete' : 'product__nocomplete' }} ">
                                            {{ $item->products_production ?? 0 }}</span>


                                    </td>
                                    <td>
                                        <!-- Các input hidden để gửi thêm thông tin cần thiết -->
                                        <input type="hidden" name="data[{{ $item->sku }}][purchase_order_id]"
                                            value="{{ $item->purchase_order_id }}">
                                        <input type="hidden" name="data[{{ $item->sku }}][sku]"
                                            value="{{ $item->sku }}">
                                        <input type="hidden" name="data[{{ $item->sku }}][name]"
                                            value="{{ $item->product->name }}">
                                        <input type="hidden" name="data[{{ $item->sku }}][order_quantity]"
                                            value="{{ $item->quantity }}">
                                        <input type="hidden" name="data[{{ $item->sku }}][products_production]"
                                            value="{{ $item->products_production ?? 0 }}">
                                        @if ($item->qty_reality >= $item->quantity)
                                            <input style="border: 2px solid #28a745; background-color: #28a745;"
                                                type="number" readonly class="qty_product_delivery qty__compete"
                                                value="" placeholder="Đã giao đủ"
                                                name="data[{{ $item->sku }}][qty_product_delivery]">
                                        @else
                                            <input type="number" class="qty_product_delivery"
                                                name="data[{{ $item->sku }}][qty_product_delivery]"
                                                placeholder="Nhập số lượng giao">
                                        @endif

                                    </td>


                                    <td
                                        class="text-center font-weight-bold {{ strtotime($item->expected_date ?? '') <= strtotime(date('Y-m-d')) ? 'text-danger' : 'text-success' }}">
                                        {{ date('d-m-Y', strtotime($item->expected_date ?? '')) }}
                                    </td>

                                    <td class="text-center">
                                        @if ($item->status == 'Đã hoàn thành')
                                            <span style="padding:6px 12px; font-size: 13px;"
                                                class="badge badge-success">{{ $item->status ?? '' }}</span>
                                        @else
                                            <span style="padding:6px 12px; font-size: 13px;"
                                                class="badge badge-warning">{{ $item->status ?? '' }}</span>
                                        @endif
                                    </td>

                                    <td>
                                        @if ($item->qty_reality > $item->quantity)
                                            <span class="production__more">Xưởng Làm Dư: 
                                               <br> {{ $item->qty_reality - $item->quantity }} Sku {{$item->sku ?? ""}} 
                                            </span>
                                        @endif
                                        @if ($item->delivery_note !== null)
                                            <span class="production__more">
                                                {{ $item->delivery_note ?? '' }}
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach

                            <!-- Container hiển thị summary của các SKU giao bổ sung -->
                            <div id="additionalDeliverySummary" class="mt-3">
                                <!-- Nội dung summary sẽ được cập nhật tự động -->
                            </div>

                            <!-- Nút mở modal giao bổ sung -->
                            <button type="button" class="delivery__more " data-toggle="modal"
                                data-target="#additionalDeliveryModal">
                                Mở Rộng <i class="fas fa-plus"></i>
                            </button>

                            <!-- Nút submit form giao hàng -->
                            <button type="submit" class="submit__delivery sumbit__confirm-delivery">
                                Giao Hàng <i class="fas fa-truck"></i>
                            </button>

                            <button type="button" class="history__delivery" id="btnDeliveryHistory">
                                Lịch Sử Giao Hàng <i class="fas fa-history"></i>
                            </button>


                            <button type="button" class="print__order"
                                onclick="openPdfModal({{ $purchaseOrderNew->id }})">
                                In File <i class="fas fa-print"></i>
                            </button>

                        </tbody>
                    </table>


                    <!-- Container ẩn để chứa các hidden input bổ sung (sẽ chuyển từ modal khi modal đóng) -->
                    <div id="hiddenAdditionalData" style="display: none;"></div>

                    <!-- Modal cho dữ liệu giao bổ sung -->
                    <div class="modal fade" id="additionalDeliveryModal" tabindex="-1" role="dialog"
                        aria-labelledby="additionalDeliveryModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h5 class="modal-title" id="additionalDeliveryModalLabel">Thêm giao bổ sung</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Đóng">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <!-- Modal Body -->
                                <div class="modal-body">
                                    <!-- Container chứa các dòng nhập bổ sung (vẫn có input hiển thị để nhập) -->

                                    <button type="button" class="addSkuMore">Thêm SKU Bổ Sung <i
                                            class="fas fa-plus-circle"></i></button> <br>
                                    <hr>
                                    <div class="box__addSkuMore">
                                        <div id="additionalDeliveryContainer"></div>
                                        <!-- Nút thêm dòng mới -->
                                        <button type="button" id="addDeliveryRow" class="btn btn-secondary">Thêm
                                            dòng</button>
                                    </div>

                                    <!-- Phần Upload hình ảnh -->
                                    <div class="mb-3">
                                        <label for="images"><strong>Upload hình ảnh (nhiều ảnh):</strong></label>
                                        <input type="file" id="images" name="images[]" multiple accept="image/*"
                                            class="form-control">
                                    </div>


                                    <!-- Phần Chụp ảnh qua camera -->
                                    <div class="mb-3">
                                        <button type="button" id="capture" class="btn btn-primary">📸 Chụp
                                            ảnh</button>
                                        <input type="hidden" id="imageData" name="imageData">
                                    </div>

                                    <!-- Container hiển thị preview hình ảnh đã chọn/chụp -->
                                    <div id="preview" class="d-flex flex-wrap"></div>

                                    <!-- Phần video và canvas để chụp ảnh (ẩn) -->
                                    <video id="camera" autoplay
                                        style="display: none;max-width: 100%;border-radius: 10px;"></video>
                                    <canvas id="canvas" style="display: none;"></canvas>

                                </div>
                                <!-- Modal Footer -->
                                <div class="modal-footer">
                                    <!-- Nút đóng modal -->
                                    <button type="button" class="btn btn-secondary close__save"
                                        data-dismiss="modal">Đóng Và Lưu <i class="far fa-save"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal hiển thị lịch sử giao hàng -->
                    <div id="deliveryHistoryModal" class="modal__custom">
                        <div class="modal-content">
                            <span class="close_custom">&times;</span>
                            <h2>Lịch sử giao hàng</h2>


                            @if ($data_history_delivery)
                                @foreach ($data_history_delivery as $item)
                                    <div class="delivery-history-details">
                                        <p style="color: #0caf60;font-weight: 600;font-size: 16px;"> Thời gian xuất hàng:
                                            {{ $item->created_at ?? '' }}</p>
                                        <div class="info-row">
                                            <label>Mã Đơn Hàng:</label>
                                            <span>{{ $item->purchaseOrder->po_id ?? '' }}</span>
                                        </div>
                                        <div class="info-row">
                                            <label>Tổng số lượng giao:</label>
                                            <span>{{ $item->total_qty ?? '' }}</span>
                                        </div>
                                        <div class="sku-details">
                                            <h3>Danh sách mã SKU đã giao:</h3>
                                            <table class="sku-table">
                                                <thead>
                                                    <tr>
                                                        <th>SKU</th>
                                                        <th>Tên sản phẩm</th>
                                                        <th>Số lượng</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                        $skuDetails = json_decode($item->sku_details, true);
                                                    @endphp
                                                    @if ($skuDetails)
                                                        @foreach ($skuDetails as $sku)
                                                            <tr>
                                                                <td>{{ $sku['sku'] ?? 'N/A' }}</td>
                                                                <td>{{ $sku['name'] ?? 'N/A' }}</td>
                                                                <td>{{ $sku['delivered_qty'] ?? 0 }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td colspan="3">Không có thông tin SKU.</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                @endforeach
                            @else
                                <p>Không có lịch sử giao hàng nào.</p>
                            @endif
                        </div>
                    </div>




                    {{-- Đơn hàng PDF --}}
                    <div class="modal fade" id="pdfModal" tabindex="-1" aria-labelledby="pdfModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="pdfModalLabel">Xem Đơn Hàng PDF</h5>
                                    <button type="button" class="btn-close close_print_order" data-bs-dismiss="modal"
                                        aria-label="Close"><i class="far fa-times-circle"></i></button>
                                </div>
                                <div class="modal-body">
                                    <iframe id="pdfViewer" width="100%" height="500px"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Container ẩn để chứa các hidden input chuyển từ modal (dữ liệu giao bổ sung) -->
                    <div id="hiddenAdditionalData" style="display:none;"></div>

                    <!-- Container hiển thị summary của giao bổ sung -->
                    <div id="additionalDeliverySummary"></div>

                    <!-- Container ẩn để lưu thông tin hình ảnh dưới dạng hidden input -->
                    <div id="hiddenImages" style="display:none;"></div>

                    <!-- Container hiển thị summary hình ảnh đã upload/chụp -->
                    <div id="additionalImagesSummary"></div>

                </form>
            </div>
        </div>
    </div>
@endsection


@section('js')
    <script>
        function openPdfModal(orderId) {
            let pdfUrl = @json(route('purchase-order.preview', ['id' => '__ID__']));
            pdfUrl = pdfUrl.replace('__ID__', orderId); // Thay ID vào URL

            document.getElementById('pdfViewer').src = pdfUrl;
            var myModal = new bootstrap.Modal(document.getElementById('pdfModal'));
            myModal.show();

            let closeButton = document.querySelector("#pdfModal .btn-close");

            // Xóa sự kiện cũ trước khi thêm mới (tránh trùng sự kiện)
            closeButton.removeEventListener("click", closeModal);
            closeButton.addEventListener("click", closeModal);

            function closeModal() {
                myModal.hide();
            }
        }

        // Xử lý modal lịch sử giao hàng
        var modal = document.getElementById("deliveryHistoryModal");
        var btn = document.getElementById("btnDeliveryHistory");
        var closeBtn = document.getElementsByClassName("close_custom")[0];

        // Mở modal khi nhấn nút
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Đóng modal khi nhấn vào nút đóng
        closeBtn.onclick = function() {
            modal.style.display = "none";
        }

        // Đóng modal khi click bên ngoài nội dung modal
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        /* Xử lý form kiểm tra số lượng trước khi submit form  */
        document.querySelector(".sumbit__confirm-delivery").addEventListener("click", function(event) {
            event.preventDefault(); // Ngăn form submit ngay lập tức

            // Lấy tất cả các input có class "qty_product_delivery"
            let qtyInputs = document.querySelectorAll(".qty_product_delivery");

            // Kiểm tra xem có ít nhất một input có giá trị hay không
            let atLeastOneFilled = false;
            qtyInputs.forEach(function(input) {
                if (input.value.trim() !== "") {
                    atLeastOneFilled = true;
                }
            });

            if (!atLeastOneFilled) {
                Swal.fire({
                    title: "Lỗi!",
                    text: "Vui lòng nhập số lượng giao hàng ít nhất một sản phẩm!",
                    icon: "error",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#d33"
                });
                return; // Dừng lại nếu không có input nào có giá trị
            }

            // Nếu có ít nhất một input có giá trị, hiển thị xác nhận
            Swal.fire({
                title: "Xác nhận",
                text: "Hãy kiểm tra lại số lượng giao hàng trước khi xác nhận!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Xác nhận giao hàng",
                cancelButtonText: "Hủy"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Gửi form khi người dùng nhấn "Xác nhận"
                    document.querySelector(".sumbit__confirm-delivery").closest("form").submit();
                }
            });
        });


        /* Copy sku  */
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelectorAll(".sku__text").forEach(function(element) {
                element.addEventListener("click", function() {
                    let skuText = this.textContent
                        .trim(); // Lấy nội dung SKU và loại bỏ khoảng trắng thừa

                    // Sao chép vào clipboard
                    navigator.clipboard.writeText(skuText).then(() => {
                        showCopyMessage(this); // Hiển thị thông báo ngay dưới SKU
                    }).catch(err => {
                        console.error("Lỗi khi sao chép:", err);
                    });
                });
            });

            function showCopyMessage(element) {
                // Kiểm tra xem đã có thông báo trước đó chưa, nếu có thì xoá trước khi thêm mới
                let existingMessage = element.nextElementSibling;
                if (existingMessage && existingMessage.classList.contains("copy-message")) {
                    existingMessage.remove();
                }

                // Tạo phần tử span hiển thị thông báo
                let message = document.createElement("span");
                message.className = "copy-message";
                message.textContent = "Đã sao chép!";

                // Chèn ngay sau phần tử SKU
                element.insertAdjacentElement("afterend", message);

                // Hiệu ứng xuất hiện (mờ dần vào)
                setTimeout(() => {
                    message.style.opacity = "1";
                }, 100);

                // Ẩn sau 3 giây (mờ dần ra)
                setTimeout(() => {
                    message.style.opacity = "0";
                    setTimeout(() => message.remove(), 500); // Xóa hẳn sau khi mờ dần
                }, 3000);
            }
        });


        /* Thêm SKU Bổ Sung */
        $(document).ready(function() {
            $(".addSkuMore").click(function() {
                $(".box__addSkuMore").toggle();

                // Đổi text của button dựa trên trạng thái hiển thị của box__addSkuMore
                if ($(".box__addSkuMore").is(":visible")) {
                    $(this).text("Ẩn");
                } else {
                    $(this).text("Thêm SKU Bổ Sung");
                }
            });
        });

        $(document).ready(function() {

            // --- Phần xử lý dòng giao bổ sung ---
            function addDeliveryRow() {
                var row = `
  <div class="additional-delivery-row border p-2 mb-2">
    <!-- Nếu có purchase_order_id chung, lấy từ biến Blade -->
    <input type="hidden" name="additional_data[][purchase_order_id]" value="{{ $purchaseOrderNew->id ?? '' }}">
    <div class="form-group">
      <label>SKU</label>
      <input type="text" name="additional_data[][sku]" class="form-control" placeholder="Nhập mã SKU" >
    </div>
    <div class="form-group">
      <label>Số lượng giao hàng</label>
      <input type="number" name="additional_data[][qty_product_delivery]" class="form-control" placeholder="Nhập số lượng giao" >
    </div>
    <div class="form-group">
      <label>Ghi chú</label>
      <textarea name="additional_data[][note]" class="form-control" placeholder="Ghi chú (nếu có)"></textarea>
    </div>
    <button type="button" class="btn btn-danger remove-delivery-row">Xóa dòng</button>
  </div>
`;
                $('#additionalDeliveryContainer').append(row);
            }

            // Khi modal mở, khởi tạo container với 1 dòng mặc định
            $('#additionalDeliveryModal').on('show.bs.modal', function() {
                $('#additionalDeliveryContainer').empty();
                addDeliveryRow();
            });

            // Thêm dòng mới khi nhấn nút "Thêm dòng" trong modal
            $('#addDeliveryRow').on('click', function() {
                addDeliveryRow();
            });

            // Xóa dòng bổ sung khi nhấn nút "Xóa dòng"
            $(document).on('click', '.remove-delivery-row', function() {
                $(this).closest('.additional-delivery-row').remove();
            });

            // --- Chuyển dữ liệu từ modal sang container hidden (dữ liệu giao bổ sung) ---
            function updateHiddenAdditionalData() {
                $('#hiddenAdditionalData').empty();
                var currentCount = 0;
                $('#additionalDeliveryContainer .additional-delivery-row').each(function() {
                    var index = currentCount;
                    currentCount++;
                    var purchase_order_id = $(this).find(
                        'input[name="additional_data[][purchase_order_id]"]').val();
                    var sku = $(this).find('input[name="additional_data[][sku]"]').val();
                    var qty_product_delivery = $(this).find(
                        'input[name="additional_data[][qty_product_delivery]"]').val();
                    var note = $(this).find('textarea[name="additional_data[][note]"]').val();
                    var hiddenBlock = `
      <div class="hidden-additional-row">
        <input type="hidden" name="additional_data[${index}][purchase_order_id]" value="${purchase_order_id}">
        <input type="hidden" name="additional_data[${index}][sku]" value="${sku}">
        <input type="hidden" name="additional_data[${index}][qty_product_delivery]" value="${qty_product_delivery}">
        <input type="hidden" name="additional_data[${index}][note]" value="${note}">
      </div>
    `;
                    $('#hiddenAdditionalData').append(hiddenBlock);
                });
            }

            function updateAdditionalDeliverySummary() {
                var summaryHtml = '';
                $('#hiddenAdditionalData .hidden-additional-row').each(function() {
                    var sku = $(this).find('input[name*="[sku]"]').val();
                    var qty = $(this).find('input[name*="[qty_product_delivery]"]').val();
                    var note = $(this).find('input[name*="[note]"]').val();
                    if (sku && qty) {
                        summaryHtml += `<div class="additional-delivery-summary-item border p-2 mb-2">
                  <strong>Xưởng giao thêm (bổ sung)</strong> <br>
                  <strong>SKU:</strong> ${sku} <br>
                  <strong>Số lượng giao:</strong> ${qty} <br>
                  <strong>Ghi chú:</strong> ${note ? note : 'N/A'}
               </div>`;
                    }
                });
                $('#additionalDeliverySummary').html(summaryHtml);
            }

            // --- Phần xử lý Upload hình ảnh ---
            $('#images').on('change', function(event) {
                var preview = $('#preview');
                preview.empty();
                var files = event.target.files;
                Array.from(files).forEach(function(file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var img = $('<img>').attr('src', e.target.result).css({
                            'width': '100px',
                            'margin': '5px'
                        });
                        preview.append(img);
                    };
                    reader.readAsDataURL(file);
                });
            });

            // --- Phần xử lý chụp ảnh qua camera ---
            $('#capture').on('click', function() {
                var video = $('#camera');
                var canvas = $('#canvas')[0];
                var context = canvas.getContext('2d');
                // Yêu cầu truy cập camera
                navigator.mediaDevices.getUserMedia({
                        video: true
                    })
                    .then(function(stream) {
                        video.show();
                        video.prop('srcObject', stream);
                    })
                    .catch(function(error) {
                        console.error('Lỗi truy cập camera:', error);
                    });
                // Khi người dùng click vào video, chụp ảnh
                video.one('click', function() {
                    canvas.width = video[0].videoWidth;
                    canvas.height = video[0].videoHeight;
                    context.drawImage(video[0], 0, 0, canvas.width, canvas.height);
                    var dataURL = canvas.toDataURL('image/png');
                    $('#imageData').val(dataURL);
                    var img = $('<img>').attr('src', dataURL).css({
                        'width': '100px',
                        'margin': '5px'
                    });
                    $('#preview').append(img);
                    // Dừng stream
                    var stream = video.prop('srcObject');
                    stream.getTracks().forEach(function(track) {
                        track.stop();
                    });
                    video.hide();
                });
            });

            // --- Khi modal đóng, cập nhật cả dữ liệu bổ sung và dữ liệu hình ảnh ---
            $('#additionalDeliveryModal').on('hidden.bs.modal', function() {
                updateHiddenAdditionalData();
                updateAdditionalDeliverySummary();
                updateImagesData();
            });

            // Hàm cập nhật dữ liệu hình ảnh từ preview sang container ẩn và summary
            function updateImagesData() {
                // Clear container ẩn và summary hình ảnh
                $('#hiddenImages').empty();
                var summaryHtml = '';
                // Duyệt qua tất cả các ảnh trong container preview
                $('#preview img').each(function(index) {
                    var src = $(this).attr('src');
                    // Tạo hidden input với tên "images_hidden[]" chứa dữ liệu ảnh (base64 hoặc đường dẫn)
                    var hiddenInput = `<input type="hidden" name="images_hidden[]" value="${src}">`;
                    $('#hiddenImages').append(hiddenInput);
                    // Tạo summary hiển thị ảnh thu nhỏ
                    summaryHtml += `<img src="${src}" style="width:100px; margin:5px;">`;
                });
                $('#additionalImagesSummary').html(summaryHtml);
            }
        });


        /* Submit form */
        $(document).ready(function() {
            $('form').on('submit', function(e) {
                var isAtLeastOneUpdated = false;

                // Duyệt qua tất cả các input nhập số lượng giao hàng
                $('.qty_product_delivery').each(function() {
                    var inputVal = $(this).val();
                    // Nếu giá trị không rỗng và lớn hơn 0
                    if (inputVal !== '' && parseInt(inputVal) > 0) {
                        isAtLeastOneUpdated = true;
                        // Dừng vòng lặp khi đã tìm thấy ít nhất 1 input hợp lệ
                        return false;
                    }
                });

                // Nếu không có SKU nào được cập nhật số lượng giao hàng mới
                if (!isAtLeastOneUpdated) {
                    e.preventDefault(); // Ngăn form không submit
                    Swal.fire({
                        title: 'Lỗi',
                        text: 'Vui lòng cập nhật số lượng giao hàng cho ít nhất 1 SKU.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    }).then(() => {
                        const firstInput = document.querySelector('.qty_product_delivery');
                        if (firstInput) {
                            firstInput.focus();
                        }
                    });
                }
            });
        });
    </script>
@endsection
