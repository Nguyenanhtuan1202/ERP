@extends('layouts.layout_factory')

@section('css')
    <link rel="stylesheet" href="{{ asset('css/production.css') }}">
@endsection

@section('content')
    <style>

    </style>

    <div class="container-fluid" style="padding: 20px;">
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <div class="row align-items-center justify-content-between listPurchaseOrder mb-2 mt-5 ">

            <div class="col-auto">
                <div class="page-header-title">
                    <h4 class="title__list-po" style="font-weight: 600; color: #0f2854;"> Danh Sách Tất Cả Các Đơn Hàng
                    </h4>
                </div>

            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ url('/') }}">Quay Lại Trang Chủ <i class="fas fa-undo-alt"></i></a>
                </div>
            </div>
        </div>

        <div class="card-body px-0 pt-0 pb-2">
            <div class="table-responsive p-0">
                <table class="table align-items-center mb-0 table__customs" id="table1">
                    <thead class="thead__custom">
                        <tr>
                            <th>Xác Nhận</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                STT</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Mã Đơn Hàng</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Số Lượng Đặt</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                Số Lượng Hoàn Thành</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Ngày Đặt Hàng</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Ngày Dự Kiến Giao Hàng</th>
                            <th style="font-size: 14px" class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                Trạng Thái</th>

                        </tr>
                    </thead>
                    <tbody>

                        @php
                            $temp = 0;
                        @endphp

                        @foreach ($purchaseOrders as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr class="{{ $item->prioritize == 1 ? 'item__prioritize' : '' }}">

                                <td style="display: flex; justify-content: center;" class="text-center">

                                    @if ($item->viewed)
                                        <a class="text-center">
                                            <span class="confirm_info"><i class="fas fa-check"></i></span>
                                        </a>
                                    @else
                                        <a href="{{ route('production.index', ['status' => 1, 'id' => $item->id ?? '']) }}"
                                            class="text-center">
                                            <span class="no_confirm_info"><i class="fas fa-times"></i></span>
                                        </a>
                                    @endif
                                </td>
                                <td class="align-middle text-center ">
                                    {{ $temp }}
                                </td>

                                <td class="align-middle text-center ">


                                    @if ($item->viewed)
                                        <a class="purchase__order"
                                            href="{{ route('production.show', [$item->id]) }}">{{ $item->po_id ?? '' }}</a>
                                    @else
                                        <span class="confirm_order">Xác nhận DH{{ $item->po_id ?? '' }}

                                        </span>
                                    @endif
                                </td>

                                <td class="align-middle text-center">
                                    <span
                                        style="font-weight: 600; font-size: 18px;">{{ $item->total_quantity ?? '' }}</span>
                                </td>
                                <td class="align-middle text-center">
                                    <span
                                        class=" {{ $item->getTotalQtyProduction() >= $item->total_quantity ? 'complete__process' : 'pending__process' }}">{{ $item->getTotalQtyProduction() }}
                                        /
                                        {{ $item->total_quantity ?? '' }}</span>
                                </td>

                                <td class="align-middle text-center ">
                                    <span
                                        class="date_custom">{{ date('d-m-Y', strtotime($item->order_date ?? '')) }}</span>
                                </td>
                                @php
                                    // Nếu tồn tại ngày dự kiến, parse nó; nếu không thì để null
                                    $expectedDate = $item->expected_date
                                        ? \Carbon\Carbon::parse($item->expected_date)
                                        : null;
                                    // Lấy ngày hiện tại (không tính thời gian)
                                    $today = \Carbon\Carbon::today();
                                    // Nếu ngày dự kiến hợp lệ, tính hiệu số ngày từ hôm nay đến ngày dự kiến
                                    $diff = $expectedDate ? $today->diffInDays($expectedDate, false) : null;
                                @endphp

                                <td style="font-weight: 700"
                                    class="date-cell 
                                @if ($expectedDate && $expectedDate->isFuture() && $diff > 2) text-success
                                @else
                                    text-danger @endif">
                                    {{ $expectedDate ? $expectedDate->format('d-m-Y') : 'N/A' }}
                                </td>

                                <td class=" text-center">
                                    @php
                                        $isComplete = $item->getTotalQtyProduction() >= $item->total_quantity;

                                        $isNotCompleted = $item->getTotalQtyProduction() < $item->total_quantity;
                                    @endphp

                                    @if ($isComplete)
                                        <span class=" complete__process">Đã hoàn thành</span>
                                    @elseif($isNotCompleted)
                                        <span class=" pending__process">Đang sản
                                            xuất</span>
                                    @endif
                                </td>


                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>



        <div class="container">
            <h4 class="text-primary mb-3">Thống kê sản xuất</h4>

            <!-- Dropdown chọn khoảng thời gian -->
            <select id="timeFilter" class="form-control w-auto d-inline-block">
                <option value="day">Hôm nay</option>
                <option value="week">Tuần này</option>
                <option value="month" selected>Tháng này</option>
                <option value="year">Năm nay</option>
            </select>

            <!-- Biểu đồ -->
            <canvas id="productionChart"></canvas>
        </div>





    </div>
@endsection


@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('productionChart').getContext('2d');

            // Lấy dữ liệu từ Laravel Blade
            const dataSets = {
                day: @json($dayData),
                week: @json($weekData),
                month: @json($monthData),
                year: @json($yearData)
            };

            // Hàm xử lý khi chọn thời gian
            function updateChart(timeFrame) {
                const selectedData = dataSets[timeFrame] || [];
                const labels = selectedData.map(item => item.name);
                const quantities = selectedData.map(item => item.total_quantity);

                chart.data.labels = labels;
                chart.data.datasets[0].data = quantities;
                chart.update();
            }

            // Khởi tạo biểu đồ mặc định là tháng
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Số lượng sản xuất',
                        data: [],
                        backgroundColor: 'rgba(54, 162, 235, 0.5)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Lắng nghe sự kiện thay đổi select
            document.getElementById('timeFilter').addEventListener('change', function() {
                updateChart(this.value);
            });
            // Load dữ liệu mặc định ban đầu
            updateChart('month');
        });
    </script>
@endsection
