@extends('layouts.admin')
@section('content')
    <div class="">

        <h3 class="title__highlight mt-5">
            <i class="fas fa-desktop"></i> Danh sách điểm danh Nhóm chuyên gia
        </h3>

        <style>
            /* Định dạng chung cho bảng */
            .table-responsive-sm {
                margin: 20px;
            }

            .dataTables_length {
                margin-bottom: 40px;
            }

            .table {

                width: 100%;
                border-collapse: collapse;
                background: #fff;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                transform: translateY(0);
                transition: transform 0.3s ease-in-out;
            }

            .table:hover {
                transform: translateY(-5px);
            }

            .table thead {
                background-color: #343a40;
                color: #fff;
            }

            .table thead th {
                padding: 15px;
                text-align: left;
                font-weight: 600;
                font-size: 16px;
            }

            .table tbody tr {
                transition: background-color 0.3s ease, transform 0.3s ease;
            }

            .table tbody tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .table tbody tr:hover {
                background-color: #e9ecef;
                transform: translateY(-2px);
            }

            .table td {
                padding: 15px;
                font-size: 16px;
                color: #333;
            }

            .table img {
                border-radius: 8px;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .table img:hover {
                transform: scale(1.1);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }

            .table a {
                color: #007bff;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s ease;
            }

            .table a:hover {
                color: #0056b3;
                text-decoration: underline;
            }

            /* Định dạng cho các cột đặc biệt */
            .table th:nth-child(1),
            .table td:nth-child(1) {
                width: 5%;
            }

            .table th:nth-child(2),
            .table td:nth-child(2) {
                width: 15%;
            }

            .table th:nth-child(3),
            .table td:nth-child(3) {
                width: 15%;
            }

            .table th:nth-child(4),
            .table td:nth-child(4) {
                width: 20%;
            }

            .table th:nth-child(5),
            .table td:nth-child(5) {
                width: 10%;
            }

            .table th:nth-child(6),
            .table td:nth-child(6) {
                width: 15%;
            }

            .table th:nth-child(7),
            .table td:nth-child(7) {
                width: 20%;
            }

            /* Định dạng cho các trạng thái đặc biệt */
            .status-pending {
                color: #ffc107;
                font-weight: bold;
            }

            .status-approved {
                color: #28a745;
                font-weight: bold;
            }
        </style>
        <div class="full price_table padding_infor_info">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive-sm">
                        <table class="table table-striped archs" id="table1" class="display" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 2%">STT</th>
                                    <th style="width: 2%">Hình </th>
                                    <th style="width: 15%">Tên</th>
                                    <th style="width: 5%">Mã chuyên gia</th>
                                    <th style="width: 5%">Level </th>
                                    <th style="width: 5%">Nhóm </th>
                                    <th style="width: 30%">Thời gian điểm danh </th>

                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $temp = 0;
                                @endphp

                                @foreach ($data as $value)
                                    @php
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <td>{{ $temp }}</td>
                                        <td>
                                            <img style="max-width: 100px;" src="{{ asset($value->image ?? '') }}"
                                                alt="{{ $value->image ?? '' }}">
                                        </td>
                                        <td>{{ $value->fullname ?? '' }}</td>
                                        <td>
                                            {{ $value->id_hs ?? '' }}
                                        </td>
                                        <td>
                                            {{ level_expert($value->listExpert->level ?? '') }}
                                        </td>


                                        <td>
                                            {{ $value->listExpert->class ?? 'Chưa cập nhật' }}
                                        </td>
                                        <td>
                                            {{ $value->checkin ?? '' }}
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
