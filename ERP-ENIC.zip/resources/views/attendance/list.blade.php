@extends('layouts.admin')
@section('content')
    <div class="">

        <h3 class="title__highlight mt-5">
            <i class="fas fa-desktop"></i> Danh sách điểm danh Nhóm chuyên gia
        </h3>


        @if (session('status'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('status') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif
        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <a class="add__expert" style="display: inline-block; margin-left: 20px;color: #fff;" id="addNewRecord">Điểm Danh <i
                class="fas fa-user-plus"></i></a>

        <!-- Modal -->
        <div class="modal fade" id="recordModal" tabindex="-1" role="dialog" aria-labelledby="recordModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="recordModalLabel">Điểm danh</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ url('/admin/attendance/save') }}" id="historyForm">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <label for="studentName">Tên Học Viên</label>
                                <input type="text" name="fullname" class="form-control" value="" id="studentName"
                                    required>

                            </div>

                            <div class="form-group">
                                <label for="id_hs">Mã Học Viên</label>
                                <input type="tel" name="id_hs" class="form-control" value="" id="id_hs"
                                    required>

                            </div>


                            <div class="form-group">
                                <label for="examDate">Ngày Đi Học</label>
                                <input type="date" name="checkin" class="form-control" id="examDate" required>
                            </div>

                            <div class="form-group">
                                <label for="notes">Ghi Chú</label>
                                <textarea class="form-control" name="note" id="notes" rows="3"></textarea>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                                <button type="submit" class="btn btn-primary">Lưu</button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>




        <style>
            h5 {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 20px;
            }

            .btn-primary {
                background-color: #007bff;
                border-color: #007bff;
            }

            .btn-primary:hover {
                background-color: #0056b3;
                border-color: #004085;
            }

            .modal-content {
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .modal-header {
                border-bottom: 1px solid #dee2e6;
                background-color: #007bff;
                color: #fff;
            }

            .modal-title {
                font-size: 18px;
                font-weight: bold;
            }

            .modal-body {
                padding: 30px;
            }

            .form-control {
                border-radius: 4px;
                border: 1px solid #ced4da;
                padding: 10px;
                box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075);
            }

            .form-control:focus {
                border-color: #007bff;
                box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
            }

            .form-group label {
                font-weight: bold;
                font-weight: bold;
                color: #111;
            }

            .modal-footer {
                border-top: 1px solid #dee2e6;
            }



            /* Định dạng chung cho bảng */
            .table-responsive-sm {
                margin: 20px;
            }

            .dataTables_length {
                margin-bottom: 40px;
            }

            .table {

                width: 100%;
                border-collapse: collapse;
                background: #fff;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                transform: translateY(0);
                transition: transform 0.3s ease-in-out;
            }

            .table:hover {
                transform: translateY(-5px);
            }

            .table thead {
                background-color: #343a40;
                color: #fff;
            }

            .table thead th {
                padding: 15px;
                text-align: left;
                font-weight: 600;
                font-size: 16px;
            }

            .table tbody tr {
                transition: background-color 0.3s ease, transform 0.3s ease;
            }

            .table tbody tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .table tbody tr:hover {
                background-color: #e9ecef;
                transform: translateY(-2px);
            }

            .table td {
                padding: 15px;
                font-size: 16px;
                color: #333;
            }

            .table img {
                border-radius: 8px;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .table img:hover {
                transform: scale(1.1);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }

            .table a {
                color: #007bff;
                text-decoration: none;
                font-weight: 500;
                transition: color 0.3s ease;
            }

            .table a:hover {
                color: #0056b3;
                text-decoration: underline;
            }

            /* Định dạng cho các cột đặc biệt */
            .table th:nth-child(1),
            .table td:nth-child(1) {
                width: 5%;
            }

            .table th:nth-child(2),
            .table td:nth-child(2) {
                width: 15%;
            }

            .table th:nth-child(3),
            .table td:nth-child(3) {
                width: 15%;
            }

            .table th:nth-child(4),
            .table td:nth-child(4) {
                width: 20%;
            }

            .table th:nth-child(5),
            .table td:nth-child(5) {
                width: 10%;
            }

            .table th:nth-child(6),
            .table td:nth-child(6) {
                width: 15%;
            }

            .table th:nth-child(7),
            .table td:nth-child(7) {
                width: 20%;
            }

            /* Định dạng cho các trạng thái đặc biệt */
            .status-pending {
                color: #ffc107;
                font-weight: bold;
            }

            .status-approved {
                color: #28a745;
                font-weight: bold;
            }
        </style>
        <div class="full price_table padding_infor_info">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive-sm">

                        <table class="table table-striped archs" id="tableCustom" class="display" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 2%">STT</th>
                                    <th style="width: 2%">Hình</th>
                                    <th style="width: 15%">Tên</th>
                                    <th style="width: 5%">Mã chuyên gia</th>
                                    <th style="width: 5%">Level</th>
                                    <th style="width: 5%">Nhóm</th>
                                    <th style="width: 30%">Thời gian điểm danh</th>
                                    <th style="width: 30%">Ghi chú</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $currentDate = null;
                                    $groupSTT = 1;
                                @endphp

                                @foreach ($data->sortByDesc(function ($item) {
            return \Carbon\Carbon::parse($item->checkin);
        }) as $value)
                                    @php
                                        $checkinDate = \Carbon\Carbon::parse($value->checkin)->format('d/m/Y');
                                    @endphp

                                    @if ($checkinDate !== $currentDate)
                                        @if ($currentDate !== null)
                                            <!-- Nếu không phải là ngày đầu tiên, hiển thị nhóm STT cho ngày cũ -->
                                            <tr>
                                                <td colspan="7" class="text-center font-weight-bold"
                                                    style="background-color: #dc3545; color:#fff">
                                                    Danh sách điểm danh ngày: {{ $currentDate }} <i
                                                        class="fas fa-arrow-up"></i>
                                                </td>
                                                <td style="background-color: #dc3545; color:#fff"></td>
                                            </tr>
                                        @endif
                                        @php
                                            $currentDate = $checkinDate;
                                            $groupSTT = 1; // Reset STT nhóm
                                        @endphp
                                    @else
                                        @php
                                            $groupSTT++;
                                        @endphp
                                    @endif

                                    <tr>
                                        <td>{{ $groupSTT }}</td>
                                        <td>
                                            <img style="max-width: 100px;" src="{{ asset($value->image ?? '') }}"
                                                alt="{{ $value->image ?? '' }}">
                                        </td>
                                        <td>{{ $value->fullname ?? '' }}</td>
                                        <td>{{ $value->id_hs ?? '' }}</td>
                                        <td>{{ level_expert($value->listExpert->level ?? '') }}</td>
                                        <td>{{ ($value->listExpert->class ?? 'Chưa cập nhật') }}</td>
                                        <td>{{ $value->checkin ?? '' }}</td>
                                        <td>{{ $value->note ?? '' }}</td>
                                    </tr>
                                @endforeach

                                <!-- Hiển thị nhóm STT cho ngày cuối cùng -->
                                @if ($currentDate !== null)
                                    <tr>
                                        <td colspan="7" class="text-center font-weight-bold"
                                            style="background-color: #dc3545; color:#fff">
                                            Danh sách điểm danh ngày: {{ $currentDate }} <i class="fas fa-arrow-up"></i>
                                        </td>
                                        <td style="background-color: #dc3545; color:#fff"></td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>



                        <script>
                            $(document).ready(function() {
                                $('#table1').DataTable({
                                    "paging": true,
                                    "ordering": true,
                                    "info": true,
                                    "autoWidth": false,
                                    "responsive": true
                                });
                            });
                        </script>


                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
