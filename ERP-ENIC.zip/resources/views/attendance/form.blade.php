<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Form</title>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    <style>
        /* CSS cho form điểm danh học viên */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #87CEEB;
            /* Màu nền cho hiệu ứng mây trôi */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
            overflow: hidden;
            /* Đảm bảo hiệu ứng không bị cuộn */
        }

        .cloud {
            position: absolute;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 50%;
            width: 150px;
            height: 80px;
            filter: blur(15px);
        }

        form#attendance-form {
            display: flex;
            flex-direction: column;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            box-sizing: border-box;
            text-align: center;
            position: relative;
            z-index: 1;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        form#attendance-form:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        form#attendance-form h2 {
            margin-bottom: 20px;
            color: #007bff;
            font-size: 24px;
            font-weight: 600;
        }

        form#attendance-form label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
            text-align: left;
        }

        form#attendance-form input[type="text"],
        form#attendance-form input[type="hidden"] {
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            width: 100%;
            transition: border-color 0.3s ease;
        }

        form#attendance-form input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
        }

        form#attendance-form button {
            background-color: #007bff;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        form#attendance-form button:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            position: relative;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-dismissible .close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            cursor: pointer;
        }

        @media (max-width: 480px) {
            form#attendance-form {
                padding: 20px;
            }

            form#attendance-form label {
                font-size: 14px;
            }

            form#attendance-form input[type="text"],
            form#attendance-form button {
                font-size: 16px;
            }
        }

        #date-time {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.8);
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 16px;
            color: #333;
        }
    </style>
</head>

<body>
    {{-- <div id="particles-js" class="particles-js"></div> --}}
    {{-- <div class="cloud" id="cloud1" style="top: 50px; left: 0;"></div>
    <div class="cloud" id="cloud2" style="top: 150px; left: 100px;"></div>
    <div class="cloud" id="cloud3" style="top: 200px; left: 200px;"></div> --}}

    <div id="date-time"></div>

    <form id="attendance-form" action="{{ url('save-form-attendance') }}" method="POST" enctype="multipart/form-data">
        @csrf

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif
        @if (session('status'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('status') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <h2>Điểm Danh Học Viên</h2>
        <label for="id_hs">Mã Học Viên:</label>
        <input type="text" id="id_hs" name="id_hs" required>
        {{-- <label for="fullname">Họ Tên:</label>
        <input type="text" id="fullname" name="fullname" required> --}}
        <input type="hidden" id="photo" name="image">
        <button type="submit">Điểm Danh</button>
    </form>


    <video id="video" width="720" height="560" autoplay style="display: none;"></video>
    <canvas id="canvas" width="720" height="560" style="display: none;"></canvas>

    <script type="text/javascript">
        // Access the camera and video element
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const context = canvas.getContext('2d');

        // Prompt user for access to camera
        navigator.mediaDevices.getUserMedia({
                video: true
            })
            .then(stream => {
                video.srcObject = stream;
            })
            .catch(err => {
                console.error("Error accessing the camera: " + err);
            });

        // Capture photo when form is submitted
        document.getElementById('attendance-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent form from submitting immediately

            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            // Convert canvas to data URL
            const photoData = canvas.toDataURL('image/png');
            document.getElementById('photo').value = photoData;

            // Submit the form
            this.submit();
        });

        // Cập nhật ngày giờ hiện tại
        function updateDateTime() {
            const now = new Date();
            const options = {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: 'numeric',
                minute: 'numeric',
                second: 'numeric',
            };
            document.getElementById('date-time').textContent = now.toLocaleString('vi-VN', options);
        }

        updateDateTime();
        setInterval(updateDateTime, 1000); // Cập nhật mỗi giây
    </script>
</body>

</html>
