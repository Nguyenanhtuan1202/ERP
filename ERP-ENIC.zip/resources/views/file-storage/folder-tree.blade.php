<ul>
    @foreach($children as $childFolder)
        <li>
            <a href="{{ route('file-storage.folder', ['path' => $childFolder->path]) }}" class="d-flex align-items-center {{ isset($currentPath) && $currentPath === $childFolder->path ? 'folder-active' : '' }}">
                <i class="fas fa-folder folder-icon"></i>
                {{ $childFolder->name }}
            </a>
            @if(count($childFolder->children) > 0)
                @include('file-storage.folder-tree', ['children' => $childFolder->children, 'currentPath' => $currentPath ?? null])
            @endif
        </li>
    @endforeach
</ul>