@extends('layouts.layout_purchaser')

@section('title', 'Truy cập file chia sẻ')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">File được bảo vệ bằng mật khẩu</h5>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <i class="fas {{ $file->getFileIconClass() }} fa-4x text-primary mb-3"></i>
                        <h5>{{ $file->name }}</h5>
                        <p class="text-muted">{{ $file->formatSize() }}</p>
                    </div>

                    @if($errors->any())
                        <div class="alert alert-danger">
                            {{ $errors->first() }}
                        </div>
                    @endif

                    <form action="{{ route('file-storage.validate-share-password') }}" method="POST">
                        @csrf
                        <input type="hidden" name="token" value="{{ $fileShare->token }}">
                        
                        <div class="form-group">
                            <label for="password">Mật khẩu truy cập</label>
                            <input type="password" class="form-control" id="password" name="password" required autofocus>
                            <small class="form-text text-muted">Vui lòng nhập mật khẩu để truy cập file này.</small>
                        </div>
                        
                        <div class="form-group mt-4">
                            <button type="submit" class="btn btn-primary btn-block">Truy cập</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection