@foreach ($children as $childFolder)
    <option value="{{ $childFolder->id }}">{{ str_repeat('—', $level) }} {{ $childFolder->name }}</option>
    @if (count($childFolder->children) > 0)
        @include('file-storage.folder-options', [
            'children' => $childFolder->children,
            'level' => $level + 1,
        ])
    @endif
@endforeach
