@extends('layouts.layout_purchaser')

@section('title', isset($currentFolder) ? $currentFolder : 'File Manager')

@section('css')
    <style>
        /* Main Layout & Container Styles */
        :root {
            --primary-color: #4285f4;
            --hover-color: #0d6efd;
            --light-hover: #f0f7ff;
            --border-color: #dee2e6;
            --text-muted: #6c757d;
            --folder-color: #ffd54f;
            --icon-text: #5f6368;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --header-height: 64px;
            --sidebar-width: 250px;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }

        .container-fluid {
            padding: 20px;
        }

        /* Header Styling */
        h1.h3 {
            font-weight: 500;
            color: #202124;
        }

        .folder-path {
            font-size: 14px;
            color: var(--text-muted);
        }

        /* File Manager Layout */
        .file-manager {
            display: flex;
            min-height: calc(100vh - var(--header-height) - 120px);
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        /* Sidebar Styling */
        .folder-sidebar {
            width: var(--sidebar-width);
            background-color: #f8f9fa;
            border-right: 1px solid var(--border-color);
            padding: 15px;
            overflow-y: auto;
        }

        .folder-tree ul {
            list-style-type: none;
            margin-bottom: 0;
        }

        .folder-tree li {
            margin-bottom: 3px;
        }

        .folder-tree a {
            display: block;
            padding: 8px 10px;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.2s;
        }

        .folder-tree a:hover {
            background-color: var(--light-hover);
        }

        .folder-tree .folder-icon {
            margin-right: 8px;
            color: var(--folder-color);
        }

        .folder-active {
            background-color: var(--light-hover);
            font-weight: 500;
        }

        /* Subfolder indentation */
        .folder-tree ul ul {
            padding-left: 20px;
        }

        /* Main Content Area */
        .folder-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        /* Card Styling for Files and Folders */
        .file-card {
            position: relative;
            border-radius: 8px;
            transition: all 0.2s;
            border: 1px solid var(--border-color);
        }

        .file-card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-color: var(--primary-color);
        }

        .file-card .card-body {
            padding: 15px;
        }

        /* File Icons */
        .fa-folder {
            color: var(--folder-color);
        }

        .fa-file-alt,
        .fa-file-pdf,
        .fa-file-word,
        .fa-file-excel,
        .fa-file-image,
        .fa-file-code {
            color: var(--icon-text);
        }

        /* Preview Thumbnails */
        .preview-thumbnail {
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .preview-thumbnail img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        /* File Actions */
        .file-actions {
            position: absolute;
            top: 5px;
            right: 5px;
            opacity: 0;
            transition: opacity 0.2s;
        }

        .file-card:hover .file-actions {
            opacity: 1;
        }

        .dropdown-toggle::after {
            display: none;
        }

        /* Search Bar */
        .search-wrapper {
            position: relative;
        }

        .search-results {
            position: absolute;
            left: 0;
            right: 0;
            top: 100%;
            background: white;
            border-radius: 0 0 4px 4px;
            border: 1px solid var(--border-color);
            z-index: 100;
            max-height: 300px;
            overflow-y: auto;
            display: none;
        }

        #searchInput:focus~.search-results {
            display: block;
        }

        .search-item {
            padding: 10px 15px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
        }

        .search-item:hover {
            background-color: var(--light-hover);
        }

        /* Storage Progress Bar */
        .storage-progress {
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
        }

        .storage-progress .progress-bar {
            border-radius: 4px;
        }

        /* Breadcrumb */
        .breadcrumb {
            background-color: transparent;
            padding: 0;
            margin-bottom: 0;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .breadcrumb-item.active {
            color: #444;
        }

        /* Dropzone for Drag & Drop */
        #dropzone {
            position: relative;
        }

        #dropzone.highlight {
            background-color: rgba(66, 133, 244, 0.05);
            border: 2px dashed var(--primary-color);
            border-radius: 8px;
        }

        /* Button Styling */
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: var(--hover-color);
            border-color: var(--hover-color);
        }

        /* Empty Folder State */
        .text-center.py-5 {
            color: var(--text-muted);
        }

        /* Modal Styling */
        .modal-header {
            border-bottom: 1px solid var(--border-color);
            background-color: #f8f9fa;
        }

        .modal-footer {
            border-top: 1px solid var(--border-color);
            background-color: #f8f9fa;
        }

        .custom-file-label {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* Upload Preview */
        #uploadPreview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .preview-item {
            position: relative;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            padding: 5px;
            width: calc(33.33% - 10px);
        }

        .preview-item img {
            width: 100%;
            height: auto;
            max-height: 80px;
            object-fit: contain;
        }

        .preview-item .preview-name {
            font-size: 12px;
            margin-top: 5px;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .preview-remove {
            position: absolute;
            top: -8px;
            right: -8px;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 10px;
        }

        /* Share File Modal */
        #shareLink {
            background-color: #f5f5f5;
        }

        .copy-btn:hover {
            background-color: var(--light-hover);
        }

        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .file-manager {
                flex-direction: column;
            }

            .folder-sidebar {
                width: 100%;
                max-height: 200px;
                border-right: none;
                border-bottom: 1px solid var(--border-color);
            }
        }

        @media (max-width: 768px) {
            .preview-item {
                width: calc(50% - 10px);
            }

            .col-md-3 {
                width: 50%;
            }
        }

        @media (max-width: 576px) {
            .preview-item {
                width: 100%;
            }

            .col-md-3 {
                width: 100%;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .file-card {
            animation: fadeIn 0.3s ease-in-out;
        }

        /* Dropdown Menu Animation */
        .dropdown-menu {
            animation: fadeIn 0.2s ease-in-out;
        }

        /* File Type-specific Colors */
        .fa-file-pdf {
            color: #f44336;
        }

        .fa-file-word {
            color: #2196f3;
        }

        .fa-file-excel {
            color: #4caf50;
        }

        .fa-file-image {
            color: #ff9800;
        }

        .fa-file-code {
            color: #9c27b0;
        }

        .fa-file-archive {
            color: #795548;
        }

        .fa-file-audio {
            color: #e91e63;
        }

        .fa-file-video {
            color: #3f51b5;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-md-6">
                <h1 class="h3 mb-0">{{ isset($currentFolder) ? $currentFolder : 'File Manager' }}</h1>
                @if (isset($currentPath))
                    <span class="folder-path">{{ $currentPath }}</span>
                @endif
            </div>
            <div class="col-md-6 text-right">
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-plus"></i> Tạo mới
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a href="#" class="dropdown-item" data-toggle="modal" data-target="#createFolderModal">
                            <i class="fas fa-folder mr-2"></i> Thư mục mới
                        </a>
                        <a href="#" class="dropdown-item" data-toggle="modal" data-target="#uploadFilesModal">
                            <i class="fas fa-file-upload mr-2"></i> Tải lên file
                        </a>
                        <a href="#" class="dropdown-item" data-toggle="modal" data-target="#createFileModal">
                            <i class="fas fa-file-alt mr-2"></i> Tạo file văn bản
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-12">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('file-storage.index') }}">
                                <i class="fas fa-home"></i> Home
                            </a>
                        </li>
                        @if (isset($currentPath) && $currentPath)
                            @php
                                $paths = explode('/', $currentPath);
                                $buildPath = '';
                            @endphp

                            @foreach ($paths as $index => $folderName)
                                @php
                                    $buildPath .= $index > 0 ? '/' . $folderName : $folderName;
                                @endphp

                                <li class="breadcrumb-item {{ $index === count($paths) - 1 ? 'active' : '' }}">
                                    @if ($index === count($paths) - 1)
                                        {{ $folderName }}
                                    @else
                                        <a href="{{ route('file-storage.folder', ['path' => $buildPath]) }}">
                                            {{ $folderName }}
                                        </a>
                                    @endif
                                </li>
                            @endforeach
                        @endif
                    </ol>
                </nav>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="row mb-3">
            <div class="col-md-8 offset-md-2">
                <div class="search-wrapper">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                        <input type="text" class="form-control" id="searchInput"
                            placeholder="Tìm kiếm file và thư mục...">
                    </div>
                    <div class="search-results shadow-sm">
                        <!-- Search results will be populated here via JavaScript -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Storage Usage -->
        <div class="row mb-4">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-body p-2">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small>Dung lượng đã sử dụng</small>
                            <small id="storageUsed">0 MB / 1 GB</small>
                        </div>
                        <div class="progress storage-progress">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="file-manager">
            <!-- Folder Tree Sidebar -->
            <div class="folder-sidebar">
                <div class="mb-3">
                    <a href="{{ route('file-storage.index') }}" class="btn btn-sm btn-outline-primary btn-block">
                        <i class="fas fa-home"></i> Trang chủ
                    </a>
                </div>

                <div class="folder-tree">
                    <ul class="p-0">
                        @foreach ($folders as $folder)
                            <li>
                                <a href="{{ route('file-storage.folder', ['path' => $folder->path]) }}"
                                    class="d-flex align-items-center {{ isset($currentPath) && $currentPath === $folder->path ? 'folder-active' : '' }}">
                                    <i class="fas fa-folder folder-icon"></i>
                                    {{ $folder->name }}
                                </a>
                                @if (count($folder->children) > 0)
                                    @include('file-storage.folder-tree', [
                                        'children' => $folder->children,
                                        'currentPath' => $currentPath ?? null,
                                    ])
                                @endif
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="folder-content" id="dropzone">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <!-- Folders -->
                @if (count($subFolders) > 0)
                    <h5 class="mb-3">Thư mục</h5>
                    <div class="row">
                        @foreach ($subFolders as $subFolder)
                            <div class="col-md-3 col-sm-4 mb-4">
                                <div class="card file-card h-100">
                                    <div class="card-body text-center">
                                        <div class="file-actions">
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle"
                                                    type="button" data-toggle="dropdown">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item rename-folder" href="#"
                                                        data-id="{{ $subFolder->id }}" data-name="{{ $subFolder->name }}">
                                                        <i class="fas fa-edit mr-2"></i> Đổi tên
                                                    </a>
                                                    <a class="dropdown-item" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('delete-folder-{{ $subFolder->id }}').submit();">
                                                        <i class="fas fa-trash-alt mr-2"></i> Xóa
                                                    </a>
                                                    <form id="delete-folder-{{ $subFolder->id }}"
                                                        action="{{ route('file-storage.delete') }}" method="POST"
                                                        style="display: none;">
                                                        @csrf
                                                        <input type="hidden" name="item_id"
                                                            value="{{ $subFolder->id }}">
                                                        <input type="hidden" name="item_type" value="folder">
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="{{ route('file-storage.folder', ['path' => $subFolder->path]) }}"
                                            class="text-decoration-none">
                                            <div class="mb-3">
                                                <i class="fas fa-folder fa-3x folder-icon"></i>
                                            </div>
                                            <h6 class="card-title text-truncate mb-0">{{ $subFolder->name }}</h6>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <hr>
                @endif

                <!-- Files -->
                @if (count($files) > 0)
                    <h5 class="mb-3">File</h5>
                    <div class="row">
                        @foreach ($files as $file)
                            <div class="col-md-3 col-sm-4 mb-4">
                                <div class="card file-card h-100">
                                    <div class="card-body text-center">
                                        <div class="file-actions">
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle"
                                                    type="button" data-toggle="dropdown">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item"
                                                        href="{{ route('file-storage.preview', $file->id) }}"
                                                        target="_blank">
                                                        <i class="fas fa-eye mr-2"></i> Xem trước
                                                    </a>
                                                    <a class="dropdown-item"
                                                        href="{{ route('file-storage.download', $file->id) }}">
                                                        <i class="fas fa-download mr-2"></i> Tải xuống
                                                    </a>
                                                    <a class="dropdown-item rename-file" href="#"
                                                        data-id="{{ $file->id }}" data-name="{{ $file->name }}">
                                                        <i class="fas fa-edit mr-2"></i> Đổi tên
                                                    </a>
                                                    <a class="dropdown-item move-file" href="#"
                                                        data-id="{{ $file->id }}" data-name="{{ $file->name }}">
                                                        <i class="fas fa-exchange-alt mr-2"></i> Di chuyển
                                                    </a>
                                                    <a class="dropdown-item share-file" href="#"
                                                        data-id="{{ $file->id }}" data-name="{{ $file->name }}">
                                                        <i class="fas fa-share-alt mr-2"></i> Chia sẻ
                                                    </a>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item text-danger" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('delete-file-{{ $file->id }}').submit();">
                                                        <i class="fas fa-trash-alt mr-2"></i> Xóa
                                                    </a>
                                                    <form id="delete-file-{{ $file->id }}"
                                                        action="{{ route('file-storage.delete') }}" method="POST"
                                                        style="display: none;">
                                                        @csrf
                                                        <input type="hidden" name="item_id"
                                                            value="{{ $file->id }}">
                                                        <input type="hidden" name="item_type" value="file">
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            @if (strpos($file->mime_type, 'image') !== false)
                                                <div class="preview-thumbnail mb-2">
                                                    <img src="{{ route('file-storage.preview', $file->id) }}"
                                                        alt="{{ $file->name }}" class="img-thumbnail"
                                                        style="max-height: 100px;">
                                                </div>
                                            @else
                                                <i class="fas {{ $file->getFileIconClass() }} fa-3x text-secondary"></i>
                                            @endif
                                        </div>
                                        <h6 class="card-title text-truncate mb-1">{{ $file->name }}</h6>
                                        <small class="text-muted">{{ $file->formatSize() }}</small>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endif

                @if (count($files) == 0 && count($subFolders) == 0)
                    <div class="text-center py-5">
                        <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                        <h5>Thư mục trống</h5>
                        <p class="text-muted">Tạo thư mục mới hoặc tải lên các file của bạn</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Create Folder Modal -->
    <div class="modal fade" id="createFolderModal" tabindex="-1" role="dialog"
        aria-labelledby="createFolderModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createFolderModalLabel">Tạo thư mục mới</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.create-folder') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="folder_name">Tên thư mục</label>
                            <input type="text" class="form-control" id="folder_name" name="folder_name" required>
                        </div>
                        <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo thư mục</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Upload Files Modal -->
    <div class="modal fade" id="uploadFilesModal" tabindex="-1" role="dialog" aria-labelledby="uploadFilesModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadFilesModalLabel">Tải lên file</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.upload') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="files">Chọn file</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="files" name="files[]" multiple
                                    required>
                                <label class="custom-file-label" for="files">Chọn file...</label>
                            </div>
                            <small class="form-text text-muted">Có thể chọn nhiều file. Dung lượng tối đa:
                                10MB/file</small>
                        </div>
                        <div class="form-group mt-3" id="uploadPreview">
                            <!-- Preview will be shown here -->
                        </div>
                        <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tải lên</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create Text File Modal -->
    <div class="modal fade" id="createFileModal" tabindex="-1" role="dialog" aria-labelledby="createFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createFileModalLabel">Tạo file văn bản</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.create-file') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="file_name">Tên file</label>
                                    <input type="text" class="form-control" id="file_name" name="file_name" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="file_extension">Phần mở rộng</label>
                                    <select class="form-control" id="file_extension" name="file_extension">
                                        <option value="txt">txt</option>
                                        <option value="md">md</option>
                                        <option value="html">html</option>
                                        <option value="css">css</option>
                                        <option value="js">js</option>
                                        <option value="json">json</option>
                                        <option value="csv">csv</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="file_content">Nội dung</label>
                            <textarea class="form-control" id="file_content" name="file_content" rows="12"></textarea>
                        </div>
                        <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo file</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Rename File Modal -->
    <div class="modal fade" id="renameFileModal" tabindex="-1" role="dialog" aria-labelledby="renameFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="renameFileModalLabel">Đổi tên file</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.rename') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="new_name">Tên mới</label>
                            <input type="text" class="form-control" id="new_file_name" name="new_name" required>
                        </div>
                        <input type="hidden" name="item_id" id="rename_file_id">
                        <input type="hidden" name="item_type" value="file">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Lưu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Rename Folder Modal -->
    <div class="modal fade" id="renameFolderModal" tabindex="-1" role="dialog"
        aria-labelledby="renameFolderModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="renameFolderModalLabel">Đổi tên thư mục</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.rename') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="new_name">Tên mới</label>
                            <input type="text" class="form-control" id="new_folder_name" name="new_name" required>
                        </div>
                        <input type="hidden" name="item_id" id="rename_folder_id">
                        <input type="hidden" name="item_type" value="folder">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Lưu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Move File Modal -->
    <div class="modal fade" id="moveFileModal" tabindex="-1" role="dialog" aria-labelledby="moveFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="moveFileModalLabel">Di chuyển file</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('file-storage.move') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <p>Di chuyển <strong id="move_file_name"></strong> tới:</p>
                        <div class="form-group">
                            <select class="form-control" name="destination_folder_id" id="destination_folder">
                                <option value="">-- Thư mục gốc --</option>
                                @foreach ($folders as $folder)
                                    <option value="{{ $folder->id }}">{{ $folder->name }}</option>
                                    @if (count($folder->children) > 0)
                                        @include('file-storage.folder-options', [
                                            'children' => $folder->children,
                                            'level' => 1,
                                        ])
                                    @endif
                                @endforeach
                            </select>
                        </div>
                        <input type="hidden" name="file_id" id="move_file_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Di chuyển</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Share File Modal -->
    <div class="modal fade" id="shareFileModal" tabindex="-1" role="dialog" aria-labelledby="shareFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="shareFileModalLabel">Chia sẻ file</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Chia sẻ <strong id="share_file_name"></strong>:</p>
                    <div class="form-group">
                        <label>Link truy cập công khai</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="shareLink" readonly>
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary copy-btn" type="button"
                                    data-clipboard-target="#shareLink">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="enableSharing" checked>
                            <label class="custom-control-label" for="enableSharing">Cho phép chia sẻ công khai</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Hạn chế truy cập</label>
                        <select class="form-control" id="expiryTime">
                            <option value="1">1 giờ</option>
                            <option value="24" selected>24 giờ</option>
                            <option value="168">1 tuần</option>
                            <option value="720">1 tháng</option>
                            <option value="0">Không giới hạn</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Bảo vệ bằng mật khẩu</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="sharePassword"
                                placeholder="Để trống nếu không cần mật khẩu">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="share_file_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="button" class="btn btn-primary" id="updateShareSettings">Cập nhật</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.8/dist/clipboard.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize clipboard.js
            new ClipboardJS('.copy-btn');

            // File upload preview
            $('#files').on('change', function() {
                const files = Array.from(this.files);
                let preview = $('#uploadPreview');
                preview.empty();

                if (files.length > 0) {
                    preview.append('<h6>Đã chọn ' + files.length + ' file:</h6>');
                    let list = $('<ul class="list-group"></ul>');

                    files.forEach(function(file) {
                        let size = file.size < 1024 ? file.size + ' bytes' :
                            file.size < 1048576 ? (file.size / 1024).toFixed(2) + ' KB' :
                            (file.size / 1048576).toFixed(2) + ' MB';

                        let item = $(
                            '<li class="list-group-item py-2 d-flex justify-content-between align-items-center"></li>'
                        );
                        let fileIcon = getFileIconClass(file.type);

                        item.html('<div><i class="fas ' + fileIcon + ' mr-2"></i>' + file.name +
                            '</div><small>' + size + '</small>');
                        list.append(item);
                    });

                    preview.append(list);
                }
            });

            // Initialize dropzone for drag and drop uploads
            const dropzone = document.getElementById('dropzone');

            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropzone.addEventListener(eventName, preventDefaults, false);
            });

            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }

            ['dragenter', 'dragover'].forEach(eventName => {
                dropzone.addEventListener(eventName, highlight, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropzone.addEventListener(eventName, unhighlight, false);
            });

            function highlight() {
                dropzone.classList.add('drag-over');
            }

            function unhighlight() {
                dropzone.classList.remove('drag-over');
            }

            dropzone.addEventListener('drop', handleDrop, false);

            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;

                if (files.length > 0) {
                    // Open upload modal with the dropped files
                    $('#uploadFilesModal').modal('show');

                    // Create a new DataTransfer object
                    const newFileList = new DataTransfer();

                    // Add dropped files to the file input element
                    for (let i = 0; i < files.length; i++) {
                        newFileList.items.add(files[i]);
                    }

                    // Set the file input's files to the new file list
                    document.getElementById('files').files = newFileList.files;

                    // Trigger change event to show preview
                    $('#files').trigger('change');
                }
            }

            // Function to determine file icon based on MIME type
            function getFileIconClass(mimeType) {
                if (mimeType.includes('image')) {
                    return 'fa-file-image';
                } else if (mimeType.includes('pdf')) {
                    return 'fa-file-pdf';
                } else if (mimeType.includes('word') || mimeType.includes('document')) {
                    return 'fa-file-word';
                } else if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) {
                    return 'fa-file-excel';
                } else if (mimeType.includes('text') || mimeType.includes('json') || mimeType.includes(
                        'javascript')) {
                    return 'fa-file-code';
                } else {
                    return 'fa-file';
                }
            }

            // Rename file functionality
            $('.rename-file').on('click', function(e) {
                e.preventDefault();
                const fileId = $(this).data('id');
                const fileName = $(this).data('name');

                $('#rename_file_id').val(fileId);
                $('#new_file_name').val(fileName);
                $('#renameFileModal').modal('show');
            });

            // Rename folder functionality
            $('.rename-folder').on('click', function(e) {
                e.preventDefault();
                const folderId = $(this).data('id');
                const folderName = $(this).data('name');

                $('#rename_folder_id').val(folderId);
                $('#new_folder_name').val(folderName);
                $('#renameFolderModal').modal('show');
            });

            // Move file functionality
            $('.move-file').on('click', function(e) {
                e.preventDefault();
                const fileId = $(this).data('id');
                const fileName = $(this).data('name');

                $('#move_file_id').val(fileId);
                $('#move_file_name').text(fileName);
                $('#moveFileModal').modal('show');
            });

            // Share file functionality
            $('.share-file').on('click', function(e) {
                e.preventDefault();
                const fileId = $(this).data('id');
                const fileName = $(this).data('name');

                $('#share_file_id').val(fileId);
                $('#share_file_name').text(fileName);

                // Generate a fake sharing link for demonstration
                const shareLink = `{{ route('file-storage.share', '') }}/${generateShareToken()}`;
                $('#shareLink').val(shareLink);

                $('#shareFileModal').modal('show');
            });

            // Generate a random share token for demonstration
            function generateShareToken() {
                return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
            }

            // Toggle password visibility
            $('#togglePassword').on('click', function() {
                const passwordInput = $('#sharePassword');
                const icon = $(this).find('i');

                if (passwordInput.attr('type') === 'password') {
                    passwordInput.attr('type', 'text');
                    icon.removeClass('fa-eye').addClass('fa-eye-slash');
                } else {
                    passwordInput.attr('type', 'password');
                    icon.removeClass('fa-eye-slash').addClass('fa-eye');
                }
            });




            $(document).ready(function() {
                $('#updateShareSettings').click(function() {
                    const fileId = $('#share_file_id').val();
                    const isEnabled = $('#enableSharing').is(':checked');
                    const expiryTime = $('#expiryTime').val();
                    const password = $('#sharePassword').val();

                    $.ajax({
                        url: "{{ route('file-shares.update') }}", // Sẽ được render bởi Blade
                        type: 'POST',
                        data: {
                            file_id: fileId,
                            is_enabled: isEnabled,
                            expiry_time: expiryTime,
                            password: password,
                            _token: $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(response) {
                            if (response.success) {
                                // Sử dụng SweetAlert2 thay vì alert thông thường
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Thành công!',
                                    text: response.message,
                                    timer: 3000,
                                    showConfirmButton: false
                                });

                                // Cập nhật UI với URL chia sẻ
                                if (response.share_link) {
                                    $('#shareLink').val(response.share_link);
                                    $('#shareUrlContainer').removeClass('hidden');
                                }
                            }
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);

                            // Sử dụng SweetAlert2 cho thông báo lỗi
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi!',
                                text: 'Có lỗi xảy ra khi cập nhật cài đặt chia sẻ.',
                            });
                        }
                    });
                });
            });


            // Update share settings (simulation)
            // $('#updateShareSettings').on('click', function() {
            //     const isEnabled = $('#enableSharing').prop('checked');
            //     const expiryTime = $('#expiryTime').val();
            //     const password = $('#sharePassword').val();

            //     // Simulate API call
            //     setTimeout(function() {
            //         alert('Cài đặt chia sẻ đã được cập nhật!');
            //         $('#shareFileModal').modal('hide');
            //     }, 500);
            // });


            // Search functionality
            $('#searchInput').on('input', function() {
                const query = $(this).val().toLowerCase().trim();
                const searchWrapper = $(this).closest('.search-wrapper');
                const searchResults = searchWrapper.find('.search-results');

                if (query.length < 2) {
                    searchWrapper.removeClass('active');
                    return;
                }

                // Simulate search
                searchResults.empty();
                searchWrapper.addClass('active');

                // Search in folders
                let foundItems = 0;

                @foreach ($folders as $folder)
                    if ('{{ strtolower($folder->name) }}'.includes(query)) {
                        searchResults.append(`
                        <a href="{{ route('file-storage.folder', ['path' => $folder->path]) }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-folder folder-icon"></i> {{ $folder->name }}
                            <small class="text-muted d-block">Thư mục</small>
                        </a>
                    `);
                        foundItems++;
                    }
                @endforeach

                @foreach ($files as $file)
                    if ('{{ strtolower($file->name) }}'.includes(query)) {
                        searchResults.append(`
                        <a href="{{ route('file-storage.preview', $file->id) }}" target="_blank" class="list-group-item list-group-item-action">
                            <i class="fas {{ $file->getFileIconClass() }} mr-2"></i> {{ $file->name }}
                            <small class="text-muted d-block">{{ $file->formatSize() }}</small>
                        </a>
                    `);
                        foundItems++;
                    }
                @endforeach

                if (foundItems === 0) {
                    searchResults.append(`
                    <div class="list-group-item text-center py-3">
                        <i class="fas fa-search-minus mb-2"></i><br>
                        Không tìm thấy kết quả phù hợp với "${query}"
                    </div>
                `);
                }
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('.search-wrapper').length) {
                    $('.search-wrapper').removeClass('active');
                }
            });

            // Calculate and update storage usage
            function calculateStorageUsage() {
                // This would normally be an API call to get actual usage data
                // For demo purposes, we'll simulate it
                const usedMB = Math.floor(Math.random() * 500); // Random number between 0-500 MB
                const totalMB = 1024; // 1 GB
                const percentage = (usedMB / totalMB) * 100;

                $('#storageUsed').text(`${usedMB} MB / 1 GB`);
                $('.storage-progress .progress-bar').css('width', `${percentage}%`);

                // Change color based on usage
                const progressBar = $('.storage-progress .progress-bar');
                progressBar.removeClass('bg-primary bg-warning bg-danger');

                if (percentage > 90) {
                    progressBar.addClass('bg-danger');
                } else if (percentage > 70) {
                    progressBar.addClass('bg-warning');
                } else {
                    progressBar.addClass('bg-primary');
                }
            }

            calculateStorageUsage();
        });
    </script>
@endsection
