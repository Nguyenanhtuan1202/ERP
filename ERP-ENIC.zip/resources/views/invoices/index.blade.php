@extends('layouts.admin')

@section('content')
<div class="container">
  <h1>Danh sách Hóa đơn</h1>
  <a href="{{ route('invoices.create') }}" class="btn btn-primary mb-3">Thêm Hóa đơn mới</a>
  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Số hóa đơn</th>
        <th>Mã vận đơn</th>
        <th>Số tiền</th>
        <th>Trạng thái</th>
        <th>Hành động</th>
      </tr>
    </thead>
    <tbody>
      @foreach($invoices as $invoice)
        <tr>
          <td>{{ $invoice->id }}</td>
          <td>{{ $invoice->invoice_number }}</td>
          <td>{{ $invoice->shipment->tracking_number ?? 'N/A' }}</td>
          <td>{{ $invoice->amount }} {{ $invoice->currency }}</td>
          <td>{{ $invoice->status }}</td>
          <td>
            <a href="{{ route('invoices.show', $invoice->id) }}" class="btn btn-info btn-sm">Xem</a>
            <a href="{{ route('invoices.edit', $invoice->id) }}" class="btn btn-warning btn-sm">Sửa</a>
            <form action="{{ route('invoices.destroy', $invoice->id) }}" method="POST" style="display:inline-block">
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>

  {{ $invoices->links() }}
</div>
@endsection
