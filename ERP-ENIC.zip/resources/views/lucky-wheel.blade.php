<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vòng Quay May Mắn - Phân Công Công Việc</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

        body {
            text-align: center;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(45deg, #ff758c, #ff7eb3);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        }

        .container {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 700px;
            transition: transform 0.3s;
        }

        .container:hover {
            transform: scale(1.02);
        }

        h2 {
            color: #333;
            font-weight: 600;
        }

        .input-container {
            margin: 20px 0;
        }

        textarea {
            width: 100%;
            height: 80px;
            margin: 10px 0;
            padding: 12px;
            border: 2px solid #ff758c;
            border-radius: 8px;
            font-size: 16px;
            resize: none;
            transition: border 0.3s;
        }

        textarea:focus {
            border-color: #ff7eb3;
            outline: none;
        }

        button {
            cursor: pointer;
            padding: 12px;
            background: #ff758c;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            transition: 0.3s;
            width: 100%;
            margin-top: 10px;
        }

        button:hover {
            background: #ff5e78;
        }

        #wheel-container {
            margin: 20px auto;
            width: 300px;
            height: 300px;
            position: relative;
            border-radius: 50%;
            overflow: hidden;
            border: 10px solid #ff758c;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        #wheel {
            width: 100%;
            height: 100%;
            position: absolute;
            transform: rotate(0deg);
        }

        .sector {
            width: 50%;
            height: 50%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform-origin: 0% 0%;
            clip-path: polygon(0% 0%, 100% 50%, 0% 100%);
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            color: white;
        }

        #result {
            font-size: 20px;
            font-weight: bold;
            margin-top: 20px;
            color: #333;
            background: #ffebf0;
            padding: 10px;
            border-radius: 8px;
            white-space: pre-line;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Vòng Quay May Mắn - Phân Công Công Việc</h2>
        <div class="input-container">
            <textarea id="nameList" placeholder="Nguyễn Văn A
Trần Thị B
Lê Văn C
Phạm Thị E"></textarea>
            <textarea id="taskList" placeholder="Quét nhà - 2
Rửa chén - 3"></textarea>
            <button onclick="assignTasks()">Phân công công việc</button>
        </div>
        <div id="wheel-container">
            <div id="wheel"></div>
        </div>
        <p id="result"></p>
    </div>

    <script>
        let angle = 0;
        let availableNames = [];

        // Vẽ lại vòng quay dựa trên danh sách người hiện có
        function renderWheel() {
            const wheel = document.getElementById("wheel");
            wheel.innerHTML = "";
            if (availableNames.length === 0) return;
            let sliceAngle = 360 / availableNames.length;
            availableNames.forEach((name, index) => {
                let sector = document.createElement("div");
                sector.classList.add("sector");
                sector.style.backgroundColor = `hsl(${index * sliceAngle}, 70%, 50%)`;
                sector.style.transform = `rotate(${index * sliceAngle}deg) translate(50%)`;
                sector.innerText = name;
                wheel.appendChild(sector);
            });
        }

        // Hàm quay một lượt (một lần chọn)
        function spinWheelOnce() {
            return new Promise((resolve) => {
                const wheel = document.getElementById("wheel");
                // Tính số độ quay ngẫu nhiên: ít nhất 3600 độ (10 vòng) cộng thêm 0-360 độ
                let randomSpin = Math.floor(3600 + Math.random() * 360);
                angle += randomSpin;
                wheel.style.transition = "transform 3s ease-out";
                wheel.style.transform = `rotate(${angle}deg)`;
                // Sau khi hiệu ứng hoàn tất (3 giây)
                setTimeout(() => {
                    let finalRotation = angle % 360;
                    let numSectors = availableNames.length;
                    let selectedIndex = Math.floor((finalRotation / 360) * numSectors);
                    let selectedName = availableNames[selectedIndex];
                    // Loại bỏ người đã chọn khỏi danh sách có sẵn
                    availableNames.splice(selectedIndex, 1);
                    // Reset hiệu ứng chuyển động cho lần quay kế tiếp
                    wheel.style.transition = "none";
                    // Cập nhật vòng quay với danh sách người còn lại
                    renderWheel();
                    resolve(selectedName);
                }, 3000);
            });
        }

        // Hàm phân công công việc theo yêu cầu
        async function assignTasks() {
            // Reset kết quả và góc quay
            document.getElementById("result").innerText = "";
            angle = 0;
            // Lấy dữ liệu từ input
            let names = document.getElementById("nameList").value.split("\n")
                .map(name => name.trim()).filter(name => name);
            let taskInputs = document.getElementById("taskList").value.split("\n")
                .map(task => {
                    let parts = task.split(" - ");
                    return {
                        job: parts[0].trim(),
                        count: parseInt(parts[1])
                    };
                }).filter(task => task.job && task.count);

            if (names.length === 0 || taskInputs.length === 0) {
                document.getElementById("result").innerText = "Vui lòng nhập đầy đủ danh sách người và công việc!";
                return;
            }

            // Sao chép danh sách người để sử dụng trong quá trình quay
            availableNames = [...names];
            renderWheel();

            let resultAssignments = "";
            // Duyệt qua từng công việc
            for (let task of taskInputs) {
                resultAssignments += `${task.job}: `;
                let assignedForTask = [];
                // Thực hiện quay vòng cho số người cần của công việc đó
                for (let i = 0; i < task.count; i++) {
                    if (availableNames.length === 0) break;
                    let selectedName = await spinWheelOnce();
                    assignedForTask.push(selectedName);
                }
                resultAssignments += assignedForTask.join(", ") + "\n";
            }
            document.getElementById("result").innerText = "Kết quả phân công:\n" + resultAssignments;
        }
    </script>
</body>

</html>
