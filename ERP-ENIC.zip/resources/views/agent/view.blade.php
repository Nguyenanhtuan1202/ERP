@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="agent-details">
            <h2>Thông Tin Đại Lý</h2>
            <p><strong>Tên:</strong> {{ $data['agent']->name ?? '' }}</p>
            <p><strong>Địa Chỉ:</strong> {{ $data['agent']->address ?? '' }}</p>
            <p><strong>Điện Thoại:</strong> {{ $data['agent']->phone ?? '' }}</p>
            <p><strong>Email:</strong> {{ $data['agent']->email ?? '' }}</p>
            <p><strong>Ngày Tham Gia:</strong> {{ $data['agent']->date_create ?? '' }}</p>


        </div>

        <div class="warehouse-list">
            <h3>Danh Sách Kho Hàng Liên Quan</h3>
            <table id="warehouseTable" class="table">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Tên Kho</th>
                        <th>Địa Chỉ</th>
                        <th>Sức Chứa</th>
                        <th>Ngày Mở Kho</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $temp = 0;
                    @endphp
                    @foreach ($data['agent']->warehouses as $warehouse)
                        @php
                            $temp++;
                        @endphp
                        <tr>
                            <td>{{ $temp }}</td>
                            <td>{{ $warehouse->name ?? '' }}</td>
                            <td>{{ $warehouse->location ?? '' }}</td>
                            <td>{{ $warehouse->capacity ?? '' }}</td>
                            <td>{{ $warehouse->date_create ?? '' }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection


@section('js')
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f7f7f7;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .agent-details {
            margin-bottom: 30px;
        }

        .agent-details h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 15px;
            border-bottom: 2px solid #f1c40f;
            padding-bottom: 5px;
        }

        .agent-details p {
            font-size: 18px;
            color: #555;
            line-height: 1.6;
        }

        .warehouse-list h3 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #3498db;
            padding-bottom: 5px;
        }

        .table {
            width: 100%;
            background-color: #fff;
            border-collapse: collapse;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
        }

        .table th {
            background-color: #3498db;
            color: #fff;
            font-size: 16px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .table tbody tr:hover {
            background-color: #ddd;
            cursor: pointer;
        }
    </style>

    <script>
        // Thêm hiệu ứng cho bảng
        document.addEventListener("DOMContentLoaded", function() {
            const rows = document.querySelectorAll("#warehouseTable tbody tr");

            rows.forEach(row => {
                row.addEventListener("click", function() {
                    // Khi nhấn vào hàng, có thể điều hướng đến trang chi tiết kho hàng
                    // window.location.href = `/warehouse/${this.dataset.id}`;
                });
            });
        });

        // Nếu muốn thêm DataTables cho bảng (nếu bạn đã cài đặt)
        $(document).ready(function() {
            $('#warehouseTable').DataTable({
                "language": {
                    "sSearch": "Tìm kiếm:",
                    "lengthMenu": "Hiển thị _MENU_ dòng",
                    "info": "Hiển thị _START_ đến _END_ của _TOTAL_ dòng",
                    "paginate": {
                        "first": "Đầu",
                        "last": "Cuối",
                        "next": "Sau",
                        "previous": "Trước"
                    },
                }
            });
        });
    </script>
@endsection
