@extends('layouts.admin')

@section('content')
    <div class="box___expert">
        <div class="form-container-custom">
            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif
            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: '{{ session('error') }}',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif

            <form action="{{ url('/admin/agent/save') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <h2>Thêm đại lý </h2>

                <div class="form-group">
                    <label for="name">Họ và tên:</label>
                    <input type="text" id="name" name="name" required value="{{ old('name') }}">
                </div>

                <div class="form-group">
                    <label for="phone">Số điện thoại:</label>
                    <input type="tel" id="phone" name="phone" required value="{{ old('phone') }}">
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}">
                </div>

                <div class="form-group">
                    <label for="address">Địa chỉ:</label>
                    <input type="text" id="address" name="address" required value="{{ old('address') }}">
                </div>


                <div class="form-group">
                    <label for="date_create">Ngày Tham Gia:</label>
                    <input type="date" id="date_create" name="date_create" required value="{{ old('date_create') }}">
                </div>


                <button class="mt-4" type="submit">
                    Thêm mới
                </button>

            </form>
        </div>


    </div>
@endsection
