@extends('layouts.admin')

@section('content')
    <div class="container mt-5">
        <style>
            .title {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 20px;
            }

            .action-bar {
                margin-bottom: 20px;
            }

            .btn-add {
                display: inline-block;
                padding: 10px 15px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                transition: 0.3s;
            }

            .btn-add:hover {
                background: #0056b3;
                color: #fff;
            }

            .task-list {
                list-style: none;
                padding: 0;
            }

            .task-item {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 10px;
                box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
            }

            .task-item h3 {
                margin: 0;
                font-size: 18px;
                color: #333;
            }

            .task-item p {
                margin: 5px 0;
                font-size: 14px;
                color: #555;
            }

            .no-task {
                font-style: italic;
                color: #888;
                padding: 15px;
            }
        </style>
        <h2 class="title">📌 Danh Sách Công Việc</h2>

        <div class="action-bar">
            <a href="{{ route('tasks.create') }}" class="btn-add">➕ Thêm Công Việc</a>
        </div>

        <ul class="task-list">
            @if ($data)
                @forelse ($data as $task)
                    <li class="task-item">
                        <div class="task-content">
                            <h3>{{ $task->title }}</h3>
                            <p>⏰ Nhắc nhở lúc:
                                <strong>{{ \Carbon\Carbon::parse($task->reminder_time)->format('H:i d/m/Y') }}</strong>
                            </p>
                            <div>
                                <span>Nội dung</span>

                                {!! $task->description ?? '' !!}
                            </div>
                        </div>
                    </li>
                @empty
                    <li class="no-task">📭 Chưa có công việc nào!</li>
                @endforelse
            @endif
        </ul>
    </div>
@endsection
