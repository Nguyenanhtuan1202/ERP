@extends('layouts.admin')

@section('content')
    <h2>Thêm công việc</h2>

    <style>
        .save__task {
            background: linear-gradient(141.55deg, #0caf60 3.46%, #0caf60 99.86%), #0caf60;
            color: #fff;
            box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
            border-radius: 6px;
            padding: 8px 25px;
            border: none;
            outline: none;
            font-weight: 600;
        }
    </style>


    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="container">

        <form action="{{ route('tasks.store') }}" method="POST">
            @csrf
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        @error('title')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="title">Tiêu đề:</label>
                        <input id="title" class="form-control" type="text" name="title" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        @error('description')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="description">Thời gian nhắc nhở:</label>
                        <input class="form-control" type="datetime-local" name="reminder_time" required>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        @error('description')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="description">Mô tả công việc:</label>
                        <textarea name="description" id="description" class="form-control ckeditor" required></textarea>

                    </div>
                </div>

                <div class="col-md-12">
                    <button type="submit" class="save__task">Lưu</button>
                </div>

            </div>
        </form>
    </div>
@endsection
