<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phân Nhóm Trực Nhật Thông Minh</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .group-animate {
            animation: fadeIn 0.3s ease-out;
        }

        /* Tùy chỉnh scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        ::-webkit-scrollbar-thumb {
            background: #bae6fd;
            border-radius: 4px;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4 font-['Inter']">
    <div class="bg-white shadow-xl rounded-2xl w-full max-w-6xl mx-auto border border-gray-200">
        <!-- Header -->
        <div class="bg-gradient-to-r from-blue-50 to-cyan-50 px-8 py-6 border-b border-gray-200">
            <h1 class="text-3xl font-bold text-gray-800">
                <span class="text-blue-600">⚙️</span> Phân Nhóm Trực Nhật
            </h1>
            <p class="text-gray-600 mt-1">Phân nhóm thông minh với thuật toán cân bằng giới tính</p>
        </div>

        <!-- Main Content -->
        <div class="grid lg:grid-cols-2 gap-8 p-8">
            <!-- Input Section -->
            <div class="space-y-6">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        🧑🤝🧑 Danh sách thành viên (Định dạng: Tên - Giới tính)
                    </label>
                    <textarea id="peopleList" rows="8" placeholder="Ví dụ:
Nguyễn Văn A - Nam
Trần Thị B
Lê Văn C - nam
..."
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-300 transition-all shadow-sm hover:shadow-md"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            👥 Số người/nhóm
                        </label>
                        <input type="number" id="peoplePerGroup" min="1"
                            class="w-full p-2 border border-gray-300 rounded-lg focus:ring-blue-300"
                            placeholder="Nhập số người">
                    </div>
                    <div class="flex items-end">
                        <button onclick="generateGroups()"
                            class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-4 rounded-lg transition-all duration-300 flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z"
                                    clip-rule="evenodd" />
                            </svg>
                            Tạo nhóm
                        </button>
                    </div>
                </div>

                <div class="pt-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-3">
                        📅 Chọn ngày trực
                    </label>
                    <div class="grid grid-cols-3 gap-3">
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="2">
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0"></span>
                            <span class="text-gray-700">Thứ 2</span>
                        </label>
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="3" checked>
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0 bg-blue-500 border-blue-500"></span>
                            <span class="text-gray-700">Thứ 3</span>
                        </label>
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="4" checked>
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0 bg-blue-500 border-blue-500"></span>
                            <span class="text-gray-700">Thứ 4</span>
                        </label>
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="5" checked>
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0 bg-blue-500 border-blue-500"></span>
                            <span class="text-gray-700">Thứ 5</span>
                        </label>
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="6" checked>
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0 bg-blue-500 border-blue-500"></span>
                            <span class="text-gray-700">Thứ 6</span>
                        </label>
                        <label
                            class="flex items-center p-2 border border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer">
                            <input type="checkbox" class="day-checkbox sr-only" value="7" checked>
                            <span
                                class="custom-checkbox w-5 h-5 border-2 border-gray-300 rounded mr-2 flex-shrink-0 bg-blue-500 border-blue-500"></span>
                            <span class="text-gray-700">Thứ 7</span>
                        </label>
                    </div>
                    <div class="flex gap-2 mt-4">
                        <button onclick="toggleAllDays(true)"
                            class="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors">
                            Chọn tất cả
                        </button>
                        <button onclick="toggleAllDays(false)"
                            class="px-3 py-1.5 text-sm bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors">
                            Bỏ chọn hết
                        </button>
                    </div>
                </div>
            </div>

            <!-- Output Section -->
            <div>
                <div id="result"
                    class="bg-gray-50 rounded-xl p-6 h-[600px] overflow-y-auto shadow-inner border border-gray-200">
                    <div class="text-gray-400 text-center py-20">
                        ⬅️ Nhập thông tin và nhấn "Tạo nhóm" để xem kết quả
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Custom checkbox styling and interaction
            function setupCheckboxStyles() {
                document.querySelectorAll('.day-checkbox').forEach(function(checkbox) {
                    checkbox.addEventListener('change', function(e) {
                        const customCheckbox = e.target.parentElement.querySelector(
                            '.custom-checkbox');
                        if (this.checked) {
                            customCheckbox.classList.add('bg-blue-500', 'border-blue-500');
                        } else {
                            customCheckbox.classList.remove('bg-blue-500', 'border-blue-500');
                        }
                    });
                });
            }

            // Toggle all days selection
            function toggleAllDays(checked) {
                document.querySelectorAll('.day-checkbox').forEach(function(checkbox) {
                    checkbox.checked = checked;
                    checkbox.dispatchEvent(new Event('change'));
                });
            }

            // Fisher-Yates shuffle algorithm
            function shuffle(array) {
                for (let i = array.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [array[i], array[j]] = [array[j], array[i]];
                }
                return array;
            }

            // Validate and parse input people list
            function parsePeopleList(peopleList) {
                return peopleList.split('\n')
                    .filter(line => line.trim())
                    .map(line => {
                        const [name, gender = 'nữ'] = line.split('-').map(p => p.trim());
                        return {
                            name,
                            gender: gender.toLowerCase()
                        };
                    });
            }

            // Advanced group generation algorithm
            function generateGroups() {
                const resultDiv = document.getElementById('result');

                try {
                    // Retrieve input values
                    const peopleList = document.getElementById('peopleList').value;
                    const peoplePerGroup = parseInt(document.getElementById('peoplePerGroup').value);

                    // Get selected days
                    const selectedDays = Array.from(document.querySelectorAll('.day-checkbox:checked'))
                        .map(checkbox => parseInt(checkbox.value))
                        .sort((a, b) => a - b);

                    // Parse and validate input
                    const people = parsePeopleList(peopleList);

                    // Comprehensive input validation
                    if (people.length === 0) throw new Error('Vui lòng nhập danh sách thành viên');
                    if (isNaN(peoplePerGroup) || peoplePerGroup < 1) throw new Error('Số người/nhóm không hợp lệ');
                    if (selectedDays.length === 0) throw new Error('Vui lòng chọn ít nhất 1 ngày trực');

                    const totalGroups = selectedDays.length;
                    const totalMembers = people.length;
                    const baseGroupSize = peoplePerGroup;

                    // Advanced distribution handling
                    let groups = [];
                    const shuffledPeople = shuffle([...people]);
                    const males = shuffledPeople.filter(p => p.gender === 'nam');
                    const females = shuffledPeople.filter(p => p.gender !== 'nam');

                    // Ensure at least one male in each group initially
                    groups = Array.from({
                            length: totalGroups
                        }, (_, i) =>
                        males[i] ? [males[i]] : []
                    );

                    // Distribute remaining people
                    let remainingPeople = [...females, ...males.slice(totalGroups)];
                    let currentGroupIndex = 0;

                    while (remainingPeople.length > 0) {
                        const person = remainingPeople.pop();

                        // Dynamic group filling strategy
                        if (groups[currentGroupIndex].length < baseGroupSize) {
                            groups[currentGroupIndex].push(person);
                        } else {
                            // Find the least populated group
                            const leastPopulatedGroupIndex = groups.reduce((minIndex, group, index, arr) =>
                                group.length < arr[minIndex].length ? index : minIndex,
                                0
                            );
                            groups[leastPopulatedGroupIndex].push(person);
                        }

                        currentGroupIndex = (currentGroupIndex + 1) % totalGroups;
                    }

                    // Render results with detailed group information
                    resultDiv.innerHTML = `
                <div class="space-y-5">
                    ${groups.map((group, index) => `
                            <div class="group-animate bg-white rounded-xl p-5 shadow-sm border border-gray-200">
                                <div class="flex items-center gap-2 mb-3">
                                    <div class="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 font-bold flex items-center justify-center">
                                        ${selectedDays[index]}
                                    </div>
                                    <h3 class="font-semibold text-gray-800">
                                        Nhóm Thứ ${selectedDays[index]} 
                                        <span class="text-gray-500 font-normal">(${group.length} người)</span>
                                    </h3>
                                </div>
                                <div class="grid gap-2">
                                    ${group.map(member => `
                                    <div class="flex items-center gap-3 p-3 rounded-lg ${member.gender === 'nam' ? 'bg-blue-50' : 'bg-pink-50'}">
                                        <div class="w-7 h-7 rounded-full ${member.gender === 'nam' ? 'bg-blue-500' : 'bg-pink-500'} flex items-center justify-center text-white text-sm">
                                            ${member.gender === 'nam' ? '♂' : '♀'}
                                        </div>
                                        <span class="${member.gender === 'nam' ? 'text-blue-700' : 'text-pink-700'}">${member.name}</span>
                                    </div>
                                `).join('')}
                                </div>
                            </div>
                        `).join('')}
                </div>
            `;

                } catch (error) {
                    // Error handling with user-friendly message
                    resultDiv.innerHTML = `
                <div class="bg-red-50 border-l-4 border-red-500 p-4 text-red-700 rounded-lg">
                    <b>Lỗi:</b> ${error.message}
                </div>
            `;
                }
            }

            // Auto-adjust textarea height dynamically
            function setupTextareaAutoResize() {
                document.getElementById('peopleList').addEventListener('input', function() {
                    this.style.height = 'auto';
                    this.style.height = `${this.scrollHeight}px`;
                });
            }

            // Expose functions globally
            window.generateGroups = generateGroups;
            window.toggleAllDays = toggleAllDays;

            // Initialize application
            function init() {
                setupCheckboxStyles();
                setupTextareaAutoResize();
            }

            // Run initialization
            init();
        });
    </script>
</body>

</html>
