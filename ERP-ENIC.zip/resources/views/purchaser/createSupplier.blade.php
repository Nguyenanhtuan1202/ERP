@extends('layouts.layout_purchaser')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/supplier.css') }}">
@endsection
@section('content')
    <style>
        .table-custom th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #111;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
            background-color: #f1f3f5;
        }

        .table-custom td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            color: #111;
            vertical-align: top;
        }

        .table-custom tbody tr:hover {
            background-color: #f8f9fa;
            transition: background-color 0.2s ease;
        }

        /* Số thứ tự căn giữa */
        .table-custom td:first-child {
            text-align: center;
            font-weight: 500;
            color: #111;
        }

        /* Làm nổi bật header */
        .table-custom thead tr {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        /* Định dạng các cột dài */
        .table-custom td:nth-child(2),
        .table-custom td:nth-child(3),
        .table-custom td:nth-child(10),
        .table-custom td:nth-child(11) {
            max-width: 250px;
            white-space: normal;
            word-break: break-word;
        }

        .table-responsive #table2_wrapper {
            box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
            background-color: #fff;
        }

        .supplier-guide__btn {
            background-color: #008ba6;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            margin-left: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15);
        }

        .supplier-guide__btn i {
            margin-right: 8px;
            font-size: 16px;
        }

        .supplier-guide__btn:hover {
            background-color: #008ba6;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .supplier-guide__btn:active {
            transform: translateY(0);
        }


        /* Style cho popup hướng dẫn */
        .guide-popup {
            border-radius: 15px !important;
        }

        .guide-popup-content {
            text-align: left;
            padding: 0 10px;
        }

        .guide-content {
            max-height: 70vh;
            overflow-y: auto;
            padding-right: 10px;
        }

        .guide-step {
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e9ecef;
        }

        .guide-step:last-child {
            border-bottom: none;
        }

        .step-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .step-header i {
            font-size: 20px;
            color: #086597;
            margin-right: 10px;
            width: 30px;
            text-align: center;
        }

        .step-header h3 {
            font-size: 16px;
            margin: 0;
            color: #343a40;
        }

        .guide-step p {
            color: #495057;
            text-align: left;
            font-size: 15px;
        }

        .guide-step ul,
        .guide-step ol {
            color: #495057;
        }

        .guide-step ul li,
        .guide-step ol li {
            margin-bottom: 5px;
            text-align: left;
            font-size: 15px;
            line-height: 24px;
        }
    </style>

    <div class="container-fluid mt-5">
        <div class="row justify-content-center">
            <div class="col-md-12 box__new-supplier">

                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                @if (session('error'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Lỗi',
                                text: '{{ session('error') }}',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#d33',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


                <form class="form row" action="{{ route('supplierManagement.store') }}" method="POST"
                    enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="col-md-4 box__new-supplier-item">
                        <h2 class="title_h2">Thông Tin Nhà Cung Cấp</h2>
                        <div class="form-group">
                            <label class="label__sp" for="username">Tên Nhà Cung Cấp<small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="username" required value="" class="form-input-custom-sp"
                                id="username" placeholder="Nhập vào tên cá nhân...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="sp_code">Mã Nhà Cung Cấp <small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="sp_code" required class="form-input-custom-sp" id="sp_code"
                                placeholder="Mã nhà cung cấp..." value="">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="phone_number">Số Điện Thoại </label>
                            <input type="text" class="form-input-custom-sp" name="phone_number" id="phone_number"
                                placeholder="Số điện thoại..." value="">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="email">Email </label>
                            <input type="email" class="form-input-custom-sp" name="email" id="email"
                                placeholder="Email..." value="">
                        </div>
                    </div>
                    <div class="col-md-4 box__new-supplier-item">
                        <div class="form-group">
                            <label class="label__sp" for="company_name">Tên Công Ty</label>
                            <input type="text" class="form-input-custom-sp" name="company_name" id="company_name"
                                placeholder="Tên công ty..." value="">
                        </div>
                        <div class="form-group">
                            <label class="companion_day" for="companion_day">Ngày Hợp Tác</label>
                            <input type="date" class="form-input-custom-sp" name="companion_day" id="companion_day"
                                placeholder="Ví dụ: Ngày" value="">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="website">Website</label>
                            <input type="text" class="form-input-custom-sp" name="website" id="website"
                                placeholder="Ví dụ enic.vn" value="">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="address">Địa Chỉ </label>
                            <input type="text" class="form-input-custom-sp" name="address" id="address"
                                placeholder="Địa chỉ..." value="">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="company_tax">MST</label>
                            <input type="text" class="form-input-custom-sp" name="company_tax" id="company_tax"
                                placeholder="MST công ty/ Cá Nhân..." value="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="tabs mb-4">
                            <ul class="nav nav-tabs" id="supplierTabs" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" id="sales-tab" data-toggle="tab" href="#sales"
                                        role="tab" aria-controls="sales" aria-selected="false">Mua Hàng</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="invoice-tab" data-toggle="tab" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="false">Thanh Toán</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="notes-tab" data-toggle="tab" href="#notes" role="tab"
                                        aria-controls="notes" aria-selected="false">Ghi chú nội bộ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="more-tab" data-toggle="tab" href="#more" role="tab"
                                        aria-controls="notes" aria-selected="false">Mở rộng</a>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content" id="supplierTabsContent">

                            <div class="tab-pane fade show active" id="sales" role="tabpanel"
                                aria-labelledby="sales-tab">
                                <!-- Content for Bán hàng và Mua hàng -->


                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="employer">Người Phụ Trách Dự Toán
                                            :</label>
                                    </div>
                                    <div>
                                        <div class="form-group">
                                            <select class="form-control select3_init" name="forecaster_id"
                                                id="forecaster_id">
                                                <option value="">Chọn</option>
                                                @foreach ($list_forecaster as $item)
                                                    <option value="{{ $item->id }}">
                                                        {{ $item->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                </div>


                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="employer">Người Phụ Trách Mua Hàng
                                            :</label>
                                    </div>
                                    <div>
                                        <div class="form-group">
                                            <select class="form-control select3_init" name="employer_id"
                                                id="employer_id">
                                                <option value="">Chọn</option>
                                                @foreach ($list_purchaser as $item)
                                                    <option @if (Auth::id() == $item->id) selected @endif
                                                        value="{{ $item->id }}">
                                                        {{ $item->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="terms">Điều khoản thanh toán :</label>
                                    </div>
                                    <div>
                                        <select name="terms" class="form-control select3_init form-input-custom-sp"
                                            id="terms">
                                            <option value="">Chọn</option>
                                            @foreach (list_terms() as $key => $term)
                                                <option value="{{ $key }}">{{ $term }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="payments">Hình thức thanh toán :</label>
                                    </div>
                                    <div>
                                        <select class="form-control form-input-custom-sp select3_init" name="payments"
                                            id="payments">
                                            <option value="">Chọn</option>
                                            <option value="ALIPAY">ALIPAY</option>
                                            <option value="TK CÁ NHÂN">TK CÁ NHÂN</option>
                                            <option value="TK CÔNG TY">TK CÔNG TY</option>
                                            <option value="WE CHAT">WE CHAT</option>
                                            <option value="VND">VND</option>
                                            <option value="USD">USD</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="industry">Ngành nghề :</label>
                                    </div>
                                    <div>
                                        <input type="text" name="industry" id="industry"
                                            class="form-input-custom-sp" placeholder="Nhập Ngành Nghề" value="">
                                    </div>
                                </div>

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="status">Trạng thái :</label>
                                    </div>
                                    <div class="form-group">

                                        <select class="form-control" name="status" id="status">
                                            <option value="1">Đang
                                                hoạt
                                                động</option>
                                            <option value="0">Tạm
                                                ngừng
                                            </option>
                                        </select>
                                    </div>
                                </div>


                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="deposit">Đặt Cọc :</label>
                                    </div>
                                    <div>
                                        <input type="text" name="deposit" id="deposit" class="form-input-custom-sp"
                                            placeholder="Vd: 20%..." value="">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="invoice" role="tabpanel" aria-labelledby="invoice-tab">
                                <!-- Content for Hóa đơn -->
                                <h5>Tài Khoản Ngân Hàng</h5>

                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Số Tài Khoản</th>
                                            <th>Tên Ngân Hàng</th>
                                            <th>Chủ Tài Khoản</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bankAccountsList">
                                        <!-- Bank accounts will be appended here -->
                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-secondary" data-toggle="modal"
                                    data-target="#addBankAccountModal">Thêm Tài Khoản Ngân Hàng</button>

                            </div>
                            <div class="tab-pane fade" id="notes" role="tabpanel" aria-labelledby="notes-tab">
                                <!-- Content for Ghi chú nội bộ -->
                                <textarea style="border:1px solid #f1f1f1; outline:none; border-radius: 8px" name="note" id="note"
                                    cols="50" rows="5" placeholder="Ghi Chú"></textarea>
                            </div>
                            <div class="tab-pane fade" id="more" role="tabpanel" aria-labelledby="more-tab">


                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="peak_season">Mùa cao điểm :</label>
                                    </div>
                                    <div>
                                        <textarea id="peak_season" name="peak_season" class="form-input-custom-sp" placeholder="Mùa cao điểm"></textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="holiday_schedule">Lịch Nghỉ Tết, Lễ :</label>
                                    </div>
                                    <div>
                                        <textarea id="holiday_schedule" name="holiday_schedule" class="form-input-custom-sp" placeholder="Nhập lịch nghỉ"></textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="packaging_specifications">Quy Cách Đóng Gói
                                            :</label>
                                    </div>
                                    <div>
                                        <textarea id="packaging_specifications" name="packaging_specifications" class="form-input-custom-sp"
                                            placeholder="Nhập quy cách đóng gói"></textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="production_time">Thời Gian Sản Xuất :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="production_time" name="production_time"
                                            class="form-input-custom-sp" placeholder="Nhập số ngày sản xuất"
                                            value="">
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="shipping_time">Thời Gian Vận Chuyển :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="shipping_time" name="shipping_time"
                                            class="form-input-custom-sp" placeholder="Nhập số ngày vận chuyển"
                                            value="">
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="total_lead_time">Tổng Thời Gian Về Kho Dự Kiến
                                            :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="total_lead_time" name="total_lead_time"
                                            class="form-input-custom-sp" placeholder="Nhập tổng thời gian"
                                            value="">
                                    </div>
                                </div>


                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="exclusive_rights">Độc Quyền :</label>
                                    </div>
                                    <div>
                                        <select id="exclusive_rights" name="exclusive_rights"
                                            class="form-input-custom-sp">
                                            <option value="0">
                                                Không</option>
                                            <option value="1">
                                                Có</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="warranty_preorder">Thống Nhất Hàng Bảo Hành Trước
                                            Khi Xảy Ra Lỗi :</label>
                                    </div>
                                    <div>
                                        <textarea id="warranty_preorder" name="warranty_preorder" class="form-input-custom-sp"
                                            placeholder="Nhập thông tin bảo hành trước khi có lỗi"></textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="warranty_postorder">Thống Nhất Hàng Bảo Hành Sau Khi
                                            Xảy Ra Lỗi :</label>
                                    </div>
                                    <div>
                                        <textarea id="warranty_postorder" name="warranty_postorder" class="form-input-custom-sp"
                                            placeholder="Nhập thông tin bảo hành sau khi có lỗi"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn__updated-info">Thêm Mới <i class="far fa-save"></i></button>
                    <a style="background-color: #086597; color:#fff" href="{{ route('supplierManagement.index') }}"
                        class="btn__updated-info ml-2">Danh Sách <i class="fas fa-stream"></i></a>
                    <button type="button" id="supplier-guide-btn" class="supplier-guide__btn">
                        <i class="fas fa-question-circle"></i> Hướng dẫn sử dụng
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal for adding bank account -->
    <div class="modal fade" id="addBankAccountModal" tabindex="-1" role="dialog"
        aria-labelledby="addBankAccountModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBankAccountModalLabel">Thêm Tài Khoản Ngân Hàng</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="modal_bank_name">Tên Ngân Hàng</label>
                        <input type="text" class="form-control" id="modal_bank_name"
                            placeholder="Nhập tên ngân hàng">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_number">Số Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_number"
                            placeholder="Nhập số tài khoản">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_holder">Chủ Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_holder"
                            placeholder="Nhập tên chủ tài khoản">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="saveBankAccount">Lưu</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tìm nút hướng dẫn
            const guideBtn = document.getElementById('supplier-guide-btn');

            // Thêm sự kiện click
            if (guideBtn) {
                guideBtn.addEventListener('click', showGuide);
            }

            // Hàm hiển thị hướng dẫn
            function showGuide() {
                Swal.fire({
                    title: '<strong>Hướng dẫn Thêm nhà cung cấp</strong>',
                    icon: 'info',
                    html: `
                <div class="guide-content">
                    <div class="guide-step">
                        <div class="step-header">
                            <i class="fas fa-user-plus"></i>
                            <h3>1. Thêm mới nhà cung cấp</h3>
                        </div>
                        <p>Nhập đầy đủ thông tin cần thiết tại các trường có dấu (<span style="color: red">*</span>):</p>
                        <ul>
                            <li>Tên Nhà Cung Cấp: Tên đầy đủ của cá nhân hoặc đơn vị cung cấp</li>
                            <li>Mã Nhà Cung Cấp: Mã định danh duy nhất</li>
                              <li>Lưu ý: Tên công ty, địa chỉ nhà cung cấp phải sử dụng tiếng anh không được sử dụng tiếng trung</li>
                        </ul>
                    </div>
                    
                    <div class="guide-step">
                        <div class="step-header">
                            <i class="fas fa-building"></i>
                            <h3>2. Thông tin công ty</h3>
                        </div>
                        <p>Điền thông tin về công ty như tên, địa chỉ, website và mã số thuế để thuận tiện trong việc quản lý.</p>
                    </div>
                    
                    <div class="guide-step">
                        <div class="step-header">
                            <i class="fas fa-tags"></i>
                            <h3>3. Các tab chức năng</h3>
                        </div>
                        <p>Hệ thống có 4 tab chính:</p>
                        <ul>
                            <li><strong>Mua Hàng</strong>: Thiết lập thông tin người phụ trách, điều khoản và hình thức thanh toán</li>
                            <li><strong>Thanh Toán</strong>: Quản lý tài khoản ngân hàng của nhà cung cấp</li>
                            <li><strong>Ghi chú nội bộ</strong>: Thêm các ghi chú quan trọng về nhà cung cấp</li>
                            <li><strong>Mở rộng</strong>: Bổ sung thông tin về thời gian sản xuất, vận chuyển và bảo hành</li>
                        </ul>
                    </div>
                    
                    <div class="guide-step">
                        <div class="step-header">
                            <i class="fas fa-university"></i>
                            <h3>4. Thêm tài khoản ngân hàng</h3>
                        </div>
                        <p>Để thêm tài khoản ngân hàng của nhà cung cấp:</p>
                        <ol>
                            <li>Chuyển đến tab "Thanh Toán"</li>
                            <li>Nhấn nút "Thêm Tài Khoản Ngân Hàng"</li>
                            <li>Điền đầy đủ thông tin vào form</li>
                        </ol>
                    </div>
                    
                    <div class="guide-step">
                        <div class="step-header">
                            <i class="fas fa-save"></i>
                            <h3>5. Lưu thông tin</h3>
                        </div>
                        <p>Sau khi hoàn tất việc nhập liệu, nhấn nút "Thêm Mới" để lưu thông tin nhà cung cấp vào hệ thống.</p>
                    </div>
                </div>
            `,
                    customClass: {
                        container: 'guide-container',
                        popup: 'guide-popup',
                        content: 'guide-popup-content',
                    },
                    width: '700px',
                    showCloseButton: true,
                    showConfirmButton: false,
                    showCancelButton: true,
                    cancelButtonText: 'Đóng',
                    cancelButtonColor: '#6c757d',
                    focusCancel: false
                });
            }
        });





        $(document).ready(function() {
            var bankAccountIndex = 0;

            $('#saveBankAccount').click(function() {
                var bankName = $('#modal_bank_name').val();
                var accountNumber = $('#modal_account_number').val();
                var accountHolder = $('#modal_account_holder').val();

                if (bankName && accountNumber && accountHolder) {
                    var newBankAccountRow = `
                    <tr>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_number]" value="${accountNumber}">${accountNumber}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][bank_name]" value="${bankName}">${bankName}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_holder]" value="${accountHolder}">${accountHolder}</td>
                    </tr>
                `;
                    $('#bankAccountsList').append(newBankAccountRow);
                    bankAccountIndex++;
                    $('#addBankAccountModal').modal('hide');
                    $('#modal_bank_name').val('');
                    $('#modal_account_number').val('');
                    $('#modal_account_holder').val('');
                } else {
                    alert('Vui lòng điền đầy đủ thông tin.');
                }
            });
        });
    </script>
@endsection
