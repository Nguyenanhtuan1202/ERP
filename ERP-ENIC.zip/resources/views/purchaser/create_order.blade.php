@extends('layouts.layout_purchaser')
@section('content')
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f4f7f6;
            color: #111;
            line-height: 1.6;
        }

        /* Container */
        #wrapper__purchase-order.container {
            width: 100%;
            max-width: 1336px;
            margin: 20px auto;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 30px;
        }

        /* Typography */
        #wrapper__purchase-order .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f1f3f5;
        }

        /* Form Elements */
        #wrapper__purchase-order .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #e0e4e7;
            border-radius: 6px;
            background-color: white;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        #wrapper__purchase-order .form-control:focus {
            outline: none;
            border-color: #3498db !important;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }

        /* Select Dropdowns */
        #wrapper__purchase-order .select-wrapper {
            position: relative;
        }

        #wrapper__purchase-order .select-wrapper::after {
            content: '▼';
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            color: #7f8c8d;
            pointer-events: none;
        }

        #wrapper__purchase-order select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }

        /* Table Styles */
        #wrapper__purchase-order .product-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        #wrapper__purchase-order .product-table thead {
            background-color: #f8f9fa;
        }

        #wrapper__purchase-order .product-table th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #2c3e50;
            border-bottom: 2px solid #e0e4e7;
        }

        #wrapper__purchase-order .product-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #f1f3f5;
        }

        #wrapper__purchase-order .empty-state {
            text-align: center;
            padding: 50px;
            color: #a0a0a0;
        }

        /* Buttons */
        #wrapper__purchase-order .btn {
            display: inline-block;
            padding: 5px 10px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
            text-transform: capitalize;
        }

        #wrapper__purchase-order .btn:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        #wrapper__purchase-order .btn-secondary {
            background-color: #2ecc71;
        }

        #wrapper__purchase-order .btn-secondary:hover {
            background-color: #27ae60;
        }

        /* Additional Sections */
        #wrapper__purchase-order .details-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        #wrapper__purchase-order .notes-area {
            width: 60%;
        }

        #wrapper__purchase-order .summary-area {
            width: 35%;
            text-align: right;
        }

        #wrapper__purchase-order textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #e0e4e7;
            border-radius: 6px;
            min-height: 100px;
        }

        /* Modern Modal Styling */
        #addSupplierModal .modal-content {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        #addSupplierModal .modal-header {
            background: linear-gradient(135deg, #4a6bff, #2541b2);
            color: white;
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            padding: 20px 25px;
        }

        #addSupplierModal .modal-title {
            font-weight: 600;
            font-size: 1.25rem;
        }

        #addSupplierModal .close {
            color: white;
            opacity: 0.8;
            text-shadow: none;
            transition: opacity 0.3s;
        }

        #addSupplierModal .close:hover {
            opacity: 1;
        }

        #addSupplierModal .modal-body {
            padding: 25px;
        }

        /* Form Styling */
        #addSupplierForm .form-group {
            margin-bottom: 20px;
        }

        #addSupplierForm label {
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
            display: block;
        }

        #addSupplierForm .form-control {
            height: auto;
            padding: 12px 15px;
            border: 1px solid #e1e5eb;
            border-radius: 8px;
            box-shadow: none;
            transition: all 0.3s;
        }

        #addSupplierForm .form-control:focus {
            border-color: #4a6bff;
            box-shadow: 0 0 0 3px rgba(74, 107, 255, 0.15);
        }

        #addSupplierForm .form-control::placeholder {
            color: #b0b6c3;
        }

        /* Button Styling */
        #addSupplierModal .modal-footer {
            border-top: none;
            padding: 0 25px 25px 25px;
        }

        #addSupplierModal .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }

        #addSupplierModal .btn-secondary {
            background-color: #eaecf1;
            border-color: #eaecf1;
            color: #4a5568;
        }

        #addSupplierModal .btn-secondary:hover {
            background-color: #d5d9e2;
            border-color: #d5d9e2;
            color: #2d3748;
        }

        #addSupplierModal .btn-primary {
            background: linear-gradient(135deg, #4a6bff, #2541b2);
            border-color: #2541b2;
            box-shadow: 0 4px 10px rgba(37, 65, 178, 0.2);
        }

        #addSupplierModal .btn-primary:hover {
            background: linear-gradient(135deg, #3a5bef, #1531a2);
            border-color: #1531a2;
            box-shadow: 0 6px 15px rgba(37, 65, 178, 0.3);
            transform: translateY(-1px);
        }

        /* Add these styles to your CSS file */



        /* CSS cho phần tìm kiếm sản phẩm */
        .product-search-results {
            position: absolute;
            z-index: 1000;
            width: 60%;
            max-height: 400px;
            overflow-y: auto;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 60px;
        }

        .search-status {
            position: absolute;
            z-index: 999;
            margin-top: 5px;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 4px;
            font-size: 14px;
            color: #6c757d;
        }

        .results-header {
            padding: 10px;
            background: #f8f9fa;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
            color: #495057;
        }

        .product-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .product-item {
            display: flex;
            padding: 10px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .product-item:hover {
            background-color: #f5f5f5;
        }

        .product-item:last-child {
            border-bottom: none;
        }

        .product-image {
            width: 60px;
            height: 60px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .product-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .product-info {
            flex: 1;
        }

        .product-name {
            font-weight: bold;
            margin-bottom: 3px;
        }

        .product-sku,
        .product-price,
        .product-unit {
            font-size: 12px;
            color: #6c757d;
            margin-bottom: 2px;
        }

        .product-action {
            display: flex;
            align-items: center;
        }

        .add-product-btn {
            padding: 3px 6px;
        }

        .no-results {
            padding: 20px;
            text-align: center;
            color: #6c757d;
        }

        .no-results.error {
            color: #dc3545;
        }

        mark {
            background-color: #fff3cd;
            padding: 0 2px;
            border-radius: 2px;
        }

        .product-thumbnail {
            width: 40px;
            height: 40px;
            object-fit: contain;
        }

        .quantity-input,
        .price-input,
        .discount-input {
            max-width: 100px;
        }
    </style>
    <div class="container" id="wrapper__purchase-order">
        <div class="row">
            <div class="col-md-8">
                <h3 class="section-title">Thông tin nhà cung cấp</h3>
                <div class="supplier-selection-container d-flex align-items-center">
                    <select class="form-control select3_init" name="supplier" id="supplier">
                        <option value="">Tìm theo tên, mã nhà cung cấp...</option>
                        @foreach ($data['list_supplier'] as $item)
                            <option value="{{ $item->sp_code ?? '' }}">{{ $item->company_name ?? '' }} |
                                {{ $item->sp_code ?? '' }}</option>
                        @endforeach
                    </select>

                    <div style="width: 120px;">
                        <a href="#" class="btn btn-primary ml-2" data-toggle="modal" data-target="#addSupplierModal">
                            <i class="fa fa-plus"></i> Thêm mới
                        </a>
                    </div>

                </div>
                <!-- Modal for adding new supplier -->
                <div class="modal fade" id="addSupplierModal" tabindex="-1" role="dialog"
                    aria-labelledby="addSupplierModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addSupplierModalLabel">Thêm mới nhà cung cấp</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <!-- Add your form fields for creating a new supplier here -->
                                <form id="addSupplierForm" action="" method="POST">
                                    @csrf
                                    <div class="form-group">
                                        <label for="company_name">Tên công ty</label>
                                        <input type="text" class="form-control" id="company_name" name="company_name"
                                            placeholder="Nhập tên công ty" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sp_code">Mã nhà cung cấp</label>
                                        <input type="text" class="form-control" id="sp_code" name="sp_code"
                                            placeholder="Nhập mã nhà cung cấp" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Địa Chỉ</label>
                                        <input type="text" class="form-control" id="address" name="address"
                                            placeholder="Nhập địa chỉ">
                                    </div>
                                    <!-- Add more fields as needed -->
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                                <button type="button" class="btn btn-primary" id="saveSupplier">
                                    <i class="fa fa-save mr-1"></i> Lưu
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info__company">Chưa có thông tin nhà cung cấp</div>
            </div>
            <div class="col-md-4">
                <h3 class="section-title">Thông tin đơn nhập hàng</h3>
                <div class="select-wrapper">
                    <select class="form-control select4_init" name="warehouse_location" id="warehouse_location">
                        <option value="TMĐT - HỒ CHÍ MINH">TMĐT - HỒ CHÍ MINH</option>
                        <option value="SHOWROOM VẠN PHÚC">SHOWROOM VẠN PHÚC</option>
                        <option value="SHOWROOM Q1/TB">SHOWROOM Q1/TB</option>
                        <option value="KHO HẢI PHÒNG">KHO HẢI PHÒNG</option>
                        <option value="KHO PHƯỚC SƠN" selected>KHO PHƯỚC SƠN</option>
                        <option value="KHO NHẤT TÍN - HƯNG YÊN">KHO NHẤT TÍN - HƯNG YÊN</option>
                        <option value="SHOWROOM XÃ ĐÀN">SHOWROOM XÃ ĐÀN</option>
                        <option value="MĐT - HÀ NỘI">MĐT - HÀ NỘI</option>
                        <option value="SHOWROOM BÌNH DƯƠNG">SHOWROOM BÌNH DƯƠNG</option>
                        <option value="KHO ĐÀ NẴNG">KHO ĐÀ NẴNG</option>
                        <option value="SHOWROOM ĐÀ NẴNG">SHOWROOM ĐÀ NẴNG</option>
                        <option value="SHOWROOM HẢI PHÒNG">SHOWROOM HẢI PHÒNG</option>
                    </select>
                </div>
                <div class="select-wrapper" style="margin-top: 10px;">
                    <select class="form-control select4_init">
                        <option>Chọn Nhân Viên</option>
                        @foreach ($data['list_user'] as $item)
                            <option {{ Auth::id() == $item->id ? 'selected' : '' }} value="{{ $item->id ?? '' }}">
                                {{ $item->name ?? '' }}</option>
                        @endforeach
                    </select>
                </div>
                <input type="datetime-local" class="form-control" placeholder="Chọn ngày hẹn giao"
                    style="margin-top: 10px;">
            </div>
        </div>

        <div style="margin-top: 30px;">
            <h3 class="section-title">Thông tin sản phẩm</h3>

            <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
                <input type="text" class="form-control" id="product-search-input" placeholder="Tìm theo tên, mã SKU"
                    style="width: 60%;">
                <button class="form-control multiple__product" style="width: 150px;">Chọn Nhiều</button>
                <select class="form-control" style="width: 10%;">
                    <option>F(10)</option>
                </select>
                <select class="form-control" style="width: 10%;">
                    <option>Giá nhập</option>
                </select>
            </div>

            <table class="product-table">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Ảnh</th>
                        <th>Tên sản phẩm</th>
                        <th>Đơn vị</th>
                        <th>SL nhập</th>
                        <th>Đơn giá</th>
                        <th>Chiết khấu</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="8" class="empty-state">
                            Đơn hàng của bạn chưa có sản phẩm nào
                        </td>
                    </tr>
                </tbody>
            </table>



            <div class="details-section">
                <div class="notes-area">
                    <textarea placeholder="Ghi Chú:"></textarea>
                </div>
                <div class="summary-area">
                    <p>Số lượng: <strong>0</strong></p>
                    <p>Tổng tiền: <strong>0</strong></p>
                    <div style="margin-top: 15px;">

                        <button class="btn" style="margin-top: 10px;">Thêm chi phí (F7)</button>
                        <button class="btn btn-secondary" style="margin-top: 10px;">Thêm phương thức</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        /* Thêm mới sản phẩm */

        $('.select3_init').select2({
            'placeholder': 'Tìm theo theo tên công ty, mã nhà cung cấp...'
        });

        $('.select4_init').select2({
            'placeholder': 'Chọn'
        });




        /* CHỨC NĂNG CHỌN TỪNG SẢN PHẨM VÀ CHỌN NHIỀU SẢN PHẨM */
        $(document).ready(function() {
            // ===== PHẦN 1: CHỌN TỪNG SẢN PHẨM =====

            // Đảm bảo phần tử tìm kiếm tồn tại trong DOM
            const productSearchInput = $('input[placeholder*="Tìm theo tên, mã SKU"]');

            // Thêm ID nếu chưa có
            if (!productSearchInput.attr('id')) {
                productSearchInput.attr('id', 'product-search-input');
            }

            const productSearchResults = $(
                '<div id="product-search-results" class="product-search-results"></div>');

            // Thêm container kết quả và styling
            productSearchInput.after(productSearchResults);
            productSearchResults.hide();

            // Thêm phần tử hiển thị trạng thái tìm kiếm
            const searchStatus = $('<div id="search-status" class="search-status"></div>');
            productSearchInput.after(searchStatus);
            searchStatus.hide();

            // Biến để lưu timer debounce
            let searchTimer;
            // Biến lưu giá trị tìm kiếm trước đó để tránh tìm kiếm trùng lặp
            let lastSearchTerm = '';

            // Khi input được focus, hiển thị kết quả gần đây nếu có
            productSearchInput.on('focus', function() {
                const searchTerm = $(this).val().toLowerCase().trim();
                if (searchTerm.length > 0) {
                    performSearch(searchTerm);
                } else {
                    loadRecentProducts();
                }
            });

            // Khi gõ trong ô tìm kiếm
            productSearchInput.on('input', function() {
                const searchTerm = $(this).val().toLowerCase().trim();

                // Xóa timer hiện tại nếu có
                if (searchTimer) {
                    clearTimeout(searchTimer);
                }

                // Không tìm kiếm nếu chuỗi tìm kiếm quá ngắn hoặc trùng với tìm kiếm trước
                if (searchTerm === lastSearchTerm) {
                    return;
                }

                if (searchTerm.length > 0) {
                    // Hiển thị trạng thái đang tìm kiếm
                    searchStatus.html('<i class="fa fa-spinner fa-spin"></i> Đang tìm kiếm...').show();
                    productSearchResults.hide();

                    // Đặt timer để trì hoãn tìm kiếm (debounce) - chỉ tìm sau khi người dùng ngừng gõ
                    searchTimer = setTimeout(function() {
                        performSearch(searchTerm);
                    }, 20);
                } else {
                    // Nếu ô tìm kiếm trống, hiển thị sản phẩm gần đây
                    searchStatus.hide();
                    loadRecentProducts();
                }
            });

            // Xử lý phím tắt và đặc biệt
            productSearchInput.on('keydown', function(e) {
                // Enter để chọn sản phẩm đầu tiên
                if (e.which === 13) {
                    e.preventDefault();
                    const firstProduct = productSearchResults.find('.product-item').first();
                    if (firstProduct.length) {
                        selectProduct(firstProduct);
                    }
                }

                // Down arrow để focus vào sản phẩm đầu tiên
                if (e.which === 40) {
                    e.preventDefault();
                    productSearchResults.find('.product-item').first().focus();
                }

                // Escape để đóng kết quả tìm kiếm
                if (e.which === 27) {
                    e.preventDefault();
                    productSearchResults.hide();
                    searchStatus.hide();
                }
            });

            // Thêm điều hướng bằng phím cho danh sách kết quả
            $(document).on('keydown', '.product-item', function(e) {
                if (e.which === 13) { // Enter
                    e.preventDefault();
                    selectProduct($(this));
                } else if (e.which === 40) { // Down arrow
                    e.preventDefault();
                    $(this).next('.product-item').focus();
                } else if (e.which === 38) { // Up arrow
                    e.preventDefault();
                    const prev = $(this).prev('.product-item');
                    if (prev.length) {
                        prev.focus();
                    } else {
                        productSearchInput.focus();
                    }
                }
            });

            // Đóng kết quả khi click bên ngoài
            $(document).on('click', function(event) {
                if (!$(event.target).closest('#product-search-input, #product-search-results').length) {
                    productSearchResults.hide();
                    searchStatus.hide();
                }
            });

            // Phím tắt F3 để focus vào ô tìm kiếm
            $(document).on('keydown', function(e) {
                if (e.which === 114) { // F3 key
                    e.preventDefault();
                    productSearchInput.focus();
                }
            });

            // ===== PHẦN 2: CHỌN NHIỀU SẢN PHẨM =====

            // Tìm nút "Chọn Nhiều" hoặc tạo mới nếu chưa có
            let multipleSelectButton = $('.multiple__product');

            // Nếu không có nút, tạo mới
            if (multipleSelectButton.length === 0) {
                multipleSelectButton = $(
                    '<button class="btn btn-info multiple__product"><i class="fa fa-th-list"></i> Chọn Nhiều</button>'
                );
                // Thêm nút vào cạnh ô tìm kiếm
                productSearchInput.parent().append(multipleSelectButton);
            }

            // Tạo modal chọn nhiều sản phẩm
            const multipleSelectModal = $(`
        <div class="modal fade" id="multipleProductModal" tabindex="-1" role="dialog" aria-labelledby="multipleProductModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="multipleProductModalLabel">Chọn nhiều sản phẩm</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" class="form-control" id="multipleProductSearch" placeholder="Tìm kiếm sản phẩm...">
                        </div>
                        <div class="products-container">
                            <div class="text-center py-4">
                                <i class="fa fa-spinner fa-spin fa-2x"></i>
                                <p>Đang tải danh sách sản phẩm...</p>
                            </div>
                        </div>
                        <div class="selected-count mt-3">
                            <span class="badge badge-primary">0</span> sản phẩm được chọn
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                        <button type="button" class="btn btn-primary" id="addSelectedProducts">
                            <i class="fa fa-plus"></i> Thêm sản phẩm đã chọn
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);

            // Thêm modal vào body nếu chưa tồn tại
            if ($('#multipleProductModal').length === 0) {
                $('body').append(multipleSelectModal);
            }

            // Xử lý khi nhấn nút "Chọn Nhiều"
            multipleSelectButton.on('click', function() {
                // Hiển thị modal
                $('#multipleProductModal').modal('show');

                // Tải danh sách sản phẩm khi modal hiển thị
                loadProductsList();
            });

            // Biến để lưu timer debounce cho tìm kiếm trong modal
            let modalSearchTimer;

            // Xử lý tìm kiếm trong modal
            $(document).on('input', '#multipleProductSearch', function() {
                const searchTerm = $(this).val().trim();

                // Xóa timer hiện tại nếu có
                if (modalSearchTimer) {
                    clearTimeout(modalSearchTimer);
                }

                // Đặt timer để trì hoãn tìm kiếm (debounce)
                modalSearchTimer = setTimeout(function() {
                    loadProductsList(searchTerm);
                }, 20);
            });

            // Xử lý khi chọn/bỏ chọn tất cả
            $(document).on('change', '#selectAllProducts', function() {
                const isChecked = $(this).prop('checked');
                $('.product-checkbox').prop('checked', isChecked);
                updateSelectedCount();
            });

            // Xử lý khi chọn/bỏ chọn từng sản phẩm
            $(document).on('change', '.product-checkbox', function() {
                updateSelectedCount();

                // Kiểm tra nếu tất cả checkbox đều được chọn thì check vào "Chọn tất cả"
                const allChecked = $('.product-checkbox:checked').length === $('.product-checkbox').length;
                $('#selectAllProducts').prop('checked', allChecked);
            });

            // Xử lý khi nhấn nút "Thêm sản phẩm đã chọn"
            $(document).on('click', '#addSelectedProducts', function() {
                const selectedProducts = [];

                // Lấy thông tin sản phẩm đã chọn
                $('.product-checkbox:checked').each(function() {
                    const productRow = $(this).closest('tr');
                    const product = {
                        id: productRow.data('id'),
                        sku: productRow.data('sku'),
                        name: productRow.data('name'),
                        price: productRow.data('price'),
                        unit: productRow.data('unit'),
                        image: productRow.data('image'),
                        quantity: 1
                    };
                    selectedProducts.push(product);
                });

                // Thêm sản phẩm vào bảng đơn hàng
                if (selectedProducts.length > 0) {
                    selectedProducts.forEach(function(product) {
                        addProductToTable(product);
                    });

                    // Đóng modal sau khi thêm
                    $('#multipleProductModal').modal('hide');

                    // Hiển thị thông báo thành công
                    Swal.fire({
                        title: 'Thành công!',
                        text: `Đã thêm ${selectedProducts.length} sản phẩm vào đơn hàng`,
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    // Hiển thị thông báo chưa chọn sản phẩm
                    Swal.fire({
                        title: 'Thông báo!',
                        text: 'Vui lòng chọn ít nhất một sản phẩm',
                        icon: 'info'
                    });
                }
            });

            // ===== PHẦN 3: CÁC HÀM CHUNG =====

            // Hàm tìm kiếm sản phẩm từ server cho chọn từng sản phẩm
            function performSearch(searchTerm) {
                lastSearchTerm = searchTerm;

                $.ajax({
                    url: "{{ route('purchaser.search-products') }}",
                    method: 'GET',
                    data: {
                        search: searchTerm
                    },
                    success: function(response) {
                        searchStatus.hide();
                        displayProductResults(response.products, searchTerm);
                    },
                    error: function(error) {
                        console.error('Error fetching products:', error);
                        searchStatus.hide();
                        productSearchResults.empty().append(
                            '<div class="no-results error">' +
                            '<i class="fa fa-exclamation-circle"></i> ' +
                            'Không thể tìm kiếm sản phẩm. Vui lòng thử lại sau.' +
                            '</div>'
                        ).show();
                    }
                });
            }
            // Hiển thị sản phẩm đã xem gần đây
            function loadRecentProducts() {
                // Lấy từ localStorage hoặc từ server
                const recentProducts = JSON.parse(localStorage.getItem('recentViewedProducts') || '[]');

                if (recentProducts.length > 0) {
                    productSearchResults.empty();
                    const resultsList = $('<ul class="product-list"></ul>');

                    productSearchResults.append('<div class="results-header">Sản phẩm đã xem gần đây</div>');

                    recentProducts.slice(0, 5).forEach(function(product) {
                        const productItem = createProductItem(product);
                        resultsList.append(productItem);
                    });

                    productSearchResults.append(resultsList);
                    productSearchResults.show();

                    // Gắn sự kiện click cho các mục sản phẩm
                    $('.product-item').on('click', function() {
                        selectProduct($(this));
                    });
                }
            }

            // Hiển thị kết quả tìm kiếm với từ khóa được highlight
            function displayProductResults(products, searchTerm) {
                productSearchResults.empty();

                if (products.length === 0) {
                    productSearchResults.append(
                        '<div class="no-results">' +
                        '<i class="fa fa-search"></i> ' +
                        'Không tìm thấy sản phẩm phù hợp với từ khóa "' + searchTerm + '"' +
                        '</div>'
                    );
                } else {
                    productSearchResults.append(
                        '<div class="results-header">' +
                        'Tìm thấy ' + products.length + ' sản phẩm cho từ khóa "' + searchTerm + '"' +
                        '</div>'
                    );

                    const resultsList = $('<ul class="product-list"></ul>');

                    products.forEach(function(product) {
                        const productItem = createProductItem(product, searchTerm);
                        resultsList.append(productItem);
                    });

                    productSearchResults.append(resultsList);
                }

                productSearchResults.show();

                // Gắn sự kiện click cho các mục sản phẩm
                $('.product-item').on('click', function() {
                    selectProduct($(this));
                });
            }

            // Tạo phần tử HTML cho một sản phẩm với từ khóa được highlight
            function createProductItem(product, searchTerm = '') {
                let productName = product.sale_key || 'Không có tên';
                let productSku = product.sku;

                // Highlight từ khóa tìm kiếm nếu có
                if (searchTerm) {
                    const regex = new RegExp('(' + searchTerm + ')', 'gi');
                    productName = productName.replace(regex, '<mark>$1</mark>');
                    productSku = productSku.replace(regex, '<mark>$1</mark>');
                }
                const imagePath = `{{ asset('/uploads/forecast_products/${product.image}') }}`;
                return `
            <li class="product-item" tabindex="0" data-id="${product.id}" data-sku="${product.sku}" data-price="${product.price}" data-sale-key="${product.sale_key}" data-unit="${product.unit}">
                <div class="product-image">
                    <img src="${imagePath}" alt="${product.sku}">
                </div>
                <div class="product-info">
                    <div class="product-name">${productName}</div>
                    <div class="product-sku">SKU: ${productSku}</div>
                    <div class="product-price">Giá nhập: ${formatCurrency(product.price)}</div>
                    <div class="product-unit">Đơn vị: ${product.unit || 'RMB'}</div>
                </div>
                <div class="product-action">
                    <button class="btn btn-sm btn-success add-product-btn">
                        <i class="fa fa-plus"></i>
                    </button>
                </div>
            </li>
        `;
            }

            // Xử lý khi chọn một sản phẩm từ tìm kiếm
            function selectProduct(productElement) {
                const productId = productElement.data('id');
                const productSku = productElement.data('sku');
                const productPrice = productElement.data('price');
                const productSaleKey = productElement.data('sale-key');
                const productUnit = productElement.data('unit') || 'RMB';
                const productImage = productElement.find('img').attr('src');

                // Xóa ô tìm kiếm và ẩn kết quả
                productSearchInput.val('');
                productSearchResults.hide();
                searchStatus.hide();

                // Lưu sản phẩm vào danh sách đã xem gần đây
                saveRecentProduct({
                    id: productId,
                    sku: productSku,
                    sale_key: productSaleKey,
                    price: productPrice,
                    unit: productUnit,
                    image: productImage
                });

                // Thêm sản phẩm vào bảng đơn hàng
                addProductToTable({
                    id: productId,
                    sku: productSku,
                    name: productSaleKey,
                    price: productPrice,
                    unit: productUnit,
                    image: productImage,
                    quantity: 1
                });
            }

            // Lưu sản phẩm đã xem gần đây vào localStorage
            function saveRecentProduct(product) {
                let recentProducts = JSON.parse(localStorage.getItem('recentViewedProducts') || '[]');

                // Loại bỏ sản phẩm nếu đã tồn tại trong danh sách
                recentProducts = recentProducts.filter(p => p.id !== product.id);

                // Thêm sản phẩm mới vào đầu danh sách
                recentProducts.unshift(product);

                // Giới hạn số lượng sản phẩm lưu trữ
                if (recentProducts.length > 10) {
                    recentProducts = recentProducts.slice(0, 10);
                }

                // Lưu lại vào localStorage
                localStorage.setItem('recentViewedProducts', JSON.stringify(recentProducts));
            }

            // Hàm tải danh sách sản phẩm cho chức năng chọn nhiều
            function loadProductsList(searchTerm = '') {
                const productsContainer = $('.products-container');

                // Hiển thị loading
                productsContainer.html(`
            <div class="text-center py-4">
                <i class="fa fa-spinner fa-spin fa-2x"></i>
                <p>Đang tải danh sách sản phẩm...</p>
            </div>
        `);

                // Gọi API để lấy danh sách sản phẩm
                $.ajax({
                    url: "{{ route('purchaser.search-products') }}",
                    method: 'GET',
                    data: {
                        search: searchTerm,
                        limit: 100 // Giới hạn số lượng sản phẩm trả về
                    },
                    success: function(response) {
                        displayProductsList(response.products);
                    },
                    error: function(error) {
                        console.error('Error fetching products:', error);
                        productsContainer.html(`
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-circle"></i> 
                        Không thể tải danh sách sản phẩm. Vui lòng thử lại sau.
                    </div>
                `);
                    }
                });
            }

            // Hàm hiển thị danh sách sản phẩm cho chọn nhiều
            function displayProductsList(products) {
                const productsContainer = $('.products-container');

                if (products.length === 0) {
                    productsContainer.html(`
                <div class="alert alert-info">
                    <i class="fa fa-info-circle"></i> 
                    Không tìm thấy sản phẩm nào.
                </div>
            `);
                    return;
                }

                // Tạo bảng hiển thị sản phẩm
                let html = `
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="40">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="selectAllProducts">
                                    <label class="custom-control-label" for="selectAllProducts"></label>
                                </div>
                            </th>
                            <th width="60">Ảnh</th>
                            <th>Tên sản phẩm</th>
                            <th>SKU</th>
                            <th>Đơn vị</th>
                            <th>Giá nhập</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

                products.forEach(function(product, index) {
                    const imagePath = `{{ asset('/uploads/forecast_products/${product.image}') }}`;
                    html += `
                <tr data-id="${product.id}" 
                    data-sku="${product.sku}" 
                    data-name="${product.sale_key || ''}" 
                    data-price="${product.price}" 
                    data-unit="${product.unit || 'RMB'}"
                    data-image="${imagePath}">
                    <td>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input product-checkbox" id="productCheck${index}">
                            <label class="custom-control-label" for="productCheck${index}"></label>
                        </div>
                    </td>
                    <td>
                        <img src="${imagePath}" alt="${product.sku}" style="max-width: 50px; max-height: 50px;">
                    </td>
                    <td>${product.sale_key || 'Không có tên'}</td>
                    <td>${product.sku}</td>
                    <td>${product.unit || 'RMB'}</td>
                    <td>${formatCurrency(product.price)}</td>
                </tr>
            `;
                });

                html += `
                    </tbody>
                </table>
            </div>
        `;

                productsContainer.html(html);

                // Reset counter
                updateSelectedCount();
            }

            // Hàm cập nhật số lượng sản phẩm đã chọn
            function updateSelectedCount() {
                const count = $('.product-checkbox:checked').length;
                $('.selected-count .badge').text(count);
            }

            // Hàm thêm sản phẩm vào bảng đơn hàng
            function addProductToTable(product) {
                // Check if product is already in the table
                const existingRow = $(`.product-row[data-product-id="${product.id}"]`);

                if (existingRow.length > 0) {
                    // Update quantity if product already exists
                    const quantityInput = existingRow.find('.quantity-input');
                    const currentQuantity = parseInt(quantityInput.val());
                    quantityInput.val(currentQuantity + 1);
                    updateRowTotal(existingRow);
                } else {
                    // Create a new row if product doesn't exist in the table
                    const productTable = $('.product-table tbody');

                    // Clear "empty state" message if it exists
                    if (productTable.find('.empty-state').length > 0) {
                        productTable.empty();
                    }

                    // Calculate row number
                    const rowNumber = productTable.find('tr').length + 1;

                    const newRow = `
                <tr class="product-row" data-product-id="${product.id}">
                    <td>${rowNumber}</td>
                    <td><img src="${product.image}" alt="${product.sku}" class="product-thumbnail"></td>
                    <td>${product.name || product.sku}<br><small>${product.sku}</small></td>
                    <td>
                        <select class="form-control unit-select">
                            <option value="${product.unit}" selected>${product.unit}</option>
                            <option value="RMB" ${product.unit === 'RMB' ? 'selected' : ''}>RMB</option>
                            <option value="USD" ${product.unit === 'USD' ? 'selected' : ''}>USD</option>
                            <option value="VND" ${product.unit === 'VND' ? 'selected' : ''}>VND</option>
                        </select>
                    </td>
                    <td>
                        <input type="number" class="form-control quantity-input" value="1" min="1">
                    </td>
                    <td>
                        <input type="number" class="form-control price-input" value="${product.price}" min="0">
                    </td>
                    <td>
                        <input type="number" class="form-control discount-input" value="0" min="0" max="100">
                    </td>
                    <td class="row-total">${formatCurrency(product.price)}</td>
                    <td>
                        <button class="btn btn-sm btn-danger remove-product">
                            <i class="fa fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;

                    productTable.append(newRow);

                    // Add event handlers for new row
                    const newRowElement = productTable.find('tr:last-child');

                    newRowElement.find('.quantity-input, .price-input, .discount-input').on('input', function() {
                        updateRowTotal(newRowElement);
                    });

                    newRowElement.find('.remove-product').on('click', function() {
                        removeProduct(newRowElement);
                    });
                }

                // Update order summary
                updateOrderSummary();
            }

            // Function to update row total price
            function updateRowTotal(row) {
                const quantity = parseInt(row.find('.quantity-input').val()) || 0;
                const price = parseFloat(row.find('.price-input').val()) || 0;
                const discount = parseFloat(row.find('.discount-input').val()) || 0;

                const total = quantity * price * (1 - discount / 100);
                row.find('.row-total').text(formatCurrency(total));

                updateOrderSummary();
            }

            // Function to remove product from table
            function removeProduct(row) {
                row.remove();

                // Add empty state if no products in table
                const productTable = $('.product-table tbody');
                if (productTable.find('tr').length === 0) {
                    productTable.html(`
                <tr>
                    <td colspan="9" class="empty-state">
                        Đơn hàng của bạn chưa có sản phẩm nào
                    </td>
                </tr>
            `);
                } else {
                    // Renumber rows
                    productTable.find('tr').each(function(index) {
                        $(this).find('td:first-child').text(index + 1);
                    });
                }

                updateOrderSummary();
            }

            // Function to update order summary
            function updateOrderSummary() {
                let totalQuantity = 0;
                let subtotal = 0;

                $('.product-row').each(function() {
                    const quantity = parseInt($(this).find('.quantity-input').val()) || 0;
                    const price = parseFloat($(this).find('.price-input').val()) || 0;
                    const discount = parseFloat($(this).find('.discount-input').val()) || 0;

                    totalQuantity += quantity;
                    subtotal += quantity * price * (1 - discount / 100);
                });

                // Update summary fields
                $('.summary-area p:nth-child(1) strong').text(totalQuantity);
                $('.summary-area p:nth-child(2) strong').text(formatCurrency(subtotal));

                // Calculate final amounts
                const discountAmount = parseFloat($('.discount-amount').val()) || 0;
                const taxAmount = parseFloat($('.tax-amount').val()) || 0;

                const finalAmount = subtotal - discountAmount + taxAmount;
                $('.summary-area p:nth-child(5) strong').text(formatCurrency(finalAmount));
                $('.summary-area p:nth-child(9) strong').text(formatCurrency(finalAmount));
                $('.summary-area p:nth-child(10) strong').text(formatCurrency(0));
            }

            // Define helper function to format currency

            function formatCurrency(amount) {
                return new Intl.NumberFormat('en-US', {
                    style: 'decimal',
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }).format(amount);
            }
        });


        $(document).ready(function() {
            // Add change event handler to fetch supplier details
            $('#supplier').on('change', function() {
                var supplierCode = $(this).val();
                if (supplierCode) {
                    // Show loading indicator
                    $('.info__company').html(
                        '<div class="text-center"><i class="fa fa-spinner fa-spin"></i> Đang tải thông tin...</div>'
                    );

                    // Fetch supplier details via AJAX
                    $.ajax({
                        url: "{{ route('purchaseOrdersManagement.getDetailSupplier') }}",
                        type: 'GET',
                        data: {
                            sp_code: supplierCode
                        },
                        success: function(response) {
                            if (response.success) {
                                // Format and display supplier information
                                var supplier = response.supplier;
                                var html = '<div class="supplier-details mt-3">';
                                html += '<table class="table table-bordered">';
                                html += '<tr><th style="width: 30%">Mã nhà cung cấp:</th><td>' +
                                    (supplier.sp_code || '') + '</td></tr>';
                                html += '<tr><th>Tên công ty:</th><td>' + (supplier
                                    .company_name || '') + '</td></tr>';
                                html += '<tr><th>Địa chỉ:</th><td>' + (supplier
                                    .address || 'Chưa cập nhật') + '</td></tr>';
                                html += '</table>';
                                html += '</div>';

                                // Update the info container
                                $('.info__company').html(html);
                            } else {
                                $('.info__company').html(
                                    '<div class="alert alert-warning">Không tìm thấy thông tin nhà cung cấp</div>'
                                );
                            }
                        },
                        error: function() {
                            $('.info__company').html(
                                '<div class="alert alert-danger">Có lỗi xảy ra khi lấy thông tin nhà cung cấp</div>'
                            );
                        }
                    });
                } else {
                    // No supplier selected, show default message
                    $('.info__company').html('Chưa có thông tin nhà cung cấp');
                }
            });

            // Handle save button click
            $('#saveSupplier').click(function() {
                // Get form data
                var formData = $('#addSupplierForm').serialize();
                // Send AJAX request
                $.ajax({
                    url: "{{ route('purchaseOrdersManagement.supplierSave') }}",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'POST',
                    data: formData,
                    beforeSend: function() {
                        // Show loading indicator
                        Swal.fire({
                            title: 'Đang xử lý...',
                            text: 'Vui lòng chờ trong giây lát',
                            icon: 'info',
                            showConfirmButton: false,
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            // Add the new supplier to the select dropdown
                            var newOption = new Option(
                                response.supplier.company_name + ' | ' + response.supplier
                                .sp_code,
                                response.supplier.sp_code,
                                true,
                                true
                            );

                            $('#supplier').append(newOption).trigger('change');

                            // Show success message
                            Swal.fire({
                                title: 'Thành công!',
                                text: 'Nhà cung cấp đã được thêm thành công',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            });

                            // Close the modal
                            $('#addSupplierModal').modal('hide');

                            // Reset the form
                            $('#addSupplierForm')[0].reset();
                        } else {
                            // Show error message
                            Swal.fire({
                                title: 'Lỗi!',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        // Handle errors
                        var errors = xhr.responseJSON.errors;
                        var errorMessage = '';

                        if (errors) {
                            for (var key in errors) {
                                errorMessage += errors[key][0] + '<br>';
                            }
                        } else {
                            errorMessage = 'Đã xảy ra lỗi trong quá trình xử lý';
                        }

                        Swal.fire({
                            title: 'Lỗi!',
                            html: errorMessage,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });
        });
    </script>
@endsection
