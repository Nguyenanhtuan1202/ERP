@extends('layouts.layout_purchaser')

<style>
    /* ERP Container - Global Styles */
    .erp-container {
        font-family: 'Inter', sans-serif;
        background-color: #f4f6f9;
        color: #333;
        padding: 20px;
    }

    /* Content Header */
    .erp-container .content-header {
        background: #ffffff;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .erp-container .content-header h1 {
        font-size: 1.75rem;
        font-weight: 600;
        color: #2c3e50;
    }

    .erp-container .card-header:first-child {
        background: linear-gradient(90deg, #21216d 0%, #182848 100%);
    }

    .erp-container .breadcrumb {
        background: transparent;
        padding: 0;
        font-size: 0.9rem;
    }

    .erp-container .breadcrumb-item a {
        color: #007bff;
        text-decoration: none;
    }

    .erp-container .breadcrumb-item.active {
        color: #6c757d;
    }

    /* Card Styling */
    .erp-container .card {
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    .erp-container .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 1.2rem;
        font-weight: 500;
        color: #34495e;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    /* Form Styling */
    .erp-container .form-group {
        margin-bottom: 15px;
    }

    .erp-container .form-label {
        font-weight: 600;
        margin-bottom: 5px;
    }

    .erp-container .form-control {
        border: 1px solid #ced4da;
        border-radius: 6px;
        padding: 10px;
        font-size: 1rem;
    }

    .erp-container .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 4px rgba(0, 123, 255, 0.25);
    }

    /* Buttons */
    .erp-container .btn {
        border-radius: 6px;
        padding: 10px 15px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

    .erp-container .btn-primary {
        background: #007bff;
        border: none;
    }

    .erp-container .btn-primary:hover {
        background: #0056b3;
    }

    .erp-container .btn-default {
        background: #f8f9fa;
        border: 1px solid #ddd;
        color: #333;
    }

    .erp-container .btn-default:hover {
        background: #e9ecef;
    }

    /* Alerts */
    .erp-container .alert-danger {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        border-radius: 6px;
        padding: 10px;
    }

    /* Animations */
    .fadeIn {
        animation: fadeIn 0.3s ease-in-out;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

@section('content')
    <div class="erp-container">
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <!-- Sidebar would go here in a full implementation -->
        <div class="main-content">
            <div class="content-wrapper">
                <!-- Content Header -->
                <section class="content-header fadeIn">
                    <div class="row">
                        <div class="col-md-6">
                            <h1>Edit Product Variant</h1>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}"><i class="fas fa-home"></i>
                                        Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('product-variants.index') }}">Product
                                        Variants</a></li>
                                <li class="breadcrumb-item active">Edit</li>
                            </ol>
                        </div>
                    </div>
                </section>

                <!-- Main content -->
                <section class="content fadeIn" style="animation-delay: 0.1s;">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Edit Product Variant Information</h3>
                        </div>
                        <form action="{{ route('product-variants.update', ['id' => $variant->id]) }}" method="POST"
                            enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="card-body">
                                <!-- Error messages -->
                                <!-- Basic Information -->
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="title">Title <span
                                                    class="text-danger">*</span></label>
                                            <input required type="text" class="form-control" id="title"
                                                name="title" placeholder="Enter variant title"
                                                value="{{ old('title', $variant->title) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="category_id">Category <span
                                                    class="text-danger">*</span></label>
                                            <select required name="category_id" id="category_id"
                                                class="form-control select3_init">
                                                <option value="">-- Chọn Danh Mục --</option>
                                                @foreach ($data['categories'] as $category)
                                                    <option value="{{ $category->id }}"
                                                        {{ old('category_id', $variant->category_id) == $category->id ? 'selected' : '' }}>
                                                        {{ $category->title }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label" for="status">Status</label>
                                            <select required name="status" id="status" class="form-control">
                                                <option value="1"
                                                    {{ old('status', $variant->status) == 1 ? 'selected' : '' }}>Active
                                                </option>
                                                <option value="0"
                                                    {{ old('status', $variant->status) == 0 ? 'selected' : '' }}>Inactive
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Description -->
                                <div class="form-group">
                                    <label class="form-label" for="description">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="4"
                                        placeholder="Enter variant description">{{ old('description', $variant->description) }}</textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update
                                </button>
                                <a href="{{ route('product-variants.index') }}" class="btn btn-default"
                                    style="margin-left: 10px;">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </div>
    </div>
@endsection
