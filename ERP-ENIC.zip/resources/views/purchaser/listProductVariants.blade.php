@extends('layouts.layout_purchaser')

@section('content')
    <style>
        /* ERP System Professional CSS */

        /* Global Styles */
        :root {
            --primary-color: #3c8dbc;
            --secondary-color: #367fa9;
            --success-color: #00a65a;
            --info-color: #00c0ef;
            --warning-color: #f39c12;
            --danger-color: #dd4b39;
            --gray-light: #f4f4f4;
            --gray-medium: #d2d6de;
            --gray-dark: #444;
            --sidebar-width: 250px;
        }

        /* Layout Styles */
        #listProductVariants.content-wrapper {
            background-color: #f4f6f9;
            padding: 15px;
        }

        #listProductVariants .content-header {
            padding: 15px 0;
        }

        #listProductVariants .content-header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 500;
        }

        #listProductVariants .breadcrumb {
            background: transparent;
            margin-bottom: 0;
            padding: 0;
        }

        #listProductVariants .breadcrumb-item a {
            color: var(--primary-color);
        }

        /* Card Styles */
        #listProductVariants .card {
            box-shadow: 0 0 1px rgba(0, 0, 0, .125), 0 1px 3px rgba(0, 0, 0, .2);
            margin-bottom: 1rem;
            border-radius: 0.25rem;
            background-color: #fff;
            border: none;
        }

        #listProductVariants .card-header {
            background-color: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, .125);
            padding: 1rem;
        }

        #listProductVariants .card-title {
            margin-bottom: 0;
            font-size: 23px;
            font-weight: 800;
            color: #111;
        }

        #listProductVariants .card-body {
            padding: 1rem;
        }

        #listProductVariants .card-body.border-top {
            border-top: 1px solid rgba(0, 0, 0, .125);
        }

        /* Button Styles */
        #listProductVariants .btn {
            border-radius: 0.25rem;
            font-size: 15px;
            transition: all 0.15s ease-in-out;
            padding: 7px 20px;
        }

        #listProductVariants .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--secondary-color);
        }

        #listProductVariants .btn-primary:hover {
            background-color: var(--secondary-color);
            border-color: #204d74;
        }

        #listProductVariants .btn-success {
            background-color: var(--success-color);
            border-color: #008d4c;
        }

        #listProductVariants .btn-success:hover {
            background-color: #008d4c;
            border-color: #006e3c;
        }

        #listProductVariants .btn-info {
            background-color: var(--info-color);
            border-color: #00a7d0;
        }

        #listProductVariants .btn-info:hover {
            background-color: #00a7d0;
            border-color: #0097bd;
        }

        #listProductVariants .btn-danger {
            background-color: var(--danger-color);
            border-color: #d73925;
        }

        #listProductVariants .btn-danger:hover {
            background-color: #d73925;
            border-color: #bf2e1a;
        }

        #listProductVariants .btn-default {
            background-color: #f4f4f4;
            border-color: #ddd;
            color: #444;
        }

        #listProductVariants .btn-default:hover {
            background-color: #e7e7e7;
        }

        #listProductVariants .btn-group {
            gap: 10px;
        }

        #listProductVariants .btn-group .btn {
            margin-right: 2px;
        }

        /* Form Styles */
        #listProductVariants .form-control {
            border-radius: 0.25rem;
            border: 1px solid #ced4da;
            padding: 0.375rem 0.75rem;
            height: calc(2.25rem + 2px);
            font-size: 14px;
            color: #495057;
        }

        #listProductVariants .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
        }

        #listProductVariants .form-group {
            margin-bottom: 1rem;
        }

        #listProductVariants .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: block;
        }

        #listProductVariants .select2-container--default .select2-selection--single {
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            height: calc(2.25rem + 2px);
            padding: 0.375rem 0.75rem;
        }

        #listProductVariants .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 1.5;
            padding: 0;
        }

        #listProductVariants .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: calc(2.25rem + 2px);
        }

        /* Table Styles */
        #listProductVariants .table-responsive {
            overflow-x: auto;
        }

        #listProductVariants .table {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }

        #listProductVariants .table th,
        #listProductVariants .table td {
            padding: 0.75rem;
            vertical-align: middle;
            border-top: 1px solid #dee2e6;
        }

        #listProductVariants .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6;
            background-color: #f8f9fa;
        }

        #listProductVariants .table tbody+tbody {
            border-top: 2px solid #dee2e6;
        }

        #listProductVariants .table-bordered {
            border: 1px solid #dee2e6;
        }

        #listProductVariants .table-bordered th,
        #listProductVariants .table-bordered td {
            border: 1px solid #dee2e6;
        }

        #listProductVariants .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.05);
        }

        #listProductVariants .table a {
            color: var(--primary-color);
            text-decoration: none;
        }

        #listProductVariants .table a:hover {
            text-decoration: underline;
        }

        /* Status Badge Styles */
        #listProductVariants .badge {
            display: inline-block;
            padding: 0.25em 0.4em;
            font-size: 14px;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }

        #listProductVariants .badge-success {
            color: #fff;
            background-color: var(--success-color);
        }

        #listProductVariants .badge-danger {
            color: #fff;
            background-color: var(--danger-color);
        }

        /* Pagination Styles */

        /* Responsive Adjustments */
        @media (max-width: 767.98px) {
            #listProductVariants .content-header .col-sm-6 {
                text-align: center;
            }

            #listProductVariants .content-header .breadcrumb {
                justify-content: center;
                margin-top: 10px;
            }

            #listProductVariants .card-header .d-flex {
                flex-direction: column;
            }

            #listProductVariants .card-header .d-flex .btn {
                margin-top: 5px;
                margin-bottom: 5px;
            }

            #listProductVariants .form-group {
                margin-bottom: 1.5rem;
            }

            #listProductVariants .table-responsive {
                overflow-x: auto;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Sort Icon Styles */
        #listProductVariants .fas.fa-sort,
        #listProductVariants .fas.fa-sort-up,
        #listProductVariants .fas.fa-sort-down {
            margin-left: 5px;
        }

        /* Modal Styles */
        #listProductVariants .modal-header {
            border-bottom: 1px solid #dee2e6;
            padding: 1rem;
        }

        #listProductVariants .modal-title {
            margin-bottom: 0;
            line-height: 1.5;
        }

        #listProductVariants .modal-body {
            padding: 1rem;
        }

        #listProductVariants .modal-footer {
            border-top: 1px solid #dee2e6;
            padding: 1rem;
        }
    </style>



    <div class="content-wrapper" id="listProductVariants">
        <!-- Content Header -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-left">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                            <li class="breadcrumb-item active">Mẫu (Phân Loại)</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="card-title">Danh Sách Mẫu (Phân Loại)</h3>
                                    <div>
                                        <a href="{{ route('product-variants.create') }}" class="btn btn-primary">
                                            <i class="fas fa-plus"></i>Thêm Mới
                                        </a>
                                        <button type="button" class="btn btn-success" id="export-btn">
                                            <i class="fas fa-file-export"></i> Xuất Excel
                                        </button>

                                    </div>
                                </div>
                            </div>
                            <!-- Filter section -->
                            <div class="card-body">
                                <form action="{{ route('product-variants.index') }}" method="GET" id="filter-form">
                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Lọc Theo Danh Mục</label>
                                                <select name="category_id" class="form-control select2">
                                                    <option value="">Tất Cả Danh Mục</option>
                                                    @foreach ($data['categories'] as $category)
                                                        <option value="{{ $category->id }}"
                                                            {{ request('category_id') == $category->id ? 'selected' : '' }}>
                                                            {{ $category->title }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Lọc Theo Trạng Thái</label>
                                                <select name="status" class="form-control" style="height: 45px">
                                                    <option value="">Tất Cả Trạng Thái</option>
                                                    <option value="1" {{ request('status') == '1' ? 'selected' : '' }}>
                                                        Đang hoạt động</option>
                                                    <option value="0" {{ request('status') == '0' ? 'selected' : '' }}>
                                                        Ngừng hoạt động</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>&nbsp;</label>
                                                <div class="d-flex">
                                                    <button type="submit" class="btn btn-primary mr-2">
                                                        <i class="fas fa-filter"></i> Lọc
                                                    </button>
                                                    <a href="{{ route('product-variants.index') }}" class="btn btn-default">
                                                        <i class="fas fa-sync"></i> Reset
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- Bulk actions -->
                            <div class="card-body border-top">
                                <!-- Table -->
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="table1">
                                        <thead>
                                            <tr>

                                                <th width="5%">ID</th>
                                                <th width="20%">
                                                    <a
                                                        href="{{ route('product-variants.index', array_merge(request()->query(), ['sort_by' => 'title', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}">
                                                        Tiêu Đề
                                                        @if (request('sort_by') == 'title')
                                                            <i
                                                                class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                                        @else
                                                            <i class="fas fa-sort"></i>
                                                        @endif
                                                    </a>
                                                </th>
                                                <th width="15%">
                                                    <a
                                                        href="{{ route('product-variants.index', array_merge(request()->query(), ['sort_by' => 'category_id', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}">
                                                        Danh Mục
                                                        @if (request('sort_by') == 'category_id')
                                                            <i
                                                                class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                                        @else
                                                            <i class="fas fa-sort"></i>
                                                        @endif
                                                    </a>
                                                </th>
                                                <th width="10%">
                                                    <a
                                                        href="{{ route('product-variants.index', array_merge(request()->query(), ['sort_by' => 'status', 'sort_order' => request('sort_order') == 'asc' ? 'desc' : 'asc'])) }}">
                                                        Trạng Thái
                                                        @if (request('sort_by') == 'status')
                                                            <i
                                                                class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                                        @else
                                                            <i class="fas fa-sort"></i>
                                                        @endif
                                                    </a>
                                                </th>
                                                <th width="30%">Mô Tả</th>
                                                <th width="16%">Hành Động</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($data['listProductVariants'] as $variant)
                                                <tr>

                                                    <td>{{ $variant->id }}</td>
                                                    <td>{{ $variant->title }}</td>
                                                    <td>{{ $variant->category->title ?? 'N/A' }}</td>
                                                    <td class="text-center">
                                                        @if ($variant->status == 1)
                                                            <span class="badge badge-success">Active</span>
                                                        @else
                                                            <span class="badge badge-danger">Inactive</span>
                                                        @endif
                                                    </td>
                                                    <td>{{ \Illuminate\Support\Str::limit($variant->description, 50) }}
                                                    </td>
                                                    <td>
                                                        <div class="btn-group">

                                                            <a href="{{ route('product-variants.edit', ['id' => $variant->id]) }}"
                                                                class="btn btn-sm btn-primary">
                                                                <i style="color: #fff" class="fas fa-edit"></i>
                                                            </a>



                                                            <a onclick="return confirm('Bạn có muốn xóa mẫu ( phân loại) này không ?')"
                                                                href="{{ route('product-variants.delete', ['id' => $variant->id]) }}"
                                                                class="btn btn-sm btn-danger">
                                                                <i style="color: #fff" class="fas fa-trash"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="7" class="text-center">No product variants found.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@section('js')
    <script>
        $(function() {
            // Initialize Select2
            $('.select2').select2();

            // Show filename when file is selected
            $('input[type="file"]').on('change', function() {
                var fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').html(fileName);
            });
        });
    </script>
@endsection
