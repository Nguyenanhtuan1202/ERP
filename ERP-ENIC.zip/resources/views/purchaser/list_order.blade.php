@extends('layouts.layout_purchaser')
@section('content')
    <style>
        :root {
            --primary-color: #3182ce;
            --secondary-color: #718096;
            --background-light: #f4f5f7;
            --border-color: #e2e8f0;
            --text-dark: #2d3748;
            --text-light: #4a5568;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: var(--background-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        /* Tabs Styling */
        .tabs {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }

        .tabs a {
            text-decoration: none;
            color: var(--secondary-color);
            font-weight: 500;
            padding-bottom: 10px;
            transition: all 0.3s ease;
            position: relative;
        }

        .tabs a.active {
            color: var(--primary-color);
        }

        .tabs a.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 2px;
            background-color: var(--primary-color);
        }

        /* Search Bar Styling */
        .search-bar {
            position: relative;
            margin-bottom: 20px;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 40px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary-color);
        }

        .search-bar input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
        }

        /* Filters Styling */
        .filters {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }

        .filters select,
        .filters button {
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            background-color: white;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .filters select:focus,
        .filters button:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
        }

        .filters button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filters button:hover {
            background-color: #2c5282;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        thead {
            background-color: var(--background-light);
        }

        th,
        td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
        }

        th {
            font-weight: 600;
            color: var(--text-light);
            text-transform: uppercase;
            font-size: 12px;
        }

        tbody tr {
            transition: background-color 0.3s ease;
        }

        tbody tr:hover {
            background-color: #f7fafc;
        }

        /* Status Styling */
        .status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-completed {
            background-color: #e6f4ea;
            color: #2e7d32;
        }

        .status-processing {
            background-color: #fff3e0;
            color: #ef6c00;
        }

        .status-cancelled {
            background-color: #ffebee;
            color: #d32f2f;
        }
    </style>


    <div class="container">
        <div class="tabs">
            <a href="#" class="active">Tất cả đơn nhập hàng</a>
            <a href="#">Đang giao dịch</a>
            <a href="#">Hoàn thành</a>
        </div>
        <div class="search-bar">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Tìm mã đơn nhập, đơn đặt hàng, tên, NCC">
        </div>
        <div class="filters">
            <select>
                <option>Trạng thái</option>
                <option>Hoàn thành</option>
                <option>Đang giao dịch</option>
                <option>Đã hủy</option>
            </select>
            <select>
                <option>Ngày tạo</option>
                <option>Hôm nay</option>
                <option>Tuần này</option>
                <option>Tháng này</option>
                <option>Năm nay</option>
            </select>
            <select>
                <option>Sản phẩm</option>
                <option>Bồn tắm</option>
                <option>Vòi nước</option>
                <option>Thiết bị nhà tắm</option>
            </select>
            <button>
                <i class="bi bi-funnel"></i> Bộ lọc khác
            </button>
            <button>
                <i class="bi bi-save"></i> Lưu bộ lọc
            </button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Mã đơn nhập</th>
                    <th>Ngày nhập</th>
                    <th>Trạng thái</th>
                    <th>Chi nhánh nhập</th>
                    <th>Nhà cung cấp</th>
                    <th>Nhân viên tạo</th>
                    <th>Giá trị đơn</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>PON09458</td>
                    <td>28/03/2025 17:59</td>
                    <td><span class="status status-completed">Hoàn thành</span></td>
                    <td>KHO PHƯỚC SƠN</td>
                    <td>Bồn tắm xưởng Việt Nam</td>
                    <td>Nguyễn Trần Thanh Vy</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>PON09457</td>
                    <td>28/03/2025 17:07</td>
                    <td><span class="status status-completed">Hoàn thành</span></td>
                    <td>KHO NHẤT TÍN</td>
                    <td>Khách Hoàn Hàng</td>
                    <td>Mr Bảo KT Kho</td>
                    <td>0</td>
                </tr>
            </tbody>
        </table>
    </div>
@endsection
