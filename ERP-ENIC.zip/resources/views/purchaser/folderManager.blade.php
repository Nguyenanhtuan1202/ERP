@extends('layouts.layout_purchaser')
@section('css')
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .bg-white {
            background-color: #21216d !important;
        }

        .storage-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .folder-tree {
            background-color: #f8f9fa;
            border-right: 1px solid #e9ecef;
            min-height: calc(100vh - 160px);
            padding: 15px;
        }

        .folder-item {
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }

        .folder-item:hover {
            background-color: #e9ecef;
        }

        .folder-item.active {
            background-color: #e7f1ff;
            color: #0d6efd;
        }

        .folder-item i {
            margin-right: 8px;
        }

        .folder-nested {
            padding-left: 25px;
        }

        .file-content {
            padding: 20px;
            min-height: calc(100vh - 160px);
        }

        .file-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            margin-bottom: 10px;
            transition: all 0.2s;
        }

        .file-item:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.04);
        }

        .file-icon {
            width: 40px;
            text-align: center;
            font-size: 20px;
            color: #6c757d;
        }

        .file-icon.folder {
            color: #ffc107;
        }

        .file-icon.doc {
            color: #0d6efd;
        }

        .file-icon.image {
            color: #20c997;
        }

        .file-icon.pdf {
            color: #dc3545;
        }

        .file-details {
            flex-grow: 1;
            margin-left: 10px;
        }

        .file-actions {
            display: flex;
            gap: 5px;
        }

        .breadcrumb-item a {
            text-decoration: none;
        }

        .preview-container {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 20px;
            min-height: 350px;
            background-color: #f8f9fa;
            overflow: auto;
        }

        .drag-area {
            border: 2px dashed #dee2e6;
            border-radius: 6px;
            padding: 30px;
            text-align: center;
            background-color: #f8f9fa;
            transition: all 0.3s;
        }

        .drag-area.active {
            border-color: #0d6efd;
            background-color: #e7f1ff;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid py-4">
        <div class="row mb-4">
            <div class="col">
                <h2>Hệ thống lưu trữ thông tin</h2>
            </div>
            <div class="col-auto">
                <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#createFolderModal">
                    <i class="fas fa-folder-plus me-1"></i> Tạo thư mục
                </button>
                <button class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#uploadFileModal">
                    <i class="fas fa-file-upload me-1"></i> Tải lên
                </button>
                <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createFileModal">
                    <i class="fas fa-file-alt me-1"></i> Tạo file mới
                </button>
            </div>
        </div>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('file-storage.index') }}"><i class="fas fa-home"></i> Home</a>
                </li>
                @if (isset($path) && $path)
                    @php
                        $pathSegments = explode('/', $path);
                        $currentPath = '';
                    @endphp
                    @foreach ($pathSegments as $segment)
                        @php $currentPath .= $segment; @endphp
                        <li class="breadcrumb-item">
                            <a href="{{ route('file-storage.folder', ['path' => $currentPath]) }}">{{ $segment }}</a>
                        </li>
                        @php $currentPath .= '/'; @endphp
                    @endforeach
                @endif
            </ol>
        </nav>

        <div class="storage-container row">
            <!-- Folder Tree -->
            <div class="col-md-3 folder-tree">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Thư mục</h5>
                    <button class="btn btn-sm btn-outline-secondary" id="refreshTree">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>

                <div id="folderTreeView">
                    <a class="folder-item {{ request()->is('file-storage') ? 'active' : '' }}" href="{{route('file-storage.index')}}" >
                        <i class="fas fa-hdd"></i> Root
                    </a>

                    <div class="folder-nested">
                        @foreach ($folders as $folder)
                            <div class="folder-item" data-path="{{ $folder->path }}">
                                <i class="fas fa-folder"></i> {{ $folder->name }}
                            </div>
                            @if (count($folder->children) > 0)
                                <div class="folder-nested">
                                    @foreach ($folder->children as $childFolder)
                                        <div class="folder-item" data-path="{{ $childFolder->path }}">
                                            <i class="fas fa-folder"></i> {{ $childFolder->name }}
                                        </div>
                                    @endforeach
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- File Content -->
            <div class="col-md-9 file-content">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if (count($files) > 0 || count($subFolders) > 0)
                    <div class="row mb-3">
                        <div class="col">
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="searchFiles" placeholder="Tìm kiếm...">
                            </div>
                        </div>
                        <div class="col-auto">
                            <select class="form-select" id="sortFiles">
                                <option value="name">Sắp xếp theo tên</option>
                                <option value="date">Sắp xếp theo ngày</option>
                                <option value="size">Sắp xếp theo kích thước</option>
                                <option value="type">Sắp xếp theo loại</option>
                            </select>
                        </div>
                    </div>

                    <div class="row file-grid">
                        <!-- Folders -->
                        @foreach ($subFolders as $folder)
                            <div class="col-md-4 mb-3 file-grid-item" data-name="{{ $folder->name }}"
                                data-date="{{ $folder->created_at->format('Ymd') }}" data-type="folder" data-size="0">
                                <div class="file-item">
                                    <div class="file-icon folder">
                                        <i class="fas fa-folder"></i>
                                    </div>
                                    <div class="file-details">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-0">{{ $folder->name }}</h6>
                                            <small class="text-muted">{{ $folder->created_at->format('d/m/Y') }}</small>
                                        </div>
                                        <small class="text-muted">{{ count($folder->files) }} files</small>
                                    </div>
                                    <div class="file-actions">
                                        <a href="{{ route('file-storage.folder', ['path' => $folder->path]) }}"
                                            class="btn btn-sm btn-outline-secondary">
                                            <i class="fas fa-folder-open"></i>
                                        </a>
                                        <button class="btn btn-sm btn-outline-danger delete-btn" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal" data-folder-id="{{ $folder->id }}"
                                            data-item-name="{{ $folder->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                        <!-- Files -->
                        @foreach ($files as $file)
                            <div class="col-md-4 mb-3 file-grid-item" data-name="{{ $file->name }}"
                                data-date="{{ $file->created_at->format('Ymd') }}" data-type="file"
                                data-size="{{ $file->size }}">
                                <div class="file-item">
                                    <div class="file-icon {{ $file->getFileIconClass() }}">
                                        <i class="fas {{ $file->getFileIconClass() }}"></i>
                                    </div>
                                    <div class="file-details">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-0">{{ $file->name }}</h6>
                                            <small class="text-muted">{{ $file->created_at->format('d/m/Y') }}</small>
                                        </div>
                                        <small class="text-muted">{{ $file->formatSize() }}</small>
                                    </div>
                                    <div class="file-actions">
                                        <button class="btn btn-sm btn-outline-primary preview-btn" data-bs-toggle="modal"
                                            data-bs-target="#previewModal" data-file-id="{{ $file->id }}"
                                            data-file-name="{{ $file->name }}" data-file-type="{{ $file->mime_type }}"
                                            data-file-url="{{ route('file-storage.preview', $file->id) }}">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <a href="{{ route('file-storage.download', $file->id) }}"
                                            class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-download"></i>
                                        </a>
                                        <button class="btn btn-sm btn-outline-danger delete-btn" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal" data-file-id="{{ $file->id }}"
                                            data-item-name="{{ $file->name }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="drag-area" id="dropArea">
                        <div class="text-center">
                            <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                            <h5>Kéo và thả file vào đây để tải lên</h5>
                            <p class="text-muted">Hoặc</p>
                            <button class="btn btn-outline-primary" data-bs-toggle="modal"
                                data-bs-target="#uploadFileModal">
                                Chọn file để tải lên
                            </button>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Create Folder Modal -->
    <div class="modal fade" id="createFolderModal" tabindex="-1" aria-labelledby="createFolderModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createFolderModalLabel">Tạo thư mục mới</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('file-storage.create-folder') }}" method="POST" id="createFolderForm">
                    @csrf
                    <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="folderName" class="form-label">Tên thư mục</label>
                            <input type="text" class="form-control" id="folderName" name="folder_name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo thư mục</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Upload File Modal -->
    <div class="modal fade" id="uploadFileModal" tabindex="-1" aria-labelledby="uploadFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadFileModalLabel">Tải lên file</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('file-storage.upload') }}" method="POST" enctype="multipart/form-data"
                    id="uploadFileForm">
                    @csrf
                    <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileUpload" class="form-label">Chọn file</label>
                            <input type="file" class="form-control" id="fileUpload" name="files[]" multiple required>
                        </div>
                        <div class="progress mb-3 d-none" id="uploadProgress">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                                style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                        </div>
                        <div id="uploadStatus" class="d-none">
                            <div class="alert alert-info">
                                Đang tải lên... vui lòng chờ
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary" id="uploadSubmitBtn">Tải lên</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create File Modal -->
    <div class="modal fade" id="createFileModal" tabindex="-1" aria-labelledby="createFileModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createFileModalLabel">Tạo file mới</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('file-storage.create-file') }}" method="POST" id="createFileForm">
                    @csrf
                    <input type="hidden" name="current_path" value="{{ $currentPath ?? '' }}">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileName" class="form-label">Tên file</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="fileName" name="file_name" required>
                                <select class="form-select" name="file_extension" style="max-width: 120px;">
                                    <option value="txt">.txt</option>
                                    <option value="md">.md</option>
                                    <option value="html">.html</option>
                                    <option value="css">.css</option>
                                    <option value="js">.js</option>
                                    <option value="json">.json</option>
                                    <option value="csv">.csv</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="fileContent" class="form-label">Nội dung</label>
                            <textarea class="form-control" id="fileContent" name="file_content" rows="10"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo file</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- File Preview Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="previewModalLabel">Xem trước file</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="preview-container">
                        <div id="filePreviewContent" class="text-center">
                            <!-- Preview content will be loaded here -->
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <p>Đang tải nội dung...</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <a href="#" id="downloadFileBtn" class="btn btn-primary">
                        <i class="fas fa-download me-1"></i>Tải xuống
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Xác nhận xóa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Bạn có chắc chắn muốn xóa <span id="deleteItemName" class="fw-bold"></span>? Hành động này không
                        thể hoàn tác.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <form id="deleteForm" action="{{ route('file-storage.delete') }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <input type="hidden" name="item_id" id="deleteItemId">
                        <input type="hidden" name="item_type" id="deleteItemType">
                        <button type="submit" class="btn btn-danger">Xóa</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            /**
             * File Preview Functionality
             */
            const initializeFilePreview = function() {
                const previewModal = document.getElementById('previewModal');
                if (!previewModal) return;

                previewModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    if (!button) return;

                    const fileId = button.getAttribute('data-file-id');
                    const fileName = button.getAttribute('data-file-name');
                    const fileType = button.getAttribute('data-file-type');
                    const fileUrl = button.getAttribute('data-file-url');

                    // Update modal title with file name
                    const modalTitle = this.querySelector('.modal-title');
                    if (modalTitle) modalTitle.textContent = 'Xem trước: ' + fileName;

                    // Update download button
                    const downloadBtn = document.getElementById('downloadFileBtn');
                    if (downloadBtn) downloadBtn.href = `/file-storage/download/${fileId}`;

                    // Load file preview content
                    const previewContent = document.getElementById('filePreviewContent');
                    if (!previewContent) return;

                    // Show loading indicator
                    previewContent.innerHTML = `
                <div class="d-flex justify-content-center align-items-center" style="min-height: 200px;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="ms-3 mb-0">Đang tải nội dung...</p>
                </div>
            `;

                    // Load preview based on file type
                    fetch(fileUrl)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok ' + response
                                    .statusText);
                            }

                            if (fileType && fileType.includes('image')) {
                                return response.blob().then(blob => {
                                    const imgUrl = URL.createObjectURL(blob);
                                    previewContent.innerHTML =
                                        `<img src="${imgUrl}" class="img-fluid" alt="${fileName}">`;
                                });
                            } else if (fileType && (
                                    fileType.includes('text') ||
                                    fileType.includes('application/json') ||
                                    fileType.includes('application/javascript') ||
                                    fileType.includes('application/xml'))) {
                                return response.text().then(text => {
                                    previewContent.innerHTML =
                                        `<pre class="text-start overflow-auto" style="max-height: 500px;">${escapeHtml(text)}</pre>`;
                                });
                            } else if (fileType && fileType.includes('pdf')) {
                                previewContent.innerHTML =
                                    `<embed src="${fileUrl}" type="application/pdf" width="100%" height="500px">`;
                            } else {
                                previewContent.innerHTML = `
                            <div class="text-center p-5">
                                <i class="fas fa-file fa-5x mb-3 text-muted"></i>
                                <p>Không thể xem trước loại file này.</p>
                                <p>Hãy tải xuống để xem nội dung.</p>
                            </div>
                        `;
                            }
                        })
                        .catch(error => {
                            previewContent.innerHTML = `
                        <div class="alert alert-danger">
                            Lỗi khi tải nội dung: ${error.message}
                        </div>
                    `;
                            console.error('Error loading preview:', error);
                        });
                });

                // Clear preview content when modal is hidden
                previewModal.addEventListener('hidden.bs.modal', function() {
                    const previewContent = document.getElementById('filePreviewContent');
                    if (previewContent) {
                        previewContent.innerHTML = '';
                    }
                });
            };

            /**
             * Delete Confirmation
             */
            const initializeDeleteConfirmation = function() {
                const deleteModal = document.getElementById('deleteModal');
                if (!deleteModal) return;

                deleteModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    if (!button) return;

                    const fileId = button.getAttribute('data-file-id');
                    const folderId = button.getAttribute('data-folder-id');
                    const itemName = button.getAttribute('data-item-name');

                    const deleteItemId = document.getElementById('deleteItemId');
                    const deleteItemType = document.getElementById('deleteItemType');
                    const deleteItemName = document.getElementById('deleteItemName');

                    if (deleteItemName) {
                        deleteItemName.textContent = itemName || '';
                    }

                    if (deleteItemId && deleteItemType) {
                        if (fileId) {
                            deleteItemId.value = fileId;
                            deleteItemType.value = 'file';
                        } else if (folderId) {
                            deleteItemId.value = folderId;
                            deleteItemType.value = 'folder';
                        }
                    }
                });
            };

            /**
             * Drag and Drop Upload
             */
            const initializeDragDropUpload = function() {
                const dropArea = document.getElementById('dropArea');
                if (!dropArea) return;

                const preventDefaultsHandler = function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                };

                const highlightHandler = function() {
                    dropArea.classList.add('active');
                };

                const unhighlightHandler = function() {
                    dropArea.classList.remove('active');
                };

                ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                    dropArea.addEventListener(eventName, preventDefaultsHandler, false);
                });

                ['dragenter', 'dragover'].forEach(eventName => {
                    dropArea.addEventListener(eventName, highlightHandler, false);
                });

                ['dragleave', 'drop'].forEach(eventName => {
                    dropArea.addEventListener(eventName, unhighlightHandler, false);
                });

                dropArea.addEventListener('drop', function(e) {
                    const dt = e.dataTransfer;
                    if (!dt) return;

                    const files = dt.files;

                    if (files && files.length > 0) {
                        // Show upload modal
                        const uploadModal = document.getElementById('uploadFileModal');
                        const fileInput = document.getElementById('fileUpload');

                        if (uploadModal && fileInput) {
                            // Create a new FileList-like object
                            const dataTransfer = new DataTransfer();

                            // Add each file to the DataTransfer
                            for (let i = 0; i < files.length; i++) {
                                dataTransfer.items.add(files[i]);
                            }

                            // Set the file input files
                            fileInput.files = dataTransfer.files;

                            // Show the modal
                            const bsModal = new bootstrap.Modal(uploadModal);
                            bsModal.show();
                        }
                    }
                });
            };

            /**
             * File Upload with Progress
             */
            const initializeFileUpload = function() {
                const uploadForm = document.getElementById('uploadFileForm');
                if (!uploadForm) return;

                uploadForm.addEventListener('submit', function(e) {
                    e.preventDefault();

                    const fileInput = document.getElementById('fileUpload');
                    const progressBar = document.getElementById('uploadProgress');
                    const progressBarInner = progressBar?.querySelector('.progress-bar');
                    const uploadStatus = document.getElementById('uploadStatus');
                    const submitButton = document.getElementById('uploadSubmitBtn');

                    if (!fileInput || !progressBar || !progressBarInner || !uploadStatus || !
                        submitButton) return;

                    if (fileInput.files.length === 0) {
                        alert('Vui lòng chọn ít nhất một file để tải lên');
                        return;
                    }

                    // Show progress bar and status
                    progressBar.classList.remove('d-none');
                    uploadStatus.classList.remove('d-none');
                    submitButton.disabled = true;

                    // Create FormData
                    const formData = new FormData(uploadForm);

                    // Create and configure AJAX request
                    const xhr = new XMLHttpRequest();

                    // Track upload progress
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            const percentComplete = Math.round((e.loaded / e.total) * 100);
                            progressBarInner.style.width = percentComplete + '%';
                            progressBarInner.textContent = percentComplete + '%';
                            progressBarInner.setAttribute('aria-valuenow', percentComplete);
                        }
                    });

                    // Handle completion
                    xhr.addEventListener('load', function() {
                        if (xhr.status >= 200 && xhr.status < 300) {
                            // Upload successful
                            progressBarInner.classList.remove('progress-bar-striped',
                                'progress-bar-animated');
                            progressBarInner.classList.add('bg-success');
                            progressBarInner.textContent = 'Hoàn thành!';

                            uploadStatus.innerHTML = `
                        <div class="alert alert-success">
                            Tải lên thành công! Trang sẽ tự động tải lại...
                        </div>
                    `;

                            // Reload after 1.5 seconds
                            setTimeout(() => {
                                window.location.reload();
                            }, 1500);
                        } else {
                            // Upload failed
                            progressBarInner.classList.remove('progress-bar-striped',
                                'progress-bar-animated');
                            progressBarInner.classList.add('bg-danger');
                            progressBarInner.textContent = 'Lỗi!';

                            uploadStatus.innerHTML = `
                        <div class="alert alert-danger">
                            Tải lên thất bại: ${xhr.statusText}
                        </div>
                    `;
                        }
                        submitButton.disabled = false;
                    });

                    // Handle network errors
                    xhr.addEventListener('error', function() {
                        progressBarInner.classList.remove('progress-bar-striped',
                            'progress-bar-animated');
                        progressBarInner.classList.add('bg-danger');
                        progressBarInner.textContent = 'Lỗi!';

                        uploadStatus.innerHTML = `
                    <div class="alert alert-danger">
                        Lỗi kết nối mạng! Vui lòng thử lại
                    </div>
                `;
                        submitButton.disabled = false;
                    });

                    // Send request
                    xhr.open('POST', uploadForm.action, true);
                    xhr.send(formData);
                });
            };

            /**
             * Search and Sort Functionality
             */
            const initializeSearchSort = function() {
                const searchInput = document.getElementById('searchFiles');
                const sortSelect = document.getElementById('sortFiles');
                const fileGrid = document.querySelector('.file-grid');

                if (!searchInput || !sortSelect || !fileGrid) return;

                const filterAndSortFiles = function() {
                    const searchTerm = searchInput.value.toLowerCase();
                    const sortBy = sortSelect.value;

                    Array.from(fileGrid.children).forEach(item => {
                        const fileName = item.querySelector('h6').textContent.toLowerCase();
                        item.style.display = fileName.includes(searchTerm) ? 'block' : 'none';
                    });

                    // Convert to array for sorting
                    const items = Array.from(fileGrid.children);

                    items.sort((a, b) => {
                        const aVal = a.dataset[sortBy];
                        const bVal = b.dataset[sortBy];

                        if (sortBy === 'date') return bVal.localeCompare(aVal);
                        if (sortBy === 'size') return bVal - aVal;
                        if (sortBy === 'type') return a.dataset.type.localeCompare(b.dataset.type);
                        return a.dataset.name.localeCompare(b.dataset.name);
                    });

                    // Re-append sorted items
                    items.forEach(item => fileGrid.appendChild(item));
                };

                searchInput.addEventListener('input', filterAndSortFiles);
                sortSelect.addEventListener('change', filterAndSortFiles);
            };

            /**
             * Folder Tree Navigation
             */
            const initializeFolderTree = function() {
                document.querySelectorAll('.folder-item').forEach(item => {
                    item.addEventListener('click', function() {
                        const path = this.dataset.path;
                        window.location.href =
                            `/file-storage/folder/${encodeURIComponent(path)}`;
                    });
                });

                // Refresh tree
                document.getElementById('refreshTree').addEventListener('click', () => {
                    window.location.reload();
                });
            };

            /**
             * Escape HTML for preview
             */
            const escapeHtml = function(unsafe) {
                return unsafe
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&#039;");
            };

            // Initialize all components
            initializeFilePreview();
            initializeDeleteConfirmation();
            initializeDragDropUpload();
            initializeFileUpload();
            initializeSearchSort();
            initializeFolderTree();
        });
    </script>
@endsection
