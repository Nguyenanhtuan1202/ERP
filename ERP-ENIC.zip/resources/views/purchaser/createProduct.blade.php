@extends('layouts.layout_purchaser')

@section('content')
    @php
        use Carbon\Carbon;
    @endphp
    <style>
        /* Typography & Base Styling */
        body {
            background-color: #f8fafc;
            color: #2d3748;
            line-height: 1.6;
        }

        /* Container Styling */
        .container-fluid {
            padding: 20px;
            background-color: #fff;
        }


        /* Main Variables */
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1d4ed8;
            --primary-light: #3b82f6;
            --secondary-color: #64748b;
            --secondary-light: #94a3b8;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --info-color: #0ea5e9;
            --light-color: #f8fafc;
            --dark-color: #1e293b;
            --gray-color: #e2e8f0;
            --body-bg: #f1f5f9;
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --text-color: #334155;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
        }

        /* General */
        body {
            font-family: 'Roboto', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: var(--text-color);
            background-color: var(--body-bg);
            line-height: 1.5;
        }

        .container-fluid {
            padding-left: 1.5rem;
            padding-right: 1.5rem;
        }

        /* Navigation */
        .navbar-dark.bg-primary {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .navbar-brand i {
            color: #ffffff;
        }

        .navbar-nav .nav-link {
            padding: 0.75rem 1rem;
            font-weight: 500;
            position: relative;
        }

        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-nav .nav-link:hover {
            color: #ffffff;
        }

        .navbar-dark .navbar-nav .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 0.25rem;
        }

        .dropdown-menu {
            border: none;
            box-shadow: var(--card-shadow);
            border-radius: 0.375rem;
        }

        .dropdown-item {
            padding: 0.625rem 1rem;
            font-size: 0.9rem;
        }

        .dropdown-item:hover {
            background-color: rgba(37, 99, 235, 0.1);
        }

        /* Breadcrumb */
        .bg-light {
            background-color: #ffffff !important;
            border-bottom: 1px solid var(--border-color);
        }

        .breadcrumb {
            font-size: 0.85rem;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .breadcrumb-item.active {
            color: var(--text-muted);
        }

        /* Main Content */
        .py-4 {
            padding-top: 1.75rem !important;
            padding-bottom: 1.75rem !important;
        }

        h1.h3 {
            font-weight: 600;
            color: var(--dark-color);
        }

        /* Cards */
        .card {
            border: none;
            border-radius: 0.5rem;
            box-shadow: var(--card-shadow);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .card-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border-color);
        }

        .card-header .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0;
        }

        .card-header i {
            color: var(--primary-color);
        }

        .card-body {
            padding: 1.25rem;
        }

        /* Form Elements */
        .form-label {
            font-weight: 500;
            font-size: 0.9rem;
            margin-bottom: 0.375rem;
            color: var(--dark-color);
        }

        .form-control,
        .form-select {
            padding: 0.5rem 0.75rem;
            font-size: 0.95rem;
            border: 1px solid var(--border-color);
            border-radius: 0.375rem;
            transition: border-color 0.2s ease;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary-light);
            box-shadow: 0 0 0 0.25rem rgba(37, 99, 235, 0.15);
        }

        .input-group .form-control {
            border-right: 0;
        }

        .input-group-text {
            background-color: #f8fafc;
            border-color: var(--border-color);
        }

        .text-danger {
            color: var(--danger-color) !important;
        }

        .form-text,
        .small {
            font-size: 0.85rem;
        }

        .form-control.is-invalid,
        .form-select.is-invalid {
            border-color: var(--danger-color);
        }

        textarea.form-control {
            min-height: 100px;
        }

        /* Buttons */
        .btn {
            padding: 0.5rem 1rem;
            font-weight: 500;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .btn-secondary {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .btn-outline-secondary {
            color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .btn-outline-secondary:hover {
            background-color: var(--secondary-color);
            color: #ffffff;
        }

        .btn i {
            font-size: 0.9rem;
        }

        /* Validation */
        .text-danger.small {
            margin-top: 0.25rem;
            font-size: 0.8rem;
        }

        /* Image Preview */
        .img-thumbnail {
            border-color: var(--border-color);
        }

        /* Responsive Adjustments */
        @media (max-width: 991.98px) {
            .navbar-collapse {
                margin-top: 0.5rem;
                padding: 0.5rem 0;
            }

            .navbar-nav .nav-link.active {
                background-color: transparent;
                color: #ffffff;
                font-weight: 600;
            }

            .navbar-nav .nav-link {
                padding: 0.5rem 0;
            }

            .dropdown-menu {
                border: none;
                background-color: rgba(255, 255, 255, 0.05);
                box-shadow: none;
                padding: 0 0 0 1rem;
            }

            .dropdown-item {
                color: rgba(255, 255, 255, 0.75);
            }

            .dropdown-item:hover {
                background-color: transparent;
                color: #ffffff;
            }
        }

        @media (max-width: 767.98px) {
            .container-fluid {
                padding-left: 1rem;
                padding-right: 1rem;
            }

            .row>[class^="col-"] {
                margin-bottom: 1rem;
            }

            .card-body {
                padding: 1rem;
            }
        }

        /* Additional Styles for ERP-specific elements */
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .action-button {
            width: 2rem;
            height: 2rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 0.25rem;
            color: var(--text-muted);
            background-color: #f8fafc;
            border: 1px solid var(--border-color);
            transition: all 0.2s ease;
        }

        .action-button:hover {
            background-color: #f1f5f9;
        }

        .action-button.edit:hover {
            color: var(--info-color);
        }

        .action-button.delete:hover {
            color: var(--danger-color);
        }

        .action-button.view:hover {
            color: var(--success-color);
        }

        /* Status Indicators */
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-active {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-inactive {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }

        .status-pending {
            background-color: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        /* Data Tables */
        .table {
            color: var(--text-color);
        }

        .table thead th {
            background-color: #f8fafc;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid var(--border-color);
            padding: 0.75rem 1rem;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid var(--border-color);
        }

        .table tbody tr:hover {
            background-color: rgba(241, 245, 249, 0.5);
        }

        .table-responsive {
            border-radius: 0.5rem;
            overflow: hidden;
        }

        /* Modal Styles */
        .modal-content {
            border: none;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .modal-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-title {
            font-weight: 600;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--border-color);
        }

    </style>

    <div class="container-fluid px-4">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="row mb-4 align-items-center">
            <div class="col-md-6">
                <h2 class="h3 mb-0">Thêm Mới Sản Phẩm</h2>

            </div>

        </div>



        <!-- Main Navigation -->


        <!-- Sub Navigation -->
        <div class="bg-light py-2">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{route('productManagement.index')}}">Danh Sách Sản Phẩm</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Thêm Sản Phẩm</li>
                    </ol>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container-fluid py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Add New Product</h1>
                <div>
                    <a href="{{ route('productManagement.index') }}" class="btn btn-outline-secondary">
                        <i class="fas fa-list me-1"></i> View All Products
                    </a>
                </div>
            </div>


      

            <!-- Product Form -->
            <form id="productForecastForm" action="{{ route('productManagement.store') }}" method="POST"
                enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Product Information Card -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-info-circle mx-2"></i>Product Information
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="supplier_id" class="form-label">Nhà Cung Cấp <span
                                                class="text-danger">*</span></label>
                                        <select required name="supplier_id" id="supplier_id"
                                            class="form-select form-control select3_init">
                                            <option value="">Chọn</option>
                                            @foreach ($data['list_supplier'] as $supplier)
                                                <option value="{{ $supplier->sp_code }}">
                                                    {{ $supplier->sp_code }} - {{ $supplier->company_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('supplier_id')
                                            <div class="text-danger small mt-1">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="col-md-6">
                                        <label for="product_name" class="form-label">Danh Mục Sản Phẩm <span
                                                class="text-danger">*</span></label>
                                        <select required name="product_name" id="product_name"
                                            class="form-select form-control select3_init">
                                            <option value="">Chọn</option>
                                            @if ($data['list_category']->count() > 0)
                                                @foreach ($data['list_category'] as $item)
                                                    <option data-id={{ $item->id ?? '' }} value="{{ $item->title ?? '' }}">
                                                        {{ $item->title ?? '' }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </select>
                                        @error('product_name')
                                            <div class="text-danger small mt-1">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="product_variant" class="form-label">Mẫu (Phân Loại) <span
                                                class="text-danger">*</span></label>
                                        <select required name="product_variant" id="product_variant"
                                            class="form-select form-control select3_init">
                                            <option value="">Chọn</option>
                                        </select>
                                        @error('product_variant')
                                            <div class="text-danger small mt-1">{{ $message }}</div>
                                        @enderror

                                    </div>
                                    <div class="col-md-6">
                                        <label for="model_version" class="form-label">Phiên Bản (Model) <span
                                                class="text-danger">*</span></label>
                                        <select required name="model_version" id="model_version"
                                            class="form-select form-control select3_init">
                                            <option value="">Chọn</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="sale_key" class="form-label">Key Chuẩn Sale <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="sale_key" name="sale_key" required>
                                    @error('sale_key')
                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="color" class="form-label">Màu Sắc</label>
                                        <input type="text" class="form-control" id="color" name="color">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="size" class="form-label">Kích Thước</label>
                                        <input type="text" class="form-control" id="size" name="size">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="sku" class="form-label">SKU <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="sku" name="sku"
                                            required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pricing Details Card -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-dollar-sign mx-2"></i>Pricing Details
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="price" class="form-label">Giá Mua <span
                                                class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" class="form-control" id="price"
                                                name="price" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <label style="display: block" for="unit" class="form-label">Đơn Vị</label>
                                        <select name="unit" id="unit"
                                            class="form-select form-control select3_init">
                                            <option value="">Select Unit</option>
                                            <option value="RMB">RMB</option>
                                            <option value="USD">USD</option>
                                            <option value="VND">VND</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="price_vn" class="form-label">Giá Việt Nam</label>
                                        <div class="input-group">
                                            <input type="number" step="1" class="form-control" id="price_vn"
                                                name="price_vn">
                                            <input type="hidden" class="real-value">
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="warehouse_price" class="form-label">Giá Nhập Về Kho</label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" class="form-control"
                                                id="warehouse_price" name="warehouse_price">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="selling_price" class="form-label">Giá Bán</label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" class="form-control" id="selling_price"
                                                name="selling_price">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <!-- Logistics & Shipping Card -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-shipping-fast mx-2"></i>Logistics & Shipping
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="length_cm" class="form-label">Chiều Dài Thùng Carton (cm)</label>
                                        <input type="number" step="0.1" class="form-control" id="length_cm"
                                            name="length_cm">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="width_cm" class="form-label">Chiều Rộng Carton (cm)</label>
                                        <input type="number" step="0.1" class="form-control" id="width_cm"
                                            name="width_cm">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="height_cm" class="form-label">Chiều Cao Carton (cm)</label>
                                        <input type="number" step="0.1" class="form-control" id="height_cm"
                                            name="height_cm">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="quantity_per_carton" class="form-label">Số Lượng Sản Phẩm Mỗi
                                            Thùng</label>
                                        <input type="number" class="form-control" id="quantity_per_carton"
                                            name="quantity_per_carton">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="cbm_per_ctn" class="form-label">Thể tích thùng (CBM)</label>
                                        <input type="number" step="0.00001" class="form-control" id="cbm_per_ctn"
                                            name="cbm_per_ctn">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="quantity_per_container" class="form-label">Số Lượng Sản Phẩm Mỗi
                                            Container</label>
                                        <input type="number" class="form-control" id="quantity_per_container"
                                            name="quantity_per_container">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="freight_cost_per_cubic_meter" class="form-label">Cước vận chuyển trên
                                            mỗi CBM</label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" class="form-control"
                                                id="freight_cost_per_cubic_meter" name="freight_cost_per_cubic_meter">
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="import_tax" class="form-label">Thuế nhập khẩu</label>
                                        <input type="number" step="0.01" class="form-control" id="import_tax"
                                            name="import_tax">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="additional_costs" class="form-label">Chi phí phát sinh khác</label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" class="form-control"
                                                id="additional_costs" name="additional_costs">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Information Card -->
                        <div class="card shadow-sm mb-4">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">
                                    <i class="fas fa-info-circle mx-2"></i>Additional Information
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="product_note" class="form-label">Ghi Chú Sản Phẩm</label>
                                    <textarea class="form-control" id="product_note" name="product_note" rows="3"></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="image" class="form-label">Hình Ảnh Sản Phẩm</label>
                                    <input type="file" class="form-control" id="image" name="image"
                                        onchange="loadFile(event)" accept="image/*">
                                    <div class="mt-2">
                                        <img id="imagePreview" class="img-thumbnail"
                                            style="max-width: 200px; display: none;" src=""
                                            alt="Product Preview">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-12">
                        <div class="card shadow-sm mb-4">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <button type="reset" class="btn btn-outline-secondary">
                                            <i class="fas fa-undo me-1"></i> Reset Form
                                        </button>
                                    </div>
                                    <div>
                                        <a href="{{ route('productManagement.index') }}" class="btn btn-secondary mx-2">
                                            <i class="fas fa-arrow-left me-1"></i> Back to List
                                        </a>
                                        <button type="submit" id="submitBtn" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Thêm Mới
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
@endsection

@section('js')
    <script>
        $('.select3_init').select2({
            'placeholder': 'Chọn'
        });





        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                title: 'Hướng dẫn sử dụng Form',
                html: `
            <div style="text-align: left; font-size: 1rem;">
                <p>Chào mừng bạn đến với hệ thống nhập thông tin sản phẩm. Vui lòng lưu ý các hướng dẫn dưới đây:</p>
                <ol style="padding-left: 20px; line-height: 1.6;">
                    <li>Các trường có dấu <strong style="color: red;">*</strong> là bắt buộc phải nhập.</li>
                    <li><strong>Upload hình ảnh</strong> sản phẩm.</li>
                    <li>Điền đầy đủ và chính xác thông tin để hệ thống xử lý hiệu quả.</li>
                    <li>Sử dụng danh sách lựa chọn (dropdown) để chọn thông tin chuẩn xác.</li>
                    <li>Các trường không bắt buộc có thể điền sau, nhưng nên cập nhật đầy đủ để quản lý tốt hơn.</li>
                    <li>Cuối cùng, nhấn nút <strong>"Thêm Mới"</strong> sau khi kiểm tra lại thông tin.</li>
                </ol>
            </div>
        `,
                icon: 'info',
                confirmButtonText: 'Tôi đã hiểu',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                },
                customClass: {
                    title: 'swal2-title-custom',
                    content: 'swal2-content-custom',
                    confirmButton: 'btn btn-primary'
                }
            });
        });

        // Listen for changes on product_name dropdown chọn product variants
        $('#product_name').on('change', function() {
            var selectedOption = $(this).find('option:selected');
            var categoryId = selectedOption.data('id');

            $('#product_variant').empty().append('<option value="">Chọn</option>');

            if (categoryId) {
                // Show loading indicator (optional)
                $('#product_variant').prop('disabled', true);

                $.ajax({
                    url: "{{ route('productManagement.getVariantsByCategory') }}",
                    type: 'GET',
                    data: {
                        category_id: categoryId,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.variants.length > 0) {
                            $.each(response.variants, function(index, variant) {
                                $('#product_variant').append('<option value="' + variant.title +
                                    '">' + variant.title + '</option>');
                            });
                        }

                        // Enable select and refresh Select2
                        $('#product_variant').prop('disabled', false).trigger('change');
                    },
                    error: function(xhr, status, error) {
                        console.error('Lỗi khi tải phân loại:', error);
                        alert('Có lỗi xảy ra khi tải dữ liệu phân loại. Vui lòng thử lại sau.');
                        $('#product_variant').prop('disabled', false);
                    }
                });
            }
        });

        // Listen for changes on product_variant dropdown
        $('#product_variant').on('change', function() {
            var variantId = $(this).val();

            // Reset model_version dropdown
            $('#model_version').empty().append('<option value="">Chọn</option>');

            if (variantId) {
                // Show loading indicator
                $('#model_version').prop('disabled', true);

                $.ajax({
                    url: "{{ route('productManagement.getModelsByVariant') }}",
                    type: 'GET',
                    data: {
                        variant_id: variantId,
                        _token: '{{ csrf_token() }}'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.models.length > 0) {
                            $.each(response.models, function(index, model) {
                                $('#model_version').append('<option value="' + model.title +
                                    '">' +
                                    model.title + '</option>');
                            });
                        }

                        // Enable select and refresh Select2
                        $('#model_version').prop('disabled', false).trigger('change');
                    },
                    error: function(xhr, status, error) {
                        console.error('Lỗi khi tải phiên bản:', error);
                        alert('Có lỗi xảy ra khi tải dữ liệu phiên bản. Vui lòng thử lại sau.');
                        $('#model_version').prop('disabled', false);
                    }
                });
            }
        });



        document.addEventListener('DOMContentLoaded', function() {
            const productForecastForm = document.getElementById('productForecastForm');

            productForecastForm.addEventListener('submit', function(e) {
                let missingFields = [];
                // Lấy tất cả các trường có thuộc tính required trong form
                const requiredFields = productForecastForm.querySelectorAll('[required]');

                requiredFields.forEach(function(field) {
                    if (!field.value.trim()) {
                        // Tìm label có for trùng với id của trường, nếu có
                        let fieldLabel = '';
                        if (field.id) {
                            const label = document.querySelector('label[for="' + field.id + '"]');
                            if (label) {
                                // Loại bỏ các ký tự như * hoặc :
                                fieldLabel = label.textContent.replace(/[\*\:]/g, '').trim();
                            }
                        }
                        // Nếu không tìm được label, sử dụng name của trường
                        if (!fieldLabel) {
                            fieldLabel = field.name;
                        }
                        missingFields.push(fieldLabel);
                    }
                });

                if (missingFields.length > 0) {
                    e.preventDefault(); // Ngăn submit form
                    // Hiển thị thông báo lỗi bằng SweetAlert
                    Swal.fire({
                        title: "Lỗi!",
                        html: "Vui lòng nhập: <br>" + missingFields.join('<br>'),
                        icon: "error"
                    });
                }
            });
        });



        // Calculate CBM when dimensions are changed
        document.addEventListener('DOMContentLoaded', function() {
            // Get all dimension input fields
            const lengthInput = document.getElementById('length_cm');
            const widthInput = document.getElementById('width_cm');
            const heightInput = document.getElementById('height_cm');
            const cbmInput = document.getElementById('cbm_per_ctn');

            // Function to calculate CBM
            function calculateCBM() {
                const length = parseFloat(lengthInput.value) || 0;
                const width = parseFloat(widthInput.value) || 0;
                const height = parseFloat(heightInput.value) || 0;

                // Convert from cm to m and calculate cubic meters
                const cbm = (length * width * height) / 1000000; // 1,000,000 cm³ = 1 m³

                // Set the calculated value with 4 decimal places
                cbmInput.value = cbm.toFixed(4);
            }

            // Add event listeners to dimension inputs
            lengthInput.addEventListener('input', calculateCBM);
            widthInput.addEventListener('input', calculateCBM);
            heightInput.addEventListener('input', calculateCBM);

            // Initial calculation in case fields are pre-filled
            calculateCBM();
        });
    </script>
@endsection
