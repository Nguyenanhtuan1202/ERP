@extends('layouts.enic')

@section('css')
    <style>
        .profile-container {
            padding: 20px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #3498db;
            margin-right: 30px;
        }

        .profile-info {
            flex: 1;
        }

        .profile-info h2 {
            margin-bottom: 5px;
            color: #333;
        }

        .profile-info p {
            color: #666;
            margin-bottom: 5px;
        }

        .badge-role {
            background: #3498db;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            margin-left: 10px;
        }

        .stat-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #3498db;
        }

        .stat-label {
            color: #777;
            font-size: 14px;
        }

        .tab-container {
            margin-top: 30px;
        }

        .nav-tabs {
            border-bottom: 2px solid #f1f1f1;
            margin-bottom: 20px;
        }

        .nav-tabs .nav-link {
            border: none;
            color: #777;
            padding: 10px 20px;
            font-weight: 500;
            position: relative;
        }

        .nav-tabs .nav-link.active {
            color: #3498db;
            background: transparent;
        }

        .nav-tabs .nav-link.active:after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #3498db;
        }

        .tab-content {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }

        .data-table th {
            background: #f9f9f9;
            font-weight: 500;
            color: #333;
            text-align: left;
        }

        .data-table tbody tr:hover {
            background: #f5f9ff;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-completed {
            background: #d4edda;
            color: #155724;
        }

        .status-cancelled {
            background: #f8d7da;
            color: #721c24;
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            color: white;
            font-size: 12px;
            margin-right: 5px;
            text-decoration: none;
            display: inline-block;
        }

        .view-btn {
            background: #3498db;
        }

        .edit-btn {
            background: #2ecc71;
        }

        .delete-btn {
            background: #e74c3c;
        }

        .breadcrumb-container {
            margin-bottom: 20px;
        }

        .no-data {
            text-align: center;
            padding: 30px;
            color: #777;
        }

        .note-container {
            background: #f9f9f9;
            padding: 10px;
            border-radius: 6px;
            margin-top: 10px;
            font-style: italic;
            color: #666;
        }

        .payment-info {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }

        .payment-item {
            flex: 1;
            text-align: center;
        }

        .payment-label {
            font-size: 12px;
            color: #777;
        }

        .payment-value {
            font-weight: bold;
            color: #333;
        }

        .payment-value.paid {
            color: #2ecc71;
        }

        .payment-value.due {
            color: #e74c3c;
        }

        .tag {
            background: #f1f1f1;
            color: #555;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-right: 5px;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid profile-container ">

        <!-- Thống kê -->
        <div class="row " style="margin-top: 100px">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value">{{ $data['history']->count() }}</div> 
                    <div class="stat-label">Lịch sử thanh toán</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value">{{ $data['supplier']->count() }}</div>
                    <div class="stat-label">Nhà cung cấp</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value">{{ $data['order']->count() }}</div>
                    <div class="stat-label">Đơn hàng</div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value">{{ $data['forecastProducts']->count() }}</div>
                    <div class="stat-label">Sản Phẩm</div>
                </div>
            </div>
        </div>

        <!-- Tabs thông tin chi tiết -->
        <div class="tab-container">
            <ul class="nav nav-tabs" id="userTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="history-tab" data-toggle="tab" href="#history" role="tab">
                        <i class="fas fa-history"></i> Lịch sử thanh toán ({{ $data['history']->count() }})
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="supplier-tab" data-toggle="tab" href="#supplier" role="tab">
                        <i class="fas fa-building"></i> Nhà cung cấp ({{ $data['supplier']->count() }})
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="order-tab" data-toggle="tab" href="#order" role="tab">
                        <i class="fas fa-shopping-cart"></i> Đơn hàng ({{ $data['order']->count() }} )
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="product-tab" data-toggle="tab" href="#product" role="tab">
                        <i class="fas fa-shopping-cart"></i> Sản Phẩm ({{ $data['forecastProducts']->count() }})
                    </a>
                </li>


            </ul>

            <div class="tab-content" id="userTabContent">
                <!-- Tab lịch sử thanh toán -->
                <div class="tab-pane fade show active" id="history" role="tabpanel">

                    @if ($data['history']->count() > 0)
                        <table class="data-table" id="table12">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Mã đơn</th>
                                    <th>Số tiền</th>
                                    <th>Ngày thanh toán</th>
                                    <th>Ghi chú</th>
                                    <th>Ngày Chỉnh Sửa</th>
                                    <th>Nội Dung Chỉnh Sửa</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $temp = 0;
                                @endphp
                                @foreach ($data['history'] as $history)
                                    @php
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <td>{{ $temp }}</td>
                                        <td>#{{ $history->order->order_code ?? '' }}</td>
                                        <td>{{ number_format($history->amount) }} đ</td>
                                        <td>{{ $history->paid_at ? date('d/m/Y: H:i', strtotime($history->paid_at)) : 'Chưa thanh toán' }}
                                        </td>

                                        <td>
                                            @if ($history->note)
                                                <span class="d-inline-block text-truncate" style="max-width: 300px;">
                                                    {{ $history->note ?? '' }}
                                                </span>
                                            @else
                                                <span class="text-muted">Không có</span>
                                            @endif
                                        </td>

                                        <td>{{ $history->date_updated != null ? date('d/m/Y: H:i', strtotime($history->date_updated ?? '')) : '' }}
                                        </td>
                                        <td>{{ $history->note_updated ?? '' }}</td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="no-data">
                            <i class="fas fa-info-circle"></i> Không có dữ liệu lịch sử thanh toán.
                        </div>
                    @endif
                </div>

                <!-- Tab nhà cung cấp -->
                <div class="tab-pane fade" id="supplier" role="tabpanel">
                    @if ($data['supplier']->count() > 0)
                        <table class="data-table" id="table2">
                            <thead>
                                <tr>
                                    <th>Mã NCC</th>
                                    <th>Tên công ty</th>
                                    <th>Liên hệ</th>
                                    <th>Địa Chỉ</th>
                                    <th>Thời gian SX</th>
                                    <th>Trạng thái</th>

                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data['supplier'] as $supplier)
                                    <tr>
                                        <td>{{ $supplier->sp_code ?? '' }}</td>
                                        <td>
                                            <div>{{ $supplier->company_name ?? '' }}</div>
                                            <div class="text-muted small">{{ $supplier->website }}</div>
                                        </td>
                                        <td>
                                            <div>{{ $supplier->username ?? '' }}</div>
                                            <div>{{ $supplier->phone_number ?? '' }}</div>
                                            <div>{{ $supplier->email ?? '' }}</div>
                                        </td>
                                        <td class="d-inline-block text-truncate" style="max-width: 300px;">
                                            {{ $supplier->address ?? '' }}</td>
                                        <td>{{ $supplier->production_time ?? '' }} ngày</td>
                                        <td>
                                            @if ($supplier->status == 1)
                                                <span class="status-badge status-completed">Đang Hoạt động</span>
                                            @elseif($supplier->status == 0)
                                                <span class="status-badge status-cancelled">Ngừng hoạt động</span>
                                            @else
                                                <span class="status-badge status-pending">Đang xét duyệt</span>
                                            @endif
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="no-data">
                            <i class="fas fa-info-circle"></i> Không có dữ liệu nhà cung cấp.
                        </div>
                    @endif
                </div>

                <!-- Tab đơn hàng -->
                <div class="tab-pane fade" id="order" role="tabpanel">
                    @if ($data['order']->count() > 0)
                        <table class="data-table" id="table3">
                            <thead>
                                <tr>
                                    <th>Mã đơn</th>
                                    <th>Nhà cung cấp</th>
                                    <th>Ngày đặt</th>
                                    <th>Số lượng</th>
                                    <th>Trạng thái</th>

                                </tr>
                            </thead>

                            <tbody>
                                @foreach ($data['order'] as $order)
                                    <tr>
                                        <td>#{{ $order->order_code ?? '' }}</td>
                                        <td>{{ $order->supplier->company_name ?? '' }}</td>
                                        <td>{{ date('d/m/Y', strtotime($order->order_date)) }}</td>
                                        <td>{{ $order->total_quantity ?? '' }}</td>
                                        <td>
                                            @if ($order->status == 0)
                                                <span class="status-badge status-pending">Chưa hoàn thành</span>
                                            @else
                                                <span class="status-badge status-completed">Đã hoàn thành</span>
                                            @endif
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="no-data">
                            <i class="fas fa-info-circle"></i> Không có dữ liệu đơn hàng.
                        </div>
                    @endif
                </div>



                <!-- Tab sản phẩm -->
                <div class="tab-pane fade" id="product" role="tabpanel">
                    @if ($data['forecastProducts']->count() > 0)
                        <table class="data-table" id="table5">
                            <thead>
                                <tr>
                                    <th>Tên Sản Phẩm</th>
                                    <th>Danh Mục</th>
                                    <th>Model</th>
                                    <th>Màu Sắc</th>
                                    <th>Kích Thước</th>
                                    <th>Key Sale</th>
                                    <th>SKU</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach ($data['forecastProducts'] as $product)
                                    <tr>
                                        <td>{{ $product->product_name ?? '' }}</td>
                                        <td>{{ $product->product_variant ?? '' }}</td>
                                        <td>{{ $product->model_version ?? '' }}</td>
                                        <td>{{ $product->color ?? '' }}</td>
                                        <td>{{ $product->size ?? '' }}</td>
                                        <td>{{ $product->sale_key ?? '' }}</td>
                                        <td>{{ $product->sku ?? '' }}</td>
                                        <td class="text-center">
                                            <a href="{{ route('forecastProduct.edit', ['id' => $product->id]) }}"><i
                                                    class="far fa-edit"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="no-data">
                            <i class="fas fa-info-circle"></i> Không có dữ liệu đơn hàng.
                        </div>
                    @endif
                </div>


            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            $('#userTabs a').on('click', function(e) {
                e.preventDefault()
                $(this).tab('show')
            })
        })
    </script>
@endsection
