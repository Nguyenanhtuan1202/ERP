    @extends('layouts.layout_purchaser')
    @section('css')
    @endsection
    @section('content')
        <style>
            .table-custom {
                width: 100%;
                position: relative;
                border-radius: 20px;
                overflow: hidden;
                background: white;
                box-shadow:
                    0 15px 35px rgba(0, 0, 0, 0.05),
                    0 5px 15px rgba(0, 0, 0, 0.03);
            }

            .table-custom::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 6px;
                background: linear-gradient(90deg,
                        #4b6cb7 0%,
                        #182848 100%);
                z-index: 10;
            }

            .table-custom thead {
                background: linear-gradient(to right,
                        #f5f7fa 0%,
                        #f5f7fa 100%);
                border-bottom: 1px solid #e9ecef;
            }

            .table-custom th {
                padding: 20px 15px;
                text-transform: uppercase;
                letter-spacing: 1px;
                font-size: 0.75rem;
                color: #2c3e50;
                font-weight: 800;
                border-bottom: 2px solid #e9ecef;
                position: relative;
                transition: all 0.3s ease;
            }

            .table-custom th::after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 0;
                width: 0;
                height: 2px;
                background: linear-gradient(90deg,
                        #4b6cb7 0%,
                        #182848 100%);
                transition: width 0.3s ease;
            }

            .table-custom th:hover::after {
                width: 100%;
            }

            .table-custom td {
                padding: 18px 15px;
                color: #34495e;
                border-bottom: 1px solid #f1f3f5;
                transition: all 0.3s ease;
                position: relative;
            }

            .table-custom tbody tr {
                transition: all 0.3s ease;
            }

            .table-custom tbody tr:nth-child(even) {
                background-color: rgba(241, 243, 245, 0.5);
            }

            .table-custom tbody tr:hover {
                background-color: rgba(236, 240, 241, 0.7);
                transform: translateY(-4px);
                box-shadow:
                    0 10px 20px rgba(0, 0, 0, 0.05),
                    0 4px 8px rgba(0, 0, 0, 0.03);
            }

            .status-tag {
                display: inline-block;
                padding: 7px 14px;
                border-radius: 30px;
                font-size: 0.7rem;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.8px;
                box-shadow:
                    0 3px 6px rgba(0, 0, 0, 0.08),
                    0 1px 3px rgba(0, 0, 0, 0.05);
                position: relative;
                overflow: hidden;
            }

            .status-active {
                background: linear-gradient(135deg,
                        #11998e 0%,
                        #38ef7d 100%);
                color: white;
                border: 1px solid rgba(57, 239, 125, 0.3);
            }

            .status-inactive {
                background: linear-gradient(135deg,
                        #ed213a 0%,
                        #93291e 100%);
                color: white;
                border: 1px solid rgba(237, 33, 58, 0.3);
            }

            .action-column {
                text-align: center;
                width: 100px;
            }

            .action-column a {
                color: #2c3e50;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                position: relative;
                overflow: hidden;
            }

            .action-column a::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                background: rgba(44, 62, 80, 0.1);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                transition: all 0.3s ease;
            }

            .action-column a:hover::before {
                width: 150%;
                height: 150%;
            }

            .action-column a:hover {
                transform: scale(1.1) rotate(4deg);
                color: #4b6cb7;
            }

            @media (max-width: 768px) {
                .table-custom {
                    font-size: 0.85rem;
                }

                .table-custom th,
                .table-custom td {
                    padding: 14px;
                }
            }

            .table-responsive {
                scrollbar-width: thin;
                scrollbar-color: #4b6cb7 #f8f9fa;
            }

            .table-responsive::-webkit-scrollbar {
                width: 10px;
            }

            .table-responsive::-webkit-scrollbar-track {
                background: #f8f9fa;
                border-radius: 10px;
            }

            .table-responsive::-webkit-scrollbar-thumb {
                background: linear-gradient(135deg,
                        #4b6cb7 0%,
                        #182848 100%);
                border-radius: 10px;
            }

            .product-management-buttons .card {
                border: none;
                border-radius: 15px;
                overflow: hidden;
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05), 0 6px 6px rgba(0, 0, 0, 0.06);
                transition: all 0.3s ease;
            }

            .product-management-buttons .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1), 0 8px 10px rgba(0, 0, 0, 0.07);
            }

            .bg-gradient-primary {
                background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
                padding: 15px 20px;
            }

            .product-card-button {
                flex: 0 0 32%;
                margin-bottom: 15px;
            }

            .btn-product-management {
                display: flex;
                align-items: center;
                background: white;
                border-radius: 12px;
                padding: 20px;
                transition: all 0.3s ease;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.03);
                text-decoration: none;
                color: #34495e;
                border: 1px solid #f1f3f5;
                height: 100%;
                overflow: hidden;
                position: relative;
            }

            .btn-product-management:hover {
                background-color: #f8f9fa;
                transform: translateY(-3px);
                box-shadow: 0 8px 15px rgba(0, 0, 0, 0.08);
                color: #4b6cb7;
            }

            .btn-product-management::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 0;
                width: 0;
                height: 3px;
                background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
                transition: width 0.3s ease;
            }

            .btn-product-management:hover::after {
                width: 100%;
            }

            .icon-wrapper {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 60px;
                height: 60px;
                background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
                border-radius: 12px;
                margin-right: 20px;
                color: white;
                flex-shrink: 0;
            }

            .icon-wrapper i {
                font-size: 24px;
            }

            .variant-icon {
                background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            }

            .model-icon {
                background: linear-gradient(135deg, #ED4264 0%, #FFEDBC 100%);
            }

            .button-content {
                flex-grow: 1;
            }

            .button-content h5 {
                font-weight: 700;
                font-size: 1.1rem;
                margin-bottom: 5px;
                color: #2c3e50;
            }

            .button-content p {
                font-size: 0.8rem;
                color: #7f8c8d;
                margin-bottom: 5px;
            }

            .category-count,
            .variant-count,
            .model-count {
                display: inline-block;
                padding: 2px 10px;
                background: rgba(75, 108, 183, 0.1);
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: 700;
                color: #4b6cb7;
            }

            .variant-count {
                background: rgba(17, 153, 142, 0.1);
                color: #11998e;
            }

            .model-count {
                background: rgba(237, 66, 100, 0.1);
                color: #ED4264;
            }

            @media (max-width: 992px) {
                .product-card-button {
                    flex: 0 0 48%;
                }
            }

            @media (max-width: 768px) {
                .product-card-button {
                    flex: 0 0 100%;
                }

                .d-flex.flex-wrap {
                    flex-direction: column;
                }
            }

            /* Dashboard Metrics */
            .dashboard-metrics {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 1.2rem;
                margin-bottom: 1.5rem;
            }

            .metric-card {
                background: white;
                border-radius: 10px;
                padding: 1.2rem;
                display: flex;
                align-items: center;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }

            .metric-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 8px 15px rgba(0, 0, 0, 0.05);
            }

            .metric-card::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 0;
                width: 100%;
                height: 3px;
                background: linear-gradient(90deg, #4b6cb7 0%, #182848 100%);
                opacity: 0;
                transition: opacity 0.3s ease;
            }

            .metric-card:hover::after {
                opacity: 1;
            }

            .metric-icon {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                height: 50px;
                border-radius: 12px;
                margin-right: 1rem;
                color: white;
                flex-shrink: 0;
            }

            .active-icon {
                background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            }

            .inactive-icon {
                background: linear-gradient(135deg, #ED4264 0%, #FFEDBC 100%);
            }

            .variant-icon {
                background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            }

            .supplier-icon {
                background: linear-gradient(135deg, #FFA17F 0%, #00223E 100%);
            }

            .metric-icon i {
                font-size: 1.5rem;
            }

            .metric-content {
                flex-grow: 1;
            }

            .metric-content h3 {
                font-size: 1.5rem;
                font-weight: 700;
                margin: 0 0 0.2rem 0;
                color: #2c3e50;
            }

            .metric-content p {
                font-size: 0.8rem;
                color: #7f8c8d;
                margin: 0;
            }

            .metric-trend {
                display: flex;
                align-items: center;
                font-size: 0.8rem;
                font-weight: 700;
                padding: 0.2rem 0.5rem;
                border-radius: 20px;
            }

            .positive {
                color: #38ef7d;
                background: rgba(56, 239, 125, 0.1);
            }

            .negative {
                color: #ED4264;
                background: rgba(237, 66, 100, 0.1);
            }

            .neutral {
                color: #7f8c8d;
                background: rgba(127, 140, 141, 0.1);
            }

            .metric-trend i {
                margin-right: 0.2rem;
                font-size: 0.7rem;
            }

            /* Filter Section */
            .filter-section {
                display: flex;
                justify-content: space-between;
                margin-bottom: 1.5rem;
            }

            .search-container {
                position: relative;
                flex-grow: 1;
                max-width: 500px;
            }

            .search-container i {
                position: absolute;
                left: 1rem;
                top: 50%;
                transform: translateY(-50%);
                color: #7f8c8d;
            }

            .search-input {
                width: 100%;
                padding: 0.8rem 1rem 0.8rem 2.5rem;
                border-radius: 8px;
                border: 1px solid #e9ecef;
                font-size: 0.9rem;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
            }

            .search-input:focus {
                outline: none;
                border-color: #4b6cb7;
                box-shadow: 0 0 0 3px rgba(75, 108, 183, 0.15);
            }

            .filter-buttons {
                display: flex;
                gap: 0.5rem;
            }

            .filter-dropdown {
                position: relative;
            }

            .filter-btn {
                display: flex;
                align-items: center;
                padding: 0.8rem 1.2rem;
                border-radius: 8px;
                background: white;
                border: 1px solid #e9ecef;
                font-weight: 600;
                font-size: 0.9rem;
                color: #2c3e50;
                cursor: pointer;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
            }

            .filter-btn i {
                margin-right: 0.5rem;
            }

            .filter-btn:hover {
                background: #f8f9fa;
            }

            .filter-content {
                position: absolute;
                top: calc(100% + 10px);
                right: 0;
                background: white;
                border-radius: 10px;
                min-width: 250px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                padding: 1rem;
                z-index: 100;
                display: none;
            }

            .filter-dropdown:hover .filter-content {
                display: block;
            }

            .filter-group {
                margin-bottom: 1rem;
            }

            .filter-group label {
                display: block;
                font-size: 0.8rem;
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: #2c3e50;
            }

            .filter-group select {
                width: 100%;
                padding: 0.6rem 0.8rem;
                border-radius: 6px;
                border: 1px solid #e9ecef;
                font-size: 0.85rem;
                background: #f8f9fa;
                transition: all 0.3s ease;
            }

            .filter-group select:focus {
                outline: none;
                border-color: #4b6cb7;
                box-shadow: 0 0 0 3px rgba(75, 108, 183, 0.15);
            }

            .filter-actions {
                display: flex;
                justify-content: space-between;
                margin-top: 1rem;
            }

            .btn-reset,
            .btn-apply {
                padding: 0.5rem 1rem;
                border-radius: 6px;
                font-size: 0.85rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                border: none;
            }

            .btn-reset {
                background: #f8f9fa;
                color: #2c3e50;
                border: 1px solid #e9ecef;
            }

            .btn-apply {
                background: #4b6cb7;
                color: white;
            }

            .view-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border-radius: 8px;
                background: white;
                border: 1px solid #e9ecef;
                color: #7f8c8d;
                cursor: pointer;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
            }

            .view-btn:hover {
                background: #f8f9fa;
                color: #2c3e50;
            }

            .view-btn.active {
                background: #4b6cb7;
                color: white;
                border-color: #4b6cb7;
            }

            /* Product Table */
            .product-table-container {
                background: white;
                border-radius: 10px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
                overflow: hidden;
            }

            .table-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1.2rem 1.5rem;
                border-bottom: 1px solid #e9ecef;
            }

            .table-header h2 {
                font-size: 1.2rem;
                font-weight: 600;
                margin: 0;
                color: #2c3e50;
            }

            .entries-select {
                padding: 0.5rem 0.8rem;
                border-radius: 6px;
                border: 1px solid #e9ecef;
                font-size: 0.85rem;
                background: #f8f9fa;
                transition: all 0.3s ease;
            }

            .product-table {
                width: 100%;
                border-collapse: collapse;
            }

            .product-table thead {
                background: #f8f9fa;
            }

            .product-table th {
                padding: 1rem 1.2rem;
                text-align: left;
                font-size: 0.85rem;
                font-weight: 600;
                color: #2c3e50;
                position: relative;
                white-space: nowrap;
            }

            .product-table th.sortable {
                cursor: pointer;
            }

            .product-table th.sortable i {
                margin-left: 0.3rem;
                font-size: 0.7rem;
                opacity: 0.5;
                transition: all 0.3s ease;
            }

            .product-table th.sortable:hover i {
                opacity: 1;
            }

            .product-table td {
                padding: 1rem 1.2rem;
                border-top: 1px solid #f1f3f5;
                font-size: 0.9rem;
                color: #34495e;
                vertical-align: middle;
            }

            .product-table tbody tr {
                transition: all 0.3s ease;
            }

            .product-table tbody tr:hover {
                background-color: rgba(236, 240, 241, 0.5);
            }


            .column-checkbox {
                width: 40px;
                text-align: center;
            }

            .checkbox-container {
                position: relative;
                display: inline-block;
                width: 20px;
                height: 20px;
            }

            .checkbox-container input[type="checkbox"] {
                opacity: 0;
                position: absolute;
            }

            .checkbox-container label {
                position: absolute;
                top: 0;
                left: 0;
                width: 20px;
                height: 20px;
                background: #f8f9fa;
                border: 1px solid #e9ecef;
                border-radius: 4px;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .checkbox-container input[type="checkbox"]:checked+label {
                background: #4b6cb7;
                border-color: #4b6cb7;
            }

            .checkbox-container input[type="checkbox"]:checked+label:after {
                content: '\f00c';
                font-family: 'Font Awesome 5 Free';
                font-weight: 900;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                color: white;
                font-size: 0.7rem;
            }

            /* Product Cell */
            .product-cell {
                display: flex;
                align-items: center;
            }

            .product-image {
                width: 50px;
                height: 50px;
                border-radius: 8px;
                overflow: hidden;
                margin-right: 1rem;
                flex-shrink: 0;
            }

            .product-image img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            .product-info {
                display: flex;
                flex-direction: column;
            }

            .product-info h4 {
                font-size: 0.95rem;
                font-weight: 600;
                margin: 0 0 0.2rem 0;
                color: #2c3e50;
            }

            .product-info small {
                font-size: 0.8rem;
                color: #7f8c8d;
            }

            /* Badges */
            .category-badge,
            .supplier-code,
            .sku-code {
                display: inline-block;
                padding: 0.3rem 0.6rem;
                border-radius: 50px;
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            .category-badge {
                background: rgba(75, 108, 183, 0.1);
                color: #4b6cb7;
                font-size: 11px !important;
            }

            .supplier-code {
                background: #2c3e50;
                color: #FFA17F;
                width: 150px;
                text-align: center;
                font-size: 11px !important;
            }

            .sku-code {
                background: rgba(44, 62, 80, 0.1);
                color: #2c3e50;
            }

            .status-badge {
                display: inline-block;
                padding: 0.4rem 0.7rem;
                border-radius: 50px;
                font-size: 0.75rem;
                font-weight: 600;
            }

            .status-badge.active {
                background: rgba(56, 239, 125, 0.15);
                color: #11998e;
            }

            .status-badge.inactive {
                background: rgba(237, 66, 100, 0.15);
                color: #ED4264;
            }

            /* Color Display */
            .color-display {
                display: flex;
                align-items: center;
            }

            .color-dot {
                display: inline-block;
                width: 15px;
                height: 15px;
                border-radius: 50%;
                margin-right: 0.5rem;
                border: 1px solid rgba(0, 0, 0, 0.1);
            }

            /* Notes Cell */
            .notes-cell {
                position: relative;
            }

            .tooltip-container {
                display: inline-block;
                position: relative;
            }

            .tooltip-container i {
                color: #7f8c8d;
                cursor: pointer;
            }

            .tooltip-content {
                position: absolute;
                bottom: 100%;
                left: 50%;
                transform: translateX(-50%);
                min-width: 250px;
                background: white;
                border-radius: 8px;
                padding: 1rem;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                z-index: 10;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }

            .tooltip-container:hover .tooltip-content {
                opacity: 1;
                visibility: visible;
            }

            .tooltip-content::after {
                content: '';
                position: absolute;
                top: 100%;
                left: 50%;
                transform: translateX(-50%);
                border-width: 6px;
                border-style: solid;
                border-color: white transparent transparent transparent;
            }

            /* Nút action và container */
            .actions-cell {
                width: 120px;
                text-align: right;
                position: relative;
            }

            .action-buttons {
                display: flex;
                gap: 0.5rem;
                align-items: center;
                justify-content: flex-end;
            }

            /* Nút action */
            .action-btn {
                width: 36px;
                height: 36px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #64748b;
                transition: all 0.2s ease;
                border: none;
                background: transparent;
                cursor: pointer;
                position: relative;
            }

            .action-btn:hover {
                background: #f1f5f9;
                color: #3b82f6;
            }

            /* Dropdown container */
            .action-dropdown {
                position: relative;
                display: inline-block;
            }

            /* Nút dropdown */
            .dropdown-btn {
                background: transparent;
                transition: transform 0.3s ease, background 0.2s ease;
            }

            .action-dropdown .dropdown-content {
                right: 0;
                /* Đảm bảo hiển thị trên các phần tử khác */
                z-index: 1000;
            }

            table {
                position: relative;
            }

            /* Wrapper cho dropdown content */
            .dropdown-wrapper {
                position: absolute;
                top: 100%;
                right: 0;
                padding-top: 10px;
                /* Tạo vùng đệm phía trên */
                z-index: 999;
                display: none;
            }

            .action-dropdown:hover .dropdown-wrapper {
                display: block;
                position: absolute;
                z-index: 99999;
                top: -30px;
            }

            /* Điều chỉnh vị trí dropdown content */
            .dropdown-content {
                position: relative;
                background: white;
                border-radius: 8px;
                min-width: 180px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                padding: 0.5rem 0;
                max-height: 300px;
            }



            /* Hiển thị dropdown khi active */
            .dropdown-content.active {
                opacity: 1;
                visibility: visible;
                transform: translateY(0);
                pointer-events: auto;
            }

            /* Items trong dropdown */
            .dropdown-content a {
                padding: 0.7rem 1.2rem;
                display: flex;
                align-items: center;
                gap: 0.8rem;
                font-size: 0.9rem;
                color: #4b5563;
                text-decoration: none;
                transition: all 0.2s ease;
                position: relative;
            }

            .dropdown-content a:hover {
                background: #f8fafc;
                padding-left: 1.5rem;
            }

            /* Icon trong dropdown item */
            .dropdown-content a i {
                width: 18px;
                text-align: center;
                font-size: 0.9rem;
                transition: transform 0.2s ease;
            }

            .dropdown-content a:hover i {
                transform: scale(1.1);
            }

            /* Màu sắc đặc biệt */
            .dropdown-content a.text-danger {
                color: #ef4444;
            }

            .dropdown-content a.text-danger:hover {
                background: #fef2f2;
            }

            /* Hiệu ứng khi active */
            .action-dropdown.active .dropdown-btn {
                background: #f1f5f9;
                transform: rotate(90deg);
                color: #3b82f6;
            }

            /* Hiệu ứng mũi tên */
            .dropdown-content::before {
                content: '';
                position: absolute;
                top: -8px;
                right: 16px;
                border-width: 0 8px 8px 8px;
                border-style: solid;
                border-color: transparent transparent white transparent;
            }

            /* Empty State */
            .empty-table {
                padding: 4rem 1rem;
                text-align: center;
            }

            .empty-state img {
                width: 200px;
                margin-bottom: 1.5rem;
            }

            .empty-state h3 {
                color: #2c3e50;
                margin-bottom: 0.5rem;
            }

            .empty-state p {
                color: #7f8c8d;
                margin-bottom: 1.5rem;
            }

            .btn-create {
                background: #3498db;
                color: white !important;
                padding: 0.7rem 1.5rem;
                border-radius: 8px;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                transition: background 0.2s ease;
            }

            .btn-create:hover {
                background: #2980b9;
            }

            /* Responsive */
            @media (max-width: 768px) {
                .table-responsive {
                    overflow-x: auto;
                    -webkit-overflow-scrolling: touch;
                }

                .product-table {
                    min-width: 800px;
                }

                .action-buttons {
                    flex-wrap: nowrap;
                }
            }


            /* Hướng dẫn sử dụng */

            /* CSS cho nút Hướng dẫn sử dụng */
            .helpguide__btn {
                padding: 10px 16px;
                background: linear-gradient(135deg, #4a69bd, #1e3799);
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: 600;
                font-size: 14px;
                box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);
                transition: all 0.3s ease;
                cursor: pointer;
            }



            .helpguide__btn i {
                font-size: 18px;
            }

            /* CSS cho nội dung hướng dẫn trong SweetAlert */
            .helpguide__content {
                font-family: 'Roboto', sans-serif;
                text-align: left;
            }

            .helpguide__step {
                margin-bottom: 20px;
                padding: 15px;
                border-radius: 8px;
                background-color: #f8f9fa;
                border-left: 4px solid #4a69bd;
            }

            .swal2-html-container {
                height: 600px;
                overflow-y: scroll;
            }

            .helpguide__step-title {
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 16px;
                font-weight: 600;
                color: #2c3e50;
                margin-bottom: 8px;
            }

            .helpguide__step-title i {
                color: #4a69bd;
                font-size: 20px;
            }

            .helpguide__step-desc {
                font-size: 14px;
                color: #555;
                line-height: 1.5;
            }

            .helpguide__key-action {
                display: inline-block;
                padding: 2px 6px;
                background-color: #eaeaea;
                border-radius: 4px;
                font-weight: 500;
                font-family: 'Courier New', monospace;
                margin: 0 2px;
            }

            .helpguide__title {
                font-size: 22px;
            }
        </style>

        <div class="container-fluid">
            <div class="row align-items-center justify-content-between listPurchaseOrder mt-3 ml-2" style="width: 100%;">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('productManagement.index') }}">Danh Sách</a></li>
                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a class="addNew" href="{{ route('productManagement.add') }}">Tạo Mới <i
                                class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang
                            <i class="fas fa-sync-alt"></i></a>
                        <button id="helpguide-btn" class="helpguide__btn"><i class="fas fa-question-circle"></i> Hướng dẫn
                            sử dụng</button>
                    </div>
                </div>
            </div>
            <!-- Row hiện tại chứa các nút -->
            <div class="row align-items-center justify-content-between mt-4 mb-4">
                <div class="col-md-12">
                    <div class="product-management-buttons">
                        <div class="card">
                            <div class="card-header bg-gradient-primary">
                                <h5 class="card-title text-white mb-0">Quản Lý Danh Mục Sản Phẩm</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex flex-wrap justify-content-between">
                                    <!-- Nút Danh Mục Sản Phẩm -->
                                    <div class="product-card-button">
                                        <a href="{{ route('category.list') }}" class="btn-product-management">
                                            <div class="icon-wrapper">
                                                <i class="fas fa-cubes"></i>
                                            </div>
                                            <div class="button-content">
                                                <h5>Danh Mục Sản Phẩm</h5>
                                                <p>Quản lý các danh mục sản phẩm chính</p>

                                            </div>
                                        </a>
                                    </div>

                                    <!-- Nút Biến Thể Sản Phẩm -->
                                    <div class="product-card-button">
                                        <a href="{{ route('product-variants.index') }}" class="btn-product-management">
                                            <div class="icon-wrapper variant-icon">
                                                <i class="fas fa-sitemap"></i>
                                            </div>
                                            <div class="button-content">
                                                <h5>Mẫu Phân Loại</h5>
                                                <p>Quản lý các mẫu ( phân loại)</p>

                                            </div>
                                        </a>
                                    </div>

                                    <!-- Nút Phiên Bản Model -->
                                    <div class="product-card-button">
                                        <a href="{{ route('model-versions.index') }}" class="btn-product-management">
                                            <div class="icon-wrapper model-icon">
                                                <i class="fas fa-code-branch"></i>
                                            </div>
                                            <div class="button-content">
                                                <h5>Phiên Bản Model</h5>
                                                <p>Quản lý các phiên bản</p>

                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Dashboard Metrics -->
            <div class="dashboard-metrics">
                <div class="metric-card">
                    <div class="metric-icon active-icon">
                        <i class="fas fa-box"></i>
                    </div>
                    <div class="metric-content">
                        <h3>{{ $data['count_active'] }}</h3>
                        <p>Sản Phẩm Đang Hoạt Động</p>
                    </div>

                </div>
                <div class="metric-card">
                    <div class="metric-icon inactive-icon">
                        <i class="fas fa-box-open"></i>
                    </div>
                    <div class="metric-content">
                        <h3>{{ $data['count_noactive'] }}</h3>
                        <p>Sản Phẩm Đã Ngừng</p>
                    </div>

                </div>

                <div class="metric-card">
                    <div class="metric-icon supplier-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="metric-content">
                        <h3>{{ $data['count_supplier'] }}</h3>
                        <p>Nhà Cung Cấp</p>
                    </div>

                </div>
            </div>


            <div class="row justify-content-center">
                <h1 class="mt-2">Danh Sách Sản Phẩm </h1>
                <div class="table-responsive">
                    <table class="table-custom product-table" id="table2">
                        <thead>
                            <tr>

                                <th class="sortable">
                                    No
                                    <i class="fas fa-sort"></i>
                                </th>
                                <th class="sortable">
                                    Mã NCC
                                    <i class="fas fa-sort"></i>
                                </th>
                                <th class="sortable">
                                    Sản Phẩm
                                    <i class="fas fa-sort"></i>
                                </th>
                                <th class="sortable">
                                    Mẫu Phân Loại
                                    <i class="fas fa-sort"></i>
                                </th>
                                <th>Phiên Bản</th>
                                <th>Màu Sắc</th>
                                <th>Kích Thước</th>
                                <th>Key Sale</th>
                                <th>SKU</th>

                                <th class="sortable">
                                    Trạng Thái
                                    <i class="fas fa-sort"></i>
                                </th>
                                <th class="actions-column">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $temp = 0;
                            @endphp
                            @forelse ($data['allProducts'] as $item)
                                @php
                                    $temp++;
                                @endphp
                                <tr data-id="{{ $item->id }}">

                                    <td>{{ $temp }}</td>
                                    <td>
                                        <span class="supplier-code">{{ $item->supplier_id ?? '' }}</span>
                                    </td>
                                    <td>
                                        <div class="product-cell">
                                            <div class="product-image">
                                                <img src="{{ asset('uploads/forecast_products/' . $item->image ?? '') ?? asset('erp/') }}"
                                                    alt="{{ $item->product_name }}">
                                            </div>
                                            <div class="product-info">
                                                <h4>{{ $item->product_name ?? '' }}</h4>

                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="category-badge">{{ $item->product_variant ?? '' }}</span>
                                    </td>
                                    <td>{{ $item->model_version ?? '' }}</td>
                                    <td>
                                        @if ($item->color)
                                            <div class="color-display">
                                                <span class="color-dot"
                                                    style="background-color: {{ $item->color_hex ?? '#cccccc' }}"></span>
                                                <span>{{ $item->color }}</span>
                                            </div>
                                        @endif
                                    </td>
                                    <td>{{ $item->size ?? '' }}</td>
                                    <td>{{ $item->sale_key ?? '' }}</td>
                                    <td>
                                        <span class="sku-code">{{ $item->sku ?? '' }}</span>
                                    </td>

                                    <td>
                                        @if ($item->status == 1)
                                            <span class="status-badge active">Đang hoạt động</span>
                                        @else
                                            <span class="status-badge inactive">Đã ngừng</span>
                                        @endif
                                    </td>
                                    <td class="actions-cell">
                                        <div class="action-buttons">
                                            <div class="action-dropdown">
                                                <button class="action-btn dropdown-btn">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <!-- Thêm wrapper div để tạo vùng đệm -->
                                                <div class="dropdown-wrapper">
                                                    <div class="dropdown-content">
                                                        <a
                                                            href="{{ route('productManagement.edit', ['id' => $item->id]) }}"><i
                                                                class="fas fa-edit"></i> Chỉnh sửa</a>

                                                        <a href="#"
                                                            onclick="confirmDelete('{{ route('productManagement.delete', ['id' => $item->id]) }}'); return false;"
                                                            class="text-danger">
                                                            <i class="fas fa-trash"></i> Xóa
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="13" class="empty-table">
                                        <div class="empty-state">
                                            <img src="{{ asset('images/empty-products.svg') }}" alt="Không có dữ liệu">
                                            <h3>Không tìm thấy sản phẩm</h3>
                                            <p>Chưa có sản phẩm nào trong hệ thống hoặc không có sản phẩm phù hợp với bộ
                                                lọc.</p>
                                            <a href="{{ route('productManagement.add') }}" class="btn-action btn-create">
                                                <i class="fas fa-plus-circle"></i> Thêm sản phẩm mới
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    @endsection


    @section('js')
        <script>
            // Hàm hiển thị hướng dẫn sử dụng
            $(document).ready(function() {
                // Xử lý sự kiện click cho nút hướng dẫn
                $(document).on('click', '#helpguide-btn', function() {
                    Swal.fire({
                        title: '<div class="helpguide__title">Hướng dẫn sử dụng hệ thống quản lý sản phẩm</div>',
                        html: `
            <div class="helpguide__content">
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-home"></i> Tổng quan Dashboard
                    </div>
                    <div class="helpguide__step-desc">
                        Dashboard hiển thị tổng quan về sản phẩm với các số liệu thống kê: số sản phẩm đang hoạt động, 
                        sản phẩm đã ngừng và số nhà cung cấp. Từ đây bạn có thể truy cập các phần quản lý khác.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-list"></i> Danh sách sản phẩm
                    </div>
                    <div class="helpguide__step-desc">
                        Bảng hiển thị danh sách sản phẩm với các thông tin chính: mã NCC, tên sản phẩm, mẫu phân loại, 
                        phiên bản, màu sắc, kích thước, key sale, SKU và trạng thái. Bạn có thể sắp xếp dữ liệu bằng 
                        cách nhấp vào các tiêu đề cột có biểu tượng <i class="fas fa-sort"></i>.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-plus-circle"></i> Thêm sản phẩm mới
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn nút <span class="helpguide__key-action">Tạo Mới <i class="fas fa-plus"></i></span> ở góc trên phải 
                        để thêm sản phẩm mới vào hệ thống. Điền đầy đủ thông tin trong form và lưu lại.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-edit"></i> Chỉnh sửa sản phẩm
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <i class="fas fa-ellipsis-v"></i> ở cột "Thao tác" của sản phẩm cần chỉnh sửa, 
                        sau đó chọn <span class="helpguide__key-action"><i class="fas fa-edit"></i> Chỉnh sửa</span> 
                        từ menu dropdown.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-trash"></i> Xóa sản phẩm
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <i class="fas fa-ellipsis-v"></i> ở cột "Thao tác" của sản phẩm cần xóa, 
                        sau đó chọn <span class="helpguide__key-action"><i class="fas fa-trash"></i> Xóa</span>. 
                        Hệ thống sẽ yêu cầu xác nhận trước khi xóa.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-cubes"></i> Quản lý danh mục sản phẩm
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <span class="helpguide__key-action">Danh Mục Sản Phẩm</span> để quản lý các danh mục sản phẩm chính 
                        trong hệ thống.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-sitemap"></i> Quản lý mẫu phân loại
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <span class="helpguide__key-action">Mẫu Phân Loại</span> để quản lý các phân loại sản phẩm.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-code-branch"></i> Quản lý phiên bản model
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <span class="helpguide__key-action">Phiên Bản Model</span> để quản lý các phiên bản của 
                        sản phẩm.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-sync-alt"></i> Làm mới dữ liệu
                    </div>
                    <div class="helpguide__step-desc">
                        Nhấn vào nút <span class="helpguide__key-action">Tải lại trang <i class="fas fa-sync-alt"></i></span> 
                        để cập nhật dữ liệu mới nhất từ hệ thống.
                    </div>
                </div>
                
                <div class="helpguide__step">
                    <div class="helpguide__step-title">
                        <i class="fas fa-search"></i> Tìm kiếm sản phẩm
                    </div>
                    <div class="helpguide__step-desc">
                        Sử dụng ô tìm kiếm để lọc danh sách sản phẩm theo từ khóa. Hệ thống sẽ hiển thị các sản phẩm 
                        phù hợp với từ khóa tìm kiếm.
                    </div>
                </div>
            </div>
        `,
                        width: '700px',
                        confirmButtonText: 'Đã hiểu',
                        confirmButtonColor: '#4a69bd',
                        showClass: {
                            popup: 'animate__animated animate__fadeIn animate__faster'
                        },
                        hideClass: {
                            popup: 'animate__animated animate__fadeOut animate__faster'
                        },
                        customClass: {
                            title: 'helpguide__swal-title',
                            content: 'helpguide__swal-content',
                            confirmButton: 'helpguide__swal-confirm'
                        }
                    });
                });
            });


            function confirmDelete(deleteUrl) {
                Swal.fire({
                    title: 'Bạn có chắc chắn muốn xóa?',
                    text: "Dữ liệu sẽ không thể khôi phục sau khi xóa!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Xóa',
                    cancelButtonText: 'Hủy'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = deleteUrl;
                    }
                });
            }

            // JavaScript
            document.addEventListener('DOMContentLoaded', function() {
                const dropdowns = document.querySelectorAll('.action-dropdown');

                // Xử lý tất cả các dropdown
                dropdowns.forEach(dropdown => {
                    const button = dropdown.querySelector('.dropdown-btn');
                    const content = dropdown.querySelector('.dropdown-content');
                    let timeoutId;

                    // Xử lý sự kiện hover
                    dropdown.addEventListener('mouseenter', function() {
                        clearTimeout(timeoutId);

                        // Đóng tất cả các dropdown khác
                        dropdowns.forEach(otherDropdown => {
                            if (otherDropdown !== dropdown) {
                                otherDropdown.classList.remove('active');
                                otherDropdown.querySelector('.dropdown-content').classList
                                    .remove('active');
                            }
                        });

                        // Mở dropdown hiện tại
                        dropdown.classList.add('active');
                        content.classList.add('active');
                    });

                    dropdown.addEventListener('mouseleave', function() {
                        timeoutId = setTimeout(function() {
                            dropdown.classList.remove('active');
                            content.classList.remove('active');
                        }, 150);
                    });

                    // Xử lý sự kiện click
                    button.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();

                        // Toggle dropdown hiện tại
                        const isActive = dropdown.classList.contains('active');

                        // Đóng tất cả các dropdown
                        dropdowns.forEach(dropdown => {
                            dropdown.classList.remove('active');
                            dropdown.querySelector('.dropdown-content').classList.remove(
                                'active');
                        });

                        // Nếu dropdown chưa active, thì mở nó
                        if (!isActive) {
                            dropdown.classList.add('active');
                            content.classList.add('active');
                        }
                    });

                    // Ngăn dropdown đóng khi click vào nội dung
                    content.addEventListener('click', function(e) {
                        e.stopPropagation();
                    });
                });

                // Đóng tất cả dropdown khi click ra ngoài
                document.addEventListener('click', function() {
                    dropdowns.forEach(dropdown => {
                        dropdown.classList.remove('active');
                        dropdown.querySelector('.dropdown-content').classList.remove('active');
                    });
                });
            });
        </script>
    @endsection
