@extends('layouts.layout_purchaser')

<style>
    /* ERP Container - Global Styles */
    .erp-container {
        font-family: 'Inter', sans-serif;
        background-color: #f4f6f9;
        color: #333;
        padding: 20px;
    }

    /* Content Header */
    .erp-container .content-header {
        background: #ffffff;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .erp-container .content-header h1 {
        font-size: 1.75rem;
        font-weight: 600;
        color: #2c3e50;
    }

    .erp-container .breadcrumb {
        background: transparent;
        padding: 0;
        font-size: 0.9rem;
    }

    .erp-container .breadcrumb-item a {
        color: #007bff;
        text-decoration: none;
    }

    .erp-container .breadcrumb-item.active {
        color: #6c757d;
    }

    /* Card Styling */
    .erp-container .card {
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    .erp-container .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 1.2rem;
        font-weight: 500;
        color: #34495e;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    /* Table Styling */
    .erp-container table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;

    }

    .erp-container th,
    .erp-container td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;

    }

    .erp-container th {
        background-color: #f8f9fa;
        font-weight: 600;

    }



    /* Buttons */
    .erp-container .btn {
        border-radius: 6px;
        padding: 6px 12px;
        font-size: 0.9rem;
        transition: all 0.3s ease;
        text-decoration: none;

    }

    .erp-container .btn-primary {
        background: #007bff;
        border: none;
        color: #fff;

    }

    .erp-container .btn-primary:hover {
        background: #0056b3;

    }

    .erp-container .btn-danger {
        background: #dc3545;
        border: none;
        color: #fff;

    }

    .erp-container .btn-danger:hover {
        background: #c82333;

    }

    .erp-container .btn-default {
        background: #f8f9fa;
        border: 1px solid #ddd;
        color: #333;

    }

    .erp-container .btn-default:hover {
        background: #e9ecef;

    }

    /* Alerts */
    .erp-container .alert-danger {
        background: #f8d7da;
        color: #721c24;
        order: 1px solid #f5c6cb;
        border-radius: 6px;
        padding: 10px;
    }

    /* Animations */
    .fadeIn {
        animation: fadeIn 0.3s ease-in-out;

    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }

    }

    .create-new-model {
        height: 45px;
        display: flex !important;
        align-items: center;
        gap: 10px;
    }
</style>

@section('content')
    <div class="erp-container">
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000,
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="main-content">
            <div class="content-wrapper">
                <!-- Content Header -->
                <section class="content-header fadeIn">
                    <div class="row">
                        <div class="col-md-6">
                            <h1>Model Versions List</h1>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}"><i class="fas fa-home"></i>
                                        Dashboard</a></li>
                                <li class="breadcrumb-item active">Model Versions</li>
                            </ol>
                        </div>
                        <div class="col-md-6" style="display: flex; justify-content: flex-end;">
                            <a href="{{ route('model-versions.create') }}" class="btn btn-primary create-new-model">
                                <i class="fas fa-plus"></i> Create New Version
                            </a>
                        </div>
                    </div>
                </section>

                <!-- Main Content: List Table -->
                <section class="content fadeIn" style="animation-delay: 0.1s;">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Model Versions</h3>
                        </div>
                        <div class="card-body">
                            @if ($modelVersions->isEmpty())
                                <p>No Model Versions found.</p>
                            @else
                                <table class="" id="table1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Mẫu Phân Loại</th>
                                            <th>Model ( Phiên Bản)</th>
                                            <th>Mô Tả</th>
                                            <th>Trạng Thái</th>
                                            <th>Hành Động</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $temp = 0;
                                        @endphp
                                        @foreach ($modelVersions as $version)
                                            @php
                                                $temp++;
                                            @endphp
                                            <tr>
                                                <td>{{ $temp }}</td>
                                                <td>{{ $version->productVariant->title ?? 'N/A' }}</td>
                                                <td>{{ $version->title }}</td>
                                                <td>{{ $version->description }}</td>
                                                <td class="text-center">
                                                    @if ($version->status == 1)
                                                        <span class="badge badge-success">Active</span>
                                                    @else
                                                        <span class="badge badge-danger">Inactive</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{ route('model-versions.edit', ['id' => $version->id]) }}"
                                                        class="btn btn-primary">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </a>

                                                    <a onclick="return confirm('Are you sure you want to delete this version?');"
                                                        href="{{ route('model-versions.delete', ['id' => $version->id]) }}"
                                                        class="btn btn-danger">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <!-- Phân trang -->
                            @endif
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
@endsection
