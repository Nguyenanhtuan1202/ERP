@extends('layouts.admin')

@section('content')
    <div id="content" class="container-fluid">
        <div class="row">

            <div class="col-12">
                <div class="card">

                    <div class="card-header font-weight-bold">
                        Danh sách Tag
                        <a href="{{ url('admin/tag/add') }}"><button style="position: absolute; right:100px; top:4px"
                                class="btn btn-success">Thêm mới <i style="font-size: 18px"
                                    class="fas fa-plus-circle"></i></button></a>
                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

                    </div>
                    <div class="card-body">
                        <table class="table table-striped" id="table1">
                            <thead>
                                <tr>
                                    <th scope="col">STT</th>
                                    <th scope="col">Tên tag</th>
                                    <th scope="col">Link</th>
                                    <th scope="col">Trạng thái</th>
                                    <th scope="col">Quản lý</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $temp = 0;
                                @endphp
                                @foreach ($tag as $item)
                                    @php
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <th>{{ $temp }}</th>
                                        <td>{{ $item->title }}</td>
                                        @if ($item->status == 1)
                                            <td><a href="{{ url('/admin/tag/list?id=' . $item->id . '&status=2') }}">
                                                    <i style="color:#05a603" class="fas fa-check"></i></a></td>
                                        @else
                                            <td><a href="{{ url('/admin/tag/list?id=' . $item->id . '&status=1') }}">
                                                    <i style="color:red" class="fas fa-times-circle"></i></a></td>
                                        @endif
                                        <td>{{ $item->slug }}</td>
                                        <td>
                                            <a href="{{ url('admin/tag/edit/' . $item->id) }}"><button class="btn btn-info">
                                                    <i class="far fa-edit"></i> Sửa </button></a>
                                            <a href="{{ url('admin/tag/delete/' . $item->id) }}"
                                                onclick="return confirm('Bạn có muốn xóa tag này không')"><button
                                                    class="btn btn-danger"> <i class="fas fa-trash"></i> Xóa
                                                </button></a>
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
