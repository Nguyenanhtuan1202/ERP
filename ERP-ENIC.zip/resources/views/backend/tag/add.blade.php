@extends('layouts.admin')

@section('content')
    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Thêm Hashtag xu hướng
                        @if (session('status'))
                            <div class="alert alert-success">
                                {{ session('status') }}
                            </div>
                        @endif
                    </div>
                    <div class="card-body">

                        <form  action="{{ url('admin/tag/save') }}" enctype="multipart/form-data" method="POST">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">

                                        @error('title')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="cat_name">Tên Hashtag</label>
                                        <input value="{{old('title')}}" class="form-control" type="text" name="title" id="cat_name"
                                            placeholder="Nhập vào tên Hashtag">
                                    </div>


                                    <div class="form-group block__image">
                                        @error('image')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="cat_image">Hình Ảnh(*)</label>
                                        <input class="form-control-file" style="width:100%" type="file" id="cat_image"
                                            name="image" accept="image/*" onchange="loadFile(event)">
                                        <img style="margin-top: 10px; border-radius:10px; max-width:180px"
                                            src="{{ asset('uploads/add.png') }}" id="output" />
                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src)
                                                }
                                            };
                                        </script>
                                    </div>

                                 

                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        @error('status')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="status">Trạng thái hiển thị (*)</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios1" value="1" checked>
                                            <label class="form-check-label" for="exampleRadios1">
                                                Hiện
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios2" value="2">
                                            <label class="form-check-label" for="exampleRadios2">
                                                Ẩn
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                     
                                        <label for="weight">Thứ tự ưu tiên</label>
                                        <input class="form-control" type="number" min="0" name="weight"
                                            id="weight" value="{{ old('weight') }}">
                                    </div>


                                    <div class="form-group group__banner">
                                        <label for="num_list">Số tin trong danh sách</label>
                                        <select name="num_list" class="form-control select3_init"id="num_list">
                                            @for ($i = 1; $i <= 20; $i++)
                                                <option value="{{ $i }}">{{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>


                                    <div class="form-group group__banner">
                                        <label for="num_list_orther">Số tin khác</label>
                                        <select name="num_list_orther" class="form-control select3_init" id="num_list_orther">
                                            @for ($j = 1; $j <= 20; $j++)
                                                <option value="{{ $j }}">{{ $j }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ckeditor">Nội Dung</label>
                                        <textarea name="content" class="form-control ckeditor" id="ckeditor" cols="30" rows="3">{!!old('content')!!}</textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">

                                    <div class="form-group" id="show__seo">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h3 class="optimal_title">Tối ưu hóa SEO </h3>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="search-engine-preview">
                                                    <div class="title">Xem kết quả tìm kiếm</div>
                                                    <div class="google-preview">
                                                        <div class="google-title"></div>
                                                        <div class="google-url">
                                                            {{ url('/') . '/hash-tag/' }}<span
                                                                class="google-url-link"></span>
                                                        </div>
                                                        <div class="google-description"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 div_friendly_link  show">
                                                <div class="form-group">

                                                    <label for="cat_url">Đường dẫn link thân thiện</label>
                                                    @error('url')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input class="form-control" type="text" name="url"
                                                        id="cat_url" value="{{ old('url') }}">
                                                    <p class="des_i">Ví dụ: gioi-thieu-ve-chung-toi</p>
                                                </div>

                                            </div>


                                            <div class="col-md-6 div_meta_title  show">
                                                <div class="form-group">
                                                    <label class="meta_seo">Tiêu đề của trang
                                                    </label>
                                                    @error('meta_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="meta_seo" type="text" size="50" maxlength="150"
                                                        value="{{ old('meta_seo') }}" class="form-control "
                                                        placeholder="" id="meta_seo">
                                                    <p class="des_i">Ví dụ: giới thiêu | gioi thieu</p>
                                                </div>
                                            </div>


                                            <div class="col-md-6 div_meta_key  show">
                                                <div class="form-group">
                                                    <label class="key_seo">Từ khóa trên công cụ tìm kiếm
                                                    </label>
                                                    @error('key_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="key_seo" type="text" size="50" maxlength="150"
                                                        value="{{ old('key_seo') }}" class="form-control "
                                                        placeholder="" id="key_seo">
                                                    <p class="des_i">Ví dụ: giới thiêu, công ty</p>
                                                </div>
                                            </div>
                                            <div class="col-md-6 div_meta_desc  show">
                                                <div class="form-group">
                                                    <label class="desc_seo">Mô tả trên công cụ tìm kiếm
                                                    </label>
                                                    @error('desc_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="desc_seo" type="text" value="{{ old('desc_seo') }}"
                                                        class="form-control " placeholder="" id="desc_seo">
                                                    <p class="des_i">Không nên nhập quá 200 chữ và cần có từ khóa cần
                                                        seo
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">Thêm mới <i style="font-size: 18px"
                                            class="fas fa-plus-circle"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
@endsection
