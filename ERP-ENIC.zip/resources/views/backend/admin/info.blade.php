@extends('layouts.enic')
@section('content')
    <div id="content" class="container-fluid" style="margin-top: 100px">
        <div class="card">
            <div style="text-align:center" class="card-header font-weight-bold">
                Thông tin tài khoản
            </div>

            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif



            <style>
                @media (max-width: 768px) {
                    .row {
                        flex-direction: column;
                        gap: 0;
                    }

                    .col-md-6 {
                        min-width: 100%;
                    }

                    .card-body {
                        max-width: 90%;
                        padding: 15px;
                    }

                    .btn-primary {
                        font-size: 15px;
                        padding: 10px 25px;
                    }
                }
            </style>


            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5 style="text-transform: uppercase; font-size:17px; font-weight:bold; text-align:center">Thông
                            Tin Cá Nhân</h5>
                        <form>
                            <div class="form-group">
                                <label for="name">Họ và tên</label>
                                <input class="form-control" disabled type="text" name="name" id="name"
                                    value="{{ Auth::user()->name }}">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input class="form-control" type="text" disabled name="email" id="email"
                                    value="{{ Auth::user()->email }}">
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6">

                        <h5 style="text-transform: uppercase; font-size:17px; font-weight:bold; text-align:center"> Cập
                            nhật Thông Tin</h5>
                        <form action="{{ url('update-admin-info/' . Auth::user()->id) }}" method="POST">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <label for="name">Họ và tên</label>
                                <input class="form-control" type="text" name="name" id="name"
                                    value="{{ Auth::user()->name }}">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input class="form-control" type="text" disabled name="email" id="email"
                                    value="{{ Auth::user()->email }}">
                            </div>
                            <div class="form-group">
                                <label for="email"> Đổi Mật khẩu</label>
                                <input class="form-control" type="password" name="password" id="email">
                            </div>
                            <button
                                style="background-color: #259c9f; border: none; padding: 10px 30px; font-weight: 600; font-size: 17px;"
                                type="submit" class="btn btn-primary ">Cập Nhật <i class="far fa-save ml-2"></i></button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection
