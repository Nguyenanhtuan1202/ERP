@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Danh Mục</h2>
                        <nav aria-label="breadcrumb" class="mt-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}">DashBoard</a></li>
                                <li class="breadcrumb-item"><a href="{{ url('/admin/menu/list') }}">Menu</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Cập Nhật</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- row -->
            <form action="{{ url('/admin/menu/update/' . $data->id) }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row column1">
                    <div class="col-md-12">
                        <div class="white_shd full margin_bottom_30">
                            <div class="full graph_head">
                                <div class="heading1 margin_0">
                                    <h2>Cập Nhật Menu <small></small></h2>
                                    @if (session('status'))
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            {{ session('status') }}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="full price_table padding_infor_info">
                                <div class="row">
                                    <div class="col-md-6 sider__bar-left">
                                        <div class="form-group">
                                            @error('name')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="cat_name">Tên Menu(*)</label>
                                            <input class="form-control" type="text" name="name" id="cat_name"
                                                value="{{ $data->name }}">
                                        </div>


                                        <div class="form-group">
                                            @error('status')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="status">Trạng thái hiển thị (*)</label>

                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="status"
                                                    id="exampleRadios1" value="1" <?php if ($data->status == 1) {
                                                        echo 'checked';
                                                    } ?>>
                                                <label class="form-check-label" for="exampleRadios1">
                                                    Hiện
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="status"
                                                    id="exampleRadios2" value="2" <?php if ($data->status == 2) {
                                                        echo 'checked';
                                                    } ?>>
                                                <label class="form-check-label" for="exampleRadios2">
                                                    Ẩn
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            @error('weight')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="weight">Thứ tự ưu tiên(*)</label>
                                            <input class="form-control" type="number" min="0" name="weight"
                                                id="weight" value="{{ $data->weight }}">
                                        </div>
                                    </div>

                                    <div class="col-md-6 sider__bar-right">

                                        <div class="form-group">
                                            @error('parent_id')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="parent_id">Danh mục cha (*)</label>
                                            <select name="parent_id" class="form-control" id="parent_id">
                                                <option value="0">Danh mục cha</option>
                                                {!! $optionSelect !!}

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            @error('image')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="cat_image">Hình Ảnh(*)</label>
                                            <input class="form-control-file" style="width:100%" type="file"
                                                id="cat_image" name="image" accept="image/*" onchange="loadFile(event)">
                                            <img style="margin-top: 10px; border-radius:10px; max-width:40%"
                                                src="{{ asset('uploads/menu/' . $data->image) }}" id="output" />
                                            <script>
                                                var loadFile = function(event) {
                                                    var output = document.getElementById('output');
                                                    output.src = URL.createObjectURL(event.target.files[0]);
                                                    output.onload = function() {
                                                        URL.revokeObjectURL(output.src)
                                                    }
                                                };
                                            </script>

                                        </div>
                                    </div>
                                    <div class="col-md-12">

                                        <div class="form-group" id="show__seo">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3 class="optimal_title">Tối ưu hóa SEO </h3>
                                                </div>

                                                <div class="col-md-12">
                                                    <div class="search-engine-preview">
                                                        <div class="title">Xem kết quả tìm kiếm</div>
                                                        <div class="google-preview">
                                                            <span class="google-title">{!! html_entity_decode($data->meta_seo ?? '') !!}</span>
                                                            <div class="google-url">
                                                                {{ url('/') . '/' }}<span
                                                                    class="google-url-link">{!! html_entity_decode($data->url) !!}</span>
                                                            </div>
                                                            <div class="google-description">{!! html_entity_decode($data->desc_seo ?? '') !!}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 div_friendly_link  show">
                                                    <div class="form-group">

                                                        <label for="cat_url">Đường dẫn link thân thiện</label>
                                                        @error('url')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input class="form-control" type="text" name="url"
                                                            id="cat_url" value="{{ $data->url }}">
                                                        <p class="des_i">Ví dụ: gioi-thieu-ve-chung-toi</p>
                                                    </div>

                                                </div>


                                                <div class="col-md-6 div_meta_title  show">
                                                    <div class="form-group">

                                                        <label class="meta_seo">Tiêu đề của trang
                                                        </label>

                                                        @error('meta_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="meta_seo" type="text" size="50"
                                                            maxlength="150" value="{{ $data->meta_seo }}"
                                                            class="form-control " placeholder="" id="meta_seo">
                                                        <p class="des_i">Ví dụ: giới thiêu | gioi thieu</p>
                                                    </div>
                                                </div>


                                                <div class="col-md-6 div_meta_key  show">
                                                    <div class="form-group">
                                                        <label class="key_seo">Từ khóa trên công cụ tìm kiếm
                                                        </label>
                                                        @error('key_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="key_seo" type="text" size="50"
                                                            maxlength="150" value="{{ $data->key_seo }}"
                                                            class="form-control " placeholder="" id="key_seo">
                                                        <p class="des_i">Ví dụ: giới thiêu, công ty</p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 div_meta_desc  show">
                                                    <div class="form-group">


                                                        <label class="desc_seo">Mô tả trên công cụ tìm kiếm
                                                        </label>
                                                        @error('desc_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="desc_seo" type="text"
                                                            value="{{ $data->desc_seo }}" class="form-control "
                                                            placeholder="" id="desc_seo">
                                                        <p class="des_i">Không nên nhập quá 200 chữ và cần có từ khóa cần
                                                            seo
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>


                                </div>
                                <button type="submit" class="btn btn__add">Cập Nhật</button>
                            </div>

                        </div>

                    </div>
                    <!-- end row -->
                </div>
            </form>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
