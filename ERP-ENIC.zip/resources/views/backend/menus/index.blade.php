@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">

            <!-- row -->
            <div class="row column1">
                <div class="col-md-12">
                    <div class="white_shd full margin_bottom_30">
                        <div class="full graph_head">
                            <div class="heading1 heading__customer">
                                @if (session('status'))
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        {{ session('status') }}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                @endif

                                <button class="btn btn__add mt-3"><a class="color-white"
                                        href="{{ url('/admin/menu/create') }}">Thêm mới</a></button>
                            </div>

                        </div>
                        <div class="full price_table padding_infor_info">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive-sm">
                                        <table class="table table-striped projects" id="table1" class="display"
                                            style="width:100%">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th style="width: 2%">STT</th>
                                                    <th style="width: 5%">Ưu Tiên</th>
                                                    <th style="width: 10%">Hình Ảnh</th>
                                                    <th style="width: 20%">Tiêu Đề</th>
                                                    <th>Url</th>
                                                    <th>Trạng Thái</th>

                                                    <th>Quản Lý</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                @php
                                                    $temp = 0;
                                                @endphp

                                                @foreach ($data as $value)
                                                    @php
                                                        $temp++;
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            <p>{{ $temp }}</p>
                                                        </td>
                                                        <td>
                                                            <p>{{ $value->weight }}</p>
                                                        </td>
                                                        <td>
                                                            <a href="{{ url('/admin/menu/edit/' . $value->id) }}">
                                                                <img style="width: 80px; border-radius: 10px"
                                                                    src="{{ asset('uploads/menu/' . $value->image ?? '') }}"
                                                                    alt="">
                                                            </a>

                                                        </td>
                                                        <td>
                                                            <p> <a
                                                                    href="{{ url('/admin/menu/edit/' . $value->id) }}">{{ $value->name }}</a>
                                                            </p>
                                                        </td>

                                                        <td>
                                                            <p>{{ $value->url ?? '' }}</p>
                                                        </td>
                                                        @if ($value->status == 1)
                                                            <td><a
                                                                    href="{{ url('/admin/menu/list?id=' . $value->id . '&status=2') }}">
                                                                    <i style="color:#05a603" class="fas fa-check"></i></a>
                                                            </td>
                                                        @else
                                                            <td><a
                                                                    href="{{ url('/admin/menu/list?id=' . $value->id . '&status=1') }}">
                                                                    <i style="color:red"
                                                                        class="fas fa-times-circle"></i></a></td>
                                                        @endif
                                                        <td>
                                                            <a onclick="return confirm('Bạn có muốn xóa menu này không ?')"
                                                                href="{{ url('/admin/menu/delete/' . $value->id) }}"> <i
                                                                    style="color:rgb(237, 24, 24); font-size:25px"
                                                                    class="fas fa-backspace"></i></a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
