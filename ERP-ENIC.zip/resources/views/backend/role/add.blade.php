@extends('layouts.enic')
@section('content')
    <div id="content" class="container-fluid">
        <div class="card" style="margin-top: 100px">

            <div class="row align-items-center justify-content-between listPurchaseOrder" style="width: 100%;">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('role.list') }}">Danh Sách</a></li>
                        <li class="breadcrumb-item active">
                            Thêm Mới
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a class="addNew" href="{{ route('role.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang <i
                                class="fas fa-sync-alt"></i></a>
                        <a style="background: #199fb7; box-shadow: none" class="addNew" href="{{ route('role.list') }}">Danh
                            Sách <i class="fas fa-list"></i></a>
                    </div>
                </div>
            </div>


            <div class="card-header font-weight-bold">
                Thêm vai trò
            </div>

            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif


            <div class="card-body">
                <form action="{{ url('/admin/save/role') }}" method="POST">
                    {{ csrf_field() }}

                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12">

                                <div class="form-group">
                                    @error('name')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                    <label for="name">Tên Vai Trò</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        value="{{ old('name') }}">
                                </div>
                            </div>

                            <div class="col-md-12">

                                <div class="form-group">
                                    @error('display_name')
                                        <small class="text-danger">{{ $message }}</small>
                                    @enderror
                                    <label for="display_name">Mô Tả Vai Trò</label>
                                    <input class="form-control" type="text" name="display_name" id="display_name"
                                        value="{{ old('display_name') }}">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12">

                                @foreach ($permissionParent as $item)
                                    <div class="card-check card border-primary mb-3">
                                        <div class="card-header" style="background: #2980b9">
                                            <h6 style="color: white" class="text-center">
                                                <label>
                                                    <input class="checkbox_wrapper" type="checkbox" name=""
                                                        id="" value="">
                                                </label>
                                                Module {{ $item->display_name }}
                                            </h6>
                                        </div>
                                        <div class="row">
                                            @foreach ($item->permissionChild as $value)
                                                <div class="card-body text-primary col-md-3">
                                                    <p style="color: black" class="card-title">
                                                        <label>
                                                            <input class="checkbox_child" type="checkbox"
                                                                name="permission_id[]" id=""
                                                                value="{{ $value->id }}">
                                                        </label>
                                                        {{ $value->display_name }}
                                                    </p>
                                                </div>
                                            @endforeach

                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">Thêm mới <i style="font-size: 18px"
                                        class="fas fa-plus-circle"></i></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>
@endsection
