@extends('layouts.layout_purchaser')
@section('content')
    <div class="erp-dashboard">
        <div class="erp-dashboard__container">
            <section class="function-blocks">
                <h2 class="section-title">Chức năng hệ thống</h2>
                <div class="function-blocks__grid">
                    @php
                        $purchaser = Auth::user()->purchaser;
                    @endphp
                    @if ($purchaser == 1)
                        <article class="function-card" data-function="purchase">
                            <a href="{{ route('orders.import') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/du-doan.png') }}" alt="Mua Hàng">
                                </div>
                                <h3 class="function-card__title">Mua Hàng</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="orders">
                            <a href="{{ route('orders.getOrdersByUser') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/ton-kho.png') }}" alt="Quản Lý Đơn Hàng">
                                </div>
                                <h3 class="function-card__title">Quản Lý Đơn Hàng</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="calendar">
                            <a href="{{ route('order.calendar') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/lich-hen.png') }}" alt="Lịch">
                                </div>
                                <h3 class="function-card__title">Lịch</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="suppliers">
                            <a href="{{ route('supplierManagement.index') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/lien-he.png') }}" alt="Nhà Cung Cấp">
                                </div>
                                <h3 class="function-card__title">Nhà Cung Cấp</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="products">
                            <a href="{{ route('productManagement.index') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/products.png') }}" alt="Sản Phẩm">
                                </div>
                                <h3 class="function-card__title">Sản Phẩm</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="import">
                            <a href="{{ route('purchaseOrdersManagement.add') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/kien-thuc.png') }}" alt="Nhập Hàng">
                                </div>
                                <h3 class="function-card__title">Nhập Hàng</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="file-management">
                            <a href="{{ route('file-storage.index') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/folder.png') }}" alt="Quản Lý File">
                                </div>
                                <h3 class="function-card__title">Quản Lý File</h3>
                            </a>
                        </article>

                        <article class="function-card" data-function="lucky-wheel">
                            <a href="{{ route('lucky-wheel') }}" class="function-card__link">
                                <div class="function-card__icon">
                                    <img src="{{ asset('/erp/spin.png') }}" alt="Vòng Quay">
                                </div>
                                <h3 class="function-card__title">Vòng Quay</h3>
                            </a>
                        </article>
                    @endif
                </div>
            </section>

            <section class="dashboard-widgets">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <div class="widget digital-clock">
                            <div class="digital-clock__face">
                                <div class="digital-clock__days">
                                    <span class="day-label" data-day="mon">MON</span>
                                    <span class="day-label" data-day="tue">TUE</span>
                                    <span class="day-label" data-day="wed">WED</span>
                                    <span class="day-label" data-day="thu">THU</span>
                                    <span class="day-label" data-day="fri">FRI</span>
                                    <span class="day-label" data-day="sat">SAT</span>
                                    <span class="day-label" data-day="sun">SUN</span>
                                </div>
                                <div class="digital-clock__time">
                                    <span id="hours">00</span>
                                    <span class="separator">:</span>
                                    <span id="minutes">00</span>
                                    <span class="separator">:</span>
                                    <span id="seconds">00</span>
                                </div>
                                <div class="digital-clock__date">
                                    <span id="current-date"></span>
                                </div>
                            </div>
                            <div class="widget-footer">
                                <h3 class="widget-title">Digital Clock</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12">
                        <div class="widget summary-stats">
                            <div class="stats-header">
                                <h3 class="widget-title">Thống kê hoạt động</h3>
                            </div>
                            <div class="stats-body">
                                <div class="stats-item">
                                    <div class="stats-icon">
                                        <i class="fas fa-shopping-cart"></i>
                                    </div>
                                    <div class="stats-info">
                                        <h4 class="stats-label">Đơn hàng tháng này</h4>
                                        <span class="stats-value" id="monthly-orders">0</span>
                                    </div>
                                </div>
                                <div class="stats-item">
                                    <div class="stats-icon">
                                        <i class="fas fa-box"></i>
                                    </div>
                                    <div class="stats-info">
                                        <h4 class="stats-label">Sản phẩm cần nhập</h4>
                                        <span class="stats-value" id="products-to-import">0</span>
                                    </div>
                                </div>
                                <div class="stats-item">
                                    <div class="stats-icon">
                                        <i class="fas fa-calendar-check"></i>
                                    </div>
                                    <div class="stats-info">
                                        <h4 class="stats-label">Lịch hẹn hôm nay</h4>
                                        <span class="stats-value" id="today-appointments">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
@endsection

@section('css')
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #e74c3c;
            --text-dark: #333333;
            --text-light: #888888;
            --bg-light: #f8f9fa;
            --bg-white: #ffffff;
            --shadow-sm: 0 2px 5px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 10px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.1);
            --border-radius-sm: 4px;
            --border-radius-md: 8px;
            --border-radius-lg: 12px;
            --spacing-xs: 0.5rem;
            --spacing-sm: 1rem;
            --spacing-md: 1.5rem;
            --spacing-lg: 2rem;
            --transition-fast: 0.2s ease;
            --transition-normal: 0.3s ease;
        }

        /* Base Styles */
        .erp-dashboard {
            padding: var(--spacing-md) 0;
        }

        .erp-dashboard__container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 var(--spacing-md);
        }

        .section-title {
            font-size: 1.5rem;
            color: var(--text-dark);
            margin-bottom: var(--spacing-md);
            font-weight: 600;
        }

        /* Function Blocks */
        .function-blocks {
            margin-bottom: var(--spacing-lg);
        }

        .function-blocks__grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-lg);
        }

        .function-card {
            background-color: var(--bg-white);
            border-radius: var(--border-radius-md);
            box-shadow: var(--shadow-md);
            height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            transform: translateY(20px);
        }

     


        .function-card__link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            width: 100%;
            height: 100%;
            text-decoration: none;
            color: var(--text-dark);
            padding: var(--spacing-sm);
        }

        .function-card__icon {
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: var(--spacing-xs);
        }

        .function-card__icon img {
            max-width: 100%;
            max-height: 75px;
            transition: transform var(--transition-fast);
        }

        .function-card:hover .function-card__icon img {
            transform: scale(1.1);
        }

        .function-card__title {
            font-size: 0.9rem;
            font-weight: 500;
            margin: 0;
            padding: 0;
            color: var(--text-dark);
        }

        /* Dashboard Widgets */
        .dashboard-widgets {
            margin-top: var(--spacing-lg);
        }

        .widget {
            background-color: var(--bg-white);
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-md);
            padding: var(--spacing-md);
            height: 100%;
            margin-bottom: var(--spacing-md);
        }

        .widget-title {
            font-size: 1.2rem;
            font-weight: 500;
            color: var(--text-dark);
            margin: 0;
        }

        /* Digital Clock Widget */
        .digital-clock {
            text-align: center;
        }

        .digital-clock__face {
            background-color: var(--bg-light);
            padding: var(--spacing-md);
            border-radius: var(--border-radius-md);
            margin-bottom: var(--spacing-sm);
        }

        .digital-clock__days {
            display: flex;
            justify-content: space-between;
            margin-bottom: var(--spacing-sm);
        }

        .day-label {
            color: var(--text-light);
            font-size: 0.75rem;
            width: 30px;
            text-align: center;
            font-weight: bold;
            transition: color var(--transition-fast);
        }

        .day-label.active {
            color: var(--primary-color);
        }

        .digital-clock__time {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: var(--spacing-xs);
            letter-spacing: 2px;
        }

        .digital-clock__time .separator {
            animation: blink 1s infinite;
        }

        .digital-clock__date {
            font-size: 1rem;
            color: var(--text-light);
            margin-top: var(--spacing-xs);
        }

        @keyframes blink {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }
        }

        /* Stats Widget */
        .summary-stats {
            height: 100%;
        }

        .stats-header {
            margin-bottom: var(--spacing-md);
            border-bottom: 1px solid #eee;
            padding-bottom: var(--spacing-xs);
        }

        .stats-body {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: var(--spacing-sm);
        }

        .stats-item {
            display: flex;
            align-items: center;
            padding: var(--spacing-sm);
            border-radius: var(--border-radius-md);
            background-color: var(--bg-light);
            transition: transform var(--transition-fast);
        }

        .stats-item:hover {
            transform: translateY(-3px);
        }

        .stats-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(52, 152, 219, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: var(--spacing-sm);
            color: var(--primary-color);
        }

        .stats-info {
            flex-grow: 1;
        }

        .stats-label {
            font-size: 0.8rem;
            color: var(--text-light);
            margin: 0;
            font-weight: normal;
        }

        .stats-value {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        /* Responsive Adjustments */
        @media (max-width: 1200px) {
            .function-blocks__grid {
                grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
            }
        }

        @media (max-width: 992px) {
            .function-blocks__grid {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }

            .digital-clock__time {
                font-size: 2rem;
            }
        }

        @media (max-width: 768px) {
            .function-blocks__grid {
                grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            }

            .function-card {
                height: 140px;
            }

            .function-card__icon {
                height: 60px;
            }

            .function-card__title {
                font-size: 0.8rem;
            }

            .stats-body {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .function-blocks__grid {
                grid-template-columns: repeat(3, 1fr);
            }

            .digital-clock__days {
                display: none;
            }
        }

        /* Theme - Inactive State for Functions */
        .function-card.noactive {
            filter: grayscale(100%);
            opacity: 0.6;
        }

        /* Accessibility */
        .function-card:focus-within {
            outline: 2px solid var(--primary-color);
        }

        @media (prefers-reduced-motion: reduce) {

            .function-card,
            .function-card__icon img,
            .stats-item {
                transition: none;
            }
        }
    </style>
@endsection

@section('js')
    <script>
        // IIFE để tránh biến toàn cục
        (function() {
            'use strict';

            // Các hàm tiện ích
            const $ = selector => document.querySelector(selector);
            const $$ = selector => document.querySelectorAll(selector);

            // Hàm cập nhật đồng hồ số
            const updateClock = () => {
                const now = new Date();
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');

                // Cập nhật thời gian
                $('#hours').textContent = hours;
                $('#minutes').textContent = minutes;
                $('#seconds').textContent = seconds;

                // Cập nhật ngày trong tuần
                const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
                const currentDay = dayNames[now.getDay()];

                // Reset tất cả ngày về trạng thái không active
                $$('.day-label').forEach(day => day.classList.remove('active'));

                // Set ngày hiện tại là active
                $(`.day-label[data-day="${currentDay}"]`).classList.add('active');

                // Cập nhật ngày tháng
                const options = {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                };
                $('#current-date').textContent = now.toLocaleDateString('vi-VN', options);
            };

            // Khởi tạo trang khi DOM đã load
            document.addEventListener('DOMContentLoaded', () => {
                // Khởi tạo đồng hồ số và cập nhật mỗi giây
                updateClock();
                setInterval(updateClock, 1000);
                // Khởi tạo các sự kiện
                initEvents();
            });
        })();
    </script>
@endsection
