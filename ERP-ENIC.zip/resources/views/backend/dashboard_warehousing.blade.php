@extends('layouts.layout_warehousing')
@section('content')
    <style>
        .clock {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .clock-face {
            background-color: #f0f0f0;
            padding: 10px 20px;
            border-radius: 8px;
        }

        .day-display {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .day {
            color: #888;
            font-size: 12px;
            width: 30px;
            text-align: center;
            font-weight: bold;
        }

        .day.active {
            color: #333;
        }

        .time-display {
            font-size: 50px;
            font-weight: bold;
            letter-spacing: 3px;
            color: #333;
            margin-bottom: 10px;
        }

        .ampm-display {
            font-size: 18px;
            font-weight: bold;
            color: #888;
        }

        .label {
            margin-top: 10px;
            color: #888;
            font-size: 20px;
            font-style: italic;
        }


        .block__item-func {
            margin-left: 15px;
            margin-bottom: 15px;
            max-width: 150px;
            height: 140px;
            text-align: center;
            border-radius: 8px;
            padding: 10px;
            background-color: #fff;
            object-fit: cover;
            transform-origin: center bottom;
            transition: box-shadow ease-in 0.1s, transform ease-in 0.1s;
            box-shadow: var(--AppSwitcherIcon-inset-shadow, inset 0 0 0 1px rgba(0, 0, 0, 0.2)), 0 1px 1px rgba(0, 0, 0, 0.02), 0 2px 2px rgba(0, 0, 0, 0.02), 0 4px 4px rgba(0, 0, 0, 0.02), 0 8px 8px rgba(0, 0, 0, 0.02), 0 16px 16px rgba(0, 0, 0, 0.02);
        }

        .block__item-func img {
            max-width: 60%;
        }

        .block__item-func span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            color: #333;
            margin-top: 10px;
        }

        .noactive {
            filter: grayscale(100%);
        }
    </style>
    <div class="container-fluid py-5">
        <div class="row">




            @php
                $ware_housing = Auth::user()->ware_housing;
            @endphp


            @if ($ware_housing == 1)
                <div class="col-md-2 block__item-func">
                    <a href="{{ route('delivery.showdelivery') }}">
                        <img src="{{ asset('/erp/giao-hang.jpg') }}" alt="Giao Hàng">
                        <span>Hàng Về Kho</span>
                    </a>
                </div>
                <div class="col-md-2 block__item-func">
                    <a href="{{ route('delivery.orderReceived') }}">
                        <img src="{{ asset('/erp/box.png') }}" alt="Giao Hàng">
                        <span>Hàng Về Thực Tế</span>
                    </a>
                </div>

                <div class="col-md-2 block__item-func">
                    <a href="{{route('warehouse.index')}}">
                        <img src="{{ asset('/erp/ton-kho.png') }}" alt="discuss.png">
                        <span>Tồn Kho</span>
                    </a>
                </div>
            @endif

        </div>


        <div class="clock">
            <div class="clock-face">
                <div class="day-display">
                    <span class="day">MON</span>
                    <span class="day">TUE</span>
                    <span class="day active">WED</span>
                    <span class="day">THU</span>
                    <span class="day">FRI</span>
                    <span class="day">SAT</span>
                    <span class="day">SUN</span>
                </div>
                <div class="time-display">
                    <span id="time"></span>
                </div>
                <div class="ampm-display">
                    <span id="ampm">PM</span>
                </div>
            </div>
            <div class="label">Digital Clock</div>
        </div>



        <style>
            .chart-container {
                background: #ffffff;
                border-radius: 10px;
                box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
                padding: 20px;
                max-width: 400px;
                width: 100%;
                margin: 20px;
            }

            #genderChart {
                max-width: 100%;
            }

            #expertLevelsChart {
                max-width: 100%;
            }
        </style>


    </div>
@endsection


@section('js')
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const cards = document.querySelectorAll('.custom-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 150);
            });
        });


        function updateClock() {
            const now = new Date();
            const hours = now.getHours(); // Không cần chuyển đổi 12 giờ nữa
            const minutes = now.getMinutes();
            const seconds = now.getSeconds();

            const dayNames = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
            const currentDay = dayNames[now.getDay()];

            document.getElementById('time').textContent =
                `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

            document.querySelectorAll('.day').forEach(day => {
                if (day.textContent === currentDay) {
                    day.classList.add('active');
                } else {
                    day.classList.remove('active');
                }
            });
        }

        setInterval(updateClock, 1000);
        updateClock();
    </script>
@endsection
