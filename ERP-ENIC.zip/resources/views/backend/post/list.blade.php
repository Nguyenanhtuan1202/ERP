@extends('layouts.admin')

@section('content')

    <div id="content" class="container-fluid">
        <div class="row">

            <div class="col-12">
                <div class="card">

                    <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                        Danh sách bài viết

                        @if ($status_post == 'trash' || $status_post == 'draft' )
                        @else
                           
                        @endif
                        <a href="{{ url('admin/post/add') }}"><button style="position: absolute; right:100px; top:10px"
                                class="btn btn-success">Thêm mới <i style="font-size: 18px"
                                    class="fas fa-plus-circle"></i></button></a>
                        @if (session('status'))

                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                        @endif


                    </div>


                    <div class="card-body">

                        <div class="analytic">
                            <a href="{{ request()->fullUrlWithQuery(['status_post' => 'public']) }}"
                                class="text-success">Tổng số bài đã đăng<span
                                    class="text-muted">({{ $count[0] }})</span></a>
                            <a href="{{ request()->fullUrlWithQuery(['status_post' => 'draft']) }}"
                                class="text-dark">Tổng số bản nháp<span
                                    class="text-muted">({{ $count[1] }})</span></a>
                            <a href="{{ request()->fullUrlWithQuery(['status_post' => 'trash']) }}"
                                class="text-danger">Thùng rác<span
                                    class="text-muted">({{ $count[2] }})</span></a>
                        </div>


                        <form action="{{ url('admin/post/action') }}" method="GET">
                            <div class="form-action form-inline py-3">
                                <select name="act" class="form-control mr-1" id="">
                                    <option>Chức năng</option>
                                    @foreach ($list_act as $k => $v)
                                        <option value="{{ $k }}">{{ $v }}</option>
                                    @endforeach
                                </select>
                                <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                            </div>
                            <table class="table table-striped table-checkall" id="table1">
                                <thead>
                                    <tr style="font-size:14.5px">
                                        <th scope="col">
                                            <input name="checkall" type="checkbox">
                                        </th>
                                        <th >STT</th>
                                        <th scope="col">Title</th>
                                        
                                        <th scope="col">Image</th>
                                        <th scope="col">Category</th>
                                       
                                        <th scope="col">View</th>
                                        <th scope="col">Show</th>
                                      
                                        <th scope="col">Status</th>
                                        <th scope="col">Updated</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @if ($post->total() > 0)

                                        @php
                                            $temp = 0;
                                        @endphp
                                        @foreach ($post as $item)
                                            @php
                                                $temp++;
                                            @endphp
                                            <tr style="font-size:14.5px">
                                                <td>
                                                    <input type="checkbox" name="list_check[]" value="{{ $item->id }}">
                                                </td>
                                                <td>{{ $temp }}</td>
                                                <td> <a href="{{ url('admin/post/edit/' . $item->id) }}">{{ Str::limit($item->title, 50)  }}</a></td>
                                            
                                                <td><img width="100" src="{{ asset('uploads/post/' . $item->image) }}"
                                                        alt="">
                                                </td>
                                                <td style="width:120px">
                                                    @foreach ($item->category as $value)
                                                        <li>{{ $value->title }}</li>
                                                    @endforeach
                                                </td>
                                               
                                                <td>{{ $item->post_view }}</td>
                                                <td><a style="color: black" href="{{url('/admin/post/show/'.$item->id)}}">View</a></td>
                                               
                                                <td><button disabled class="btn btn-info">{{ $item->status }}</button> </td>
                                                <td>{{ $item->updated_at }}</td>
                                                <td>
                                                    <a href="{{ url('admin/post/copy/' . $item->id) }}"> <i
                                                        style="color:rgb(7, 183, 180); font-size:18px"
                                                        class="far fa-copy"></i></a>


                                                    <a href="{{ url('admin/post/edit/' . $item->id) }}"> <i
                                                            style="color:green; font-size:18px"
                                                            class="far fa-edit"></i></a>
                                                    <a href="{{ url('admin/post/delete/' . $item->id) }}"
                                                        onclick="return confirm('Bạn có muốn xóa bài viết này không ?')"> <i
                                                            style="color: red;font-size:18px" class="fas fa-trash"></i>
                                                    </a>
                                                </td>

                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="7" class="bg-white">Bảng ghi rỗng</td>
                                        </tr>
                                    @endif

                                </tbody>
                            </table>
                        </form>
                        {{ $post->links('pagination::bootstrap-4') }}
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection
