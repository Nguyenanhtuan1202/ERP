@extends('layouts.admin')

@section('content')
    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Cập nhật bài viết
                        @if (session('status'))
                            <div class="alert alert-success">
                                {{ session('status') }}
                            </div>
                        @endif
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ url('/admin/post/update/' . $post->id) }}"
                            enctype="multipart/form-data">
                            {{ csrf_field() }}

                            <div class="row">
                                <div class="col-md-6 col-lg-6">
                                    <div class="form-group">

                                        @error('title')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror


                                        <label for="title">Tên bài viết</label>
                                        <input id="cat_name" class="form-control" type="text" name="title"
                                            id="title" placeholder="Nhập vào tên danh mục" value="{{ $post->title }}">
                                    </div>

                                    <div class="form-group">
                                        <label for="image">Hình Đại Diện </label>

                                        @error('image')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <input class="form-control-file @error('image') is-invalid @enderror"
                                            style="width:100%" type="file" name="image" accept="image/*"
                                            onchange="loadFile(event)">
                                        <img style="margin-top: 10px; border-radius:10px; max-width:180px"
                                            src="{{ asset('uploads/post/' . $post->image ?? '') }}" id="output" />
                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src)
                                                }
                                            };
                                        </script>

                                    </div>


                                </div>

                                <div class="col-md-6 col-lg-6">

                                    <div class="form-group">
                                        @error('desc')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="desc">Mô tả</label>
                                        <textarea name="desc" class="form-control ckeditor" id="editor1" id="desc" cols="30" rows="10">
                                            {{ $post->desc ?? '' }}
                                        </textarea>


                                        <script>
                                            ClassicEditor
                                                .create(document.querySelector('#editor1'))
                                                .catch(error => {
                                                    console.error(error);
                                                });
                                        </script>
                                    </div>


                                    <script>
                                        ClassicEditor
                                            .create(document.querySelector('#editor1'))
                                            .catch(error => {
                                                console.error(error);
                                            });
                                    </script>
                                </div>





                                <div class="col-md-6">
                                    <div class="form-group">
                                        @error('category')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="">Danh mục bài viết</label>
                                        <select name="category[]" class="form-control select3_init" id="" multiple>
                                            <option value="">Chọn</option>
                                            @foreach ($category as $cat_item)
                                                <option {{ $catOfPost->contains('id', $cat_item->id) ? 'selected' : '' }}
                                                    value="{{ $cat_item->id }}"> {{ $cat_item->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-12">                                    
                                    <div class="form-group">
                                        <label for="link_youtube">Link Youtube</label>
                                        <input value="{{ $post->link_youtube }}" class="form-control" type="text"
                                            name="link_youtube" id="link_youtube" placeholder="Nhập link youtube nếu có...">
                                    </div>

                                    <div class="form-group">
                                        @error('content')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="content_id">Nội dung bài viết</label>
                                        <textarea name="content" class="form-control ckeditor" id="editor" id="content_id" cols="30" rows="10">{{ $post->content }}</textarea>
                                    </div>

                                    <script>
                                        ClassicEditor
                                            .create(document.querySelector('#editor'))
                                            .catch(error => {
                                                console.error(error);
                                            });
                                    </script>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        @error('status')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="">Trạng Thái</label>
                                        <select name="status" class="form-control" id="">
                                            <option value="{{ $post->status }}">{{ $post->status }}</option>
                                            @if ($post->status == 'draft')
                                                <option value="publish">publish</option>
                                            @else
                                                <option value="draft">draft</option>
                                            @endif

                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group" id="show__seo">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h3 class="optimal_title">Tối ưu hóa SEO </h3>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="search-engine-preview">
                                                    <div class="title">Xem kết quả tìm kiếm</div>
                                                    <div class="google-preview">
                                                        <div class="google-title">{{ $post->meta_seo ?? '' }}</div>
                                                        <div class="google-url">
                                                            {{ url('/') . '/' }}<span
                                                                class="google-url-link">{{ $post->url ?? '' }}</span>
                                                        </div>
                                                        <div class="google-description">{{ $post->desc_seo ?? '' }}</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 div_friendly_link  show">
                                                <div class="form-group">

                                                    <label for="cat_url">Đường dẫn link thân thiện</label>
                                                    @error('url')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input class="form-control" type="text" name="url"
                                                        id="cat_url" value="{{ $post->url ?? '' }}">
                                                    <p class="des_i">Ví dụ: gioi-thieu-ve-chung-toi</p>
                                                </div>

                                            </div>


                                            <div class="col-md-6 div_meta_title  show">
                                                <div class="form-group">
                                                    <label class="meta_seo">Tiêu đề của trang
                                                    </label>
                                                    @error('meta_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="meta_seo" type="text" size="50" maxlength="150"
                                                        value="{{ $post->meta_seo ?? '' }}" class="form-control "
                                                        placeholder="" id="meta_seo">
                                                    <p class="des_i">Ví dụ: giới thiêu | gioi thieu</p>
                                                </div>
                                            </div>


                                            <div class="col-md-6 div_meta_key  show">
                                                <div class="form-group">
                                                    <label class="key_seo">Từ khóa trên công cụ tìm kiếm
                                                    </label>
                                                    @error('key_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="key_seo" type="text" size="50" maxlength="150"
                                                        value="{{ $post->key_seo ?? '' }}" class="form-control "
                                                        placeholder="" id="key_seo">
                                                    <p class="des_i">Ví dụ: giới thiêu, công ty</p>
                                                </div>
                                            </div>
                                            <div class="col-md-6 div_meta_desc  show">
                                                <div class="form-group">
                                                    <label class="desc_seo">Mô tả trên công cụ tìm kiếm
                                                    </label>
                                                    @error('desc_seo')
                                                        <small class="text-danger">({{ $message }})</small>
                                                    @enderror
                                                    <input name="desc_seo" type="text"
                                                        value="{{ $post->desc_seo ?? '' }}" class="form-control "
                                                        placeholder="" id="desc_seo">
                                                    <p class="des_i">Không nên nhập quá 200 chữ và cần có từ khóa cần
                                                        seo
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-success">Cập Nhật <i style="font-size: 18px"
                                            class="fas fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    </div>
@endsection
