{!! $post->content !!}
