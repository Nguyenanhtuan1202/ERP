@extends('layouts.enic')

@section('content')
    <style>
        /* Base Styles */
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #e74c3c;
            --text-dark: #333;
            --text-light: #888;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 8px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 8px 16px rgba(0, 0, 0, 0.15);
            --transition-speed: 0.3s;
        }

        .dashboard-container {
            padding: 20px;
            background-color: #f5f7fa;
            min-height: 100vh;
            margin-top: 100px;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;

            margin-bottom: 20px;
            padding: 15px 20px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
        }

        .dashboard-title-container {
            margin-top: 20px;
            margin-left: 20px;
        }

        .dashboard-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }

        .dashboard-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-dark);
            margin: 0;
        }

        .dashboard-subtitle {
            color: var(--text-light);
            font-size: 14px;
            margin-top: 5px;
        }

        /* Function Grid */
        .functions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .function-card {
            background-color: #fff;
            border-radius: 12px;
            padding: 20px 15px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-speed) ease;
            height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .function-card::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.3s ease;
        }

        .function-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .function-card:hover::after {
            transform: scaleX(1);
            transform-origin: left;
        }

        .function-icon {
            height: 60px;
            width: 60px;
            object-fit: contain;
            margin-bottom: 15px;
            transition: transform 0.3s ease;
        }

        .function-card:hover .function-icon {
            transform: scale(1.1);
        }

        .function-title {
            font-size: 15px;
            font-weight: 400;
            color: var(--text-dark);
            margin: 0;
        }

        .inactive .function-icon {
            filter: grayscale(100%) opacity(0.6);
        }

        /* Dashboard Sections */
        .dashboard-section {
            background-color: #fff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
        }

        .section-header {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-dark);
            margin-top: 0;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Digital Clock */
        .digital-clock {
            background-color: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            text-align: center;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }

        .digital-clock::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
        }

        .clock-face {
            background-color: #f8f9fa;
            padding: 15px 25px;
            border-radius: 10px;
            border: 1px solid #eee;
            position: relative;
        }

        .day-display {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .day {
            color: var(--text-light);
            font-size: 13px;
            width: 40px;
            text-align: center;
            padding: 5px 0;
            border-radius: 20px;
            transition: all 0.3s ease;
        }

        .day.active {
            color: #fff;
            background-color: var(--primary-color);
            font-weight: bold;
            box-shadow: 0 3px 8px rgba(52, 152, 219, 0.3);
        }

        .time-display {
            font-size: 48px;
            font-weight: bold;
            letter-spacing: 2px;
            color: var(--text-dark);
            margin-bottom: 10px;
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .ampm-display {
            font-size: 16px;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .date-display {
            font-size: 14px;
            color: var(--text-light);
            margin-top: 10px;
        }

        .clock-label {
            margin-top: 15px;
            color: var(--text-light);
            font-size: 16px;
            font-weight: 500;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-auto-flow: dense;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow-sm);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: var(--primary-color);
        }

        .stat-card:nth-child(2n)::before {
            background: var(--secondary-color);
        }

        .stat-card:nth-child(3n)::before {
            background: var(--accent-color);
        }

        .stat-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 30px;
            color: rgba(0, 0, 0, 0.1);
        }

        .stat-title {
            font-size: 14px;
            color: var(--text-light);
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: var(--text-dark);
            margin-bottom: 5px;
        }

        .stat-change {
            font-size: 12px;
            color: #2ecc71;
            display: flex;
            align-items: center;
        }

        .stat-change.negative {
            color: #e74c3c;
        }

        /* Charts */
        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-card {
            background-color: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
            height: 300px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .functions-grid {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }

            .charts-container {
                grid-template-columns: 1fr;
            }

            .stats-container {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }

        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animated {
            animation: fadeInUp 0.5s ease forwards;
        }

        .animation-delay-1 {
            animation-delay: 0.1s;
        }

        .animation-delay-2 {
            animation-delay: 0.2s;
        }

        .animation-delay-3 {
            animation-delay: 0.3s;
        }

        .animation-delay-4 {
            animation-delay: 0.4s;
        }



        /* Progress indicator */
        .progress-indicator {
            width: 100%;
            height: 6px;
            background-color: #f1f1f1;
            border-radius: 3px;
            margin-top: 10px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            border-radius: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            transition: width 0.5s ease;
        }

        /* Weather widget */
        .weather-widget {
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 10px;
            display: flex;
            align-items: center;
            margin-top: 15px;
        }

        .weather-icon {
            font-size: 32px;
            margin-right: 15px;
            color: var(--primary-color);
        }

        .weather-info {
            flex: 1;
        }

        .weather-temp {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }

        .weather-desc {
            color: var(--text-light);
            margin: 0;
        }

        /* Quick actions */
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .action-button {
            padding: 10px 20px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .action-button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }

        .action-button i {
            font-size: 16px;
        }

        /* New Tooltip */
        .tooltip-wrapper {
            position: relative;
        }

        .tooltip-wrapper .tooltip-text {
            visibility: hidden;
            width: 120px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 12px;
        }

        .tooltip-wrapper .tooltip-text::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        .tooltip-wrapper:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        .day.active {
            background-color: #3498db;
            color: white;
            font-weight: 500;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }
    </style>


    <div class="dashboard-container">
        <!-- Dashboard Header -->
        <div class="dashboard-header animated">
            <div class="dashboard-title-container">
                <div>
                    <h1 class="dashboard-title">ERP Dashboard</h1>
                    <p class="dashboard-subtitle">Quản lý hệ thống doanh nghiệp</p>
                </div>
            </div>
            <div class="digital-clock">
                <div class="clock-face">
                    <div class="day-display">
                        <span class="day">CN</span>
                        <span class="day">T2</span>
                        <span class="day">T3</span>
                        <span class="day">T4</span>
                        <span class="day">T5</span>
                        <span class="day">T6</span>
                        <span class="day">T7</span>
                    </div>
                    <div class="time-display">
                        <span id="time">00:00:00</span>
                    </div>


                </div>
                <div class="clock-label">Digital Clock</div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-container animated animation-delay-1">
            <div class="stat-card">
                <i class="fas fa-box-open stat-icon"></i>
                <div class="stat-title">Tổng Đơn Hàng</div>
                <div class="stat-value" id="totalOrders">357</div>
                <div class="stat-change"><i class="fas fa-arrow-up"></i> 12.5% so với tháng trước</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-truck stat-icon"></i>
                <div class="stat-title">Hàng Về Kho</div>
                <div class="stat-value" id="inventoryCount">128</div>
                <div class="stat-change negative"><i class="fas fa-arrow-down"></i> 5.2% so với tháng trước</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-users stat-icon"></i>
                <div class="stat-title">Nhà Cung Cấp</div>
                <div class="stat-value" id="supplierCount">42</div>
                <div class="stat-change"><i class="fas fa-arrow-up"></i> 3.8% so với tháng trước</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-shopping-cart stat-icon"></i>
                <div class="stat-title">Sản Phẩm</div>
                <div class="stat-value" id="productCount">1,254</div>
                <div class="stat-change"><i class="fas fa-arrow-up"></i> 8.7% so với tháng trước</div>
            </div>
        </div>

        @php
            $supplier_id = Auth::user()->supplier_id;
            $ware_housing = Auth::user()->ware_housing;
        @endphp

        <!-- Main Functions -->
        <div class="dashboard-section animated animation-delay-2">


            <div class="functions-grid">
                @if (($supplier_id == '' && $ware_housing == 0) || ($supplier_id == null && $ware_housing == 0))
                    <div class="function-card animated animation-delay-1 tooltip-wrapper" id="function-supplier">
                        <span class="tooltip-text">Quản lý thông tin nhà cung cấp</span>
                        <a href="{{ route('supplier.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/lien-he.png') }}" alt="discuss.png">
                            <h3 class="function-title">Nhà Cung Cấp</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-1 tooltip-wrapper" id="function-purchase">

                        <span class="tooltip-text">Quản lý đơn hàng từ xưởng Việt Nam</span>
                        <a href="{{ route('purchaseorder.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/mua-hang.png') }}" alt="discuss.png">
                            <h3 class="function-title">Xưởng Việt Nam</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-2 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý thu mua hàng hóa</span>
                        <a href="{{ route('orders.import') }}">
                            <img class="function-icon" src="{{ asset('/erp/du-doan.png') }}" alt="discuss.png">
                            <h3 class="function-title">Thu Mua</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-2 tooltip-wrapper">
                        <span class="tooltip-text">Xem lịch hẹn và sự kiện</span>
                        <a href="{{ route('order.calendar') }}">
                            <img class="function-icon" src="{{ asset('/erp/lich-hen.png') }}" alt="lich-hen.png">
                            <h3 class="function-title">Lịch</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-2 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý vật tư sản xuất</span>
                        <a href="{{ route('material.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/xuong.png') }}" alt="discuss.png">
                            <h3 class="function-title">Vật Tư</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-3 tooltip-wrapper">

                        <span class="tooltip-text">Quản lý sửa chữa và bảo hành</span>
                        <a href="{{ route('repairorders.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/sua-chua.png') }}" alt="discuss.png">
                            <h3 class="function-title">Sửa Chữa| BH</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-3 tooltip-wrapper">
                        <span class="tooltip-text">Theo dõi hàng về kho</span>
                        <a href="{{ route('delivery.showdelivery') }}">
                            <img class="function-icon" src="{{ asset('/erp/giao-hang.jpg') }}" alt="Giao Hàng">
                            <h3 class="function-title">Hàng Về Kho</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-3 tooltip-wrapper">
                        <span class="tooltip-text">Theo dõi hàng về thực tế</span>
                        <a href="{{ route('delivery.orderReceived') }}">
                            <img class="function-icon" src="{{ asset('/erp/box.png') }}" alt="Giao Hàng">
                            <h3 class="function-title">Hàng Về Thực Tế</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-4 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý sản phẩm Việt Nam</span>
                        <a href="{{ route('product.list') }}">
                            <img class="function-icon" src="{{ asset('/erp/discuss.png') }}" alt="discuss.png">
                            <h3 class="function-title">Sản Phẩm (VN)</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-3">
                        <a href="{{ route('warehouse.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/ton-kho.png') }}" alt="discuss.png">
                            <h3 class="function-title">Tồn Kho</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-3">
                        <a href="{{ route('forecastProduct.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/products.png') }}" alt="products.png">
                            <h3 class="function-title">Sản Phẩm (QT)</h3>
                        </a>
                    </div>
                @endif

                @if ($supplier_id != '' || $supplier_id != null)
                    <div class="function-card animated animation-delay-1">
                        <a href="{{ route('production.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/san-xuat.png') }}" alt="Sản Xuất">
                            <h3 class="function-title">Sản Xuất</h3>
                        </a>
                    </div>
                    <div class="function-card animated animation-delay-2">
                        <a href="{{ route('delivery.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/giao-hang.jpg') }}" alt="Giao Hàng">
                            <h3 class="function-title">Giao Hàng</h3>
                        </a>
                    </div>
                @endif

                @if ($ware_housing == 1)
                    <div class="function-card animated animation-delay-1">
                        <a href="{{ route('delivery.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/giao-hang.jpg') }}" alt="Giao Hàng">
                            <h3 class="function-title">Đơn Hàng</h3>
                        </a>
                    </div>
                @endif
            </div>
        </div>

        <!-- Administration Functions -->
        <div class="dashboard-section animated animation-delay-3">
            <h2 class="section-header">Quản Trị Hệ Thống</h2>

            <div class="functions-grid">
                @if (($supplier_id == '' && $ware_housing == 0) || ($supplier_id == null && $ware_housing == 0))
                    <div class="function-card animated animation-delay-1">
                        <a href="{{ route('user_list') }}">
                            <img class="function-icon" src="{{ asset('/erp/human-resource.png') }}"
                                alt="human-resource.png">
                            <h3 class="function-title">Quản Lý NV</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-1">
                        <a href="{{ url('admin/role/list') }}">
                            <img class="function-icon" src="{{ asset('/erp/project-manager.png') }}"
                                alt="project-manager.png">
                            <h3 class="function-title">Phân Quyền</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-4 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý nhân viên kho</span>
                        <a href="{{ route('warehousingmanager.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/nhan-vien.png') }}" alt="discuss.png">
                            <h3 class="function-title">NV Kho</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-4 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý nhân viên thu mua</span>
                        <a href="{{ route('purchaser.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/nhan-vien.png') }}" alt="discuss.png">
                            <h3 class="function-title">NV Thu Mua</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-4 tooltip-wrapper">
                        <span class="tooltip-text">Quản lý nhân viên dự toán</span>
                        <a href="{{ route('forecaster.index') }}">
                            <img class="function-icon" src="{{ asset('/erp/nhan-vien.png') }}" alt="discuss.png">
                            <h3 class="function-title">NV Dự Toán</h3>
                        </a>
                    </div>


                    <div class="function-card animated animation-delay-2">
                        <a href="{{ route('lucky-wheel') }}">
                            <img class="function-icon" src="{{ asset('/erp/spin.png') }}" alt="spin.png">
                            <h3 class="function-title">Vòng Quay May Mắn</h3>
                        </a>
                    </div>

                    <div class="function-card animated animation-delay-2">
                        <a href="{{ route('division_of_duty') }}">
                            <img class="function-icon" src="{{ asset('/erp/ke-hoach.png') }}" alt="spin.png">
                            <h3 class="function-title">Chia Trực Nhật</h3>
                        </a>
                    </div>



                    <div class="function-card animated animation-delay-4 inactive">
                        <a href="#">
                            <img class="function-icon" src="{{ asset('/erp/viec-can-lam.png') }}" alt="discuss.png">
                            <h3 class="function-title">Việc Cần Làm</h3>
                        </a>
                        <div class="progress-indicator">
                            <div class="progress-bar" style="width: 70%"></div>
                        </div>
                    </div>

                    <div class="function-card animated animation-delay-4 inactive">
                        <a href="#">
                            <img class="function-icon" src="{{ asset('/erp/kien-thuc.png') }}" alt="discuss.png">
                            <h3 class="function-title">Kiến Thức</h3>
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection


@section('js')
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const cards = document.querySelectorAll('.custom-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 150);
            });
        });


        // Update the clock
        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');

            document.getElementById('time').innerText = `${hours}:${minutes}:${seconds}`;

            // Update active day
            const dayElements = document.querySelectorAll('.day');
            const today = now.getDay(); // 0 is Sunday, 1 is Monday, etc.

            dayElements.forEach((el) => {
                el.classList.remove('active');
            });

            // In Vietnam, Sunday is still day 0
            dayElements[today].classList.add('active');
        }

        // Initial call
        updateClock();

        // Update every second
        setInterval(updateClock, 1000);
    </script>
@endsection
