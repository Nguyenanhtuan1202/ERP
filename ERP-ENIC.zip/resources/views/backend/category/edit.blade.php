@extends('layouts.enic')


<style>
    /* ERP Product Category Edit Form CSS */

    .card-header {
        font-size: 1.25rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        background: linear-gradient(90deg, #004890 0%, #204591 100%);
    }

    .card__body-custom {
        background-color: #f8f9fa;
        padding: 30px;
        border-radius: 6px;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    }

    .card__body-custom form {
        font-family: 'Roboto', 'Segoe UI', sans-serif;
    }

    /* Form Header */
    .card__body-custom .form-header {
        border-bottom: 1px solid #e0e0e0;
        margin-bottom: 25px;
        padding-bottom: 15px;
        position: relative;
    }

    .card__body-custom .form-header h5 {
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }

    /* Form Group Styling */
    .card__body-custom .form-group {
        margin-bottom: 22px;
        position: relative;
    }

    .card__body-custom .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #495057;
        font-size: 14px;
    }

    /* Required field indicator */
    .card__body-custom .form-group label:after {
        content: " *";
        color: #e74c3c;
    }

    .card__body-custom .form-group label[for="weight"]:after,
    .card__body-custom .form-group label[for="parent_id"]:after,
    .card__body-custom .form-group label[for="ckeditor"]:after {
        content: "";
    }

    /* Input Fields */
    .card__body-custom .form-control {
        border: 1px solid #dce4ec;
        border-radius: 4px;
        padding: 12px 15px;
        height: 45px;
        width: 100%;
        font-size: 14px;
        color: #34495e;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05);
        transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }

    .card__body-custom .form-control:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        outline: 0;
    }

    .card__body-custom .form-control::placeholder {
        color: #b2bec3;
        opacity: 1;
    }

    /* SKU Field Styling */
    .card__body-custom #sku {
        font-family: 'Roboto Mono', monospace;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        background-color: #f8f9fa;
        font-weight: 500;
    }

    /* File Input Styling */
    .card__body-custom .form-control-file {
        border: 1px dashed #ced4da;
        padding: 15px;
        border-radius: 4px;
        background-color: #fff;
        cursor: pointer;
        width: 100%;
        transition: border-color 0.15s ease-in-out;
    }

    .card__body-custom .form-control-file:hover {
        border-color: #3498db;
        background-color: #f2f9ff;
    }

    /* Image Preview */
    .card__body-custom #output {
        border: 1px solid #ddd;
        padding: 5px;
        background-color: #fff;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease;
    }

    .card__body-custom #output:hover {
        transform: scale(1.05);
    }

    .card__body-custom .block__image {
        background-color: #fcfcfc;
        padding: 20px;
        border-radius: 5px;
        border: 1px solid #e9ecef;
        margin-bottom: 25px;
    }

    /* Select Styling */
    .card__body-custom .select3_init {
        width: 100%;
        height: 45px;
        border-radius: 4px;
        background-color: #fff;
        border: 1px solid #dce4ec;
        padding: 0 10px;
        color: #34495e;
    }

    /* Radio Buttons */
    .card__body-custom .form-check {
        display: inline-block;
        margin-right: 15px;
        margin-bottom: 10px;
        padding-left: 30px;
        position: relative;
    }

    .card__body-custom .form-check-input {
        position: absolute;
        left: 0;
        top: 2px;
        margin-left: 0;
        cursor: pointer;
        width: 18px;
        height: 18px;
    }

    .card__body-custom .form-check-label {
        cursor: pointer;
        font-size: 14px;
        font-weight: normal;
        color: #555;
    }

    /* Radio button custom styling */
    .card__body-custom .form-check-input:checked+.form-check-label {
        color: #2c3e50;
        font-weight: 500;
    }

    /* Textarea Styling */
    .card__body-custom .ckeditor {
        min-height: 180px;
    }

    /* Validation Styling */
    .card__body-custom .text-danger {
        color: #e74c3c;
        font-size: 12px;
        margin-bottom: 5px;
        display: block;
    }

    /* Submit Button */
    .card__body-custom .btn-success {
        background-color: #27ae60;
        border-color: #27ae60;
        color: #fff;
        padding: 12px 25px;
        border-radius: 4px;
        font-size: 15px;
        font-weight: 500;
        transition: all 0.2s ease;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .card__body-custom .btn-success:hover {
        background-color: #2ecc71;
        border-color: #2ecc71;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transform: translateY(-1px);
    }

    .card__body-custom .btn-success i {
        margin-left: 8px;
        vertical-align: middle;
    }

    /* Responsive Adjustments */
    @media (max-width: 767px) {
        .card__body-custom {
            padding: 20px 15px;
        }

        .card__body-custom .form-group {
            margin-bottom: 15px;
        }

        .card__body-custom .btn-success {
            width: 100%;
        }
    }

    /* Form Sections */
    .card__body-custom .form-section {
        margin-bottom: 25px;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
    }

    .card__body-custom .form-section:last-child {
        border-bottom: none;
    }

    /* Input fields with icons */
    .card__body-custom .input-with-icon {
        position: relative;
    }

    .card__body-custom .input-with-icon i {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: #7f8c8d;
    }

    /* Number input styling */
    .card__body-custom input[type="number"] {
        -moz-appearance: textfield;
    }

    .card__body-custom input[type="number"]::-webkit-outer-spin-button,
    .card__body-custom input[type="number"]::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
</style>


@section('content')
    <div id="content" class="container-fluid" style="margin-top: 100px">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Cập nhật Danh mục sản phẩm ({{ $category->title ?? '' }})
                        @if (session('success'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('success') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>
                    <div class="card-body card__body-custom">

                        <form action="{{ url('/admin/category/update/' . $category->id) }}" enctype="multipart/form-data"
                            method="POST">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">

                                        @error('title')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="cat_name">Tên loại sản phẩm</label>
                                        <input value="{{ $category->title ?? '' }}" class="form-control" type="text"
                                            name="title" id="cat_name" placeholder="Nhập vào tên danh mục">
                                    </div>


                                    <div class="form-group block__image">
                                        @error('image')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="cat_image">Hình Ảnh(*)</label>
                                        <input class="form-control-file" style="width:100%" type="file" id="cat_image"
                                            name="image" accept="image/*" onchange="loadFile(event)">
                                        <img style="margin-top: 10px; border-radius:10px; max-width:180px"
                                            src="{{ asset('uploads/category/' . $category->image ?? '') }}"
                                            id="output" />
                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src)
                                                }
                                            };
                                        </script>
                                    </div>

                                    <div class="form-group">
                                        @error('parent_id')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="parent_id">Danh mục cha</label>
                                        <select name="parent_id" class="form-control select3_init" id="parent_id">
                                            <option value="0">Chọn danh mục cha</option>
                                            {!! $htmlOption !!}
                                        </select>
                                    </div>

                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        @error('status')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="status">Trạng thái hiển thị (*)</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios1" value="1" <?php if ($category->status == 1) {
                                                    echo 'checked';
                                                } ?>>
                                            <label class="form-check-label" for="exampleRadios1">
                                                Hiện
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios2" value="2" <?php if ($category->status == 2) {
                                                    echo 'checked';
                                                } ?>>
                                            <label class="form-check-label" for="exampleRadios2">
                                                Ẩn
                                            </label>
                                        </div>
                                    </div>


                                    <div class="form-group">

                                        <label for="weight">Thứ tự ưu tiên</label>
                                        <input class="form-control" type="number" min="0" name="weight"
                                            id="weight" value="{{ $category->weight ?? '' }}">
                                    </div>

                                    <div class="form-group">

                                        <label for="sku">Mã SKU</label>
                                        <input class="form-control" type="text" min="0" name="sku"
                                            id="sku" value="{{ $category->sku ?? '' }}">
                                    </div>

                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ckeditor">Nội Dung ( Không bắt buộc)</label>
                                        <textarea name="content" class="form-control ckeditor" id="ckeditor" cols="30" rows="3">{!! $category->content !!}</textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-success">Cập Nhật <i style="font-size: 18px"
                                            class="fas fa-save"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
@endsection
