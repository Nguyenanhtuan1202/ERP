@extends('layouts.layout_purchaser')
@section('content')
    <style>
        /* Premium ERP System CSS - Enterprise Edition */
        :root {
            /* Color Palette */
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #475569;
            --success-color: #10b981;
            --info-color: #0ea5e9;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-color: #f9fafb;
            --dark-color: #1e293b;

            /* Neutral Colors */
            --neutral-50: #f8fafc;
            --neutral-100: #f1f5f9;
            --neutral-200: #e2e8f0;
            --neutral-300: #cbd5e1;
            --neutral-400: #94a3b8;
            --neutral-500: #64748b;
            --neutral-600: #475569;
            --neutral-700: #334155;
            --neutral-800: #1e293b;
            --neutral-900: #0f172a;

            /* UI Elements */
            --border-radius-sm: 0.25rem;
            --border-radius: 0.375rem;
            --border-radius-md: 0.5rem;
            --border-radius-lg: 0.75rem;
            --box-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --box-shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --box-shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            --transition-all: all 0.2s ease-in-out;

            /* Typography */
            --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        /* Base Styles */
        body {
            background-color: var(--neutral-100);
            font-family: var(--font-sans);
            color: var(--neutral-800);
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        #content.container-fluid {
            padding: 1.5rem 2rem;
            max-width: 1600px;
            margin: 0 auto;
        }

        /* Card Styling */
        .card {
            border: none;
            border-radius: var(--border-radius-lg);
            box-shadow: var(--box-shadow);
            background-color: white;
            overflow: hidden;
            transition: var(--transition-all);
            margin-bottom: 2rem;
        }

        .card:hover {
            box-shadow: var(--box-shadow-md);
        }

        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--neutral-200);
            padding: 1.25rem 1.75rem;
            position: relative;
        }

        .card-header.font-weight-bold {
            font-size: 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            background: linear-gradient(90deg, #004890 0%, #204591 100%);
        }

        .card-header.font-weight-bold::before {
            content: "";
            display: inline-block;
            width: 0.25rem;
            height: 1.25rem;
            background-color: var(--primary-color);
            border-radius: 2px;
            margin-right: 0.75rem;
            position: relative;
            top: 0;
        }

        .card-body {
            padding: 1.5rem 1.75rem;
        }

        /* Action Buttons Bar */
        .listPurchaseOrder {
            background-color: var(--neutral-50);
            border-bottom: 1px solid var(--neutral-200);
            padding: 1.25rem 1.75rem !important;
            margin: 0 !important;
        }

        /* Buttons */
        .addNew,
        .settingNew {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.625rem 1.25rem;
            margin-right: 0.75rem;
            font-weight: 500;
            color: white;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition-all);
            box-shadow: var(--box-shadow-sm);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .addNew::after,
        .settingNew::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 0;
            background-color: rgba(0, 0, 0, 0.1);
            transition: var(--transition-all);
            z-index: -1;
        }

        .addNew:hover::after,
        .settingNew:hover::after {
            height: 100%;
        }

        .addNew:hover,
        .settingNew:hover {
            transform: translateY(-2px);
            box-shadow: var(--box-shadow);
            color: white;
        }

        .addNew i,
        .settingNew i {
            margin-left: 0.5rem;
            font-size: 0.875rem;
        }

        .addNew {
            background-color: var(--primary-color);
        }

        .settingNew {
            background-color: var(--secondary-color);
        }

        .addNew[style*="background: rgb(52, 176, 176)"] {
            background: linear-gradient(135deg, #34b0b0, #2c9a9a) !important;
        }

        .addNew[style*="background: rgb(23, 145, 88)"] {
            background: linear-gradient(135deg, #17915c, #128150) !important;
        }

        /* Table Styling */
        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 0;
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: var(--neutral-50);
        }

        .table thead th {
            background-color: var(--neutral-100);
            color: var(--neutral-600);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 1rem 1rem;
            border-bottom: 2px solid var(--neutral-200);
            vertical-align: middle;
        }

        .table tbody td {
            padding: 1rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid var(--neutral-200);
            color: var(--neutral-700);
            font-size: 0.9375rem;
            transition: var(--transition-all);
        }

        .table tbody tr:hover td {
            background-color: var(--neutral-100);
        }

        /* Status Icons */
        .fas.fa-check,
        .fas.fa-times-circle {
            font-size: 1.5rem;
            border-radius: 50%;
            padding: 0.25rem;
            transition: var(--transition-all);
        }

        .fas.fa-check {
            color: white !important;
            background-color: var(--success-color);
        }

        .fas.fa-times-circle {
            color: white !important;
            background-color: var(--danger-color);
        }

        /* Action Buttons in Table */
        .btn {
            border-radius: var(--border-radius);
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            transition: var(--transition-all);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.375rem;
            box-shadow: var(--box-shadow-sm);
        }

        .btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--box-shadow);
        }

        .btn-info {
            background: linear-gradient(135deg, var(--info-color), #0284c7);
            border-color: transparent;
            color: white;
        }

        .btn-info:hover {
            background: linear-gradient(135deg, #0284c7, #0369a1);
            border-color: transparent;
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            border-color: transparent;
            color: white;
        }

        .btn-danger:hover {
            background: linear-gradient(135deg, #dc2626, #b91c1c);
            border-color: transparent;
            color: white;
        }

        .btn i {
            font-size: 0.875rem;
        }

        /* Child Categories Styling */
        tbody tr td:nth-child(2):contains("--") {
            position: relative;
            padding-left: 2rem;
        }

        tbody tr td:nth-child(2):contains("--")::before {
            content: "└─";
            position: absolute;
            left: 1rem;
            color: var(--neutral-500);
            font-weight: 400;
        }

        /* SweetAlert2 Customization */
        .swal2-popup {
            border-radius: var(--border-radius-lg);
            padding: 2rem;
            box-shadow: var(--box-shadow-lg);
        }

        .swal2-title {
            font-family: var(--font-sans);
            font-weight: 600;
            color: var(--neutral-800);
        }

        .swal2-html-container {
            font-family: var(--font-sans);
            color: var(--neutral-600);
        }

        .swal2-confirm {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover)) !important;
            border-radius: var(--border-radius) !important;
            box-shadow: var(--box-shadow-sm) !important;
            font-weight: 500 !important;
            padding: 0.625rem 1.25rem !important;
        }

        .swal2-confirm:hover {
            box-shadow: var(--box-shadow) !important;
            transform: translateY(-1px);
        }

        /* Empty State */
        .table:empty::after {
            content: "Không có dữ liệu để hiển thị";
            display: block;
            text-align: center;
            padding: 3rem 1rem;
            color: var(--neutral-500);
            font-style: italic;
            background-color: var(--neutral-50);
            border-radius: var(--border-radius);
            margin-top: 1rem;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            #content.container-fluid {
                padding: 1.25rem 1.5rem;
            }
        }

        @media (max-width: 992px) {
            .card-header.font-weight-bold {
                font-size: 1.125rem;
            }

            .d-flex.ml-3.mt-4,
            .d-flex.mt-4 {
                flex-direction: column;
                gap: 0.75rem;
            }

            .addNew,
            .settingNew {
                width: 100%;
                margin-right: 0;
            }
        }

        @media (max-width: 768px) {
            .table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .table thead th,
            .table tbody td {
                padding: 0.75rem;
            }

            .btn {
                padding: 0.375rem 0.625rem;
                font-size: 0.875rem;
            }

            .card-header.font-weight-bold::before {
                display: none;
            }
        }

        /* Animation Effects */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card {
            animation: fadeIn 0.3s ease-out;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--neutral-100);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--neutral-300);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--neutral-400);
        }
    </style>

    <div id="content" class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh mục sản phẩm
                        @if (session('success'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('success') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>
                    <div class="row align-items-center justify-content-between listPurchaseOrder" style="width: 100%;">
                        <div class="col-auto">

                            <div class="d-flex ml-3 mt-4">
                                <a class="addNew" style="background: rgb(52, 176, 176);box-shadow:none"
                                    href="{{ route('category.import_excel') }}">Nhập File
                                    <i class="fas fa-file-upload"></i> </a>
                                <a class="addNew" style="background: rgb(23, 145, 88);box-shadow:none"
                                    href="{{ route('category.export') }}">Xuất File
                                    <i class="fas fa-file-download"></i> </a>
                            </div>
                        </div>
                        <div class="col-auto mt-4">
                            <div class="d-flex">
                                <a class="addNew" href="{{ route('category.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                            
                            </div>
                        </div>
                    </div>


                    <div class="card-body">
                        <table class="table table-striped" id="table1">
                            <thead>
                                <tr>
                                    <th scope="col">STT</th>
                                    <th scope="col">Tên loại Sản Phẩm</th>
                                    <th scope="col">Sku</th>
                                    <th scope="col">Trạng Thái</th>
                                    <th scope="col">Quản Lý</th>
                                </tr>
                            </thead>
                            <tbody>


                                @php
                                    $temp = 0;
                                @endphp

                                @foreach ($listCategory as $item)
                                    @php
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <td>{{ $temp }}</td>
                                        <td>{{ $item->title ?? '' }}</td>
                                        <td>{{ $item->sku ?? '' }}</td>
                                        @if ($item->status == 1)
                                            <td><a href="{{ url('/admin/category/list?id=' . $item->id . '&status=2') }}">
                                                    <i style="color:#05a603" class="fas fa-check"></i></a></td>
                                        @else
                                            <td><a href="{{ url('/admin/category/list?id=' . $item->id . '&status=1') }}">
                                                    <i style="color:red" class="fas fa-times-circle"></i></a></td>
                                        @endif
                                        <td>
                                            <a href="{{ url('admin/category/edit/' . $item->id) }}"><button
                                                    class="btn btn-info"> <i class="far fa-edit"></i> Sửa </button></a>
                                            <a href="{{ url('admin/category/delete/' . $item->id) }}"
                                                onclick="return confirm('Bạn có muốn xóa danh mục này không')"><button
                                                    class="btn btn-danger"> <i class="fas fa-trash"></i> Xóa </button></a>
                                        </td>

                                        @if ($item->catChild->isNotEmpty())
                                            @foreach ($item->catChild as $child)
                                    <tr>
                                        <td></td>
                                        <td> -- {{ $child->title }}</td>
                                        <td>{{ $child->url }}</td>
                                        @if ($child->status == 1)
                                            <td><a href="{{ url('/admin/category/list?id=' . $child->id . '&status=2') }}">
                                                    <i style="color:#05a603" class="fas fa-check"></i></a></td>
                                        @else
                                            <td><a href="{{ url('/admin/category/list?id=' . $child->id . '&status=1') }}">
                                                    <i style="color:red" class="fas fa-times-circle"></i></a></td>
                                        @endif

                                        <td>
                                            <a href="{{ url('admin/category/edit/' . $child->id) }}"><button
                                                    class="btn btn-info"> <i class="far fa-edit"></i> Sửa
                                                </button></a>
                                            <a href="{{ url('admin/category/delete/' . $child->id) }}"
                                                onclick="return confirm('Bạn có muốn xóa danh mục này không')"><button
                                                    class="btn btn-danger"> <i class="fas fa-trash"></i> Xóa
                                                </button></a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tr>
                                @endif
                                @endforeach

                            </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
