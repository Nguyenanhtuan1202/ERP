@extends('layouts.enic')

@section('content')
    <style>
        .card-header {
            font-size: 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            background: linear-gradient(90deg, #004890 0%, #204591 100%);
        }

        /* Main Form Styling */
        .card-body {
            background-color: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);

        }



        /* Form Group Styling */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #495057;
            font-size: 14px;
        }

        /* Input Styling */
        .form-control {
            border: 1px solid #ced4da;
            border-radius: 4px;
            padding: 10px 12px;
            height: 42px;
            width: 100%;
            font-size: 14px;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            border-color: #4a89dc;
            box-shadow: 0 0 0 0.2rem rgba(74, 137, 220, 0.25);
            outline: 0;
        }

        /* File Input Styling */
        .form-control-file {
            border: 1px dashed #ced4da;
            padding: 10px;
            border-radius: 4px;
            background-color: #fff;
            cursor: pointer;
        }

        /* Image Preview */
        #output {
            border: 1px solid #ddd;
            padding: 3px;
            background-color: #fff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        /* Select Styling */
        .select3_init {
            width: 100%;
            height: 42px;
            border-radius: 4px;
            background-color: #fff;
        }

        /* Radio Buttons */
        .form-check {
            margin-bottom: 8px;
            padding-left: 30px;
            position: relative;
        }

        .form-check-input {
            position: absolute;
            left: 0;
            top: 2px;
            margin-left: 0;
            cursor: pointer;
        }

        .form-check-label {
            cursor: pointer;
            font-size: 14px;
        }

        /* Textarea Styling */
        .ckeditor {
            min-height: 150px;
        }

        /* Validation Styling */
        .text-danger {
            color: #dc3545;
            font-size: 12px;
            margin-bottom: 5px;
            display: block;
        }

        /* Submit Button */
        .btn-primary {
            background-color: #4a89dc;
            border-color: #3b78d4;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #3b78d4;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .btn-primary i {
            margin-left: 5px;
            vertical-align: middle;
        }

        /* Responsive Adjustments */
        @media (max-width: 767px) {
            .col-md-6 {
                margin-bottom: 15px;
            }
        }

        /* ERP Professional Touches */
        .row {
            margin-bottom: 10px;
        }

        .block__image {
            background-color: #fff;
            padding: 15px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
        }

        /* Add this to your existing CSS */
        .form-header {
            background-color: #f1f5f9;
            padding: 15px;
            border-left: 4px solid #4a89dc;
            margin-bottom: 20px;
            border-radius: 0 4px 4px 0;
        }

        .form-section {
            padding-bottom: 15px;
            margin-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        /* Input fields with icons */
        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
    </style>

    <div id="content" class="container-fluid" style="margin-top: 100px">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Thêm Mới Danh Mục Sản Phẩm
                        @if (session('success'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('success') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>
                    <div class="card-body">

                        <form action="{{ url('admin/category/save') }}" enctype="multipart/form-data" method="POST">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">

                                        @error('title')
                                            <small class="text-danger">({{ $message }})</small>
                                        @enderror
                                        <label for="cat_name">Tên loại sản phẩm (*)</label>
                                        <input value="{{ old('title') }}" class="form-control" type="text"
                                            name="title" id="cat_name" placeholder="Nhập vào tên danh mục">
                                    </div>


                                    <div class="form-group block__image">
                                        @error('image')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="cat_image">Hình Ảnh</label>
                                        <input class="form-control-file" style="width:100%" type="file" id="cat_image"
                                            name="image" accept="image/*" onchange="loadFile(event)">
                                        <img style="margin-top: 10px; border-radius:10px; max-width:180px"
                                            src="{{ asset('uploads/add.png') }}" id="output" />
                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src)
                                                }
                                            };
                                        </script>
                                    </div>




                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        @error('parent_id')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="parent_id">Danh mục cha</label>
                                        <select name="parent_id" class="form-control select3_init" id="parent_id">
                                            <option value="0">Chọn danh mục cha</option>
                                            {!! $htmlOption !!}
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        @error('status')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <label for="status">Trạng thái hiển thị (*)</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios1" value="1" checked>
                                            <label class="form-check-label" for="exampleRadios1">
                                                Hiện
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status"
                                                id="exampleRadios2" value="2">
                                            <label class="form-check-label" for="exampleRadios2">
                                                Ẩn
                                            </label>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="weight">Thứ tự ưu tiên</label>
                                            <input class="form-control" type="number" min="0" name="weight"
                                                id="weight" value="{{ old('weight') }}">
                                        </div>
                                    </div>

                                </div>




                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="ckeditor">Nội Dung ( Không Bắt buộc)</label>
                                        <textarea name="content" class="form-control ckeditor" id="ckeditor" cols="30" rows="3">{!! old('content') !!}</textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">Thêm mới <i style="font-size: 18px"
                                            class="fas fa-plus-circle"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>
@endsection
