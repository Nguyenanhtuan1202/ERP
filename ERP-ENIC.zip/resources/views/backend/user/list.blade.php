@extends('layouts.enic')

@section('content')
    <div id="content" class="container-fluid">
        <div class="card" style="margin-top: 100px">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách nhân viên</h5>
                @if (session('status'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('status') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


            </div>

            <div class="row align-items-center justify-content-between listPurchaseOrder mt-3 ml-2" style="width: 100%;">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('user_list') }}">Danh Sách</a></li>

                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        {{-- <a class="addNew" href="{{ route('user_add') }}">Tạo Mới <i class="fas fa-plus"></i></a> --}}
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang
                            <i class="fas fa-sync-alt"></i></a>
                        <a style="background: #199fb7; box-shadow: none" class="addNew" href="{{ route('user_list') }}">Danh
                            Sách <i class="fas fa-list"></i></a>
                    </div>
                </div>
            </div>

            <div class="card-body">

                {{-- <div class="form-action form-inline py-3">
                    <button class="btn btn-success"><a style="color: white" href="{{ url('admin/user/add') }}">Thêm
                            mới</a> <i style="font-size: 18px" class="fas fa-plus-circle"></i></button>
                </div> --}}
                <table class="table table-striped table-checkall" id="table1">
                    <thead>
                        <tr>

                            <th scope="col">No</th>
                            <th scope="col">Họ tên</th>
                            <th scope="col">Email</th>
                            <th scope="col">Vai trò</th>
                            <th scope="col">Ngày tạo</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>

                        @php
                            $temp = 0;
                        @endphp
                        @foreach ($users as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr>

                                <th scope="row">{{ $temp }}</th>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->email }}</td>
                                <td>
                                    @foreach ($item->role as $role)
                                        <li>
                                            {{ $role->display_name }}
                                        </li>
                                    @endforeach
                                </td>
                                <td>{{ $item->created_at }}</td>
                                <td>
                                    <a href="{{ url('/admin/user/edit/' . $item->id) }}"
                                        class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                            class="fa fa-edit"></i></a>
                                    <a href="{{ url('admin/user/delete/' . $item->id) }}"
                                        onclick="return confirm('Bạn có muốn xóa user này không ?')"
                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
