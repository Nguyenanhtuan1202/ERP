@extends('layouts.enic')

@section('content')
    <div id="content" class="container-fluid">
        <div class="card" style="margin-top: 100px">
            <div class="card-header font-weight-bold" >
                Thêm nhân viên
                @if (session('status'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('status') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

            </div>


            <div class="row align-items-center justify-content-between listPurchaseOrder mt-3 ml-2" style="width: 100%;">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('user_list') }}">Danh Sách</a></li>
                        <li class="breadcrumb-item active">
                            Thêm Mới
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a class="addNew" href="{{ route('user_add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang
                            <i class="fas fa-sync-alt"></i></a>
                        <a style="background: #199fb7; box-shadow: none" class="addNew" href="{{ route('user_list') }}">Danh
                            Sách <i class="fas fa-list"></i></a>
                    </div>
                </div>
            </div>




            <div class="card-body">
                <form action="{{ url('/admin/save/user') }}" method="POST">
                    {{ csrf_field() }}
                    <div class="form-group">
                        @error('name')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="name">Họ và tên</label>
                        <input class="form-control" type="text" name="name" id="name"
                            value="{{ old('name') }}">
                    </div>
                    <div class="form-group">
                        @error('email')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="email">Email</label>
                        <input class="form-control" type="email" name="email" id="email"
                            value="{{ old('email') }}">
                    </div>
                    <div class="form-group">
                        @error('password')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                        <label for="password">Mật khẩu</label>
                        <input class="form-control" type="password" name="password" id="password">
                    </div>

                    <div class="form-group">
                        <label for="">Phân quyền</label>
                        <select name="role_id[]" class="form-control select2_init" id="" multiple>
                            <option value="">Chọn vai trò</option>
                            @foreach ($roles as $item)
                                <option value="{{ $item->id }}">{{ $item->display_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm mới <i style="font-size: 18px"
                            class="fas fa-plus-circle"></i></button>
                </form>
            </div>
        </div>
    </div>
@endsection
