@extends('layouts.admin')

@section('content')

    <div id="content" class="container-fluid">
        <div class="row">

            <div class="col-12">
                <div class="card">

                    <div class="card-header font-weight-bold">
                        Danh sách bình luận
                        @if (session('status'))

                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr style="font-size: 14px">
                                    <th scope="col">STT</th>
                                    <th scope="col">Tên KH</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Tên bài viết</th>
                                    <th scope="col">Nội dung</th>
                                    <th scope="col">Trạng thái</th>
                                    <th scope="col">Ngày Đăng</th>
                                    <th scope="col">Quản Lý</th>
                                </tr>
                            </thead>
                            <tbody>

                                <form action="" method="GET">
                                    @php
                                        $temp = 0;
                                    @endphp
                                    @foreach ($comments as $item)
                                        @php
                                            $temp++;
                                        @endphp
                                        <tr style="font-size: 14px">
                                            <th>{{ $temp }}</th>
                                            <td>{{ $item->comment_name }}</td>
                                            <td>{{ $item->comment_email }}</td>
                                            <td><a style="color: blue"
                                                    href="{{ URL::to('tin-tuc/' . $item->post->slug) }}" target="_blank"
                                                    rel="noopener noreferrer">{{ $item->post->title }}</a>
                                            </td>
                                            <td>{{ $item->comment_content }}
                                                <br>
                                                <ul>
                                                    @foreach ($comment as $comment_reply)
                                                        @if ($comment_reply->comment_parent_content == $item->id)
                                                            <li style="color:indianred"> Trả lời: {{ $comment_reply->comment_content}}</li>
                                                        @endif

                                                    @endforeach

                                                </ul>
                                                @if ($item->comment_status == 'approve')
                                                    <textarea id="reply_comment_{{ $item->id }}"
                                                        class=" form-control reply_comment_{{ $item->id }}" cols="
                                                            30" rows="3" placeholder="Trả lời bình luận"></textarea>
                                                    <button class="mt-2 btn btn-success btn-reply-comment"
                                                        data-post_id="{{ $item->post_id }}"
                                                        data-comment_id="{{ $item->id }}" type="button"> Trả lời bình
                                                        luận </button>
                                                @else

                                                @endif

                                            </td>

                                            @if ($item->comment_status == 'approve')
                                                <td style="font-size: 15px; font-weight:bold;text-transform:capitalize">Đã
                                                    Duyệt <i style="font-size: 15px" class="fas fa-check"></i></td>
                                            @else
                                                <td style="font-size: 15px; font-weight:bold;text-transform:capitalize">Chưa
                                                    Duyệt x</td>
                                            @endif

                                            <td>{{ $item->created_at }}</td>
                                            <td>

                                                @if ($item->comment_status == 'approve')
                                                @else
                                                    <button type="button" data-comment_status="approve"
                                                        data-comment_id="{{ $item->id }}" id="{{ $item->post_id }}"
                                                        class="btn btn-success comment_duyet_btn"
                                                        style="font-size: 14px;width:105px"> Duyệt <i
                                                            style="font-size: 12px" class="fas fa-check"></i></button>

                                                @endif
                                                <a href="{{ url('admin/comment/delete/' . $item->id) }}"
                                                    onclick="return confirm('Bạn có muốn xóa danh mục này không')"><i style="color: red; font-size:22px" class="fas fa-trash"></i>
                                                    </a>
                                            </td>

                                        </tr>
                                    @endforeach
                                </form>

                            </tbody>
                        </table>

                        {{ $comments->links('pagination::bootstrap-4') }}
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection
