@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title" style="padding: 30px">
                        <h2>Hệ Thống</h2>
                    </div>
                </div>
            </div>
            <!-- row -->
            <div class="row column1">
                <div class="col-md-12">
                    <div class="white_shd full margin_bottom_30 " style="padding:50px 0px">

                        <div class="full price_table padding_infor_info">
                            <div class="row">

                                <div class="col-md-3">
                                    <button class="system__box"><a href="{{ url('/admin/system/theme') }}">
                                            <i class="icon__box  fas fa-user-shield"></i>
                                            Theme giao diện</a></button>
                                </div>

                               
                                <div class="col-md-3">
                                    <button class="system__box"><a href="{{route('embedhtml')}}">
                                            <i class=" icon__box  fas fa-plus"></i>
                                            Mã Nhúng Website</a></button>
                                </div>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
