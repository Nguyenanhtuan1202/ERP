@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <nav aria-label="breadcrumb" class="mt-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/dashboard') }}">DashBoard</a></li>
                               
                                <li class="breadcrumb-item active" aria-current="page">Cấu Hình</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- row -->
            <form action="{{ url('/system/home/update/setting/' . $data->id) }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row column1">
                    <div class="col-md-12">
                        <div class="white_shd full margin_bottom_30">
                            <div class="full graph_head">
                                <div class="heading1 margin_0">
                                    <h2>Cấu Hình
                                    </h2>
                                    @if (session('status'))
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            {{ session('status') }}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="full price_table padding_infor_info">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group" id="show__seo">
                                            <div class="row">
                                                <div class="col-md-6 div_meta_title  show">
                                                    <div class="form-group">

                                                        <label class="meta_seo">Tiêu đề của trang
                                                        </label>

                                                        @error('meta_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="meta_seo" type="text" size="50" maxlength="150"
                                                            value="{{ $data->meta_seo }}" class="form-control "
                                                            placeholder="" id="meta_seo">
                                                        <p class="des_i">Ví dụ: giới thiêu | gioi thieu</p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 div_meta_key  show">
                                                    <div class="form-group">
                                                        <label class="key_seo">Từ khóa trên công cụ tìm kiếm
                                                        </label>
                                                        @error('key_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="key_seo" type="text" size="50" maxlength="150"
                                                            value="{{ $data->key_seo ?? '' }}" class="form-control "
                                                            placeholder="" id="key_seo">
                                                        <p class="des_i">Ví dụ: giới thiêu, công ty</p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 div_meta_desc  show">
                                                    <div class="form-group">


                                                        <label class="desc_seo">Mô tả trên công cụ tìm kiếm
                                                        </label>
                                                        @error('desc_seo')
                                                            <small class="text-danger">({{ $message }})</small>
                                                        @enderror
                                                        <input name="desc_seo" type="text"
                                                            value="{{ $data->desc_seo ?? '' }}" class="form-control "
                                                            placeholder="" id="desc_seo">
                                                        <p class="des_i">Không nên nhập quá 200 chữ và cần có từ khóa cần
                                                            seo
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">

                                        <div class="form-group group__banner">
                                            <label for="">Số tin trong danh sách</label>
                                            <select name="num_list" class="form-control" name="" id="">
                                                @for ($i = 1; $i <= 20; $i++)
                                                    <option {{ $data->num_list == $i ? 'selected' : '' }}
                                                        value="{{ $i }}">{{ $i }}</option>
                                                @endfor
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group group__banner">
                                            <label for="">Số tin khác</label>
                                            <select name="num_list_orther" class="form-control" name=""
                                                id="">
                                                @for ($j = 1; $j <= 20; $j++)
                                                    <option {{ $data->num_list_orther == $j ? 'selected' : '' }}
                                                        value="{{ $j }}">{{ $j }}</option>
                                                @endfor
                                            </select>
                                        </div>
                                    </div>


                                    <div class="col-md-12">
                                        <div class="form-group">
                                            @error('content')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="ckeditor">Nội Dung</label>
                                            <textarea name="content" class="form-control ckeditor" id="ckeditor" cols="30" rows="3">{!! $data->content !!}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn__add">Cập Nhật <i class="fas fa-save"></i></button>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
            </form>
        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
