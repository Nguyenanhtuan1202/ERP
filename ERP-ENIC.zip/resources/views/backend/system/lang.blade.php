@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Ngôn Ngữ</h2>
                    </div>
                </div>
            </div>
            <!-- row -->
            <div class="row column1">
                <div class="col-md-12">
                    <div class="white_shd full margin_bottom_30">

                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        <div class="full price_table padding_infor_info">
                            <form action="{{ url('/system/save/lang') }}" method="POST">
                                @csrf
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            @error('lang_key')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="exampleInputEmail1">Key</label>
                                            <input type="text" name="lang_key" class="form-control"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                placeholder="Enter Key">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            @error('lang_value')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="exampleInputPassword1">Value</label>
                                            <input type="text" name="lang_value" class="form-control"
                                                id="exampleInputPassword1" placeholder="Enter Value">
                                        </div>
                                    </div>
                                    <div class="col-md-12"> <button type="submit" class="btn btn-success">Thêm Mới</button>
                                    </div>

                                </div>
                            </form>


                            <div class="mt-5">
                                @foreach ($data as $item)
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">{{ $item->lang_key }}</span>
                                        </div>
                                        <div class="custom-file">
                                            <input type="text" class="form-control" placeholder="" aria-label=""
                                                aria-describedby="basic-addon1" value="{{ $item->lang_value }}">

                                        </div>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary button__delete" type="button"><a
                                                    class="text-white"
                                                    href="{{ url('/system/lang/delete/' . $item->id) }}">Xoá</a> </button>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
