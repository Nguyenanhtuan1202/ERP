@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Nhúng mã vào website</h2>
                    </div>
                </div>
            </div>
            <!-- row -->
            <div class="row column1">
                <div class="col-md-12">
                    <div class="white_shd full margin_bottom_30">

                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif



                        <form class="card padding" action="{{ url('/admin/system/embedhtml/update/' . $data->id )}}" method="post">
                            {{ csrf_field() }}
                            <div class="row" style="padding: 20px !important">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="">Nhúng vào sau phần &lt;head&gt;</label>
                                        <textarea style="height: 200px !important" class="form-control" rows="3" name="embedcode_head_begin">
                                            {!! html_entity_decode($data->embedcode_head_begin) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">

                                        <label class="">Nhúng vào trước phần &lt;/head&gt;</label>

                                        <textarea style="height: 200px !important" class="form-control " rows="3" name="embedcode_head">

                                            {!! html_entity_decode($data->embedcode_head) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">

                                        <label class="">Nhúng vào sau phần &lt;body&gt;</label>

                                        <textarea style="height: 200px !important" class="form-control " rows="3" name="embedcode_body_begin">
                                            {!! html_entity_decode($data->embedcode_body_begin) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">

                                        <label class="">Nhúng vào trước phần &lt;/body&gt;. Nên nhúng code google
                                            analytics, code box chat ở phần này</label>

                                        <textarea style="height: 200px !important" class="form-control " cols="30" rows="10" name="embedcode_body">
                                            {!! html_entity_decode($data->embedcode_body) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn_save" type="submit">Hoàn tất</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
