@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Theme giao diện</h2>
                    </div>
                </div>
            </div>
            <!-- row -->
            <div class="row " >
                <div class="col-md-12">
                    <div class="white_shd full margin_bottom_30">

                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        <form class="card padding" action="{{ url('/admin/system/theme/update/' . $data->id )}}" method="post">
                            {{ csrf_field() }}
                            <div class="row" style="padding: 20px !important">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="">HTML</label>
                                        <textarea style="height: 200px !important" class="form-control" rows="3" name="html">
                                            {!! html_entity_decode($data->html) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="">CSS</label>
                                        <textarea style="height: 200px !important" class="form-control" rows="3" name="css">
                                            {!! html_entity_decode($data->css) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="">JAVASCRIPT</label>
                                        <textarea style="height: 200px !important" class="form-control" rows="3" name="javascript">
                                            {!! html_entity_decode($data->javascript) !!}
                                        </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn_save" type="submit">Hoàn tất</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
