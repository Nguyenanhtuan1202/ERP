@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">
                <div class="col-md-12">
                    <div class="page_title">
                        <h2>Thư Viện Hình Ảnh</h2>
                    </div>
                </div>

                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=project"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Dự Án
                        </div>
                    </a>
                </div>
                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=arch"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Kiến Trúc
                        </div>
                    </a>
                </div>
                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=furniture"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Nội Thất
                        </div>
                    </a>
                </div>
                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=landscape"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                LandScape
                        </div>
                    </a>
                </div>
                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=material"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Vật Liệu
                        </div>
                    </a>
                </div>
                <div class="col-md-2">
                    <a href="{{url('system/gallery'). "?act=recommend"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Tìm Kiếm Ý Tưởng
                        </div>
                    </a>
                </div>


                <div class="col-md-2 mt-5">
                    <a href="{{url('system/gallery'). "?act=post"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Tin Tức
                        </div>
                    </a>
                </div>
                

                <div class="col-md-2 mt-5">
                    <a href="{{url('system/gallery'). "?act=params"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Hệ Thống
                        </div>
                    </a>
                </div>

                <div class="col-md-2 mt-5">
                    <a href="{{url('system/gallery'). "?act=banner"}}" class="item__folder">
                        <img src="{{asset('uploads/folder.png')}}" alt="">
                        <div class="folder__box">
                                Banner
                        </div>
                    </a>
                </div>
            </div>
            <!-- row -->

            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection

