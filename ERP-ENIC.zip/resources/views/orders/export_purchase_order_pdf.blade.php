<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Purchase Order - {{ $orderData['order_code'] ?? 'N/A' }}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');


        body {
            font-family: 'Inter', Arial, sans-serif;
            font-size: 10px;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.2;
        }

        /* Prevent word wrapping */
        .nowrap {
            white-space: nowrap !important;
        }

        .container {
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 15px;
            width: 100%;
        }

        .header h2 {
            font-size: 20px;
            margin: 0 0 5px 0;
            color: #2c3e50;
        }

        .divider {
            border-top: 1px solid #333;
            margin: 10px 0;
        }

        .company-details {
            width: 100%;
            margin-bottom: 15px;
        }

        .company-box {
            display: inline-block;
            width: 48%;
            padding: 5px;
            vertical-align: top;
        }

        .company-box h3 {
            margin: 0 0 5px 0;
            padding: 0;
            font-size: 12px;
            color: #2c3e50;
        }

        .company-info {
            margin: 2px 0;
            font-size: 13px;
        }

        .company-label {
            display: inline-block;
            width: 60px;
            font-weight: bold;
        }

        .order-summary {
            margin-bottom: 15px;
            background-color: #f5f9fc;
            padding: 5px;
            border-left: 3px solid #3498db;
        }

        .order-info {
            margin: 2px 0;
        }

        .order-label {
            display: inline-block;
            width: 120px;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 9px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            text-align: center;
            padding: 4px 2px;
        }

        td {
            padding: 4px 2px;
            text-align: center;
            vertical-align: middle;
        }

        .product-image {
            width: 70px;
            height: 70px;
        }

        .totals {
            text-align: right;
        }

        .totals p {
            margin: 2px 0;
        }

        .signature-section {
            margin-top: 30px;
            width: 100%;
        }

        .signature-box {
            display: inline-block;
            width: 45%;
            text-align: center;
        }

        .signature-line {
            border-top: 1px solid #333;
            margin-top: 40px;
            padding-top: 5px;
        }

        .footer {
            margin-top: 15px;
            text-align: center;
            font-size: 8px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container">


        {{-- {{dd($orderData)}} --}}

        <div class="header">

            <div style="width: 100%; margin-bottom: 20px;">
                <!-- Logo and Title Row -->
                <div style="display: flex;  align-items: center; margin-bottom: 15px;">
                    <div style="align-self: flex-start; margin-bottom: 10px;">
                        <img style="width: 150px; height: auto;" src="{{ public_path('erp/enic.png') }}" alt="Enic">
                    </div>
                    <h1 style="font-size: 24px; font-weight: bold;  margin: 0; text-align: center; width: 100%;">
                        PURCHASE ORDER</h1>
                </div>

                <div style="display: flex; justify-content: space-between;">
                    PO Number: {{ $orderData['order_code'] ?? 'update' }} | Date:
                    {{ date('d-m-Y', strtotime($orderData['order_date'] ?? '2025-03-24')) }}
                </div>

            </div>



        </div>

        <div class="divider"></div>

        <div class="company-details">
            <div class="company-box">
                <h3>Buyer</h3>
                <p class="company-info">
                    {{ $orderData['name__company'] ?? '' }}</p>
                <p class="company-info">
                    {{ $orderData['address__company'] ?? '' }}
                </p>
            </div>

            <div class="company-box">
                <h3>Vendor</h3>
                <p class="company-info">
                    {{ $orderData['supplier_name'] ?? '' }}
                </p>
                <p class="company-info">
                    {{ $orderData['supplier']->address ?? '' }}</p>
            </div>
        </div>



        <table>
            <thead>
                <tr>
                    <th style="width: 30px;">No.</th>
                    <th style="width: 100px;">Image</th>
                    <th>Standard Key</th>
                    <th style="width: 80px;">SKU</th>
                    <th style="width: 60px;">Quantity</th>
                    <th style="width: 60px;">Price</th>
                    <th style="width: 60px;">Total</th>
                    <th style="width: 60px;">Unit</th>
                    <th style="width: 70px;">Note</th>
                </tr>
            </thead>
            <tbody>
                @php $i = 1; @endphp
                @foreach ($orderData['items'] as $item)
                    <tr>
                        <td>{{ $i++ }}</td>
                        <td class="image-cell">
                            <img class="product-image"
                                src="{{ public_path('uploads/forecast_products/' . ($item['image'] ?? '')) }}"
                                alt="No image">
                        </td>
                        <td>{{ $item['product_name'] ?? '' }}</td>
                        <td>{{ $item['sku'] ?? '' }}</td>
                        <td>{{ $item['quantity'] ?? '' }}</td>
                        <td>{{ number_format($item['price'], 2) }}</td>
                        <td>{{ number_format($item['total'], 2) }}</td>
                        <td>{{ $item['unitPrice'] ?? '' }}</td>
                        <td>{{ $item['note'] ?? '' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <p style="font-size: 13px;margin: 2px 0; font-weight: 600">Note:</p>
                <p style="font-size: 13px;margin: 2px 0">{{ $orderData['note__custom'] ?? '' }}</p>
            </div>
            <div class="totals">
                <p><strong>Total Quantity:</strong>
                    {{ $orderData['total_quantity'] ?? 'N/A' }}</p>
                <p><strong>Subtotal:</strong> {{ $orderData['subtotal'] }}</p>
                @if ($orderData['deposit'] > 0)
                    <p><strong>Deposit Percentage:</strong> {{ $orderData['deposit'] ?? '0' }}</p>
                    <p><strong>Remaining Balance:</strong> {{ number_format($orderData['grand_total'], 2) }}</p>
                @else
                @endif

            </div>
        </div>
        {{-- <div class="signature-section">
            <div class="signature-box">
                <div class="signature-line">Authorized By (Buyer)</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">Accepted By (Vendor)</div>
            </div>
        </div> --}}

        <div class="footer">
            <p>This purchase order is subject to the terms and conditions as agreed upon by both parties.</p>
        </div>
    </div>
</body>

</html>
