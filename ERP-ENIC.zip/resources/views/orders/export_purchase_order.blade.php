<table>
    <tr>
        <td colspan="9" style="text-align: center; font-size: 18px;"><strong>Purchase Order (采购订单)</strong></td>
    </tr>
    <tr>
        <td colspan="4"><strong>PO Number:</strong> {{ $order_code }}</td>
        <td colspan="5"><strong>Date:</strong> {{ $order_date }}</td>
    </tr>
    <tr>
        <td colspan="9"><strong>Total Quantity:</strong> {{ $total_quantity }}</td>
    </tr>
    <tr>
        <th>No.</th>
        <th>Product Name</th>
        <th>SKU</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Size</th>
        <th>Color</th>
        <th>Specifications</th>
        <th>Packaging</th>
    </tr>
    @php $i = 1; @endphp
    @foreach ($items as $item)
        <tr>
            <td>{{ $i++ }}</td>
            <td>{{ $item['product_name']   ?? ""}}</td>
            <td>{{ $item['sku']  ?? "" }}</td>
            <td>{{ $item['quantity']  ?? "" }}</td>
            <td>{{ $item['price']  ?? "" }}</td>
            <td>{{ $item['size']  ?? "" }}</td>
            <td>{{ $item['color']  ?? "" }}</td>
            <td>{{ $item['product_specifications'] ?? "" }}</td>
            <td>{{ $item['packaging'] ?? "" }}</td>
        </tr>
    @endforeach
    <tr>
        <td colspan="9"><strong>Subtotal:</strong> {{ $subtotal  ?? "" }}</td>
    </tr>
    <tr>
        <td colspan="9"><strong>Deposit:</strong> {{ $deposit  ?? "" }}</td>
    </tr>
    <tr>
        <td colspan="9"><strong>Grand Total:</strong> {{ $grand_total  ?? "" }}</td>
    </tr>
</table>
