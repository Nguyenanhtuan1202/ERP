@extends('layouts.enic')
@section('content')
    <style>
        /* Modern Card and Table Styling */
        .dashboard-container {
            padding: 25px;
            margin-top: 80px;
        }

        .card-dashboard {
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            background: #fff;
            transition: all 0.3s ease;
            border: none;
            overflow: hidden;
        }

        .card-dashboard:hover {
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.12);
            transform: translateY(-3px);
        }

        .card-header-custom {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            color: white;
            padding: 20px 25px;
            border-bottom: none;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .title__highlight {
            margin: 0;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.4rem;
        }

        .title__highlight i {
            font-size: 1.6rem;
        }


        .table__customs {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 5px;
        }

        .thead__custom th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 15px 10px;
            border: none;
            white-space: nowrap;
        }

        .table__customs tbody tr {
            transition: all 0.2s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.03);
            border-radius: 8px;
        }

        .table__customs tbody tr:hover {
            background-color: #f8f9fa;
            transform: translateY(-1px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
        }

        .table__customs td {
            padding: 15px 10px;
            border-top: 1px solid #f3f3f3;
            vertical-align: middle;
            font-size: 0.9rem;
            color: #495057;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 500;
            display: inline-block;
            min-width: 100px;
        }



        .badge-success {
            background-color: #c6f6d5;
            color: #2f855a;
        }

        .order-code {
            font-weight: 600;
            color: #2d3748;
        }


        /* Advanced Search Filter Styling */
        .advanced-search-container {
            background: linear-gradient(to right, #fff, #fff);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05), 0 5px 10px rgba(0, 0, 0, 0.02);
            border: 1px solid #e6e6e6;
        }

        .advanced-search-container .filter-label {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }

        .advanced-search-container .input-group {
            position: relative;
            border-radius: 8px;
            overflow: hidden;
        }

        .advanced-search-container .input-group-text {
            background-color: #fff;
            border: none;
            color: #495057;
            padding: 0.575rem 0.75rem;
            transition: background-color 0.3s ease;
        }

        .advanced-search-container .form-control {
            border: 1px solid #17a2b8 !important;
        }

        .advanced-search-container .form-control,
        .advanced-search-container .form-select {
            background-color: white;
            border: 1px solid #ced4da;
            border-radius: 8px;
            padding: 0.675rem 0.75rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .advanced-search-container .form-control:focus,
        .advanced-search-container .form-select:focus {
            border-color: #3498db;
            box-shadow:
                0 0 0 3px rgba(52, 152, 219, 0.15),
                0 2px 4px rgba(0, 0, 0, 0.08);
            outline: none;
        }

        .advanced-search-container .input-group-text i {
            color: #3498db;
            font-size: 1rem;
            transition: color 0.3s ease;
        }

        .advanced-search-container .input-group:hover .input-group-text {
            background-color: #e9ecef;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .advanced-search-container {
                padding: 15px;
            }

            .advanced-search-container [class^="col-"] {
                margin-bottom: 15px;
            }
        }

        /* Subtle Hover Effect */
        .advanced-search-container .form-control,
        .advanced-search-container .form-select {
            transition: transform 0.2s ease;
        }

        .advanced-search-container .form-control:hover,
        .advanced-search-container .form-select:hover {
            transform: translateY(-2px);

        }

        .delete__filter {
            width: 120px;
            padding: 7px;
            background-color: #dc3545;
            border: none;
            border-radius: 8px;
            /* padding: 0.675rem 0.75rem; */
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            text-align: center;
            cursor: pointer;
        }

        .wrapper__listOrder {
            padding: 10px 10px;
            margin-top: 100px;
        }
    </style>

    <div class="wrapper__listOrder">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ url('/') }}">Dash Board</a></li>
                <li class="breadcrumb-item"><a href="{{ route('orders.getOrdersByUser') }}">Danh sách</a></li>
                <li class="breadcrumb-item" aria-current="page"> <a href="{{ route('orders.import') }}">Thêm Mới</a> </li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">
                        <h3 class="title__highlight" style="text-transform: capitalize">
                            <i class="fas fa-desktop"></i> Danh sách đơn đặt hàng
                        </h3>

                        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px">

                        </div>

                        @if (session('success'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('success') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>

                    <div class="advanced-search-container row my-3 mx-2">
                        <div class="col-md-3">
                            <label class="filter-label" for="">Bộ Lọc Thanh Toán</label>
                            <div class="input-group">
                                <select id="is_paid" class="form-select form-control is_paid">
                                    <option value="">Chọn</option>
                                    <option value="0">Chưa Thanh Toán Đủ</option>
                                    <option value="1">Đã Thanh Toán Đủ</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label class="filter-label" for="">Bộ Lọc Trạng Thái Đơn Hàng</label>
                            <div class="input-group">
                                <select id="status" class="form-select form-control status">
                                    <option value="">Chọn</option>
                                    <option value="0">Chưa Hoàn Thành</option>
                                    <option value="1">Hoàn thành</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label class="filter-label" for="">Bộ Lọc Ngày Đặt Hàng</label>
                            <div class="input-group">

                                <input type="date" id="order_date" class="form-control">
                            </div>
                        </div>

                        <div class="col-md-3">
                            <label class="filter-label" for="">Xoá Bộ Lọc</label>
                            <div class="delete__filter">
                                <button type="button"
                                    style="background: transparent; font-size: 18px; border:none; color: #fff;"><i
                                        class="fas fa-trash-alt"></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid py-4">
                        <div class="row">
                            <div class="col-12">


                                <div class="card mb-4">



                                    <!-- Đơn hàng đã hoàn thành -->
                                    <div class="card-body px-0 pt-0 pb-2">
                                        <div class="table-responsive p-0">
                                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                                <thead class="thead__custom">
                                                    <tr>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                                            STT</th>
                                                        <th style="font-size: 12px"
                                                            class="text-center text-uppercase text-sm font-weight-bolder opacity-7">
                                                            Nhà Cung Cấp</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                                            Mã đơn hàng</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Ngày Đặt Hàng</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Số Lượng</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Đặt Cọc</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Đã Thanh Toán</th>
                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Chưa Thanh Toán</th>

                                                        <th style="font-size: 12px"
                                                            class="text-uppercase text-sm font-weight-bolder opacity-7 ps-2">
                                                            Trạng Thái Đơn</th>
                                                        <th style="font-size: 12px"
                                                            class="text-center text-uppercase text-sm font-weight-bolder opacity-7">
                                                            Quản Lý</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                        $temp = 0;
                                                    @endphp

                                                    @foreach ($data as $item)
                                                        @php
                                                            $temp++;
                                                            $totalPayment = $item->totalPayment();
                                                            $totalImportCost = $item->totalImportCost()
                                                                ? $item->totalImportCost()
                                                                : 0;
                                                            $subtotal = $item->subtotal + $totalImportCost;
                                                            $debt = $subtotal - $totalPayment;
                                                            $totalAllPayments = $item->subtotal + $totalImportCost;
                                                        @endphp

                                                        <tr>
                                                            <td class="align-middle text-center">
                                                                {{ $temp }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                {{ $item->supplier->sp_code ?? '' }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                <span
                                                                    class="order-code">{{ $item->order_code ?? '' }}</span>
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                {{ date('d-m-Y', strtotime($item->order_date ?? '')) }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                {{ $item->total_quantity ?? '' }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                {{ $item->deposit ?? '' }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                {{ number_format($item->totalPayment(), 2, '.', ',') }}
                                                            </td>
                                                            <td class="align-middle text-center">
                                                                @if ($debt == 0)
                                                                    <span class="text-success"
                                                                        style="font-size: 14px; font-weight: 600">{{ number_format($debt, 2, '.', ',') }}</span>
                                                                @else
                                                                    <span class="text-danger"
                                                                        style="font-size: 14px; font-weight: 600">{{ number_format($debt, 2, '.', ',') }}</span>
                                                                @endif
                                                            </td>

                                                            <td class="align-middle text-center">

                                                                @if ($item->status == 1)
                                                                    <span class="badge badge-success" style="padding: 10px">
                                                                        <i class="fas fa-check"></i> Hoàn Thành
                                                                    </span>
                                                                @else
                                                                    <span class="badge badge-danger" style="padding: 10px">
                                                                        <i class="fas fa-times-circle"></i> Chưa Hoàn
                                                                        Thành
                                                                    </span>
                                                                @endif
                                                            </td>
                                                            <td class="align-middle">
                                                                <a href="{{ route('detailOrder', ['id' => $item->id]) }}"
                                                                    class="btn btn-info btn-sm">
                                                                    <i class="fas fa-eye"></i> <!-- Icon Xem -->
                                                                </a>
                                                                {{-- <a onclick="return confirm('Bạn có muốn xóa đơn hàng này không ?')"
                                                                    href="{{ route('deleteDetailOrder', ['id' => $item->id]) }}"
                                                                    class="btn btn-danger btn-sm">
                                                                    <i class="fas fa-trash-alt"></i> <!-- Icon Xóa -->
                                                                </a> --}}
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
@endsection


@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get filter elements
            const isPaidFilter = document.getElementById('is_paid');
            const statusFilter = document.getElementById('status');
            const orderDateFilter = document.getElementById('order_date');

            // Function to update URL with current filter values
            function updateUrlFilters() {
                // Get current URL
                let url = new URL(window.location.href);

                // Update or remove query parameters based on filter values
                if (isPaidFilter.value) {
                    url.searchParams.set('is_paid', isPaidFilter.value);
                } else {
                    url.searchParams.delete('is_paid');
                }

                if (statusFilter.value) {
                    url.searchParams.set('status', statusFilter.value);
                } else {
                    url.searchParams.delete('status');
                }

                if (orderDateFilter.value) {
                    url.searchParams.set('order_date', orderDateFilter.value);
                } else {
                    url.searchParams.delete('order_date');
                }
                // Redirect to the new URL
                window.location.href = url.toString();
            }
            // Add event listeners to filters
            isPaidFilter.addEventListener('change', updateUrlFilters);
            statusFilter.addEventListener('change', updateUrlFilters);
            orderDateFilter.addEventListener('change', updateUrlFilters);

            // On page load, set filter values from URL if they exist
            function initializeFiltersFromUrl() {
                const urlParams = new URLSearchParams(window.location.search);

                // Set is_paid filter
                if (urlParams.has('is_paid')) {
                    isPaidFilter.value = urlParams.get('is_paid');
                }

                // Set status filter
                if (urlParams.has('status')) {
                    statusFilter.value = urlParams.get('status');
                }

                // Set order_date filter
                if (urlParams.has('order_date')) {
                    orderDateFilter.value = urlParams.get('order_date');
                }
            }

            // Initialize filters from URL
            initializeFiltersFromUrl();
        });


        $(function() {
            $(".delete__filter").on("click", function() {
                window.location.href = "{{ route('orders.getOrdersByUser') }}";
            });
        });
    </script>
@endsection
