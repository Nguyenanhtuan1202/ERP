@extends('layouts.enic')
<meta name="csrf-token" content="{{ csrf_token() }}">
@section('content')
    <style>
        /* Modern Purchase Order CSS - Enhanced with animations and effects */
        body {
            color: #1e293b;
            background-color: #f8fafc;
        }

        /* Container Purchase Order - Enhanced */
        .purchase-order-preview {
            max-width: 100%;
            margin: 40px auto;
            padding: 40px;
            background-color: #fff;
            border: none;
            border-radius: 1rem;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .purchase-order-preview::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 8px;
            background: linear-gradient(90deg, #21216d 0%, #7c3aed 100%);
        }



        /* Header styles - Enhanced */
        .purchase-order-preview .header {
            text-align: center;
            margin-bottom: 35px;
            position: relative;
            padding-bottom: 25px;
        }

        .purchase-order-preview .header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, #21216d 0%, #21216d 100%);
            border-radius: 4px;
        }

        .purchase-order-preview .header h2 {
            font-size: 38px;
            color: #1e293b;
            margin-bottom: 15px;
            font-weight: 700;
            letter-spacing: -0.5px;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .purchase-order-preview .header p {
            font-size: 17px;
            color: #64748b;
            margin: 4px 0;
            transition: all 0.2s ease;
        }

        .purchase-order-preview .header p strong {
            color: #21216d;
            font-weight: 600;
        }

        /* Order Summary - Enhanced */
        .purchase-order-preview .order-summary {
            margin-bottom: 30px;
            font-size: 18px;
            color: #1e293b;
            padding: 15px 20px;
            background-color: #f1f5f9;
            border-radius: 0.5rem;
            border-left: 4px solid #21216d;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .purchase-order-preview .order-summary p {
            margin: 0;
        }

        .purchase-order-preview .order-summary .label {
            font-weight: 600;
            color: #21216d;
        }

        /* Table styles - Enhanced */
        .purchase-order-preview table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 35px;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .purchase-order-preview table th,
        .purchase-order-preview table td {
            padding: 16px;
            font-size: 15px;
            text-align: center;
            border: none;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: middle;
        }

        .purchase-order-preview table th {
            background: linear-gradient(to right, #21216d, #21216d);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 14px;
            position: relative;
        }

        .purchase-order-preview table th:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 20%;
            right: 0;
            height: 60%;
            width: 1px;
            background-color: rgba(255, 255, 255, 0.2);
        }

        .purchase-order-preview table tr:nth-child(even) {
            background-color: #f1f5f9;
        }

        .purchase-order-preview table tr:hover {
            background-color: rgba(59, 130, 246, 0.05);
        }

        .purchase-order-preview table tr:last-child td {
            border-bottom: none;
        }

        .purchase-order-preview table tr td:first-child {
            font-weight: 600;
            color: #21216d;
        }

        .purchase-order-preview table td img {
            transition: all 0.3s ease;
            border-radius: 0.25rem;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            object-fit: cover;
        }

        .purchase-order-preview table td img:hover {

            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        /* Input fields in table - Enhanced */
        .purchase-order-preview table td input[type="text"],
        .purchase-order-preview table td select,
        .purchase-order-preview table td input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 14px;
            text-align: center;
            transition: all 0.2s ease;
            background-color: white;
        }

        .purchase-order-preview table td input[type="text"]:focus,
        .purchase-order-preview table td input[type="number"]:focus {
            border-color: #21216d;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .purchase-order-preview table td input[readonly] {
            background-color: #f1f5f9;
        }

        /* Totals and Deposit Section - Enhanced */
        .purchase-order-preview .totals {
            font-size: 16px;
            margin-bottom: 30px;
            text-align: right;
            line-height: 2;
            padding: 20px;
            background-color: #f1f5f9;
            border-radius: 0.5rem;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .purchase-order-preview .totals span.label {
            font-weight: 600;
            margin-right: 10px;
            color: #1e293b;
        }

        .purchase-order-preview .totals input#deposit,
        .purchase-order-preview .totals .customer_input {
            width: 200px;
            padding: 10px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 15px;
            text-align: center;
            transition: all 0.2s ease;
        }

        .purchase-order-preview .totals input#deposit:focus,
        .purchase-order-preview .totals .customer_input:focus {
            border-color: #21216d;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .purchase-order-preview .totals input[readonly] {
            background-color: #fff;
            color: #21216d;
            font-weight: 600;
        }

        .purchase-order-preview .totals p:last-child {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px dashed #cbd5e1;
            font-size: 18px;
        }

        .purchase-order-preview .totals p:last-child .label,
        .purchase-order-preview .totals p:last-child input {
            color: #21216d;
            font-weight: 700;
        }

        /* Note Custom - Enhanced */
        .note__custom {
            background: linear-gradient(135deg, #ffd700, #ffbf02eb);
            border: 2px dashed #111;
            color: #111;
            border-radius: 0.5rem;
            width: 100%;
            height: 130px;
            padding: 12px 15px;
            font-size: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            resize: none;
        }

        .note__custom:focus {
            border-color: #21216d;
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 191, 2, 0.3);
        }

        /* Supplier Selection - Enhanced */
        .select3_init {
            padding: 12px;
            border-radius: 0.5rem;
            border: 1px solid #cbd5e1;
            width: 100%;
            font-size: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .select3_init:focus {
            border-color: #21216d;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: #1e293b;
            font-weight: 700;
            font-size: 20px;
            position: relative;
            padding-left: 15px;
        }

        .form-group label::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 18px;
            background-color: #21216d;
            border-radius: 3px;
        }

        /* Print Order Button - Enhanced */
        .print__order {
            background: linear-gradient(to right, #0891b2, #06b6d4);
            border: none;
            padding: 14px 22px;
            border-radius: 0.5rem;
            color: #fff;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .print__order:hover {
            background: linear-gradient(to right, #0e7490, #0891b2);
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .print__order:active {
            transform: translateY(0);
        }

        .print__order i {
            font-size: 18px;
        }

        /* Confirm Button - Enhanced */
        .purchase-order-preview .confirm {
            text-align: center;
            padding: 35px 20px;
            margin-top: 40px;
            position: relative;
        }

        .purchase-order-preview .confirm::before {
            content: '';
            position: absolute;
            top: 0;
            left: 10%;
            right: 10%;
            height: 1px;
            background: linear-gradient(90deg,
                    transparent 0%,
                    #cbd5e1 20%,
                    #cbd5e1 80%,
                    transparent 100%);
        }

        .purchase-order-preview .confirm button {
            padding: 15px 35px;
            font-size: 18px;
            color: #fff;
            background: linear-gradient(135deg, #0caf60, #059669);
            box-shadow: 0 8px 15px -3px rgba(12, 175, 96, 0.4);
            border-radius: 0.5rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            position: relative;
            overflow: hidden;
        }

        .purchase-order-preview .confirm button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg,
                    transparent 0%,
                    rgba(255, 255, 255, 0.2) 50%,
                    transparent 100%);
            transition: all 0.5s ease;
        }

        .purchase-order-preview .confirm button:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 20px -7px rgba(12, 175, 96, 0.5);
        }

        .purchase-order-preview .confirm button:hover::before {
            left: 100%;
        }



        .purchase-order-preview .confirm button i {
            font-size: 20px;
        }

        /* Modal PDF Preview - Enhanced */

        #pdfModal .modal-dialog {
            max-width: 90%;
            margin: 40px auto;
        }

        #pdfModal .modal-content {
            border-radius: 1rem;
            overflow: hidden;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            border: none;
        }

        /* Header of Modal - Enhanced */
        #pdfModal .modal-header {
            background: linear-gradient(135deg, #21216d, #7c3aed);
            color: #fff;
            padding: 25px 30px;
            border-bottom: none;
            position: relative;
        }

        #pdfModal .modal-header .modal-title {
            font-size: 28px;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        #pdfModal .modal-header .modal-title::before {
            content: '\f1c1';
            font-family: 'Font Awesome 5 Free';
            font-weight: 400;
            font-size: 24px;
        }

        #pdfModal .modal-header .btn-close {
            background: transparent;
            border: none;
            color: #fff;
            font-size: 26px;
            opacity: 0.9;
            transition: all 0.2s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        #pdfModal .modal-header .btn-close:hover {
            opacity: 1;
            background-color: rgba(255, 255, 255, 0.1);
            transform: rotate(90deg);
        }

        /* Body of Modal - Enhanced */
        #pdfModal .modal-body {
            padding: 0;
            background-color: #f8fafc;
        }

        #pdfModal .modal-body iframe {
            display: block;
            width: 100%;
            height: 650px;
            border: none;
        }

        /* Custom animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(12, 175, 96, 0.7);
            }

            70% {
                box-shadow: 0 0 0 15px rgba(12, 175, 96, 0);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(12, 175, 96, 0);
            }
        }

        /* Apply animations */
        .purchase-order-preview {
            animation: fadeIn 0.5s ease-out;
        }

        .purchase-order-preview .header {
            animation: slideInLeft 0.5s ease-out;
        }

        .purchase-order-preview .confirm button:focus {
            animation: pulse 1.5s infinite;
        }

        /* Table Row Animation */
        .purchase-order-preview table tbody tr {
            transition: all 0.3s ease;
            transform-origin: center;
        }



        /* Responsive adjustments */
        @media (max-width: 992px) {
            .purchase-order-preview {
                padding: 30px 20px;
            }

            .purchase-order-preview .header h2 {
                font-size: 32px;
            }

            .purchase-order-preview table th,
            .purchase-order-preview table td {
                padding: 12px 8px;
            }

            .purchase-order-preview .confirm button {
                padding: 12px 24px;
                font-size: 16px;
            }
        }

        @media (max-width: 768px) {
            .purchase-order-preview {
                margin: 20px auto;
                padding: 20px 15px;
            }

            .purchase-order-preview .header {
                margin-bottom: 25px;
            }

            .purchase-order-preview .header h2 {
                font-size: 28px;
            }

            .purchase-order-preview table th,
            .purchase-order-preview table td {
                font-size: 12px;
                padding: 8px 4px;
            }

            .purchase-order-preview .totals {
                font-size: 14px;
                padding: 15px;
            }

            .purchase-order-preview .totals input#deposit,
            .purchase-order-preview .totals .customer_input {
                width: 150px;
            }

            .print__order,
            .purchase-order-preview .confirm button {
                width: 100%;
                margin-bottom: 10px;
            }

            #pdfModal .modal-dialog {
                max-width: 95%;
                margin: 10px auto;
            }

            #pdfModal .modal-body iframe {
                height: 500px;
            }
        }

        /* Special effects for table - zebra striping with hover */
        .purchase-order-preview table tbody tr:nth-child(odd) {
            background-color: #fff;
        }

        .purchase-order-preview table tbody tr:nth-child(even) {
            background-color: #f8fafc;
        }



        /* Subtle hover effect for buttons */
        .purchase-order-preview button:hover {
            letter-spacing: 0.5px;
        }

        /* Grow effect for images */
        .purchase-order-preview table td img {
            transition: transform 0.3s ease;
        }

        .purchase-order-preview table td img:hover {

            z-index: 5;
        }

        #address_company {
            width: 100%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 0.25rem;
            font-size: 14px;
            text-align: left;
            transition: all 0.2s ease;
            background-color: white;
            outline: none;
        }
    </style>


    <div class="container-fluid">
        <div class="purchase-order-preview">
            <!-- Header Purchase Order -->
            <div class="header">
                <h2>Purchase Order</h2>
                <p>PO Number: <strong>{{ $order->order_code ?? '' }}</strong></p>
                <p>Date:
                    <strong>{{ isset($order->order_date) ? date('d/m/Y', strtotime($order->order_date)) : date('d/m/Y') }}</strong>

                </p>
            </div>

            <!-- Order Summary -->
            <div class="order-summary">
                <p><span class="label">Total Quantity:</span> {{ $order->total_quantity ?? '' }} </p>
            </div>
            <!-- Order Items Table -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Hình Ảnh</th>
                            <th>Key Chuẩn</th>
                            <th>SKU</th>
                            <th>Số Lượng </th>
                            <th>Tiền </th>
                            <th>Đơn Vị</th>
                            <th>Thành Tiền </th>
                            <th>Ghi Chú</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $i = 1; @endphp
                        @foreach ($order->items as $item)
                            <tr>
                                <td>{{ $i++ }}</td>
                                <td>
                                    <img style="width: 150px; height: 150px; object-fit: cover;"
                                        src="{{ asset('uploads/forecast_products/' . $item->image ?? '') }}"
                                        alt="{{ $item->image ?? '' }}">
                                </td>
                                <td> <input readonly style="width: 250px;" type="text" id="product_name"
                                        name="product_name" value="{{ $item->product_name ?? '' }}">

                                    <input type="hidden" name="image" id="image" value="{{ $item->image ?? '' }}">
                                </td>
                                <td> <input type="text" name="sku" id="sku" readonly
                                        value="{{ $item->sku ?? '' }}"> </td>
                                <td style="text-align: right;"> <input type="text" name="quantity" id="quantity"
                                        readonly class="quantity-input" value="{{ $item->quantity ?? '' }}"> </td>
                                <td style="text-align: right;"> <input type="text" name="price" id="price"
                                        class="price-input" value="{{ number_format($item->price ?? 0, 2) }}"> </td>

                                <td style="width: 120px;">
                                    <select name="unit" class="unit" id="unit">
                                        <option value="RMB">RMB</option>
                                        <option value="USD">USD</option>
                                        <option value="VND">VND</option>
                                        <option value="Khác">Khác</option>
                                    </select>
                                </td>

                                <td style="text-align: right;">
                                    <input class="total-input" type="text" name="total" id="total"
                                        value="{{ number_format($item->total ?? 0, 2) }}">
                                </td>
                                <td>
                                    <input type="text" name="noteOrder" class="noteOrder" id="noteOrder" value="">
                                </td>
                            </tr>
                        @endforeach
                        @if ($order->items->isEmpty())
                            <tr>
                                <td colspan="10">No items found.</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>


            <div class="row">
                <div class="col-md-5">
                    <div id="deposit-info"></div>
                    <div class="form-group">
                        <label style="color: #111; font-weight: 700; font-size: 20px;" for="">Chọn Nhà Cung
                            Cấp</label>
                        <select required class="form-control select3_init supplier" name="supplier" id="supplier">
                            @foreach ($list_supplier as $item)
                                <option value="{{ $item->sp_code }}">{{ $item->sp_code ?? '' }} |
                                    {{ $item->company_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="color: #111; font-weight: 700; font-size: 20px;" for="">Chọn Công Ty</label>
                        <select required class="form-control select3_init company_buyer" name="company_buyer"
                            id="company_buyer">
                            <option value="Enic">Enic</option>
                            <option value="Chilux">Chilux</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label style="color: #111; font-weight: 700; font-size: 20px;" for="">Địa Chỉ Công
                            Ty</label>
                        <input type="text" value="" class="address_company" name="address_company"
                            id="address_company" placeholder="(Không bắt buộc)">
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="totals">
                        <div class="">
                            <textarea class="note__custom" name="note" id="note" placeholder="Nhập ghi chú của bạn"></textarea>
                        </div>

                        <p>
                            <span class="label">Tổng Tiền:</span>
                            <input class="customer_input" type="text" name="subtotal" id="subtotal" readonly
                                value="{{ number_format($order->subtotal ?? 0, 2) }}">

                        </p>
                        <p>
                            <span class="label">Cọc (nhập số tiền hoặc %):</span>
                            <input type="text" name="deposit" id="deposit" placeholder="VD 20%">

                        </p>
                        <p>
                            <span class="label">Tiền Cọc Tính Được:</span>
                            <input class="customer_input" type="text" name="calculatedDeposit" readonly
                                id="calculatedDeposit" value="0.00">

                        </p>
                        <p>
                            <span class="label">Còn Lại:</span>
                            <input class="customer_input" type="text" readonly name="remaining_amount"
                                id="remainingAmountInput" value="{{ number_format($order->grand_total ?? 0, 2) }}">

                        </p>
                    </div>
                </div>
            </div>


            <button type="button" class="print__order" onclick="openPdfModalWithData()">Xem Đơn Hàng <i
                    class="fas fa-print"></i></button>

            <!-- Confirm Button -->
            <div class="confirm">
                <button type="button" id="confirmOrderNew">Lưu Đơn Hàng <i class="far fa-save"></i></button>
            </div>

        </div>
    </div>

    {{-- Đơn hàng PDF --}}
    <div class="modal fade" id="pdfModal" tabindex="-1" aria-labelledby="pdfModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="pdfModalLabel">Xem Đơn Hàng PDF </h5>

                </div>
                <div class="modal-body">
                    <iframe id="pdfViewer" width="100%" height="600px" style="border: none;"></iframe>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {

            // Lấy ra tiền cọc của từng nhà cung cấp
            $('#supplier').on('change', function() {
                // Get the selected supplier code
                const supplierCode = $(this).val();

                // Check if a supplier was selected
                if (supplierCode) {
                    // Make the Ajax request
                    $.ajax({
                        url: "{{ route('orders.getDeposit') }}",
                        type: 'POST',
                        data: {
                            sp_code: supplierCode,
                            _token: $('meta[name="csrf-token"]').attr('content')
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success == true) {
                                $('#deposit').val(response.deposit);
                                // Display the deposit amount
                                $('#deposit-info').html(
                                    `<div class="alert alert-info mt-2">Tiền đặt cọc: ${response.deposit}</div>`
                                );
                            } else {
                                $('#deposit').val('');
                                $('#deposit-info').html(
                                    `<div class="alert alert-warning mt-2">${response.message || 'Không có thông tin tiền đặt cọc'}</div>`
                                );
                            }
                        },
                        error: function() {
                            $('#deposit-info').html(
                                '<div class="alert alert-danger mt-2">Lỗi khi lấy thông tin</div>'
                            );
                        }
                    });
                } else {
                    // Clear deposit display if no supplier selected
                    $('#deposit-info').empty();
                }
            });
        });


        // Lấy giá trị tổng tiền ban đầu từ input "subtotal" và lưu vào biến originalGrandTotal
        var originalGrandTotal = parseFloat($('#subtotal').val().replace(/,/g, '')) || 0;

        // Hàm tính lại tổng cho 1 dòng (row) trong bảng
        function recalcRowTotal(row) {
            var quantityVal = row.find('.quantity-input').val() || "";
            var priceVal = row.find('.price-input').val() || "";
            var quantity = parseFloat(quantityVal.replace(/,/g, '')) || 0;
            var price = parseFloat(priceVal.replace(/,/g, '')) || 0;
            var total = quantity * price;
            row.find('.total-input').val(total.toFixed(2));
        }

        // Hàm tính lại tổng tiền (subtotal) cho toàn bộ bảng và cập nhật originalGrandTotal
        function recalcSubtotal() {
            var subtotal = 0;
            $('table tbody tr').each(function() {
                var totalVal = $(this).find('.total-input').val() || "0";
                var total = parseFloat(totalVal.replace(/,/g, '')) || 0;
                subtotal += total;
            });
            $('#subtotal').val(subtotal.toFixed(2));
            // Cập nhật originalGrandTotal với subtotal mới
            originalGrandTotal = subtotal;
            // Cập nhật lại phần cọc và số tiền còn lại dựa trên giá trị deposit hiện tại
            updateCalculations($('#deposit').val());
        }

        // Hàm cập nhật phần tính toán deposit và số tiền còn lại
        function updateCalculations(depositInput) {
            var depositValue = depositInput.trim();
            var depositAmount = 0;

            // Nếu nhập theo dạng phần trăm (ví dụ: "20%")
            if (depositValue.endsWith('%')) {
                var percent = parseFloat(depositValue.slice(0, -1));
                if (!isNaN(percent)) {
                    depositAmount = originalGrandTotal * (percent / 100);
                }
            } else {
                depositAmount = parseFloat(depositValue.replace(/,/g, '')) || 0;
            }

            if (isNaN(depositAmount)) {
                depositAmount = 0;
            }

            var remaining = originalGrandTotal - depositAmount;

            // Cập nhật giao diện: định dạng số theo kiểu "18,297,000" (không có phần thập phân)
            $('#calculatedDeposit').val(depositAmount.toLocaleString('en-US', {
                maximumFractionDigits: 0
            }));
            $('#remainingAmountInput').val(remaining.toLocaleString('en-US', {
                maximumFractionDigits: 0
            }));
        }

        // Khi nhập vào ô giá hoặc số lượng, tính lại Total cho dòng đó và cập nhật Subtotal
        $(document).on('input', '.price-input, .quantity-input', function() {
            var row = $(this).closest('tr');
            recalcRowTotal(row);
            recalcSubtotal();
        });

        // Lắng nghe sự kiện nhập cho ô deposit để tính lại deposit và remaining
        $('#deposit').on('input', function() {
            updateCalculations($(this).val());
        });



        document.addEventListener('DOMContentLoaded', function() {
            // Lấy nút đóng modal
            const closeButton = document.querySelector('#pdfModal .btn-close');
            // Lấy phần tử modal
            const pdfModalEl = document.getElementById('pdfModal');
            // Khởi tạo modal
            const pdfModal = new bootstrap.Modal(pdfModalEl);

            // Lắng nghe sự kiện click để đóng modal
            closeButton.addEventListener('click', function() {
                pdfModal.hide();
            });
        });

        // Hàm thu thập dữ liệu đơn hàng từ các input và bảng
        function getOrderData() {


            // Thu thập dữ liệu đơn hàng chung
            var orderData = {
                order_code: "{{ $order->order_code }}",
                supplier_code: document.querySelector('.supplier').value,
                address_company: document.querySelector('.address_company').value ?? "",
                company_buyer: document.querySelector('.company_buyer').value,
                order_date: "{{ isset($order->order_date) ? date('Y-m-d', strtotime($order->order_date)) : date('Y-m-d') }}",
                total_quantity: "{{ $order->total_quantity }}",
                subtotal: $('#subtotal').val(),
                note__custom: $('.note__custom').val(),
                grand_total: $('#remainingAmountInput').val(), // Sử dụng input riêng hiển thị remaining amount
                deposit: $('#deposit').val(),
                calculatedDeposit: $('#calculatedDeposit').val(),
                items: []
            };

            // Thu thập dữ liệu các item từ bảng
            // Giả sử mỗi hàng trong tbody chứa các input với tên trường tương ứng
            $('table tbody tr').each(function() {
                // Nếu hàng không chứa input nào (hoặc rỗng) thì bỏ qua
                if ($(this).find('input').length === 0) return;

                var item = {
                    product_name: $(this).find('input[name="product_name"]').val(),
                    image: $(this).find('input[name="image"]').val(),
                    sku: $(this).find('input[name="sku"]').val(),
                    quantity: $(this).find('input[name="quantity"]').val(),
                    price: $(this).find('input[name="price"]').val(),
                    unit: $(this).find('select[name="unit"]').val(),
                    noteOrder: $(this).find('input[name="noteOrder"]').val(),
                };
                // Chỉ thêm nếu SKU có giá trị (bắt buộc)
                if (item.sku) {
                    orderData.items.push(item);
                }
            });

            return orderData;

        }

        // Hàm mở modal PDF: chuyển dữ liệu đơn hàng thành chuỗi JSON, mã hóa và gán vào query string
        function openPdfModal(orderData) {
            var orderJson = encodeURIComponent(JSON.stringify(orderData));
            var pdfUrl = "{{ route('orders.export.pdf') }}?order=" + orderJson;
            $('#pdfViewer').attr('src', pdfUrl);
            var myModal = new bootstrap.Modal(document.getElementById('pdfModal'));
            myModal.show();
        }

        // Hàm được gọi khi nhấn nút
        function openPdfModalWithData() {
            var orderData = getOrderData();
            openPdfModal(orderData);
        }

        //Xử lý  lưu cở sở dữ liệu vè đơn đặt hàng và xử lý google sheeets
        // document.getElementById('confirmOrderNew').addEventListener('click', function() {
        //     if (!confirm("Xác nhận xử lý nếu đã In đơn hàng ! ")) {
        //         return;
        //     }

        //     // Thu thập dữ liệu đơn hàng chung
        //     var orderData = {
        //         order_code: "{{ $order->order_code }}",
        //         supplier_code: document.querySelector('.select3_init').value,
        //         order_date: "{{ isset($order->order_date) ? date('Y-m-d', strtotime($order->order_date)) : date('Y-m-d') }}",
        //         total_quantity: "{{ $order->total_quantity }}",
        //         subtotal: $('#subtotal').val(),
        //         note: $('#note').val(),
        //         grand_total: $('#remainingAmountInput').val(), // Sử dụng input riêng hiển thị remaining amount
        //         deposit: $('#deposit').val(),
        //         items: []
        //     };

        //     // Thu thập dữ liệu các item từ bảng
        //     // Giả sử mỗi hàng trong tbody chứa các input với tên trường tương ứng
        //     $('table tbody tr').each(function() {
        //         // Nếu hàng không chứa input nào (hoặc rỗng) thì bỏ qua
        //         if ($(this).find('input').length === 0) return;

        //         var item = {
        //             product_name: $(this).find('input[name="product_name"]').val(),
        //             image: $(this).find('input[name="image"]').val(),
        //             sku: $(this).find('input[name="sku"]').val(),
        //             quantity: $(this).find('input[name="quantity"]').val(),
        //             price: $(this).find('input[name="price"]').val(),
        //             size: $(this).find('input[name="size"]').val(),
        //             color: $(this).find('input[name="color"]').val(),
        //             product_specifications: $(this).find('input[name="product_specifications"]').val(),
        //             packaging: $(this).find('input[name="packaging"]').val()
        //         };
        //         // Chỉ thêm nếu SKU có giá trị (bắt buộc)
        //         if (item.sku) {
        //             orderData.items.push(item);
        //         }
        //     });

        //     // Gửi dữ liệu đơn hàng qua AJAX dưới dạng JSON
        //     $.ajax({
        //         url: "{{ route('orders.createNew') }}", // Tạo mới 1 đơn hàng
        //         method: "POST",
        //         data: {
        //             _token: "{{ csrf_token() }}",
        //             order: JSON.stringify(orderData)
        //         },
        //         beforeSend: function() {
        //             Swal.fire({
        //                 title: 'Đang xử lý...',
        //                 html: 'Vui lòng chờ trong giây lát...',
        //                 allowOutsideClick: false,
        //                 didOpen: () => {
        //                     Swal.showLoading();
        //                 }
        //             });
        //         },
        //         success: function(response) {
        //             if (response.success) {
        //                 Swal.fire({
        //                     title: 'Thành công',
        //                     text: response.message,
        //                     icon: 'success',
        //                     confirmButtonText: 'OK'
        //                 }).then(() => {
        //                     window.location.reload();
        //                     // Sau khi xác nhận, chuyển hướng lại trang import hoặc trang danh sách đơn hàng
        //                 });
        //             } else {
        //                 Swal.fire({
        //                     title: 'Lỗi',
        //                     text: response.message,
        //                     icon: 'error',
        //                     confirmButtonText: 'OK'
        //                 });
        //             }
        //         },
        //         error: function() {
        //             Swal.fire({
        //                 title: 'Lỗi',
        //                 text: 'Có lỗi xảy ra khi xử lý đơn hàng.',
        //                 icon: 'error',
        //                 confirmButtonText: 'OK'
        //             });
        //         }
        //     });
        // });






        document.getElementById('confirmOrderNew').addEventListener('click', function() {
            Swal.fire({
                title: "Xác nhận xử lý?",
                text: "Bạn có chắc chắn đã in đơn hàng và muốn tiếp tục?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Xác nhận",
                cancelButtonText: "Hủy",
            }).then((result) => {
                if (!result.isConfirmed) return; // Nếu người dùng nhấn Hủy

                // Thu thập dữ liệu đơn hàng
                var orderData = {
                    order_code: "{{ $order->order_code }}",
                    supplier_code: document.querySelector('.supplier').value,
                    company_buyer: document.querySelector('.company_buyer').value,
                    address_company: document.querySelector('.address_company').value ?? "",
                    order_date: "{{ isset($order->order_date) ? date('Y-m-d', strtotime($order->order_date)) : date('Y-m-d') }}",
                    total_quantity: "{{ $order->total_quantity }}",
                    subtotal: $('#subtotal').val(),
                    note: $('#note').val(),
                    grand_total: $('#remainingAmountInput').val(), // Tổng tiền còn lại
                    deposit: $('#deposit').val(),
                    items: []
                };

                // Thu thập dữ liệu từ bảng
                $('table tbody tr').each(function() {
                    var $row = $(this);
                    var sku = $row.find('input[name="sku"]').val(); // SKU bắt buộc

                    if (sku) {
                        var item = {
                            product_name: $row.find('input[name="product_name"]').val(),
                            image: $row.find('input[name="image"]').val(),
                            sku: sku,
                            quantity: $row.find('input[name="quantity"]').val(),
                            price: $row.find('input[name="price"]').val(),
                            total: $row.find('input[name="total"]').val(),
                            unit: $row.find('select[name="unit"]').val(),
                            noteOrder: $row.find('input[name="noteOrder"]').val(),
                        };
                        orderData.items.push(item);
                    }
                });

                if (orderData.items.length === 0) {
                    Swal.fire({
                        title: "Lỗi",
                        text: "Đơn hàng chưa có sản phẩm nào!",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                    return;
                }

                // Gửi AJAX lưu vào database và xử lý Google Sheets
                $.ajax({
                    url: "{{ route('orders.createNew') }}",
                    method: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        order: JSON.stringify(orderData)
                    },
                    beforeSend: function() {
                        Swal.fire({
                            title: 'Đang xử lý...',
                            html: 'Vui lòng chờ trong giây lát...',
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        Swal.fire({
                            title: response.success ? 'Thành công' : 'Lỗi',
                            text: response.message,
                            icon: response.success ? 'success' : 'error',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            if (response.success) window.location.reload();
                        });
                    },
                    error: function() {
                        Swal.fire({
                            title: "Lỗi",
                            text: "Có lỗi xảy ra khi xử lý đơn hàng.",
                            icon: "error",
                            confirmButtonText: "OK"
                        });
                    }
                });
            });


        });
    </script>
@endsection
