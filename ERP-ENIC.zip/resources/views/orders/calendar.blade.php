@extends('layouts.enic')

@section('css')
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/calendar.css') }}">
@endsection

@section('content')
    <main class="content-wrapper">
        <div class="container-fluid">
            <section class="row justify-content-center">
                <div class="col-12">
                    <article class="app-card">
                        <header class="app-card-header">
                            <i class="fas fa-calendar-alt" aria-hidden="true"></i>
                            <h1 class="app-card-title">Lịch theo dõi đơn hàng</h1>
                            <button id="helpButtonCustom" class="help-button" aria-label="Xem hướng dẫn sử dụng">
                                <i class="fas fa-question"></i>
                            </button>
                        </header>

                        <div class="app-card-body">
                            <div class="calendar-toolbar">
                                <div class="toolbar-controls">
                                    <div class="toolbar-buttons">
                                        <button id="today-btn" class="toolbar-button toolbar-button--today"
                                            aria-label="Đến ngày hôm nay">
                                            <i class="fas fa-calendar-day" aria-hidden="true"></i>
                                            <span>Hôm nay</span>
                                        </button>
                                        <button id="prev-btn" class="toolbar-button" aria-label="Tháng trước">
                                            <i class="fas fa-chevron-left" aria-hidden="true"></i>
                                            <span>Trước</span>
                                        </button>
                                        <button id="next-btn" class="toolbar-button" aria-label="Tháng sau">
                                            <i class="fas fa-chevron-right" aria-hidden="true"></i>
                                            <span>Sau</span>
                                        </button>
                                    </div>
                                    <div>
                                        <label for="view-selector" class="visually-hidden">Chọn kiểu hiển thị</label>
                                        <select id="view-selector" class="view-selector"
                                            aria-label="Chọn kiểu hiển thị lịch">
                                            <option value="dayGridMonth">Tháng</option>
                                            <option value="timeGridWeek">Tuần</option>
                                            <option value="timeGridDay">Ngày</option>
                                            <option value="listMonth">Danh sách</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="stats-panel">
                                    <div class="stats-item">
                                        <i class="fas fa-shopping-cart" aria-hidden="true"></i>
                                        <span class="stats-label">Tổng đơn hàng:</span>
                                        <span id="total-orders" class="stats-value">0</span>
                                    </div>
                                    <div class="stats-item">
                                        <i class="fas fa-box-open" aria-hidden="true"></i>
                                        <span class="stats-label">Sản phẩm cần theo dõi:</span>
                                        <span id="total-events" class="stats-value">0</span>
                                    </div>
                                </div>
                            </div>

                            <div class="calendar-grid">
                                <div class="calendar-container">
                                    <div id="calendar"></div>
                                </div>

                                <aside class="filter-panel">
                                    <div class="filter-section">
                                        <h2 class="filter-title">Bộ lọc sản phẩm</h2>
                                        <div class="filter-group">
                                            <button id="filter-arrival"
                                                class="btn btn-sm filter-button filter-button--arrival active">
                                                <i class="fas fa-boxes" aria-hidden="true"></i>
                                                <span>Ngày về dự kiến</span>
                                            </button>
                                            <button id="filter-delivery"
                                                class="btn btn-sm filter-button filter-button--delivery active">
                                                <i class="fas fa-truck" aria-hidden="true"></i>
                                                <span>Xưởng sản xuất xong</span>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="filter-section">
                                        <h3 class="filter-subtitle">Mã sản phẩm</h3>
                                        <div id="sku-legend" class="sku-legend">
                                            <!-- SKU items will be inserted here by JavaScript -->
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </article>
                </div>
            </section>
        </div>
    </main>

    <!-- Event Detail Modal -->
    <div class="modal fade event-modal" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventModalLabel">Chi tiết đơn hàng</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Đóng"></button>
                </div>
                <div class="modal-body">
                    <div class="event-detail-row">
                        <span class="detail-label">Loại sự kiện:</span>
                        <span id="event-type" class="detail-value"></span>
                    </div>
                    <div class="event-detail-row">
                        <span class="detail-label">Mã đơn hàng:</span>
                        <span id="event-order-code" class="detail-value"></span>
                    </div>
                    <div class="event-detail-row">
                        <span class="detail-label">Mã sản phẩm:</span>
                        <span id="event-sku" class="detail-value"></span>
                    </div>
                    <div class="event-detail-row">
                        <span class="detail-label">Số lượng:</span>
                        <span id="event-quantity" class="detail-value"></span>
                    </div>
                    <div class="event-detail-row">
                        <span class="detail-label">Ngày:</span>
                        <span id="event-date" class="detail-value"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <a id="event-detail-link" href="#" class="btn btn-primary">
                        <i class="fas fa-external-link-alt" aria-hidden="true"></i>
                        <span>Xem chi tiết đơn hàng</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript để xử lý hướng dẫn sử dụng
        document.getElementById('helpButtonCustom').addEventListener('click', function() {
            Swal.fire({
                title: 'Hướng dẫn sử dụng lịch theo dõi đơn hàng',
                html: `
            <div class="user-guide" id="guideDoc">
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-calendar-day step-icon"></i>
                        <span>Điều hướng lịch</span>
                    </div>
                    <div class="step-content">
                        <p>Sử dụng các nút <strong>Hôm nay</strong>, <strong>Trước</strong>, và <strong>Sau</strong> để điều hướng giữa các tháng. Nút "Hôm nay" sẽ đưa bạn về ngày hiện tại.</p>
                    </div>
                </div>
                
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-th step-icon"></i>
                        <span>Chế độ xem lịch</span>
                    </div>
                    <div class="step-content">
                        <p>Chọn chế độ hiển thị lịch từ menu thả xuống: <strong>Tháng</strong>, <strong>Tuần</strong>, <strong>Ngày</strong>, hoặc <strong>Danh sách</strong>.</p>
                    </div>
                </div>
                
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-filter step-icon"></i>
                        <span>Bộ lọc sản phẩm</span>
                    </div>
                    <div class="step-content">
                        <p>Sử dụng nút <strong>Ngày về dự kiến</strong> và <strong>Xưởng sản xuất xong</strong> để lọc loại sự kiện.</p>
                        <p>Bạn cũng có thể chọn/bỏ chọn các mã sản phẩm (SKU) trong danh sách để lọc theo sản phẩm cụ thể.</p>
                    </div>
                </div>
                
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-info-circle step-icon"></i>
                        <span>Xem chi tiết sự kiện</span>
                    </div>
                    <div class="step-content">
                        <p>Nhấp vào bất kỳ sự kiện nào trên lịch để xem thông tin chi tiết về đơn hàng và sản phẩm.</p>
                        <p>Từ cửa sổ chi tiết, bạn có thể nhấn <strong>Xem chi tiết đơn hàng</strong> để chuyển đến trang đơn hàng đầy đủ.</p>
                    </div>
                </div>
                
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-chart-bar step-icon"></i>
                        <span>Thống kê tổng quan</span>
                    </div>
                    <div class="step-content">
                        <p>Phần đầu lịch hiển thị tổng số đơn hàng và tổng số sản phẩm cần theo dõi.</p>
                    </div>
                </div>
                
                <div class="guide-step">
                    <div class="step-title">
                        <i class="fas fa-palette step-icon"></i>
                        <span>Mã màu</span>
                    </div>
                    <div class="step-content">
                        <p>Mỗi mã sản phẩm (SKU) có một màu riêng để dễ phân biệt trên lịch.</p>
                        <p>Các icon <i class="fas fa-truck"></i> đại diện cho "Ngày về dự kiến" và <i class="fas fa-boxes"></i> cho "Xưởng sản xuất xong".</p>
                    </div>
                </div>
            </div>
        `,
                width: '800px',
                confirmButtonText: 'Đã hiểu',
                confirmButtonColor: '#3498db',
                showClass: {
                    popup: 'animate__animated animate__fadeIn'
                }
            });
        });

        /* ------------------------------------------------------------------- */


        document.addEventListener('DOMContentLoaded', function() {
            // Dữ liệu từ controller
            const events = {!! $events !!};
            const skuLegend = {!! $skuLegend !!};

            // Cập nhật số liệu thống kê
            document.getElementById('total-events').textContent = events.length;
            const uniqueOrders = [...new Set(events.map(event => event.order_code))];
            document.getElementById('total-orders').textContent = uniqueOrders.length;

            // Render legend cho các SKU
            const skuLegendContainer = document.getElementById('sku-legend');
            let skuHTML = '';

            for (const [sku, color] of Object.entries(skuLegend)) {
                skuHTML += `
                <div class="legend-item" data-sku="${sku}">
                    <input type="checkbox" class="form-check-input me-1" id="sku-${sku}" checked>
                    <div class="color-box" style="background-color: ${color}"></div>
                    <label for="sku-${sku}" class="form-check-label">${sku}</label>
                </div>
            `;
            }

            skuLegendContainer.innerHTML = skuHTML;

            // Khởi tạo FullCalendar
            const calendarEl = document.getElementById('calendar');
            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'vi',
                headerToolbar: {
                    left: '',
                    center: 'title',
                    right: ''
                },
                events: events,
                eventClick: function(info) {
                    // Hiển thị modal với thông tin chi tiết
                    const eventData = info.event.extendedProps;
                    const modal = new bootstrap.Modal(document.getElementById('eventModal'));

                    document.getElementById('event-type').textContent =
                        eventData.type === 'arrival' ? 'Ngày Về Dự Kiến' :
                        'Dự kiến thời gian xưởng sản xuât xong';
                    document.getElementById('event-order-code').textContent = eventData.order_code;
                    document.getElementById('event-sku').textContent = eventData.sku;
                    document.getElementById('event-quantity').textContent = eventData.quantity;
                    // document.getElementById('event-price').textContent = new Intl.NumberFormat(
                    //     'vi-VN', {
                    //         style: 'currency',
                    //         currency: 'VND'
                    //     }).format(eventData.price);
                    document.getElementById('event-date').textContent = new Date(info.event.start)
                        .toLocaleDateString('vi-VN');

                    // Thêm link để xem chi tiết đơn hàng
                    // Trong view, tạo URL mẫu với placeholder (ví dụ: :order_code)
                    let baseRoute = '{{ route('detailOrder', ['id' => ':order_id']) }}';

                    // Sau đó, thay thế placeholder bằng giá trị thực từ eventData
                    document.getElementById('event-detail-link').href = baseRoute.replace(':order_id',
                        eventData.order_id);
                    modal.show();
                },
                eventContent: function(arg) {
                    return {
                        html: `
                        <div class="fc-event-main-wrapper">
                            <i class="fas ${arg.event.extendedProps.type === 'arrival' ? 'fa-truck' : 'fa-boxes'} me-1"></i>
                            <span class="fc-event-title">${arg.event.title}</span>
                        </div>
                    `
                    };
                },
                dayMaxEvents: true, // Hiển thị nút "more" khi có nhiều sự kiện
                eventTimeFormat: {
                    hour: 'numeric',
                    minute: '2-digit',
                    meridiem: 'short'
                }
            });

            calendar.render();

            // Xử lý các nút điều hướng
            document.getElementById('today-btn').addEventListener('click', function() {
                calendar.today();
            });

            document.getElementById('prev-btn').addEventListener('click', function() {
                calendar.prev();
            });

            document.getElementById('next-btn').addEventListener('click', function() {
                calendar.next();
            });

            // Xử lý bộ chọn chế độ xem
            document.getElementById('view-selector').addEventListener('change', function() {
                calendar.changeView(this.value);
            });

            // Xử lý lọc theo loại sự kiện
            document.getElementById('filter-arrival').addEventListener('click', function() {
                this.classList.toggle('active');
                filterEvents();
            });

            document.getElementById('filter-delivery').addEventListener('click', function() {
                this.classList.toggle('active');
                filterEvents();
            });

            // Xử lý lọc theo SKU
            document.querySelectorAll('.legend-item').forEach(item => {
                item.addEventListener('click', function(e) {
                    if (e.target.tagName === 'INPUT') {
                        filterEvents();
                    } else {
                        const checkbox = this.querySelector('input[type="checkbox"]');
                        checkbox.checked = !checkbox.checked;
                        filterEvents();
                    }
                });
            });

            // Hàm lọc sự kiện
            function filterEvents() {
                const showArrival = document.getElementById('filter-arrival').classList.contains('active');
                const showDelivery = document.getElementById('filter-delivery').classList.contains('active');

                // Lấy danh sách SKU đã chọn
                const selectedSkus = Array.from(document.querySelectorAll('.legend-item input:checked'))
                    .map(checkbox => checkbox.parentElement.dataset.sku);

                const filteredEvents = events.filter(event => {
                    const matchesType = (event.type === 'arrival' && showArrival) ||
                        (event.type === 'delivery' && showDelivery);
                    const matchesSku = selectedSkus.includes(event.sku);

                    return matchesType && matchesSku;
                });

                // Cập nhật sự kiện trên lịch
                calendar.removeAllEvents();
                calendar.addEventSource(filteredEvents);
            }
        });
    </script>
@endsection
