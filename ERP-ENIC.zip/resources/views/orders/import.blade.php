@extends('layouts.enic')

@section('css')
    <link rel="stylesheet" href="{{ asset('css/order.css') }}">
@endsection

@section('content')
    <div class="midde_cont" style="margin-top: 100px" id="importOrder">
        <div class="container-fluid">
            <div class="row column_title">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });

                        });
                    </script>
                @endif



                @if (session('error'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Lỗi',
                                text: '{{ session('error') }}',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#d33',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif


                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Dash Board</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('orders.getOrdersByUser') }}">Danh sách đơn đặt
                                    hàng</a></li>
                            <li class="breadcrumb-item" aria-current="page"> <a href="{{ route('orders.import') }}">Thêm
                                    Mới</a> </li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row ">
                <div class="col-md-12">
                    <div>

                        <a href="{{ route('orders.getOrdersByUser') }}" class="list__order">
                            <i class="fas fa-stream"></i> Danh sách đơn đặt hàng
                        </a>
                        <button id="userGuideBtn" class="guide-btn userGuideBtnCustom">
                            <i class="fas fa-question-circle"></i> Hướng dẫn sử dụng
                        </button>


                        {{-- <a class="checkDateOrder" href="{{ route('checkDateOrder') }}">Kiểm Tra Tự Động</a> --}}
                    </div>



                    <div class="card shadow-sm mt-5">
                        <div class="card-header  text-white">
                            <h4 class="mb-0">Nhập Dữ Liệu Đơn Hàng</h4>
                        </div>
                        <div class="card-body">
                            <p>Vui lòng dán dữ liệu đơn hàng vào khung dưới đây . Dữ liệu cần nhập theo
                                định dạng:</p>
                            <ul>
                                <li><strong>Dòng 1:</strong> Mã đơn hàng (ví dụ: DHT18022501)</li>
                                <li><strong>Dòng 2:</strong> Tổng SL (ví dụ: Tổng SL 400)</li>
                                <li><strong>Các dòng tiếp theo:</strong> Tên sản phẩm, SKU và số lượng (cách nhau bằng
                                    tab hoặc 2 khoảng trắng)</li>
                            </ul>

                            <form id="importForm" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <label for="order_data"><strong>Dữ liệu đơn hàng</strong></label>
                                    <textarea name="order_data" id="order_data" class="form-control" rows="10"
                                        placeholder="DHT18022501
        Tổng SL 400
        Kệ Đựng Giấy A06 Xám    PVN2869    100
        Kệ Đựng Cốc A06 Xám      PVN2871    100
        Móc Treo Đôi A06 Xám      PVN2875    100
        Kệ Đa Năng A06 Vàng Ánh Kim   PVN2874    100"></textarea>
                                </div>
                                <div class="form-group mt-3">
                                    <label for="order_file"><strong>Hoặc tải lên file</strong></label>
                                    <a style="color: rgb(13, 123, 13); font-weight: 500" download
                                        href="{{ asset('import/purchase.txt') }}">(Tải xuống file mẫu)</a>
                                    <input accept="text/plain" type="file" name="order_file" id="order_file"
                                        class="form-control-file">
                                    <small class="form-text text-muted">Chọn file .txt chứa dữ liệu đơn hàng.</small>
                                </div>
                                <div class="mt-4 text-right">
                                    <button type="button" id="btnPreview" class="btn btn-success">Xem trước</button>
                                    <button type="reset" class="btn btn-secondary">Làm mới</button>
                                </div>
                            </form>


                            <!-- Container để hiển thị preview đơn hàng -->
                            <div id="previewExcelContainer" class="mt-4"></div>

                        </div>
                        <div class="card-footer text-muted text-center">
                            <small>Hệ Thống Xử Lý Đơn Hàng Tự Động ERP ENIC</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- end dashboard inner -->
        </div>
    @endsection


    @section('js')
        <script>
            /* Hướng dẫn sử dụng  */
            document.addEventListener('DOMContentLoaded', function() {
                // Thêm nút vào container thích hợp
                const cardHeader = document.querySelector('.card-header');
                if (cardHeader) {
                    cardHeader.style.position = 'relative';
                    cardHeader.appendChild(document.getElementById('userGuideBtn'));
                }

                // Xử lý sự kiện click trên nút hướng dẫn
                document.getElementById('userGuideBtn').addEventListener('click', function() {
                    Swal.fire({
                        title: 'Hướng dẫn nhập dữ liệu đơn hàng',
                        html: `
                <div class="guide-container" id="Guide__ImportOrder">
                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-file-alt" style="color: #3498db;"></i> Bước 1: Chuẩn bị dữ liệu
                        </div>
                        <div class="guide-step-content">
                            Dữ liệu đơn hàng cần được chuẩn bị theo định dạng sau:
                            <div class="guide-format-example">
                                DHT18022501<br>
                                Tổng SL 400<br>
                                Kệ Đựng Giấy A06 Xám    PVN2869    100<br>
                                Kệ Đựng Cốc A06 Xám      PVN2871    100<br>
                                Móc Treo Đôi A06 Xám      PVN2875    100<br>
                                Kệ Đa Năng A06 Vàng Ánh Kim   PVN2874    100
                            </div>
                            <ul>
                                <li>Dòng 1: Mã đơn hàng (ví dụ: DHT18022501)</li>
                                <li>Dòng 2: Tổng số lượng sản phẩm (ví dụ: Tổng SL 400)</li>
                                <li>Dòng 3 trở đi: Thông tin sản phẩm với định dạng: Tên sản phẩm, mã SKU và số lượng (cách nhau bằng tab hoặc 2 khoảng trắng)</li>
                            </ul>
                        </div>
                    </div>

                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-keyboard" style="color: #e74c3c;"></i> Bước 2: Nhập dữ liệu
                        </div>
                        <div class="guide-step-content">
                            Bạn có thể nhập dữ liệu bằng một trong hai cách:
                            <ul>
                                <li><strong>Cách 1:</strong> Dán trực tiếp dữ liệu vào ô textarea "Dữ liệu đơn hàng"</li>
                                <li><strong>Cách 2:</strong> Tải lên file .txt chứa dữ liệu đơn hàng đã định dạng</li>
                            </ul>
                            <div class="guide-note">
                                <i class="fas fa-info-circle"></i> Bạn có thể tải xuống file mẫu để xem định dạng chuẩn bằng cách nhấp vào liên kết "Tải xuống file mẫu" bên dưới ô tải file.
                            </div>
                        </div>
                    </div>

                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-eye" style="color: #2ecc71;"></i> Bước 3: Xem trước đơn hàng
                        </div>
                        <div class="guide-step-content">
                            <ul>
                                <li>Sau khi nhập dữ liệu, nhấn nút <strong>"Xem trước"</strong> để hiển thị bảng preview đơn hàng</li>
                                <li>Kiểm tra kỹ thông tin đơn hàng hiển thị trên bảng preview để đảm bảo dữ liệu đã được nhập chính xác</li>
                                <li>Nếu có lỗi, hãy chỉnh sửa dữ liệu trong ô textarea hoặc tải lại file đúng định dạng</li>
                            </ul>
                        </div>
                    </div>

                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-save" style="color: #f39c12;"></i> Bước 4: Xác nhận và lưu đơn hàng
                        </div>
                        <div class="guide-step-content">
                            <ul>
                                <li>Chức năng <strong>"Xem Đơn Hàng"</strong> giúp bạn xem Purchase Order và có thể tải file PDF gửi cho nhà cung cấp.</li>
                                <li>Sau khi kiểm tra kỹ thông tin, nếu đơn hàng hiển thị chính xác, nhấn nút <strong>"Lưu đơn hàng"</strong> trong bảng preview để lưu đơn hàng vào hệ thống</li>
                                <li>Hệ thống sẽ hiển thị thông báo xác nhận khi đơn hàng được lưu thành công</li>
                            </ul>
                        </div>
                    </div>

                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-exclamation-triangle" style="color: #e74c3c;"></i> Lưu ý quan trọng
                        </div>
                        <div class="guide-step-content">
                            <ul>
                                <li>Mã đơn hàng không được trùng với các đơn hàng đã có trong hệ thống</li>
                                <li>Tổng số lượng sản phẩm phải khớp với tổng số lượng của từng sản phẩm liệt kê bên dưới</li>
                                <li>Mã SKU của sản phẩm phải tồn tại trong hệ thống</li>
                                <li>Nếu gặp lỗi khi nhập đơn hàng, hãy kiểm tra thông báo lỗi và chỉnh sửa dữ liệu theo hướng dẫn</li>
                            </ul>
                        </div>
                    </div>

                    <div class="guide-step">
                        <div class="guide-step-title">
                            <i class="fas fa-undo" style="color: #9b59b6;"></i> Làm mới dữ liệu
                        </div>
                        <div class="guide-step-content">
                            <ul>
                                <li>Nhấn nút <strong>"Làm mới"</strong> để xóa toàn bộ dữ liệu đã nhập và bắt đầu lại</li>
                                <li>Bạn cũng có thể nhấn vào liên kết <strong>"Danh sách đơn đặt hàng"</strong> để quay trở lại danh sách các đơn hàng đã nhập</li>
                            </ul>
                        </div>
                    </div>
                </div>
            `,
                        width: '700px',
                        confirmButtonText: 'Đã hiểu',
                        confirmButtonColor: '#3498db',
                        showClass: {
                            popup: 'animate__animated animate__fadeIn animate__faster'
                        },
                        hideClass: {
                            popup: 'animate__animated animate__fadeOut animate__faster'
                        }
                    });
                });
            });

            /* ------------------------------------------------------------------------------------------ */



            // Khi chọn file, tự động đọc nội dung và điền vào textarea
            document.getElementById('order_file').addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('order_data').value = e.target.result;
                    };
                    reader.readAsText(file);
                }
            });

            // Sự kiện khi nhấn nút Xem trước
            $('#btnPreview').click(function() {
                // Lấy dữ liệu form
                var formData = new FormData($('#importForm')[0]);

                $.ajax({
                    url: "{{ route('orders.previewOrder.ajax') }}",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    method: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        // Hiển thị loading (nếu cần)
                        $('#previewExcelContainer').html(
                            '<div class="text-center"><i class="fas fa-spinner fa-spin fa-2x"></i></div>'
                        );
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#previewExcelContainer').html(response.html);
                        } else {
                            $('#previewContainer').html('<div class="alert alert-danger">' + response
                                .error + '</div>');
                        }
                    },
                    error: function(xhr) {
                        $('#previewExcelContainer').html(
                            '<div class="alert alert-danger">Vui lòng nhập thông tin đơn hàng!</div>'
                        );
                    }
                });
            });
        </script>
    @endsection
