@extends('layouts.enic')
@section('content')
    <div class="card mt-4 ">
        <div class="card-header bg-info text-white">
            <h4>Preview Đơn Hàng: {{ $order->order_code }}</h4>
        </div>
        <div class="card-body">
            <p><strong>Tổng số lượng:</strong> {{ $order->total_quantity }}</p>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Tên Sản Phẩm</th>
                        <th>SKU</th>
                        <th>Số Lượng</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($order->items as $index => $item)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $item->product_name }}</td>
                            <td>{{ $item->sku }}</td>
                            <td>{{ $item->quantity }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="card-footer text-center">
            <!-- Form ẩn để gửi dữ liệu sang process() -->
            <form id="processOrderForm">
                @csrf
                <input type="hidden" name="order_code" value="{{ $order->order_code }}">
                <input type="hidden" name="total_quantity" value="{{ $order->total_quantity }}">
                @foreach ($order->items as $index => $item)
                    <input type="hidden" name="items[{{ $index }}][product_name]" value="{{ $item->product_name }}">
                    <input type="hidden" name="items[{{ $index }}][sku]" value="{{ $item->sku }}">
                    <input type="hidden" name="items[{{ $index }}][quantity]" value="{{ $item->quantity }}">
                @endforeach
                <button type="button" id="confirmOrder" class="btn btn-success">Xác nhận xử lý</button>
            </form>
        </div>
    </div>
@endsection
