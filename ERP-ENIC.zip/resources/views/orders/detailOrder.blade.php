@extends('layouts.enic')
@section('content')
    <style>
        /* Tổng thể trang */
        body {
            background-color: #f8f9fa;
        }

        p {
            font-size: 15px !important;
            color: #0a013e;
        }

        /* Card Tùy Chỉnh */
        .card-custom {
            border: none;
            /* Bỏ border gốc của card */
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 1rem;
        }

        .card-header-custom {
            background-color: #fff;
            box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
            color: #111;
            border-bottom: none;
            padding: 16px;
            font-weight: 600;
            font-size: 18px;
            border-radius: 8px 8px 0 0;
        }

        .card-body-custom {
            background-color: #fff;
            padding: 16px;
            border-radius: 0 0 8px 8px;
        }

        /* Tiêu đề, Phụ đề Đơn Hàng */
        .order-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0;
        }

        .order-subtitle {
            font-size: 0.9rem;
            color: #666;
        }

        /* Label & Value */
        .info-label {
            color: #666;
            margin-right: 6px;
        }

        .info-value {
            font-weight: 500;
        }

        /* Nút Primary Tùy Chỉnh */
        .btn-primary-custom {
            background-color: #007bff;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            color: #fff;
            font-size: 0.875rem;
        }

        .btn-primary-custom:hover {
            background-color: #0056b3;
        }

        /* Nút Secondary Outline */
        .btn-outline-secondary {
            border-radius: 4px;
            font-size: 0.875rem;
        }

        /* Bảng Sản Phẩm */
        .table-products th {
            background-color: #f2f2f2;
            color: #333;
        }

        .table-products td,
        .table-products th {
            font-size: 15px;
            vertical-align: middle !important;
        }

        .table-products tbody tr:nth-child(even) {
            background-color: #fafafa;
        }

        /* Khối Tóm Tắt (Phần dưới bảng) */
        .summary-box {
            display: flex;
            justify-content: space-between;
            border-top: 1px solid #e0e0e0;
            padding-top: 20px;
            margin-top: 1rem;
        }

        .summary-box .summary-notes {
            flex: 1;
            margin-right: 1rem;
        }

        .summary-box .summary-totals {
            flex: 1;
            text-align: right;
        }

        .summary-box p {
            margin: 0.2rem 0;
        }

        .summary-box p span {
            font-weight: 600;
            color: #333;
            margin-left: 0.5rem;
        }

        #updateOrderDetail {
            border: none;
            background: linear-gradient(141.55deg, #0caf60 3.46%, #0caf60 99.86%), #0caf60;
            color: #fff;
            box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
            border-radius: 6px;
            padding: 13px 15px;
            font-weight: 600;
        }

        #splitLoad {
            border: none;
            background: linear-gradient(141.55deg, #d7132a 3.46%, #d7132a 99.86%), #d7132a;
            color: #fff;
            border-radius: 6px;
            padding: 13px 15px;
            font-weight: 600;
        }

        .forecast__title {
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        .forecast__title p {
            font-size: 18px !important;
            margin: 0px !important;
        }

        #actionSplitOrder {
            background-color: #dc3545;
            border: none;
            padding: 10px 15px;
            color: #fff;
            font-weight: 600;
            border-radius: 6px;
        }



        /* CSS tùy chỉnh cho modal thanh toán cọc */
        #depositModal .modal-content {
            border-radius: 15px;
            border: none;
            max-width: 600px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        #depositForm {
            width: 100%;
        }

        #depositModal .modal-header {
            background: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            border-radius: 15px 15px 0 0;
            padding: 1.5rem;
        }

        #depositModal .modal-dialog {
            max-width: 650px;
        }


        #depositModal .modal-title {
            color: #2a3042;
            font-weight: 600;
            font-size: 1.25rem;
        }

        #depositModal .btn-close {
            font-size: 0.75rem;
            padding: 0.5rem;
            margin: -0.5rem -0.5rem -0.5rem auto;
            background-color: #dc3545;
            color: #fff;
            border: none;
            width: 35px;
            border-radius: 4px;
        }



        #depositModal .form-label {
            font-weight: 500;
            color: #4a4a4a;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }

        #depositModal .form-control {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 0.625rem 1rem;
            font-size: 0.875rem;
            transition: all 0.3s ease;
        }

        #depositModal .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        #depositModal input[readonly] {
            background-color: #f8fafc;
            cursor: not-allowed;
        }

        #depositModal .modal-footer {
            border-top: 1px solid #dee2e6;
            padding: 1.5rem;
        }

        #depositModal .btn-secondary {
            background: #f1f5f9;
            color: #64748b;
            border: none;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
        }

        #depositModal .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border: none;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        #depositModal .btn-success:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.3);
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {
            #depositModal .modal-body .row>div {
                width: 100%;
                flex: 0 0 100%;
                max-width: 100%;
            }

            #depositModal .modal-dialog {
                margin: 0.5rem;
            }
        }



        /* CSS tùy chỉnh cho modal thêm chi phí */
        #importCostModal .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        #importCostModal .modal-header {
            background: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            border-radius: 15px 15px 0 0;
            padding: 1.5rem;
        }

        #importCostModal .modal-title {
            color: #2a3042;
            font-weight: 600;
            font-size: 1.25rem;
        }

        #importCostModal .modal-body {
            padding: 1.5rem;
        }

        #importCostModal .cost-item {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 0.75rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        #importCostModal .cost-item:hover {
            border-color: #c3dafe;
            box-shadow: 0 2px 6px rgba(163, 177, 204, 0.1);
        }

        #importCostModal .form-control {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 0.625rem 1rem;
            font-size: 0.875rem;
            transition: all 0.3s ease;
        }

        #importCostModal .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        #importCostModal .removeCostItem {
            padding: 0.5rem 0.75rem;
            border-radius: 6px;
            font-size: 0.75rem;
            line-height: 1;
            transition: all 0.2s ease;
        }

        #importCostModal .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            border: none;
        }

        #importCostModal #addCostItem {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            background: #f1f5f9;
            border: 1px dashed #94a3b8;
            color: #64748b;
            transition: all 0.3s ease;
        }

        #importCostModal #addCostItem:hover {
            background: #e2e8f0;
            border-color: #64748b;
        }

        #importCostModal .modal-footer {
            border-top: 1px solid #dee2e6;
            padding: 1.5rem;
        }

        #importCostModal .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            border: none;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        #importCostModal .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {

            #importCostModal .cost-item .col-5,
            #importCostModal .cost-item .col-2 {
                width: 100%;
                flex: 0 0 100%;
                max-width: 100%;
                margin-bottom: 0.5rem;
            }

            #importCostModal .removeCostItem {
                width: 100%;
                margin-top: 0.5rem;
            }

            #importCostModal .modal-dialog {
                margin: 0.5rem;
            }
        }

        /* CSS cho component thanh toán */
        #payment__Order__Card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            transition: transform 0.3s ease;
            padding: 20px 10px;
        }

        #payment__Order__Card:hover {
            transform: translateY(-2px);
        }

        .card-header-custom {
            background: #fff;
            padding: 1.25rem 1.5rem;
            border-bottom: 2px solid #e2e8f0;
            font-weight: 600;
            color: #1e293b;
            font-size: 20px;
        }

        .card-body-custom {
            padding: 1.5rem;
            color: #475569;
        }

        .info-label {
            display: inline-block;
            min-width: 160px;
            font-weight: 500;
            color: #64748b;
            margin-right: 1rem;
        }

        .info-value {
            font-weight: 600;
            color: #1e293b;
        }

        /* Style cho các trạng thái */
        .text-success {
            color: #10b981;
        }

        .text-warning {
            color: #f59e0b;
        }

        .text-danger {
            color: #ef4444;
        }

        .text-primary {
            color: #3b82f6;
        }

        /* Phần separator */
        hr {
            border: 0;
            height: 1px;
            background: #e2e8f0;
            margin: 1.5rem 0;
        }

        /* Nút bấm */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.2s ease;
            border: none;
            cursor: pointer;
        }

        .btn-info {
            background: linear-gradient(135deg, #06b6d4 0%, #0ea5e9 100%);
            color: white;
        }

        .btn-success {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Phần chi phí nhập hàng */
        #importCostsSection {
            margin-top: 1.5rem;
            border-top: 2px solid #f1f5f9;
            padding-top: 1.5rem;
        }

        #importCostsSection p {
            background: #f8fafc;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 0.75rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #importCostsSection strong {
            color: #1e293b;
            margin-right: 0.5rem;
        }

        #importCostsSection span {
            color: #64748b;
            font-size: 0.875rem;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .card-header-custom {
                padding: 1rem;
                font-size: 1rem;
            }

            .card-body-custom {
                padding: 1rem;
            }

            .info-label {
                display: block;
                width: 100%;
                margin-bottom: 0.5rem;
            }

            .btn {
                width: 100%;
                margin-top: 1rem;
            }

            #importCostsSection p {
                flex-direction: column;
                align-items: flex-start;
            }

            #importCostsSection span {
                margin-top: 0.25rem;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #payment__Order__Card {
            animation: fadeIn 0.4s ease forwards;
        }


        /* CSS cho modal cập nhật thanh toán */
        #updatePaymentModal .modal-content {
            border-radius: 12px;
            border: none;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        #updatePaymentModal .modal-header {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            padding: 1.25rem 1.5rem;
        }

        #updatePaymentModal .modal-title {
            color: #1e293b;
            font-weight: 600;
            font-size: 1.2rem;
        }

        #updatePaymentModal .modal-body {
            padding: 1.5rem;
        }

        #updatePaymentModal .form-label {
            color: #475569;
            font-weight: 500;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            display: block;
        }

        #updatePaymentModal .form-control {
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        #updatePaymentModal .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        #updatePaymentModal .btn-close {
            filter: invert(0.4);
            transition: transform 0.2s ease;
        }

        #updatePaymentModal .btn-close:hover {
            transform: rotate(90deg);
        }

        #updatePaymentModal .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            margin-top: 1rem;
            transition: all 0.3s ease;
        }

        #updatePaymentModal .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
        }

        /* Responsive Design */
        @media (max-width: 576px) {
            #updatePaymentModal .modal-dialog {
                margin: 0.5rem;
            }

            #updatePaymentModal .modal-body {
                padding: 1rem;
            }

            #updatePaymentModal .form-control {
                padding: 0.625rem 0.875rem;
            }
        }

        /* CSS cho mỗi item thanh toán */
        .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid #f1f5f9;
            transition: background-color 0.2s ease;
        }

        .payment-item:hover {
            background-color: #f8fafc;
        }

        .payment-content {
            flex: 1;
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            font-size: 0.9rem;
            color: #475569;
        }

        .payment-meta {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.25rem 0.75rem;
            background: #f1f5f9;
            border-radius: 6px;
            margin: 2px 0;
        }

        .payment-label {
            font-weight: 600;
            color: #1e293b;
        }

        .payment-value {
            color: #001c39;
        }

        .payment-edit {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        .payment-edit:hover {
            background-color: #fee2e2;
        }

        .payment-edit i {
            font-size: 1.1rem;
            transition: transform 0.2s ease;
        }

        .payment-edit:hover i {
            transform: scale(1.1);
            color: #ef4444;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .payment-item {
                flex-direction: column;
                gap: 0.5rem;
                padding: 0.75rem 0;
            }

            .payment-content {
                flex-direction: column;
                gap: 0.5rem;
            }

            .payment-meta {
                width: 100%;
                justify-content: space-between;
                padding: 0.5rem;
            }
        }


        /* CSS cho modal cập nhật chi phí */
        #updateCostModal .modal-content {
            border-radius: 12px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        #updateCostModal .modal-header {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            padding: 1.25rem 1.5rem;
            position: relative;
        }

        #updateCostModal .modal-title {
            color: #1e293b;
            font-weight: 600;
            font-size: 1.25rem;
        }

        #updateCostModal .btn-close {
            position: absolute;
            right: 1.5rem;
            top: 50%;
            transform: translateY(-50%);
            filter: opacity(0.6);
            transition: all 0.2s ease;
        }

        #updateCostModal .btn-close:hover {
            filter: opacity(1);
            transform: translateY(-50%) scale(1.1);
        }

        #updateCostModal .modal-body {
            padding: 1.5rem;
        }

        #updateCostModal .form-label {
            color: #475569;
            font-weight: 500;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            display: block;
        }

        #updateCostModal .form-control {
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        #updateCostModal .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        #updateCostModal .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            margin-top: 1rem;
            transition: all 0.3s ease;
        }

        #updateCostModal .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
        }

        /* Responsive */
        @media (max-width: 576px) {
            #updateCostModal .modal-dialog {
                margin: 0.5rem;
            }

            #updateCostModal .modal-header {
                padding: 1rem;
            }

            #updateCostModal .modal-body {
                padding: 1rem;
            }

            #updateCostModal .form-control {
                padding: 0.625rem 0.875rem;
            }
        }

        /* Animation */
        @keyframes modalEntry {
            from {
                transform: translateY(20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        #updateCostModal .modal-content {
            animation: modalEntry 0.3s ease-out;
        }



        #history_deposit_payments {

            padding: 12px;
            background-color: #dee2e6;
            border-radius: 5px;
            margin: 0px;
            font-weight: 400 !important;
        }


        @media screen and (min-width: 1000px) {

            #depositHistoryModal .modal-lg,
            .modal-xl {
                max-width: 1000px;
            }
        }

        .group__forecast-order {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        #lightbulb {
            font-size: 16px;
            background: #35a5b6;
            border: 1px solid #fff;
            padding: 7px 16px;
            border-radius: 6px;
            color: #fff;
            outline: none;
        }



        .supplier-modal .modal-content {
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .supplier-modal .modal-header {
            background: linear-gradient(135deg, #17a2b8 0%, #2575fc 100%);
            color: white;
            padding: 1rem 1.5rem;
            border-bottom: none;
        }

        .supplier-modal .modal-header .modal-title {
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .supplier-modal .modal-header .modal-title i {
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .supplier-modal .modal-body {
            background-color: #f8f9fa;
            padding: 1.5rem;
        }

        .supplier-modal .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .supplier-modal .card-body h3 {
            color: #2575fc;
            margin-bottom: 1rem;
            font-weight: 600;
            border-bottom: 2px solid #2575fc;
            padding-bottom: 0.5rem;
        }

        .supplier-modal .list-group-item {
            background-color: transparent;
            border-color: rgba(0, 0, 0, 0.08);
            padding: 0.75rem 1rem;
            transition: background-color 0.3s ease;
            gap: 20px;
        }

        .supplier-modal .list-group-item:hover {
            background-color: rgba(37, 117, 252, 0.05);
        }

        .supplier-modal .list-group-item span:first-child {
            color: #2575fc;
            font-weight: 500;
            display: flex;
            align-items: center;
        }

        .supplier-modal .list-group-item span:first-child i {
            margin-right: 10px;
            color: #6a11cb;
        }

        .supplier-modal .list-group-item span:last-child {
            color: #212529;
            font-weight: 300;
        }


        .supplier-modal .card-subtitle {
            font-size: 18px;
            font-weight: 400;
            padding: 10px;
            color: #111 !important;
        }


        .payment-history-wrapper {
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .payment-history-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            cursor: pointer;
            user-select: none;
        }

        .payment-history-header h5 {
            margin: 0;
            color: #2c3e50;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .payment-history-header .toggle-icon {
            transition: transform 0.3s ease;
        }

        .payment-history-header.collapsed .toggle-icon {
            transform: rotate(0deg);
        }

        .payment-history-header.expanded .toggle-icon {
            transform: rotate(180deg);
        }

        .payment-history-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
            padding: 0 20px;
        }

        .payment-history-content.show {
            max-height: 500px;
            padding: 20px;
        }

        .payment-history-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
        }

        .payment-history-table thead {
            background-color: #3498db;
            color: white;
        }

        .payment-history-table th,
        .payment-history-table td {
            padding: 12px;
            text-align: left;
        }

        .payment-history-table tbody tr {
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .payment-history-table tfoot tr {
            background-color: #f1f3f5;
            font-weight: bold;
        }




        .payment-summary {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8f9fa;
            border-radius: 12px;
            padding: 15px 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-top: 15px;
        }

        .payment-total {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .payment-total-paid {
            display: flex;
            align-items: center;
            color: #04a777;
            font-weight: 600;
            font-size: 18px;
        }

        .payment-total-paid i {
            margin-right: 10px;
            color: #04a777;
        }

        .payment-debt {
            display: flex;
            align-items: center;
            color: #dc3545;
            font-weight: 600;
            font-size: 18px;
        }

        .payment-debt i {
            margin-right: 10px;
            color: #e74c3c;
        }

        .payment-complete {
            display: flex;
            align-items: center;
            color: #2ecc71;
            font-weight: 600;
            font-size: 18px;
        }

        .payment-complete i {
            margin-right: 10px;
            color: #2ecc71;
        }

        .payment-amount {
            font-weight: 700;
            margin-left: 5px;
        }

        @media screen and (min-width: 1000px) {
            #paymentOrderModal .modal-dialog {
                max-width: 780px !important;
                margin: 1.75rem auto;
            }
        }



        /* Chức năng hướng dẫn */

        /* CSS cho nút hướng dẫn */
        .helpguide__btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #17a2b8;
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 999;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }

        .helpguide__btn:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /* CSS cho nội dung popup */
        .helpguide__content {
            text-align: left;
            max-height: 70vh;
            overflow-y: auto;
            padding-right: 10px;
        }

        .helpguide__step {
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }

        .helpguide__step:last-child {
            border-bottom: none;
        }

        .helpguide__step-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .helpguide__icon {
            font-size: 20px;
            margin-right: 15px;
            color: #17a2b8;
            width: 24px;
        }

        .helpguide__step-header h3 {
            font-size: 18px;
            margin: 0;
            color: #333;
        }

        .helpguide__step-body {
            padding-left: 39px;
        }

        .helpguide__step-body p {
            margin-bottom: 8px;
            font-size: 14px;
            line-height: 1.5;
        }

        /* Tùy chỉnh scrollbar */
        .helpguide__content::-webkit-scrollbar {
            width: 8px;
        }

        .helpguide__content::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        .helpguide__content::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }

        .helpguide__content::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Điều chỉnh style cho SweetAlert2 */
        .swal2-popup {
            font-family: 'Roboto', sans-serif;
        }

        .swal2-title {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
    </style>


    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif



    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif



    <div class="container-fluid" style="margin-top: 100px">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ url('/') }}">Dash Board</a></li>
                <li class="breadcrumb-item"><a href="{{ route('orders.getOrdersByUser') }}">Danh sách</a></li>
                <li class="breadcrumb-item" aria-current="page"> <a href="{{ route('orders.import') }}">Thêm Mới</a> </li>
            </ol>
        </nav>

        <button type="button" class="helpguide__btn" id="helpguide-btn">
            <i class="fas fa-question-circle mr-2"></i>Hướng dẫn
        </button>



        <!-- Header: Thông tin chung đơn hàng -->
        <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
            <div>
                <h3 class="order-title mb-0">#Đơn: {{ $data['order']->order_code ?? '' }}</h3>

            </div>
            <div>
                <a href="{{ route('orders.import') }}" class="btn btn-sm btn-primary-custom me-2"
                    style="font-size: 16px; padding: 10px 25px; font-weight: 600 ">Tạo Mới <i
                        class="fas fa-plus ml-2"></i></a>

            </div>
        </div>

        <!-- Hai cột chính -->
        <div class="row">
            <!-- Cột trái -->
            <div class="col-lg-8">
                <!-- Card: Thông tin nhà cung cấp -->
                <div class="card-custom">
                    <div class="card-header-custom">
                        Thông tin nhà cung cấp
                    </div>
                    <div class="card-body-custom">
                        <div class="d-flex justify-content-between" style="gap: 5px">
                            <div>

                                <p class="mb-2"><strong style="font-weight: 700"> Tên Công
                                        Ty:</strong> {{ $data['order']->supplier->company_name ?? '' }}</p>
                                <p class="mb-1 text-muted">Địa chỉ:
                                    {{ $data['order']->supplier->address ?? 'chưa cập nhật' }}</p>
                            </div>

                            @php
                                $totalPayment = $data['order']->totalPayment() ?? '';
                                $totalImportCost = $data['order']->totalImportCost()
                                    ? $data['order']->totalImportCost()
                                    : 0;
                                $subtotal = $data['order']->subtotal + $totalImportCost;
                                $debt = $subtotal - $totalPayment;

                                $totalAllPayments = $data['order']->subtotal + $totalImportCost;

                            @endphp


                            <div class="text-end">
                                <p class="mb-1">
                                    <span class="info-label" style="color: #111;font-weight: 600">Công nợ: </span>
                                    @if ($debt == 0)
                                        <span class="info-value">0</span>
                                    @else
                                        <span class="info-value text-danger"
                                            style="font-weight: 600">-{{ number_format($debt, 2, '.', ',') }}</span>
                                    @endif
                                </p>
                                <p class="mb-0">
                                    <span class="info-label" style="color: #111;font-weight: 600">Đã thanh toán:</span>
                                    <span
                                        class="info-value text-success">{{ number_format($totalPayment, 2, '.', ',') }}</span>
                                </p>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card: Đơn nhập hàng chưa nhập kho -->
                <div class="card-custom">
                    <div class="card-header-custom">
                        Đơn nhập hàng chưa nhập kho
                    </div>
                    <div class="card-body-custom">
                        <p>Đang chờ nhập kho.</p>
                    </div>
                </div>

                <!-- Card: Thanh toán phần một phần -->
                <div class="card-custom">
                    <div class="card-header-custom">
                        Các Đợt Thanh Toán
                    </div>
                    <div class="card-body-custom">

                        @if ($data['order']->historypayment->count() > 0)
                            @php
                                $temp = 0;
                            @endphp
                            @foreach ($data['order']->historypayment as $item)
                                @php
                                    $temp++;
                                @endphp

                                <div class="payment-item">
                                    <div class="payment-content">
                                        <div class="payment-meta">
                                            <span class="payment-label">Lần {{ $temp }}:</span>
                                            <span class="payment-value">{{ $item->paid_at ?? '' }}</span>
                                        </div>

                                        <div class="payment-meta">
                                            <span class="payment-label">Tiền:</span>
                                            <span
                                                class="payment-value">{{ number_format($item->amount, 2, ',', '.') }}</span>
                                        </div>

                                        <div class="payment-meta">
                                            <span class="payment-label">Note:</span>
                                            <span class="payment-value">{{ $item->note ?? 'Không có' }}</span>
                                        </div>

                                        <div class="payment-meta">
                                            <span class="payment-label">Người TT:</span>
                                            <span class="payment-value">{{ $item->user->name ?? 'Không xác định' }}</span>
                                        </div>

                                    </div>

                                    <a href="#" class="editPayment payment-edit" data-id="{{ $item->id ?? '' }}"
                                        data-amount="{{ $item->amount }}" data-note="{{ $item->note ?? '' }}">
                                        <i class="far fa-edit" style="color: #dc3545"></i>
                                    </a>
                                </div>
                            @endforeach
                        @else
                            <p>Chưa có lịch sử thanh toán nào.</p>
                        @endif

                    </div>
                </div>
            </div>

            <!-- Cột phải -->
            <div class="col-lg-4">
                <!-- Card: Thông tin đơn nhập hàng -->
                <div class="card-custom">
                    <div class="card-header-custom">
                        Thông tin đơn nhập hàng
                    </div>
                    <div class="card-body-custom">
                        <p class="mb-1">
                            <span class="info-label">Tạo đơn:</span>
                            <span
                                class="info-value">{{ date('d-m-Y', strtotime($data['order']->order_date ?? '')) }}</span>
                        </p>
                        <p class="mb-1">
                            <span class="info-label">Nhập hàng:</span>
                            <span class="info-value">Đang chờ</span>
                        </p>
                        <p class="mb-1">
                            <span class="info-label">Hoàn tất:</span>
                            <span class="info-value">Chưa</span>
                        </p>
                        <p class="mb-0">
                            <span class="info-label">Tình trạng:</span>
                            <span class="info-value text-warning">Đang xử lý</span>
                        </p>
                        <hr>
                        <a href="#" class="text-decoration-none text-primary" style="font-weight: 700">Xem lịch sử đơn
                            nhập hàng</a>
                    </div>
                </div>
                @php
                    // Ép kiểu số an toàn, nếu không có thì mặc định = 0
                    $subtotal = isset($data['order']->subtotal) ? (float) $data['order']->subtotal : 0;
                    $depositPercentage = isset($data['order']->deposit) ? (float) $data['order']->deposit : 0;
                    // Tính số tiền cần thanh toán: Tổng tiền * (Phần trăm cọc / 100)
                    $depositAmount = $subtotal * ($depositPercentage / 100);
                @endphp

                <div class="card-custom" id="payment__Order__Card">
                    <div class="card-header-custom">
                        Thông tin thanh toán
                    </div>
                    <div class="card-body-custom">
                        <p class="mb-1">
                            <span class="info-label">Tổng tiền:</span>
                            <span class="info-value">{{ number_format($subtotal, 2, ',', '.') }}</span>
                        </p>

                        <p class="mb-1">
                            <span class="info-label">Đặt Cọc:</span>
                            @if ($depositPercentage == 0)
                                <span class="info-value text-success">Không cần cọc trước</span>
                            @else
                                <span class="info-value">{{ $depositPercentage }}%</span>
                            @endif
                        </p>
                        <p class="mb-1">
                            @if ($data['order']->deposit > 0)
                                <span class="info-label">Tình trạng:</span>
                                <span
                                    class="info-value {{ $data['order']->historypayment->count() > 0 ? 'text-success' : 'text-dark' }}">
                                    {{ $data['order']->historypayment->count() > 0 ? 'Đã thanh toán cọc' : 'Chưa Thanh Toán Cọc' }}
                                </span>
                            @endif
                        </p>

                        @if ($data['order']->importCosts->count() > 0)
                            <hr style="margin: 3px 0px">
                            @foreach ($data['order']->importCosts as $item)
                                <div class="import-cost-item" data-id="{{ $item->id }}"
                                    data-name="{{ $item->cost_name }}" data-value="{{ $item->cost_value }}"
                                    style="display: flex; justify-content: space-between; align-items: center; gap: 5px; margin-bottom: 10px;">

                                    <p class="mb-0">
                                        <span class="info-label">{{ $item->cost_name }}:</span>
                                        <span
                                            class="info-value">{{ number_format($item->cost_value, 2, '.', ',') }}</span>
                                    </p>

                                    <div class="action-buttons" style="display: flex; gap: 8px; align-items: center;">
                                        <a style="cursor: pointer;" class="btn-edit-cost" data-id="{{ $item->id }}"
                                            data-name="{{ $item->cost_name }}" data-value="{{ $item->cost_value }}">
                                            <i class="far fa-edit text-primary"></i>
                                        </a>
                                        <a style="cursor: pointer;" class="btn-delete-cost"
                                            data-id="{{ $item->id }}">
                                            <i class="fas fa-times text-danger"></i>
                                        </a>

                                    </div>
                                </div>
                            @endforeach
                        @endif


                        @php
                            $totalImportCost = $data['order']->totalImportCost()
                                ? $data['order']->totalImportCost()
                                : 0;

                            $totalAll = $subtotal + $totalImportCost;

                        @endphp
                        <hr style="margin: 3px 0px">
                        <p class="mb-0">
                            <span class="info-label">Tiền Cần Trả :</span>
                            <span class="info-value"
                                style="color: rgb(200, 28, 28)">{{ number_format($totalAll, 2, '.', ',') }} </span>
                        </p>

                        <hr style="margin: 3px 0px">


                        <p class="mb-1">
                            @if ($data['order']->deposit > 0)
                            @elseif($data['order']->historypayment->count() < 1)
                                <a href="#" class="btn btn-info mt-2  payment__Order" id="payment__Order">Thanh
                                    toán <i class="fas fa-money-check ml-2"></i></a>
                            @endif
                        </p>

                        <p class="mb-1">
                            @if ($data['order']->deposit == 0 && $data['order']->historypayment->count() < 1)
                                <a href="#" class="btn btn-info mt-2  payment__Order" id="payment__Order">Thanh
                                    toán <i class="fas fa-money-check ml-2"></i></a>
                            @endif
                        </p>


                    </div>

                    @if (isset($data['order']) && $data['order']->deposit > 0)
                        @if ($data['order']->is_paid == 0)
                            @if ($data['order']->historyPayments->count() > 0)
                                <a href="#" class="ml-3 mr-2 btn btn-info payment__Order" id="payment__Order">
                                    Thanh toán <i class="fas fa-money-check ml-2"></i>
                                </a>
                            @else
                                <div class="card-body-custom mt-0">
                                    <p class="mb-1">
                                        <span class="info-label" style="color: #111">
                                            Số Tiền Cần Thanh Toán (tiền cọc):
                                        </span>
                                        <span class="info-value text-danger">
                                            {{ isset($depositAmount) ? number_format($depositAmount, 2, '.', ',') : '0' }}
                                        </span>
                                    </p>
                                    <a href="#" id="pay-deposit-btn"
                                        class="text-decoration-none btn btn-success mt-2">
                                        Thanh Toán Cọc <i class="ml-2 fas fa-money-check"></i>
                                    </a>
                                </div>
                            @endif
                        @else
                            <span class="btn btn-success mt-3 ml-3" style="display: block">Đã thanh toán đủ tiền</span>
                        @endif
                    @elseif (isset($data['order']) && $data['order']->deposit == 0 && $data['order']->is_paid == 1)
                        <span class="btn btn-success mt-3" style="display: block">Đã thanh toán đủ tiền</span>
                    @endif
                    <hr>
                    <div>
                        <a href="#" id="history_deposit_payments" class="text-decoration-none  ml-3 "
                            style="font-weight: 700"> Xem lịch sử thanh
                            toán <i class="fas fa-history ml-2"></i></a>
                        @if ($data['order']->is_paid == 0)
                            <a href="#" id="importCost" class="btn btn-primary ">Chi Phí Nhập Hàng <i
                                    class="fas fa-hand-holding-usd ml-2"></i></a>
                        @endif
                    </div>


                    @if ($data['order']->importCosts->count() > 0)
                        <div class="card-custom mt-3">
                            <div class="card-header-custom">
                                Chi Phí Nhập Hàng
                            </div>
                            <div class="card-body-custom">
                                @if ($data['order']->importCosts->count() > 0)
                                    @foreach ($data['order']->importCosts as $item)
                                        <p> <strong style="font-weight: 700">{{ $item->cost_name }}:</strong>
                                            {{ $item->cost_value }} |
                                            <span>Ngày Thêm: {{ $item->created_at }}</span>
                                        </p>
                                    @endforeach
                                @endif

                            </div>
                        </div>
                    @endif

                </div>
                <!-- Modal lịch sử thanh toán cọc -->
                <div class="modal fade" id="depositHistoryModal" tabindex="-1"
                    aria-labelledby="depositHistoryModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="depositHistoryModalLabel">Lịch sử thanh toán <i
                                        class="fas fa-history"></i> </h5>

                            </div>
                            <div class="modal-body">
                                @if ($data['order']->historypayment->count() > 0)
                                    <table class="table" id="table10">
                                        <thead>
                                            <tr style="font-size: 14px">
                                                <th>#</th>
                                                <th style="width: 50px;">Số tiền</th>
                                                <th style="width: 120px;">Nội Dung</th>
                                                <th style="width: 60px;">Ngày Thanh Toán</th>
                                                <th style="width: 60px;">Ngày Cập Nhật</th>
                                                <th style="width: 120px;">Nội Dung Cập Nhật</th>
                                                <th style="width: 60px;">Người Thực Hiện</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($data['order']->historypayment as $payment)
                                                <tr style="font-size: 14px">
                                                    <td>{{ $loop->iteration }}</td>
                                                    <td>{{ number_format($payment->amount, 2, '.', ',') }}</td>

                                                    <td>{{ $payment->note ?? '' }}</td>
                                                    <td>{{ \Carbon\Carbon::parse($payment->paid_at)->format('d/m/Y') }}
                                                    </td>
                                                    <td>{{ $payment->date_updated ?? '' }}</td>
                                                    <td>{{ $payment->note_updated ?? '' }}</td>
                                                    <td>{{ $payment->user->name ?? '' }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                @else
                                    <p>Chưa có lịch sử thanh toán nào.</p>
                                @endif
                            </div>

                        </div>
                    </div>
                </div>

                {{-- End lịch sử thanh toán cọc --}}


                <!-- Modal Bootstrap: Thanh toán cọc -->
                <div class="modal fade" id="depositModal" tabindex="-1" aria-labelledby="depositModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Form gửi qua AJAX -->
                            <form id="depositForm" method="POST">
                                @csrf
                                <div class="modal-header">
                                    <h5 class="modal-title" id="depositModalLabel">Thanh Toán Tiền Cọc</h5>

                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label for="depositAmount" class="form-label">Số Tiền Cần Thanh Toán:</label>
                                            <input type="number" class="form-control" id="depositAmount"
                                                name="deposit_amount" value="{{ $depositAmount }}" readonly>
                                        </div>
                                        <!-- Cho phép nhập số tiền thanh toán (mặc định = số tiền cần thanh toán) -->

                                        <div class="mb-3 col-md-6">
                                            <label for="inputDepositAmount" class="form-label">Nhập Số Tiền Thanh
                                                Toán</label>
                                            <input required type="number" class="form-control" id="inputDepositAmount"
                                                name="payment_amount" placeholder="Nhập số tiền thanh toán"
                                                value="{{ $depositAmount }}">
                                        </div>


                                        <div class="mb-3 col-md-6">
                                            <label for="date_payment" class="form-label">Ngày Thanh Toán</label>
                                            <input required type="datetime-local" class="form-control" id="date_payment"
                                                name="date_payment" placeholder="Ngày thanh toán" value="">
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label for="note_payment" class="form-label">Ghi Chú</label>
                                            <input required type="text" class="form-control" id="note_payment"
                                                name="note_payment"
                                                placeholder="Cọc RMB {{ date('d-m-Y') }} Tỉ Giá: 3555"
                                                value="Cọc RMB {{ date('d-m-Y') }} Tỉ Giá: 3555">
                                        </div>
                                    </div>
                                    <!-- Hiển thị số tiền cần thanh toán (readonly) -->

                                    <!-- Ẩn thông tin order_id để gửi về backend -->
                                    <input type="hidden" name="order_id" value="{{ $data['order']->id }}">
                                </div>
                                <div class="modal-footer">

                                    <button type="submit" class="btn btn-success" id="confirmDeposit">Xác nhận thanh
                                        toán <i class="fas fa-location-arrow ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                {{-- End thanh toán cọc --}}


                {{-- Modal Thanh Toán Tiền --}}

                <div class="modal fade" id="paymentOrderModal" tabindex="-1" aria-labelledby="paymentOrderModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Form gửi qua AJAX -->
                            <form id="paymentOrderForm" method="POST">
                                @csrf
                                <div class="modal-header">
                                    <h3 style="width: 100%; text-align: center; font-weight: 700" class="modal-title"
                                        id="paymentOrderModalLabel">Thanh Toán Tiền</h3>

                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="mb-3 col-md-12">

                                            <div class="payment-history-wrapper">
                                                <div class="payment-history-header collapsed">
                                                    <h5>
                                                        <i class="fas fa-history"></i>
                                                        Lịch Sử Thanh Toán
                                                    </h5>
                                                    <i class="fas fa-chevron-down toggle-icon"></i>
                                                </div>

                                                <div class="payment-history-content">
                                                    <table class="payment-history-table">
                                                        <thead>
                                                            <tr>
                                                                <th>Lần Thanh Toán</th>
                                                                <th>Số Tiền</th>
                                                                <th>Ngày Thanh Toán</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @php
                                                                $total = 0;
                                                            @endphp
                                                            @foreach ($data['order']->historypayment as $payment)
                                                                @php
                                                                    $total += $payment->amount;
                                                                @endphp
                                                                <tr>
                                                                    <td>{{ $loop->iteration }}</td>
                                                                    <td>{{ number_format($payment->amount, 2, '.', ',') }}
                                                                    </td>
                                                                    <td>{{ \Carbon\Carbon::parse($payment->paid_at)->format('d/m/Y') }}
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <td>Tổng Cộng</td>
                                                                <td colspan="2">
                                                                    {{ number_format($total, 2, '.', ',') }}</td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>


                                            <hr>
                                            <div class="payment-summary">
                                                <div class="payment-total">
                                                    <div class="payment-total-paid">
                                                        <i class="fas fa-wallet"></i>
                                                        Tổng Tiền Đã Thanh Toán:
                                                        <span
                                                            class="payment-amount">{{ number_format($totalPayment ?? 0, 2, '.', ',') }}
                                                        </span>
                                                    </div>

                                                    @if ($totalAllPayments - $total > 0)
                                                        <div class="payment-debt">
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                            Công Nợ:
                                                            <span
                                                                class="payment-amount">{{ number_format($debt, 2, '.', ',') }}
                                                            </span>
                                                        </div>
                                                    @else
                                                        <div class="payment-complete">
                                                            <i class="fas fa-check-circle"></i>
                                                            Đã Thanh Toán Đủ
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>

                                            <hr>
                                        </div>

                                        <!-- Cho phép nhập số tiền thanh toán (mặc định = số tiền cần thanh toán) -->

                                        <div class="mb-3 col-md-6">
                                            <label for="inputPayment" class="form-label">Nhập Số Tiền Thanh
                                                Toán</label>
                                            <input required type="tel" max="{{ $debt }}"
                                                class="form-control" id="inputPayment" name="payment_amount"
                                                placeholder="Nhập số tiền thanh toán" value="">
                                        </div>


                                        <div class="mb-3 col-md-6">
                                            <label for="date_payment" class="form-label">Ngày Thanh Toán</label>
                                            <input required type="datetime-local" class="form-control" id="date_payment"
                                                name="date_payment" placeholder="Ngày thanh toán" value="">
                                        </div>

                                        <div class="mb-3 col-md-12">
                                            <label for="note_payment" class="form-label">Ghi Chú</label>
                                            <input required type="text" class="form-control" id="note_payment"
                                                name="note_payment"
                                                placeholder="Cọc RMB {{ date('d-m-Y') }} Tỉ Giá: 3555"
                                                value="TT RMB {{ date('d-m-Y') }} Tỉ Giá: 3555">
                                        </div>
                                    </div>
                                    <!-- Hiển thị số tiền cần thanh toán (readonly) -->

                                    <!-- Ẩn thông tin order_id để gửi về backend -->
                                    <input type="hidden" name="order_id" value="{{ $data['order']->id }}">
                                </div>
                                <div class="modal-footer">

                                    <button type="submit" class="btn btn-success" id="confirmPaymentOrder">Xác nhận
                                        thanh
                                        toán <i class="fas fa-check-double ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                {{-- End thanh toán tiền --}}

                <!-- Modal: Thêm chi phí nhập hàng -->
                <div class="modal fade" id="importCostModal" tabindex="-1" aria-labelledby="importCostModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Header -->
                            <div class="modal-header">
                                <h5 class="modal-title" id="importCostModalLabel">Thêm chi phí nhập hàng</h5>

                            </div>

                            <!-- Body -->
                            <div class="modal-body">
                                <form id="importCostForm">
                                    @csrf
                                    <!-- Ẩn order_id, giả sử bạn đang xử lý cho order có id = 123 -->
                                    <input type="hidden" name="order_id" value="{{ $data['order']->id }}">

                                    <!-- Khu vực chứa các dòng chi phí -->
                                    <div id="costItems">
                                        <!-- Dòng chi phí mẫu -->
                                        <div class="cost-item row mb-3">
                                            <div class="col-6">
                                                <input type="text" required class="form-control" name="costName[]"
                                                    placeholder="VD: Vận chuyển, bốc vác...">
                                            </div>
                                            <div class="col-5">
                                                <input type="number" required class="form-control" name="costValue[]"
                                                    placeholder="0">
                                            </div>
                                            <div style="display: flex; justify-content: center; align-items: center;"
                                                class="col-1 text-end">
                                                <button type="button" class="btn btn-danger removeCostItem">X</button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Nút thêm dòng chi phí -->
                                    <button type="button" class="btn btn-secondary mb-3" id="addCostItem">Thêm chi
                                        phí</button>
                                </form>
                            </div>

                            <!-- Footer -->
                            <div class="modal-footer">

                                <button type="button" class="btn btn-primary" id="applyImportCost">Áp dụng <i
                                        class="fas fa-location-arrow ml-2"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- End chi phí nhập hàng --}}



                {{-- Cập Nhật Thông Tin Lịch Sử Thanh Toán --}}

                <!-- Bootstrap Modal -->
                <div class="modal fade" id="updatePaymentModal" tabindex="-1" aria-labelledby="updatePaymentLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="updatePaymentLabel">Cập nhật thanh toán</h5>

                            </div>
                            <div class="modal-body">
                                <form id="updatePaymentForm">
                                    <input type="hidden" id="paymentId">
                                    <div class="mb-3">
                                        <label for="newAmount" class="form-label">Số tiền mới</label>

                                        <input type="hidden" class="form-control" id="orderIdPayment"
                                            value="{{ $data['order']->id }}">
                                        <input type="number" class="form-control" id="newAmount" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="newNote" class="form-label">Ghi chú</label>
                                        <input type="text" class="form-control" id="newNote">
                                    </div>
                                    <button type="button" class="btn btn-primary" id="submitUpdatePayment">Cập
                                        nhật <i class="far fa-save ml-2"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- End cập nhật thanh toán --}}

                <!-- Bootstrap Modal - Cập nhật chi phí nhập hàng-->
                <div class="modal fade" id="updateCostModal" tabindex="-1" aria-labelledby="updateCostLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="updateCostLabel">Cập nhật chi phí nhập hàng</h5>

                            </div>
                            <div class="modal-body">
                                <form id="updateCostForm">
                                    <input type="hidden" id="costId">
                                    <div class="mb-3">
                                        <label for="costName" class="form-label">Tên chi phí</label>
                                        <input type="text" class="form-control" id="costName" required>
                                        <input type="hidden" class="form-control" id="orderIdCost"
                                            value="{{ $data['order']->id }}">
                                    </div>
                                    <div class="mb-3">
                                        <label for="costValue" class="form-label">Giá trị chi phí</label>
                                        <input type="tel" class="form-control" id="costValue" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Cập nhật <i
                                            class="far fa-save ml-2"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Xác nhận xóa tất cả chi phí nhập hàng -->
                <div class="modal fade" id="deleteAllCostModal" tabindex="-1" aria-labelledby="deleteAllCostLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteAllCostLabel">Xóa tất cả chi phí</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Bạn có chắc chắn muốn xóa tất cả chi phí không?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                <button type="button" class="btn btn-danger" id="confirmDeleteAll">Xóa tất cả</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        {{-- Danh sách dời dự kiến hàng về --}}
        <div class="card-custom">
            <div class="card-header-custom">
                <div class="forecast__title">
                    <div class="group__forecast-order">
                        <p>Dự Kiến Nhập Hàng </p>
                        <button style="font-size: 16px" id="lightbulb">Gợi Ý <i class="far fa-lightbulb"></i> </button>
                    </div>



                    <button style="font-size: 16px" id="actionSplitOrder">Mở Rộng </button>
                </div>
            </div>
            <div class="card-body-custom" id="box__UpdateOrder">
                <div class="table-responsive">
                    <table class="table table-products mb-0">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Sku</th>
                                <th>Key Chuẩn</th>
                                <th>Ngày Đặt</th>
                                <th>SL</th>
                                <th>Sản Xuất Xong</th>
                                <th>Ngày Dự Kiến Về</th>
                                <th>Ngày Dự Kiến Sale</th>
                                <th>Kho</th>
                                <th>Container</th>
                                <th>Trạng Thái</th>
                            </tr>
                        </thead>
                        <tbody id="orderTableUpdate">
                            <form id="orderFormUpdate">
                                @php $temp = 0; @endphp
                                @foreach ($data['orderDetail'] as $key => $item)
                                    @php $temp++; @endphp
                                    <tr class="order-row-New">
                                        <td>{{ $temp }}</td>
                                        <td>{{ $item->sku ?? '' }}</td>
                                        <td>{{ $item->forecastProduct->sale_key ?? '' }}</td>
                                        <td>{{ date('d-m-Y', strtotime($data['order']->order_date ?? '')) }}</td>
                                        <td>
                                            <input type="hidden" name="data[{{ $key }}][order_id]"
                                                value="{{ $data['order']->id }}">
                                            <input type="hidden" name="data[{{ $key }}][sku]"
                                                value="{{ $item->sku }}">
                                            <input readonly style="    width: 100px;" class="form-control quantity"
                                                type="number" name="data[{{ $key }}][quantity]"
                                                value="{{ $item->quantity }}" min="1">
                                        </td>
                                        <td><input class="date_of_manufacture form-control"
                                                style="width: 140px; font-weight: 300" type="date"
                                                name="data[{{ $key }}][date_of_manufacture]"
                                                value="{{ $item->date_of_manufacture ?? '' }}"></td>
                                        <td><input class="date_estimated_arrival form-control"
                                                style="width: 140px;font-weight: 300" type="date"
                                                name="data[{{ $key }}][date_estimated_arrival]"
                                                value="{{ $item->expected_date ?? '' }}"></td>
                                        <td><input class="date_for_sale form-control"
                                                style="width: 140px; font-weight: 300" type="date"
                                                name="data[{{ $key }}][date_for_sale]"
                                                value="{{ $item->date_for_sale ?? '' }}"></td>
                                        <td>
                                            <select style="    width: 120px;font-weight: 300; font-size: 14px;"
                                                class="form-control ware_housing"
                                                name="data[{{ $key }}][ware_housing]">
                                                <option value="">Chọn Kho</option>
                                                <option value="KHO HCM"
                                                    {{ old('ware_housing', $item->ware_housing) == 'KHO HCM' ? 'selected' : '' }}>
                                                    KHO HCM</option>
                                                <option value="KHO HN"
                                                    {{ old('ware_housing', $item->ware_housing) == 'KHO HN' ? 'selected' : '' }}>
                                                    KHO HN</option>
                                            </select>
                                        </td>
                                        <td><input class="form-control container" type="text"
                                                style="font-weight: 300; width: 150px;"
                                                value="{{ $item->container ?? '' }}"
                                                name="data[{{ $key }}][container]" placeholder="Nhập container">
                                        </td>

                                        <td style="display: flex; justify-content: center; align-items: center;">
                                            @if ($item->status == 0)
                                                <a style="font-size: 25px;"
                                                    href="{{ route('updateStatusOrder', ['id' => $item->id, 'status' => 1]) }}">
                                                    <i class="fas fa-toggle-off"></i>
                                                </a>
                                            @else
                                                <a style="font-size: 25px; color:green"
                                                    href="{{ route('updateStatusOrder', ['id' => $item->id, 'status' => 0]) }}"><i
                                                        class="fas fa-toggle-on"></i></a>
                                            @endif
                                        </td>

                                    </tr>
                                @endforeach
                            </form>
                        </tbody>
                    </table>
                </div>

                <!-- Nút Thao Tác -->
                <div class="summary-box mt-3">
                    <button type="button"id="updateOrder" class="btn btn-success">Cập Nhật <i
                            class="far fa-save ml-2"></i></button>

                </div>
            </div>

            <div class="card-body-custom box__splitOrder" id="box__splitOrder" style="display: none;">
                <div class="table-responsive">
                    <table class="table table-products mb-0">
                        <thead>
                            <tr>
                                <th>Chọn</th>
                                <th>STT</th>
                                <th>Sku</th>
                                <th>Key Chuẩn</th>
                                <th>Ngày Đặt</th>
                                <th>SL</th>
                                <th>Sản Xuất Xong</th>
                                <th>Ngày Dự Kiến Về</th>
                                <th>Ngày Dự Kiến Sale</th>
                                <th>Kho</th>
                                <th>Container</th>
                                <th>Note</th>
                            </tr>
                        </thead>
                        <tbody id="orderTable">
                            <form id="orderForm">
                                @php $temp = 0; @endphp
                                @foreach ($data['orderDetail'] as $key => $item)
                                    @php $temp++; @endphp
                                    <tr class="order-row">
                                        <td><input type="checkbox" class="select-row"></td>
                                        <td>{{ $temp }}</td>
                                        <td style="width: 95px;">{{ $item->sku ?? '' }}</td>
                                        <td style="width: 95px;">{{ $item->forecastProduct->sale_key ?? '' }}</td>
                                        <td style=" width: 120px;">
                                            {{ date('d-m-Y', strtotime($data['order']->order_date ?? '')) }}</td>
                                        <td>
                                            <input type="hidden" name="data[{{ $key }}][order_id]"
                                                value="{{ $data['order']->id }}">
                                            <input type="hidden" name="data[{{ $key }}][sku]"
                                                value="{{ $item->sku }}">
                                            <input style="    width: 70px;" class="form-control quantity" type="number"
                                                name="data[{{ $key }}][quantity]" value="{{ $item->quantity }}"
                                                min="1">
                                        </td>
                                        <td><input style="width: 120px;" class="form-control date_of_manufacture_split"
                                                type="date" name="data[{{ $key }}][date_of_manufacture]"
                                                value="{{ $item->date_of_manufacture ?? '' }}"></td>
                                        <td><input style="width: 120px;" class="form-control date_estimated_arrival_split"
                                                type="date" name="data[{{ $key }}][date_estimated_arrival]"
                                                value="{{ $item->expected_date ?? '' }}"></td>
                                        <td><input style="width: 120px;" class="form-control date_for_sale_split"
                                                type="date" name="data[{{ $key }}][date_for_sale]"
                                                value="{{ $item->date_for_sale ?? '' }}"></td>
                                        <td>
                                            <select style="    width: 120px;" class="form-control ware_housing"
                                                name="data[{{ $key }}][ware_housing]">
                                                <option value="KHO HCM"
                                                    {{ old('ware_housing', $item->ware_housing) == 'KHO HCM' ? 'selected' : '' }}>
                                                    KHO HCM</option>
                                                <option value="KHO HN"
                                                    {{ old('ware_housing', $item->ware_housing) == 'KHO HN' ? 'selected' : '' }}>
                                                    KHO HN</option>
                                            </select>
                                        </td>
                                        <td><input style="width: 120px;" class="form-control container" type="text"
                                                value="{{ $item->container ?? '' }}"
                                                name="data[{{ $key }}][container]"
                                                placeholder="Nhập container">
                                        </td>
                                        {{-- <td>
                                            <button type="button" class="btn btn-danger remove-row">Xóa</button>
                                        </td> --}}
                                        <td>
                                            <input style="width: 190px;" type="text"
                                                name="data[{{ $key }}][note]" id="note"
                                                class="form-control" placeholder="Ghi Chú"
                                                value="{{ $item->note ?? '' }}">
                                        </td>
                                    </tr>
                                @endforeach
                            </form>
                        </tbody>
                    </table>
                </div>

                <!-- Nút Thao Tác -->
                <div class="summary-box mt-3">
                    <button type="button" id="updateOrderDetail" class="btn btn-primary">Cập Nhật <i
                            class="far fa-save ml-2"></i></button>
                    <button type="button" id="splitLoad" class="btn btn-warning">Tách Load <i
                            class="far fa-save ml-2"></i></button>
                </div>
            </div>
        </div>


        <!-- Danh sách sản phẩm -->
        <div class="card-custom">
            <div class="card-header-custom">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h5>Danh sách sản phẩm</h5>

                    <button type="button" class="btn btn-primary" id="btnAddProduct">
                        <i class="fas fa-plus"></i> Thêm sản phẩm mới
                    </button>
                </div>

            </div>
            <div class="card-body-custom">
                <div class="table-responsive">
                    <table class="table table-products mb-0">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Mã Đơn Hàng</th>
                                <th>Hình</th>
                                <th>Key Chuẩn</th>
                                <th>SKU</th>
                                <th>Số lượng</th>
                                <th>Đơn giá</th>
                                <th>Thành tiền</th>
                                <th>Đơn Vị</th>
                                <th>Ghi Chú</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $temp = 0;
                            @endphp

                            @foreach ($data['orderDetail'] as $item)
                                @php
                                    $temp++;

                                    $total = $item->quantity * (int) $item->forecastProduct->price;
                                @endphp
                                <tr>
                                    <td>{{ $temp }}</td>
                                    <td>{{ $item->order_code ?? '' }}</td>
                                    <td>
                                        <img style="width: 100px; height: 100px; object-fit: cover; border-radius: 6px"
                                            src="{{ asset('uploads/forecast_products/' . $item->forecastProduct->image ?? '') }}"
                                            alt="{{ $item->forecastProduct->sale_key ?? '' }}">
                                    </td>
                                    <td>{{ $item->forecastProduct->sale_key ?? '' }}</td>
                                    <td>{{ $item->sku ?? '' }}</td>
                                    <td>{{ $item->quantity ?? '' }}</td>
                                    <td>{{ $item->forecastProduct->price ?? '' }}</td>
                                    <td>{{ number_format($total ?? '') }}</td>
                                    <td>{{ $item->unit ?? '' }}</td>
                                    <td>{{ $item->noteOrder ?? '' }}</td>
                                </tr>
                            @endforeach


                        </tbody>
                    </table>
                </div>

                <!-- Khối Tóm Tắt Đơn Hàng -->
                <div class="summary-box mt-3">
                    <div class="summary-notes">
                        <p class="mb-1"><strong>Ghi chú đơn:</strong></p>
                        <p class="mb-0">{{ $data['order']->note ?? '' }}</p>
                    </div>
                    <div class="summary-totals">
                        <p>Số Lượng: <span>{{ $data['order']->total_quantity ?? '' }}</span></p>

                        <p>Tổng Tiền Phải Trả: <span>{{ number_format($totalAll, 2, '.', ',') }}</span></p>

                        </span></p>

                        <p>Còn Lại: <span>{{ number_format($debt, 2, '.', ',') }}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Supplier Info Modal Thông tin gợi ý nhà cung cấp -->
    <div class="modal fade" id="supplierModal" tabindex="-1" aria-labelledby="supplierModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg supplier-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="supplierModalLabel">
                        <i class="fas fa-truck me-2"></i>Thông Tin Nhà Cung Cấp
                    </h5>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <h3>Thông Tin Công Ty</h3>
                                    <h6 class="card-subtitle mb-2 ">
                                        <strong>Tên Công Ty: </strong> {{ $data['order']->supplier->company_name ?? '' }}
                                    </h6>

                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="far fa-clock mr-2"></i>Thời Gian Sản Xuất: </span>
                                            <span>{{ $data['order']->supplier->production_time ?? '' }}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="far fa-clock mr-2"></i>Thời Gian Vận Chuyển: </span>
                                            <span>{{ $data['order']->supplier->shipping_time ?? '' }}</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="far fa-clock mr-2"></i>Tổng Thời Gian Về Kho Dự Kiến:
                                            </span>
                                            <span>{{ $data['order']->supplier->total_lead_time ?? '' }}</span>
                                        </li>
                                        <li style="width: 100%;"
                                            class="list-group-item d-flex justify-content-between align-items-center">
                                            <span style="width: 30%;"><i class="fas fa-calendar-alt mr-2"></i>Lịch Nghỉ
                                                Tết, Lễ :</span>
                                            <span style="width: 70%;">{!! $data['order']->supplier->holiday_schedule ?? '' !!}</span>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-calendar-alt mr-2"></i>Hình Thức Thanh Toán:</span>
                                            <span>{{ $data['order']->supplier->payments ?? '' }}</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>

            </div>
        </div>
    </div>


    <!-- Thêm chức năng search SKU vào form thêm sản phẩm -->
    <div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addProductModalLabel">Thêm Sản Phẩm Mới</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addProductForm" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="order_id" value="{{ $data['order']->id ?? '' }}">
                        <input type="hidden" name="order_code" value="{{ $data['order']->order_code ?? '' }}">

                        <div class="form-group">
                            <label for="sku">SKU</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="sku" name="sku" required>
                                <div class="input-group-append">
                                    <button style="background-color: #17a2b8; color: #fff;"
                                        class="btn btn-outline-secondary" type="button" id="searchSku">
                                        <i class="fas fa-search"></i> Tìm kiếm
                                    </button>
                                </div>
                            </div>
                            <div id="skuSearchResults" class="list-group mt-2"
                                style="display: none; position: absolute; z-index: 1000; width: 94%; height: 300px; overflow-y: scroll;">
                            </div>
                            <small class="form-text text-muted">Nhập SKU và nhấn tìm kiếm hoặc bắt đầu gõ để tìm sản
                                phẩm</small>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="product_name">Key Chuẩn</label>
                                <input type="text" class="form-control" id="product_name" name="product_name"
                                    required>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="">Đơn Vị</label>
                                <select required class="form-control" name="unit" id="unit">
                                    <option value="RMB">RMB</option>
                                    <option value="USD">USD</option>
                                    <option value="VND">VND</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="quantity">Số lượng</label>
                                <input type="number" class="form-control" id="quantity" name="quantity"
                                    min="1" value="1" required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="price">Đơn giá</label>
                                <input type="number" class="form-control" id="price" name="price" min="0"
                                    required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="total">Thành tiền</label>
                                <input type="number" class="form-control" id="total" name="total" readonly>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="product_image">Hình ảnh</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="product_image"
                                        name="product_image">
                                    <label class="custom-file-label" for="product_image">Chọn file</label>
                                </div>
                            </div>
                            <div id="imagePreview" class="mt-2" style="display: none;">
                                <img src="" id="previewImg"
                                    style="max-width: 200px; max-height: 200px; object-fit: contain;">
                            </div>
                        </div>

                        <input type="hidden" id="product_id" name="product_id">

                        <div class="form-group">
                            <label for="note">Ghi chú</label>
                            <textarea class="form-control" id="note" name="noteOrder" rows="2"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="saveProduct">Lưu sản phẩm</button>
                </div>
            </div>
        </div>
    </div>


    {{-- End thêm mới sản phẩm trong đơn hàng --}}

@endsection
@section('js')
    <script>
        /* Chức Năng Hướng Dẫn */
        // Khởi tạo hướng dẫn sử dụng khi người dùng nhấn vào nút
        document.addEventListener('DOMContentLoaded', function() {
            const helpGuideBtn = document.getElementById('helpguide-btn');

            if (helpGuideBtn) {
                helpGuideBtn.addEventListener('click', function() {
                    Swal.fire({
                        title: '<strong>Hướng dẫn sử dụng hệ thống</strong>',
                        icon: 'info',
                        html: `
                    <div class="helpguide__content">
                        <div class="helpguide__step">
                            <div class="helpguide__step-header">
                                <i class="fas fa-clipboard-list helpguide__icon"></i>
                                <h3>1. Thông tin đơn hàng</h3>
                            </div>
                            <div class="helpguide__step-body">
                                <p>Bạn có thể xem thông tin chi tiết đơn hàng, mã đơn, thông tin nhà cung cấp và trạng thái đơn hàng.</p>
                                <p>Nhấn <strong>"Tạo Mới"</strong> để thêm đơn nhập hàng mới.</p>
                            </div>
                        </div>

                        <div class="helpguide__step">
                            <div class="helpguide__step-header">
                                <i class="fas fa-money-bill-wave helpguide__icon"></i>
                                <h3>2. Quản lý thanh toán</h3>
                            </div>
                            <div class="helpguide__step-body">
                                <p>Xem công nợ và lịch sử thanh toán trong mục <strong>"Thông tin thanh toán"</strong>.</p>
                                <p>Nhấn <strong>"Thanh toán"</strong> để thực hiện thanh toán mới.</p>
                                <p>Nhấn <strong>"Xem lịch sử thanh toán"</strong> để theo dõi các khoản đã thanh toán.</p>
                            </div>
                        </div>
                        
                        <div class="helpguide__step">
                            <div class="helpguide__step-header">
                                <i class="fas fa-shipping-fast helpguide__icon"></i>
                                <h3>3. Dự kiến nhập hàng</h3>
                            </div>
                            <div class="helpguide__step-body">
                                <p>Cập nhật thông tin dự kiến nhập hàng trong bảng <strong>"Dự Kiến Nhập Hàng"</strong>.</p>
                                <p>Nhấn <strong>"Mở Rộng"</strong> để chỉnh sửa chi tiết hoặc tách đơn.</p>
                                <p>Nhấn <strong>"Gợi Ý"</strong> để xem thông tin nhà cung cấp và ước tính thời gian.</p>
                                <p>Nhấn <strong>"Cập Nhật"</strong> để lưu thay đổi.</p>
                            </div>
                        </div>
                        
                        <div class="helpguide__step">
                            <div class="helpguide__step-header">
                                <i class="fas fa-box-open helpguide__icon"></i>
                                <h3>4. Quản lý sản phẩm</h3>
                            </div>
                            <div class="helpguide__step-body">
                                <p>Xem danh sách sản phẩm trong đơn hàng.</p>
                                <p>Nhấn <strong>"Thêm sản phẩm mới"</strong> để bổ sung sản phẩm vào đơn hàng.</p>
                                <p>Tìm kiếm sản phẩm bằng SKU hoặc tên sản phẩm.</p>
                            </div>
                        </div>
                        
                        <div class="helpguide__step">
                            <div class="helpguide__step-header">
                                <i class="fas fa-hand-holding-usd helpguide__icon"></i>
                                <h3>5. Chi phí nhập hàng</h3>
                            </div>
                            <div class="helpguide__step-body">
                                <p>Nhấn <strong>"Chi Phí Nhập Hàng"</strong> để thêm các chi phí phát sinh.</p>
                                <p>Chỉnh sửa hoặc xóa chi phí hiện có bằng cách nhấn vào biểu tượng bút chì hoặc dấu X.</p>
                            </div>
                        </div>
                    </div>
                `,
                        width: '700px',
                        showCloseButton: true,
                        showConfirmButton: true,
                        confirmButtonText: 'Đã hiểu',
                        confirmButtonColor: '#3085d6',
                        footer: '<a href="#">Liên hệ hỗ trợ kỹ thuật</a>'
                    });
                });
            }
        });


        /* ---------------------------------------------------- */




        /*-----------------Chức năng kiểm tra số tiền cọc -------------------------*/

        document.addEventListener('DOMContentLoaded', function() {
            const depositAmountField = document.getElementById('depositAmount');
            const inputDepositField = document.getElementById('inputDepositAmount');

            // Add validation on blur (when user finishes typing)
            inputDepositField.addEventListener('blur', function() {
                const maxDepositAmount = parseFloat(depositAmountField.value);
                const inputAmount = parseFloat(this.value);

                if (inputAmount > maxDepositAmount) {
                    Swal.fire({
                        title: 'Cảnh báo!',
                        text: 'Số tiền thanh toán không được lớn hơn số tiền cần thanh toán.',
                        icon: 'warning',
                        confirmButtonText: 'Đã hiểu'
                    });

                    // Reset to the max deposit amount
                    this.value = maxDepositAmount;
                } else if (inputAmount <= 0 || isNaN(inputAmount)) {
                    Swal.fire({
                        title: 'Cảnh báo!',
                        text: 'Vui lòng nhập số tiền thanh toán hợp lệ.',
                        icon: 'warning',
                        confirmButtonText: 'Đã hiểu'
                    });

                    // Reset to the max deposit amount
                    this.value = maxDepositAmount;
                }
            });

            // Add validation before form submission
            const form = inputDepositField.closest('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const maxDepositAmount = parseFloat(depositAmountField.value);
                    const inputAmount = parseFloat(inputDepositField.value);

                    if (inputAmount > maxDepositAmount) {
                        e.preventDefault();
                        Swal.fire({
                            title: 'Cảnh báo!',
                            text: 'Số tiền thanh toán không được lớn hơn số tiền cần thanh toán.',
                            icon: 'warning',
                            confirmButtonText: 'Đã hiểu'
                        });

                        // Reset to the max deposit amount
                        inputDepositField.value = maxDepositAmount;
                    }
                });
            }
        });

        /* --------------------------------------- END ---------------------------------------------------------- */

        /* side up thành lịch sử thanh toán trong thanh toán */
        $(document).ready(function() {
            $('.payment-history-header').on('click', function() {
                // Toggle classes
                $(this).toggleClass('expanded').toggleClass('collapsed');

                // Toggle content visibility
                var $content = $(this).next('.payment-history-content');
                $content.toggleClass('show');

                // Rotate toggle icon
                $(this).find('.toggle-icon').css('transform',
                    $(this).hasClass('expanded') ? 'rotate(180deg)' : 'rotate(0deg)'
                );
            });
        });


        /* popup gợi ý nhà cung cấp */

        document.getElementById('lightbulb').addEventListener('click', function() {
            var supplierModal = new bootstrap.Modal(document.getElementById('supplierModal'));
            supplierModal.show();
        });

        $(document).ready(function() {


            // Mở modal thêm sản phẩm
            $(document).ready(function() {
                $('#btnAddProduct').click(function(e) {
                    e.preventDefault(); // Prevent default button action

                    // Check if the product already exists in the order
                    Swal.fire({
                        title: 'Thêm Sản Phẩm',
                        text: 'Chỉ thêm sản phẩm không có trong đơn hàng. Nếu sản phẩm đã có trong đơn hàng, vui lòng cập nhật số lượng.',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Tiếp tục',
                        cancelButtonText: 'Hủy bỏ'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Reset the form
                            $('#addProductForm')[0].reset();

                            // Hide image preview and search results
                            $('#imagePreview').hide();
                            $('#skuSearchResults').hide();

                            // Show the modal
                            $('#addProductModal').modal('show');
                        }
                    });
                });
            });


            // Tính tổng tiền khi thay đổi số lượng hoặc đơn giá
            $('#quantity, #price').on('input', function() {
                calculateTotal();
            });

            function calculateTotal() {
                var quantity = parseInt($('#quantity').val()) || 0;
                var price = parseFloat($('#price').val()) || 0;
                var total = quantity * price;
                $('#total').val(total);
            }

            // Tìm kiếm SKU khi nhấn nút tìm kiếm
            $('#searchSku').click(function() {
                searchProducts();
            });

            // Tìm kiếm SKU khi gõ
            $('#sku').on('input', function() {
                var query = $(this).val().trim();
                if (query.length >= 2) { // Chỉ tìm kiếm khi có ít nhất 2 ký tự
                    searchProducts();
                } else {
                    $('#skuSearchResults').hide();
                }
            });

            // Hiển thị hình ảnh xem trước khi chọn file
            $('#product_image').change(function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#previewImg').attr('src', e.target.result);
                        $('#imagePreview').show();
                    }
                    reader.readAsDataURL(file);
                    $('.custom-file-label').text(file.name);
                }
            });

            // Hàm tìm kiếm sản phẩm theo SKU
            function searchProducts() {
                var query = $('#sku').val().trim();
                if (query.length === 0) return;

                $.ajax({
                    url: "{{ route('product.search') }}", // Cần tạo route này trong Laravel
                    type: 'GET',
                    data: {
                        query: query
                    },
                    success: function(response) {
                        var resultsContainer = $('#skuSearchResults');
                        resultsContainer.empty();

                        if (response.data.length > 0) {
                            response.data.forEach(function(product) {
                                var item = $(`
                            <a href="#" class="list-group-item list-group-item-action product-item">
                                <div class="d-flex align-items-center">
                                    <div class="mr-3">
                                        <img src="${product.image_url || '{{ asset('images/no-image.png') }}'}" 
                                             style="width: 50px; height: 50px; object-fit: cover;" alt="${product.name}">
                                    </div>
                                    <div>
                                        <h6 class="mb-1">${product.name}</h6>
                                        <small>SKU: ${product.sku} | Size: ${product.size || 'N/A'} | Màu: ${product.color || 'N/A'}</small>
                                        <p class="mb-0 text-primary">Giá: ${parseInt(product.price).toLocaleString()} đ</p>
                                    </div>
                                </div>
                            </a>
                        `);

                                // Lưu dữ liệu sản phẩm vào data attribute
                                item.data('product', product);

                                // Thêm sự kiện click cho item
                                item.click(function(e) {
                                    e.preventDefault();
                                    var selectedProduct = $(this).data('product');
                                    fillProductForm(selectedProduct);
                                    resultsContainer.hide();
                                });

                                resultsContainer.append(item);
                            });

                            resultsContainer.show();
                        } else {
                            resultsContainer.html(
                                '<div class="list-group-item">Không tìm thấy sản phẩm nào</div>');
                            resultsContainer.show();
                        }
                    },
                    error: function() {
                        $('#skuSearchResults').html(
                            '<div class="list-group-item text-danger">Đã xảy ra lỗi khi tìm kiếm</div>'
                        );
                        $('#skuSearchResults').show();
                    }
                });
            }

            // Hàm điền thông tin sản phẩm vào form
            function fillProductForm(product) {
                $('#product_id').val(product.id);
                $('#product_name').val(product.name);
                $('#sku').val(product.sku);
                $('#price').val(product.price);

                // Hiển thị hình ảnh nếu có
                if (product.image_url) {
                    $('#previewImg').attr('src', product.image_url);
                    $('#imagePreview').show();
                } else {
                    $('#imagePreview').hide();
                }

                // Tính lại tổng tiền
                calculateTotal();
            }

            // Xử lý khi nhấn nút lưu sản phẩm
            $('#saveProduct').click(function() {
                var formData = new FormData($('#addProductForm')[0]);
                $.ajax({
                    url: "{{ route('order.add.product') }}",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            // Thêm sản phẩm mới vào bảng
                            var newRow = `
                        <tr>
                            <td>${$('#productTableBody tr').length + 1}</td>
                            <td>${formData.get('order_code')}</td>
                            <td>
                                <img style="width: 100px; height: 100px; object-fit: cover; border-radius: 6px"
                                    src="${response.image_url}"
                                    alt="${formData.get('product_name')}">
                            </td>
                            <td>${formData.get('product_name')}</td>
                            <td>${formData.get('sku')}</td>
                            <td>${formData.get('quantity')}</td>
                            <td>${parseInt(formData.get('price')).toLocaleString()}</td>
                            <td>${parseInt(formData.get('total')).toLocaleString()}</td>
                            <td>${formData.get('note') || ''}</td>
                        </tr>
                    `;
                            $('#productTableBody').append(newRow);

                            // Cập nhật tổng số lượng và tổng tiền
                            updateOrderSummary(response.order_data);

                            // Đóng modal
                            $('#addProductModal').modal('hide');

                            // Hiển thị thông báo thành công

                            Swal.fire({
                                icon: 'success',
                                title: 'Thành công!',
                                text: 'Thêm sản phẩm thành công!',
                                showConfirmButton: false,
                                timer: 2000
                            }).then(function() {
                                // Optionally: cập nhật giao diện hoặc reload trang
                                location.reload();
                            });


                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi!',
                                text: errors[key][0],
                            });
                        }
                    },
                    error: function(xhr) {
                        var errors = xhr.responseJSON.errors;
                        var errorMessage = '';

                        for (var key in errors) {
                            errorMessage += errors[key][0] + '<br>';
                            toastr.error(errors[key][0]);
                        }
                    }
                });
            });

            // Đóng kết quả tìm kiếm khi click ra ngoài
            $(document).on('click', function(e) {
                if (!$(e.target).closest('#sku, #skuSearchResults, #searchSku').length) {
                    $('#skuSearchResults').hide();
                }
            });

            // Hàm cập nhật thông tin tóm tắt đơn hàng
            function updateOrderSummary(orderData) {
                $('#totalQuantity').text(orderData.total_quantity);
                $('#subtotal').text(parseInt(orderData.subtotal).toLocaleString());
                $('#grandTotal').text(parseInt(orderData.grand_total).toLocaleString());
            }
        });

        /* Lịch sử thanh toán cọc */
        document.addEventListener('DOMContentLoaded', function() {
            // Khởi tạo modal lịch sử thanh toán
            var depositHistoryModalEl = document.getElementById('depositHistoryModal');
            var depositHistoryModal = new bootstrap.Modal(depositHistoryModalEl);

            // Lắng nghe sự kiện click trên link lịch sử thanh toán
            var historyBtn = document.getElementById('history_deposit_payments');
            if (historyBtn) {
                historyBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    depositHistoryModal.show();
                });
            }
        });

        /* Xử lý thanh toán tiền cọc */

        document.addEventListener('DOMContentLoaded', function() {
            // Khởi tạo modal Bootstrap
            var depositModalEl = document.getElementById('depositModal');
            var depositModal = new bootstrap.Modal(depositModalEl);

            // Khi nhấn nút "Thanh Toán Cọc" hiển thị modal
            var payDepositBtn = document.getElementById('pay-deposit-btn');
            if (payDepositBtn) {
                payDepositBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    depositModal.show();
                });
            }

            // Xử lý submit form thanh toán cọc qua AJAX
            $('#depositForm').submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize();

                $.ajax({
                    url: '{{ route('order.deposit.confirm') }}', // Đường dẫn route xử lý thanh toán
                    method: 'POST',
                    data: formData,
                    beforeSend: function() {
                        $('#confirmDeposit').prop('disabled', true);
                    },
                    success: function(response) {
                        $('#confirmDeposit').prop('disabled', false);
                        if (response.success) {
                            // Ẩn modal khi thanh toán thành công
                            depositModal.hide();
                            // Sử dụng SweetAlert2 để thông báo thành công
                            Swal.fire({
                                icon: 'success',
                                title: 'Thanh toán cọc thành công!',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(function() {
                                // Optionally: cập nhật giao diện hoặc reload trang
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Thanh toán không thành công',
                                text: response.message
                            });
                        }
                    },
                    error: function() {
                        $('#confirmDeposit').prop('disabled', false);
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi',
                            text: 'Có lỗi xảy ra khi xử lý thanh toán.'
                        });
                    }
                });
            });
        });


        document.getElementById("inputPayment").addEventListener("input", function() {
            let maxAmount = parseFloat(this.getAttribute("max"));
            let enteredAmount = parseFloat(this.value);

            if (!isNaN(enteredAmount) && enteredAmount > maxAmount) {
                Swal.fire({
                    icon: "error",
                    title: "Lỗi!",
                    text: "Số tiền nhập vào vượt quá giới hạn!",
                }).then(() => {
                    Swal.fire({
                        icon: "warning",
                        title: "Chú ý!",
                        text: "Vui lòng nhập số tiền nhỏ hơn hoặc bằng " + maxAmount + "!",
                    });
                });
                this.value = maxAmount; // Đặt lại giá trị tối đa
            }
        });

        /* Xử Lý Thanh Toán */

        document.addEventListener('DOMContentLoaded', function() {
            // Khởi tạo modal Bootstrap cho thanh toán đơn hàng
            var paymentOrderModalEl = document.getElementById('paymentOrderModal');
            var paymentOrderModal = new bootstrap.Modal(paymentOrderModalEl);

            // Khi nhấn nút "Thanh Toán", hiển thị modal
            var payOrderBtn = document.querySelector('.payment__Order');
            if (payOrderBtn) {
                payOrderBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    paymentOrderModal.show();
                });
            }

            // Xử lý submit form thanh toán đơn hàng qua AJAX
            $('#paymentOrderForm').submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize();

                $.ajax({
                    url: '{{ route('order.payment.confirm') }}', // Đường dẫn route xử lý thanh toán đơn hàng
                    method: 'POST',
                    data: formData,
                    beforeSend: function() {
                        $('#confirmPaymentOrder').prop('disabled', true);
                    },
                    success: function(response) {
                        $('#confirmPaymentOrder').prop('disabled', false);
                        if (response.success) {
                            // Ẩn modal khi thanh toán thành công
                            paymentOrderModal.hide();
                            // Hiển thị thông báo thành công với SweetAlert2
                            Swal.fire({
                                icon: 'success',
                                title: 'Thanh toán thành công!',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(function() {
                                location
                                    .reload(); // Reload trang để cập nhật trạng thái
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Thanh toán không thành công',
                                text: response.message
                            });
                        }
                    },
                    error: function() {
                        $('#confirmPaymentOrder').prop('disabled', false);
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi',
                            text: 'Có lỗi xảy ra khi xử lý thanh toán.'
                        });
                    }
                });
            });
        });
        /* End  Xử Lý Đơn Hàng*/
        /* Cập Nhật Giá Thị Thanh Toán */
        // Hiệu ứng khi mở modal
        $('#updatePaymentModal').on('show.bs.modal', function() {
            $(this).find('.modal-content').css({
                'transform': 'translateY(20px)',
                'opacity': '0'
            }).animate({
                'transform': 'translateY(0)',
                'opacity': '1'
            }, 300);
        });
        $(document).ready(function() {
            $(".editPayment").click(function() {
                let paymentId = $(this).data("id");
                let currentAmount = $(this).data("amount");
                let currentNote = $(this).data("note");
                let orderIdPayment = {{ $data['order']->id }};
                // Đưa dữ liệu vào modal
                $("#paymentId").val(paymentId);
                $("#newAmount").val(currentAmount);
                $("#newNote").val(currentNote);
                // Hiển thị modal
                $("#updatePaymentModal").modal("show");
            });
            $("#submitUpdatePayment").on('click', function(event) {
                event.preventDefault();
                let orderIdPayment = {{ $data['order']->id }};
                let paymentId = $("#paymentId").val();
                let newAmount = $("#newAmount").val();
                let newNote = $("#newNote").val();

                $.ajax({
                    url: "{{ route('updatePaymentHistoryAjax') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        id: paymentId,
                        amount: newAmount,
                        note: newNote,
                        orderIdPayment: orderIdPayment,
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire("Thành công!", "Cập nhật thanh toán thành công!",
                                    "success")
                                .then(() => location.reload());
                        } else {
                            Swal.fire("Lỗi!", "Không thể cập nhật, thử lại sau!", "error");
                        }
                    },
                    error: function() {
                        Swal.fire("Lỗi!", "Đã xảy ra lỗi, thử lại sau!", "error");
                    }
                });
            });
        });


        /* End Cập nhật giá trị thanh toán */

        /* Chi Phí Nhập Hàng */


        document.addEventListener("DOMContentLoaded", function() {
            // Khởi tạo các phần tử
            const importCostModalEl = document.getElementById("importCostModal");
            const importCostModal = new bootstrap.Modal(importCostModalEl);
            const importCostBtn = document.getElementById("importCost");
            const addCostItemBtn = document.getElementById("addCostItem");
            const costItemsContainer = document.getElementById("costItems");
            const applyImportCostBtn = document.getElementById("applyImportCost");

            // Mở modal khi nhấn nút "Chi Phí Nhập Hàng"
            importCostBtn.addEventListener("click", e => {
                e.preventDefault();
                importCostModal.show();
            });

            // Thêm dòng chi phí mới với hiệu ứng
            addCostItemBtn.addEventListener("click", e => {
                e.preventDefault();
                const newItem = costItemsContainer.querySelector(".cost-item").cloneNode(true);
                newItem.querySelectorAll("input").forEach(input => input.value = "");
                newItem.style.opacity = "0";
                newItem.style.transform = "translateY(20px)";
                costItemsContainer.appendChild(newItem);
                setTimeout(() => {
                    newItem.style.opacity = "1";
                    newItem.style.transform = "translateY(0)";
                }, 10);
            });

            // Xóa dòng chi phí (nếu chỉ có 1 dòng thì reset giá trị)
            costItemsContainer.addEventListener("click", e => {
                if (e.target.classList.contains("removeCostItem")) {
                    e.preventDefault();
                    const costItems = costItemsContainer.querySelectorAll(".cost-item");
                    const currentItem = e.target.closest(".cost-item");
                    if (costItems.length > 1) {
                        // Hiệu ứng xóa: dịch sang trái và mờ dần
                        currentItem.style.transform = "translateX(-100%)";
                        currentItem.style.opacity = "0";
                        setTimeout(() => currentItem.remove(), 300);
                    } else {
                        currentItem.querySelector('[name="costName[]"]').value = "";
                        currentItem.querySelector('[name="costValue[]"]').value = "";
                    }
                }
            });

            // Xử lý "Áp dụng" với kiểm tra dữ liệu và gửi AJAX
            applyImportCostBtn.addEventListener("click", () => {
                let valid = true;
                costItemsContainer.querySelectorAll(".cost-item").forEach(item => {
                    const costName = item.querySelector('[name="costName[]"]').value.trim();
                    const costValue = item.querySelector('[name="costValue[]"]').value.trim();
                    if (!costName || !costValue) valid = false;
                });

                if (!valid) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Lỗi',
                        text: 'Vui lòng nhập đầy đủ thông tin cho từng chi phí!'
                    });
                    return;
                }

                const formData = new FormData(document.getElementById("importCostForm"));

                fetch("{{ route('import.costs.store') }}", {
                        method: "POST",
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Thành công',
                                text: data.message,
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                importCostModal.hide();
                                // Optionally: 
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi',
                                text: data.message || 'Thêm chi phí thất bại.'
                            });
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi',
                            text: 'Lỗi server!'
                        });
                    });
            });
        });



        /* Cập Nhật Chi Phí Nhập Hàng */


        $(document).ready(function() {
            // Mở modal cập nhật chi phí
            $(".btn-edit-cost").click(function() {
                let costId = $(this).data("id");
                let costName = $(this).data("name");
                let costValue = $(this).data("value");

                $("#costId").val(costId);
                $("#costName").val(costName);
                $("#costValue").val(costValue);

                $("#updateCostModal").modal("show");
            });

            // Gửi yêu cầu cập nhật chi phí bằng AJAX
            $("#updateCostForm").submit(function(event) {
                event.preventDefault();

                let costId = $("#costId").val();
                let costName = $("#costName").val();
                let costValue = $("#costValue").val();
                let orderIdCost = $("#orderIdCost").val();
                $.ajax({
                    url: "{{ route('updateImportCostAjax') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        id: costId,
                        cost_name: costName,
                        cost_value: costValue,
                        order_id: orderIdCost
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire("Thành công!", "Chi phí đã được cập nhật!", "success")
                                .then(() => location.reload());
                        } else {
                            Swal.fire("Lỗi!", "Không thể cập nhật chi phí!", "error");
                        }
                    },
                    error: function() {
                        Swal.fire("Lỗi!", "Có lỗi xảy ra, thử lại sau!", "error");
                    }
                });
            });

            // Xóa một chi phí
            $(".btn-delete-cost").click(function() {
                let costId = $(this).data("id");

                Swal.fire({
                    title: "Bạn có chắc không?",
                    text: "Chi phí này sẽ bị xóa vĩnh viễn!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#dc3545",
                    cancelButtonColor: "#6c757d",
                    confirmButtonText: "Xóa ngay!",
                    cancelButtonText: "Hủy"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "{{ route('deleteImportCostAjax') }}",
                            type: "POST",
                            data: {
                                _token: "{{ csrf_token() }}",
                                id: costId
                            },
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire("Đã xóa!", "Chi phí đã được xóa!",
                                            "success")
                                        .then(() => location.reload());
                                } else {
                                    Swal.fire("Lỗi!", "Không thể xóa chi phí!",
                                        "error");
                                }
                            },
                            error: function() {
                                Swal.fire("Lỗi!", "Có lỗi xảy ra, thử lại sau!",
                                    "error");
                            }
                        });
                    }
                });
            });


        });

        /* Cập nhật thời gian tách load */

        $(document).ready(function() {
            $(".date_of_manufacture_split").on("change", function() {
                let manufactureDate = new Date($(this).val());

                if (!isNaN(manufactureDate)) {
                    // Cộng thêm 20 ngày cho ngày dự kiến về hàng
                    let estimatedArrivalDate = new Date(manufactureDate);
                    estimatedArrivalDate.setDate(estimatedArrivalDate.getDate() + 20);

                    // Cộng thêm 1 ngày cho ngày dự kiến sale
                    let forSaleDate = new Date(estimatedArrivalDate);
                    forSaleDate.setDate(forSaleDate.getDate() + 1);

                    // Chuyển đổi ngày thành định dạng yyyy-mm-dd
                    let formatDate = (date) => date.toISOString().split("T")[0];

                    // Tìm hàng tương ứng và cập nhật giá trị
                    let row = $(this).closest("tr");
                    row.find(".date_estimated_arrival_split").val(formatDate(estimatedArrivalDate));
                    row.find(".date_for_sale_split").val(formatDate(forSaleDate));
                }
            });
        });

        /* Cập nhật ngày Đơn Cập Nhật  */

        $(document).ready(function() {
            $(".date_of_manufacture").on("change", function() {
                let manufactureDate = new Date($(this).val());

                if (!isNaN(manufactureDate)) {
                    // Cộng thêm 20 ngày cho ngày dự kiến về hàng
                    let estimatedArrivalDate = new Date(manufactureDate);
                    estimatedArrivalDate.setDate(estimatedArrivalDate.getDate() + 20);

                    // Cộng thêm 1 ngày cho ngày dự kiến sale
                    let forSaleDate = new Date(estimatedArrivalDate);
                    forSaleDate.setDate(forSaleDate.getDate() + 1);

                    // Chuyển đổi ngày thành định dạng yyyy-mm-dd
                    let formatDate = (date) => date.toISOString().split("T")[0];

                    // Tìm hàng tương ứng và cập nhật giá trị
                    let row = $(this).closest("tr");
                    row.find(".date_estimated_arrival").val(formatDate(estimatedArrivalDate));
                    row.find(".date_for_sale").val(formatDate(forSaleDate));
                }
            });
        });
        /* Ẩn Hiện Box Cập Nhật Và Tách Load */
        $(document).ready(function() {
            $("#box__UpdateOrder").show(); // Hiển thị mặc định Update Order
            $("#box__splitOrder").hide(); // Ẩn Split Order

            $("#actionSplitOrder").click(function() {
                if ($("#box__splitOrder").is(":hidden")) {
                    $("#box__UpdateOrder").hide();
                    $("#box__splitOrder").show();
                    $(this).text("Quay lại");
                } else {
                    $("#box__UpdateOrder").show();
                    $("#box__splitOrder").hide();
                    $(this).text("Mở Rộng");
                }
            });
        });


        /* Chức Năng Tách Load Sản Phẩm */
        $(document).ready(function() {
            let rowIndex = $(".order-row").length;

            // Nhân bản chỉ các dòng đã chọn khi nhấn "Tách Load"
            $("#splitLoad").click(function() {
                $(".select-row:checked").each(function() {
                    let selectedRow = $(this).closest("tr"); // Lấy dòng được chọn
                    let clonedRow = selectedRow.clone(); // Nhân bản dòng
                    rowIndex++;

                    // Cập nhật lại name cho tất cả các input của dòng mới
                    clonedRow.find("input, select").each(function() {
                        let oldName = $(this).attr("name");
                        if (oldName) {
                            let newName = oldName.replace(/\[\d+\]/, "[" + rowIndex + "]");
                            $(this).attr("name", newName);
                        }
                    });

                    // Đảm bảo checkbox của dòng mới không được chọn
                    clonedRow.find(".select-row").prop("checked", false);

                    // Thêm dòng mới vào bảng
                    $("#orderTable").append(clonedRow);
                });
            });

            // Xóa dòng khi nhấn "Xóa"
            $(document).on("click", ".remove-row", function() {
                if ($(".order-row").length > 1) {
                    $(this).closest("tr").remove();
                } else {
                    alert("Không thể xóa dòng cuối cùng!");
                }
            });

            // Gửi dữ liệu qua Ajax khi nhấn "Cập Nhật"
            // Gửi dữ liệu qua Ajax khi nhấn "Cập Nhật"
            $("#updateOrderDetail").click(function() {
                let formData = [];

                // Lặp qua từng dòng có class .order-row trong form và thu thập dữ liệu
                $(".order-row").each(function(index, row) {
                    $(row).find(":input").each(function() {
                        let name = $(this).attr("name");
                        let value = $(this).val();
                        if (name) {
                            formData.push({
                                name: name,
                                value: value
                            });
                        }
                    });
                });

                // Kiểm tra dữ liệu trước khi gửi (mở Console kiểm tra)
                console.log("Dữ liệu gửi đi:", formData);

                $.ajax({
                    url: "{{ route('updateOrderDetail') }}", // Route Laravel xử lý
                    type: "POST",
                    data: $.param(formData), // Chuyển mảng thành chuỗi để gửi
                    dataType: "json",
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}" // Token bảo mật
                    },
                    success: function(response) {

                        Swal.fire({
                            title: 'Thành công',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            window.location.reload();
                            // Sau khi xác nhận, chuyển hướng lại trang import hoặc trang danh sách đơn hàng
                        });
                    },
                    error: function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: 'Có lỗi xảy ra khi xử lý đơn hàng.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

        });



        $(document).ready(function() {
            $("#updateOrder").click(function() {
                let formData = $("#orderFormUpdate").serialize(); // Lấy dữ liệu form
                $.ajax({
                    url: "{{ route('update.order') }}", // Đường dẫn đến action controller
                    type: "POST",
                    data: formData,
                    dataType: "json",
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}" // Bảo vệ CSRF
                    },
                    beforeSend: function() {
                        Swal.fire({
                            title: 'Đang xử lý...',
                            html: 'Vui lòng chờ trong giây lát...',
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                title: 'Thành công',
                                text: response.message,
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.reload();
                                // Sau khi xác nhận, chuyển hướng lại trang import hoặc trang danh sách đơn hàng
                            });
                        } else {
                            Swal.fire({
                                title: 'Lỗi',
                                text: response.message,
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        console.error(xhr.responseText);
                        Swal.fire({
                            title: 'Có lỗi trong quá trình xử lý',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });
        });
    </script>
@endsection
