@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/listOrdersByUser.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
@endsection

@section('content')
    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="app-container">
        <!-- Breadcrumb Navigation -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item ml-2"><a href="/">Dash Board</a></li>
                <li class="breadcrumb-item"><a href="{{ route('orders.getOrdersByUser') }}">Danh sách</a></li>
                <li class="breadcrumb-item"><a href="{{ route('orders.import') }}">Thêm Mới</a></li>
            </ol>
        </nav>

        <!-- Main Content -->
        <main id="mainContentListOrder" class="main-content">
            <section class="card">
                <header class="card-header">
                    <h1 class="section-title">
                        <i class="fas fa-desktop"></i> Danh sách đơn đặt hàng
                    </h1>
                    <button id="helpguide-btn" class="helpguide__btn ml-3">
                        <i class="fas fa-question-circle"></i> Hướng dẫn sử dụng
                    </button>
                    <button id="filterToggleBtn" class="filter-toggle">
                        <i class="fas fa-filter"></i> Bộ lọc
                    </button>
                </header>

                <div class="card-body">
                    <!-- Success Alert Placeholder -->
                    <div id="successAlert" style="display: none;" class="alert-success"></div>

                    <!-- Active Filters Display -->
                    <div class="active-filters" id="activeFilters"></div>

                    <!-- Table Content -->
                    <div class="table-container">
                        <table class="data-table" id="ordersTable">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Nhà Cung Cấp</th>
                                    <th>Mã đơn hàng</th>
                                    <th>Ngày Đặt Hàng</th>
                                    <th>Số Lượng</th>
                                    <th>Đặt Cọc</th>
                                    <th>Đã Thanh Toán</th>
                                    <th>Chưa Thanh Toán</th>
                                    <th>Trạng Thái Đơn</th>
                                    <th>Quản Lý</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $temp = 0;
                                @endphp

                                @foreach ($data as $item)
                                    @php
                                        $temp++;
                                        $totalPayment = $item->totalPayment();
                                        $totalImportCost = $item->totalImportCost() ? $item->totalImportCost() : 0;
                                        $subtotal = $item->subtotal + $totalImportCost;
                                        $debt = $subtotal - $totalPayment;
                                        $totalAllPayments = $item->subtotal + $totalImportCost;
                                    @endphp

                                    <tr>
                                        <td class="align-middle text-center">
                                            {{ $temp }}
                                        </td>
                                        <td class="align-middle text-center">
                                            {{ $item->supplier->sp_code ?? '' }}
                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="order-code">{{ $item->order_code ?? '' }}</span>
                                        </td>
                                        <td class="align-middle text-center">
                                            {{ date('d-m-Y', strtotime($item->order_date ?? '')) }}
                                        </td>
                                        <td class="align-middle text-center">
                                            {{ $item->total_quantity ?? '' }}
                                        </td>
                                        <td class="align-middle text-center">
                                            {{ $item->deposit ?? '' }}
                                        </td>
                                        <td class="align-middle text-center">
                                            {{ number_format($item->totalPayment(), 2, '.', ',') }}
                                        </td>
                                        <td class="align-middle text-center">
                                            @if ($debt == 0)
                                                <span class="text-success"
                                                    style="font-size: 14px; font-weight: 600">{{ number_format($debt, 2, '.', ',') }}</span>
                                            @else
                                                <span class="text-danger"
                                                    style="font-size: 14px; font-weight: 600">{{ number_format($debt, 2, '.', ',') }}</span>
                                            @endif
                                        </td>

                                        <td class="align-middle text-center">

                                            @if ($item->status == 1)
                                                <span class="badge badge-success" style="padding: 10px">
                                                    <i class="fas fa-check"></i> Hoàn Thành
                                                </span>
                                            @else
                                                <span class="badge badge-danger" style="padding: 10px">
                                                    <i class="fas fa-times-circle"></i> Chưa Hoàn
                                                    Thành
                                                </span>
                                            @endif
                                        </td>
                                        <td class="align-middle">
                                            <a href="{{ route('detailOrder', ['id' => $item->id]) }}"
                                                class="btn btn-info btn-sm">
                                                <i class="fas fa-eye"></i> <!-- Icon Xem -->
                                            </a>
                                            <button href="javascript:void(0)"
                                                onclick="confirmDelete('{{ $item->id }}')"
                                                class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>

                                            <!-- Form ẩn để submit khi xác nhận xóa -->
                                            <form id="delete-form-{{ $item->id }}"
                                                action="{{ route('deleteDetailOrder', ['id' => $item->id]) }}"
                                                method="GET" style="display: none;">
                                                @csrf
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        @if ($data->hasPages())
                            <ul class="pagination pagination__custom">
                                {{ $data->appends(request()->query())->links('vendor.pagination.custom') }}
                            </ul>
                        @endif
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- Filter Drawer -->
    <aside id="filterDrawer" class="filter-drawer">
        <div class="filter-header">
            <h2>Bộ lọc nâng cao</h2>
            <button id="closeFilterBtn" class="filter-close">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form id="filterForm">
            <div class="filter-group">
                <label class="filter-label" for="searchTerm">Tìm kiếm</label>
                <div class="search-input-container">
                    <input type="text" id="searchTerm" name="search" class="filter-input"
                        placeholder="Nhập mã đơn hàng, nhà cung cấp..." value="{{ request('search') }}">
                    <i class="fas fa-search search-icon"></i>
                </div>
            </div>

            <div class="filter-group">
                <label class="filter-label" for="isPaid">Tình trạng thanh toán</label>
                <select id="isPaid" class="filter-input">
                    <option value="">Tất cả</option>
                    <option value="0">Chưa thanh toán đủ</option>
                    <option value="1">Đã thanh toán đủ</option>
                </select>
            </div>

            <div class="filter-group">
                <label class="filter-label" for="status">Trạng thái đơn hàng</label>
                <select id="status" class="filter-input">
                    <option value="">Tất cả</option>
                    <option value="0">Chưa hoàn thành</option>
                    <option value="1">Hoàn thành</option>
                </select>
            </div>

            <div class="filter-group">
                <label class="filter-label" for="orderDate">Ngày đặt hàng</label>
                <input type="date" id="orderDate" class="filter-input">
            </div>

            <div class="filter-group">
                <label class="filter-label" for="supplier">Nhà cung cấp</label>
                <select id="supplier" class="filter-input">
                    <option value="">Tất cả</option>
                    @php
                        $uniqueSuppliers = $data->pluck('supplier.sp_code')->unique()->filter();
                    @endphp
                    @foreach ($uniqueSuppliers as $supplierCode)
                        <option value="{{ $supplierCode }}">{{ $supplierCode }}</option>
                    @endforeach
                </select>
            </div>

            <div class="filter-group">
                <label class="filter-label" for="minAmount">Số tiền tối thiểu</label>
                <input type="number" id="minAmount" class="filter-input" placeholder="Nhập số tiền tối thiểu">
            </div>

            <div class="filter-group">
                <label class="filter-label" for="maxAmount">Số tiền tối đa</label>
                <input type="number" id="maxAmount" class="filter-input" placeholder="Nhập số tiền tối đa">
            </div>

            <div class="filter-actions">
                <button type="button" id="resetFilterBtn" class="btn btn-danger">
                    <i class="fas fa-trash-alt"></i> Xóa bộ lọc
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Áp dụng
                </button>
            </div>
        </form>
    </aside>

    <!-- Overlay for filter drawer -->
    <div id="overlay" class="overlay"></div>
@endsection


@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Thêm sự kiện click cho nút hướng dẫn
            const helpGuideBtn = document.getElementById('helpguide-btn');
            if (helpGuideBtn) {
                helpGuideBtn.addEventListener('click', showHelpGuide);
            }

            // Hàm hiển thị hướng dẫn sử dụng
            function showHelpGuide() {
                Swal.fire({
                    title: '<i class="fas fa-book-open"></i> Hướng dẫn sử dụng',
                    html: `
                <div class="helpguide__content">
                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-search helpguide__icon"></i>
                            <h3>Tìm kiếm & Lọc dữ liệu</h3>
                        </div>
                        <p>Nhấn nút <strong>"Bộ lọc"</strong> để mở bảng điều khiển lọc. Bạn có thể lọc theo mã đơn hàng, nhà cung cấp, trạng thái thanh toán và nhiều tiêu chí khác.</p>
                    </div>

                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-plus-circle helpguide__icon"></i>
                            <h3>Thêm đơn hàng mới</h3>
                        </div>
                        <p>Nhấn vào liên kết <strong>"Thêm Mới"</strong> trên thanh breadcrumb để nhập đơn hàng mới vào hệ thống.</p>
                    </div>

                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-eye helpguide__icon"></i>
                            <h3>Xem chi tiết đơn hàng</h3>
                        </div>
                        <p>Nhấn nút <strong><i class="fas fa-eye"></i></strong> để xem thông tin chi tiết của đơn hàng, bao gồm danh sách sản phẩm và lịch sử thanh toán.</p>
                    </div>

                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-trash-alt helpguide__icon"></i>
                            <h3>Xóa đơn hàng</h3>
                        </div>
                        <p>Nhấn nút <strong><i class="fas fa-trash-alt"></i></strong> để xóa một đơn hàng. Hệ thống sẽ yêu cầu xác nhận trước khi xóa.</p>
                    </div>

                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-tag helpguide__icon"></i>
                            <h3>Hiểu về trạng thái đơn hàng</h3>
                        </div>
                        <p>
                            <span class="badge badge-success" style="padding: 5px"><i class="fas fa-check"></i> Hoàn Thành</span>: Đơn hàng đã hoàn tất.<br>
                            <span class="badge badge-danger" style="padding: 5px"><i class="fas fa-times-circle"></i> Chưa Hoàn Thành</span>: Đơn hàng đang trong quá trình xử lý.
                        </p>
                    </div>

                    <div class="helpguide__step">
                        <div class="helpguide__step-header">
                            <i class="fas fa-money-bill-wave helpguide__icon"></i>
                            <h3>Theo dõi thanh toán</h3>
                        </div>
                        <p>Cột <strong>"Đã Thanh Toán"</strong> và <strong>"Chưa Thanh Toán"</strong> giúp bạn dễ dàng theo dõi tình trạng tài chính của từng đơn hàng.</p>
                    </div>
                </div>
            `,
                    confirmButtonText: 'Đã hiểu',
                    confirmButtonColor: '#3085d6',
                    width: '700px',
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                });
            }
        });

        /* ---------------------------------- */





        /* Xoá Đơn Hàng */

        // Đảm bảo script này chạy sau khi trang đã load
        document.addEventListener('DOMContentLoaded', function() {
            // Định nghĩa hàm confirmDelete trong phạm vi global
            window.confirmDelete = function(id) {
                Swal.fire({
                    title: 'Xác nhận xóa?',
                    text: "Bạn có chắc chắn muốn xóa đơn hàng này không?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Có, xóa nó!',
                    cancelButtonText: 'Hủy'
                }).then((result) => {
                    if (result.isConfirmed) {
                        document.getElementById('delete-form-' + id).submit();
                    }
                });
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            // Elements
            const filterToggleBtn = document.getElementById('filterToggleBtn');
            const filterDrawer = document.getElementById('filterDrawer');
            const closeFilterBtn = document.getElementById('closeFilterBtn');
            const overlay = document.getElementById('overlay');
            const filterForm = document.getElementById('filterForm');
            const resetFilterBtn = document.getElementById('resetFilterBtn');
            const activeFiltersContainer = document.getElementById('activeFilters');

            // Success alert handling
            const showSuccessAlert = (message) => {
                const alertElement = document.getElementById('successAlert');
                alertElement.textContent = message;
                alertElement.style.display = 'block';

                // Auto-hide after 5 seconds
                setTimeout(() => {
                    alertElement.style.display = 'none';
                }, 5000);
            };

            // Check for success messages in URL (simulating server-side flash messages)
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                showSuccessAlert(urlParams.get('success'));
            }

            // Filter drawer toggle
            filterToggleBtn.addEventListener('click', () => {
                filterDrawer.classList.add('active');
                overlay.classList.add('active');
                document.body.style.overflow = 'hidden';
            });

            // Close filter drawer
            const closeFilterDrawer = () => {
                filterDrawer.classList.remove('active');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            };

            closeFilterBtn.addEventListener('click', closeFilterDrawer);
            overlay.addEventListener('click', closeFilterDrawer);


            // Handle form submission
            filterForm.addEventListener('submit', (e) => {
                e.preventDefault();

                // Create URL with filter parameters
                const url = new URL(window.location.href);

                // Get filter values
                const isPaid = document.getElementById('isPaid').value;
                const search = document.getElementById('searchTerm').value;
                const status = document.getElementById('status').value;
                const orderDate = document.getElementById('orderDate').value;
                const supplier = document.getElementById('supplier').value;
                const minAmount = document.getElementById('minAmount').value;
                const maxAmount = document.getElementById('maxAmount').value;

                // Update URL parameters
                if (isPaid) url.searchParams.set('is_paid', isPaid);
                else url.searchParams.delete('is_paid');

                // This line was missing - need to add the search parameter
                if (search) url.searchParams.set('search', search);
                else url.searchParams.delete('search');

                if (status) url.searchParams.set('status', status);
                else url.searchParams.delete('status');

                if (orderDate) url.searchParams.set('order_date', orderDate);
                else url.searchParams.delete('order_date');

                if (supplier) url.searchParams.set('supplier', supplier);
                else url.searchParams.delete('supplier');

                if (minAmount) url.searchParams.set('min_amount', minAmount);
                else url.searchParams.delete('min_amount');

                if (maxAmount) url.searchParams.set('max_amount', maxAmount);
                else url.searchParams.delete('max_amount');

                // Redirect to the filtered URL
                window.location.href = url.toString();
            });



            // Reset filters
            resetFilterBtn.addEventListener('click', () => {
                // Reset form fields
                filterForm.reset();

                // Redirect to base URL without parameters
                const url = new URL(window.location.href);
                url.search = '';
                window.location.href = url.toString();
            });

            // Initialize filters from URL and display active filters
            const initializeFiltersFromUrl = () => {
                const urlParams = new URLSearchParams(window.location.search);
                let hasActiveFilters = false;

                // Set form values from URL params and create filter tags
                if (urlParams.has('is_paid')) {
                    document.getElementById('isPaid').value = urlParams.get('is_paid');
                    createFilterTag('Thanh toán',
                        urlParams.get('is_paid') === '1' ? 'Đã thanh toán đủ' : 'Chưa thanh toán đủ',
                        'is_paid');
                    hasActiveFilters = true;
                }

                if (urlParams.has('search')) {
                    document.getElementById('searchTerm').value = urlParams.get('search');
                    createFilterTag('Tìm kiếm', urlParams.get('search'), 'search');
                    hasActiveFilters = true;
                }

                if (urlParams.has('status')) {
                    document.getElementById('status').value = urlParams.get('status');
                    createFilterTag('Trạng thái',
                        urlParams.get('status') === '1' ? 'Hoàn thành' : 'Chưa hoàn thành',
                        'status');
                    hasActiveFilters = true;
                }

                if (urlParams.has('order_date')) {
                    document.getElementById('orderDate').value = urlParams.get('order_date');
                    createFilterTag('Ngày đặt hàng', formatDate(urlParams.get('order_date')), 'order_date');
                    hasActiveFilters = true;
                }

                if (urlParams.has('supplier')) {
                    document.getElementById('supplier').value = urlParams.get('supplier');
                    createFilterTag('Nhà cung cấp', urlParams.get('supplier'), 'supplier');
                    hasActiveFilters = true;
                }

                if (urlParams.has('min_amount')) {
                    document.getElementById('minAmount').value = urlParams.get('min_amount');
                    createFilterTag('Số tiền tối thiểu', formatCurrency(urlParams.get('min_amount')),
                        'min_amount');
                    hasActiveFilters = true;
                }

                if (urlParams.has('max_amount')) {
                    document.getElementById('maxAmount').value = urlParams.get('max_amount');
                    createFilterTag('Số tiền tối đa', formatCurrency(urlParams.get('max_amount')),
                        'max_amount');
                    hasActiveFilters = true;
                }

                // If there are active filters, show a "Clear all" button
                if (hasActiveFilters) {
                    const clearAllBtn = document.createElement('button');
                    clearAllBtn.className = 'btn btn-sm btn-danger';
                    clearAllBtn.innerHTML = '<i class="fas fa-times"></i> Xóa tất cả bộ lọc';
                    clearAllBtn.addEventListener('click', () => {
                        const url = new URL(window.location.href);
                        url.search = '';
                        window.location.href = url.toString();
                    });
                    activeFiltersContainer.appendChild(clearAllBtn);
                }
            };

            // Create a visual tag for active filters
            const createFilterTag = (name, value, paramName) => {
                const tag = document.createElement('span');
                tag.className = 'filter-tag';
                tag.innerHTML =
                    `${name}: <strong>${value}</strong> <i class="fas fa-times" data-param="${paramName}"></i>`;

                // Add event listener to remove individual filter
                tag.querySelector('i').addEventListener('click', (e) => {
                    const param = e.target.dataset.param;
                    const url = new URL(window.location.href);
                    url.searchParams.delete(param);
                    window.location.href = url.toString();
                });

                activeFiltersContainer.appendChild(tag);
            };

            // Format date for display
            const formatDate = (dateString) => {
                const date = new Date(dateString);
                return `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear()}`;
            };

            // Format currency for display
            const formatCurrency = (amount) => {
                return new Intl.NumberFormat('vi-VN').format(amount);
            };

            // Initialize filters from URL
            initializeFiltersFromUrl();

            // Simulate order deletion confirmation

        });
    </script>
@endsection
