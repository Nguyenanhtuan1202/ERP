@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/supplier.css') }}">
@endsection
@section('content')
    <div class="container-fluid mt-5">

        <div class="row justify-content-center">
            <div class="col-md-12 box__new-supplier">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif
                <form class="form row" action="{{ route('suppliers.store') }}" method="POST" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="col-md-4 box__new-supplier-item">
                        <h2 class="title_h2">Thêm Mới Nhà Cung Cấp</h2>
                        <div class="form-group">
                            <label class="label__sp" for="username">Tên Nhà Cung Cấp <small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="username" required class="form-input-custom-sp" id="username"
                                placeholder="Nhập vào tên cá nhân...">
                        </div>
                        <div class="form-group">
                            <label class="label__sp" for="sp_code">Mã Nhà Cung Cấp <small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="sp_code" required class="form-input-custom-sp" id="sp_code"
                                placeholder="Mã nhà cung cấp...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="phone_number">Số Điện Thoại</label>
                            <input type="text"  class="form-input-custom-sp" name="phone_number"
                                id="phone_number" placeholder="Số điện thoại...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="email">Email </label>
                            <input type="email"  class="form-input-custom-sp" name="email" id="email"
                                placeholder="Email...">
                        </div>
                    </div>
                    <div class="col-md-4 box__new-supplier-item">
                        <div class="form-group">
                            <label class="label__sp" for="company_name">Tên Công Ty</label>
                            <input type="text" class="form-input-custom-sp" name="company_name" id="company_name"
                                placeholder="Tên công ty...">
                        </div>
                        <div class="form-group">
                            <label class="companion_day" for="companion_day">Ngày Hợp Tác</label>
                            <input type="date" class="form-input-custom-sp" name="companion_day" id="companion_day"
                                placeholder="Ví dụ: Ngày...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="website">Website</label>
                            <input type="text" class="form-input-custom-sp" name="website" id="website"
                                placeholder="Ví dụ enic.vn">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="address">Địa Chỉ </label>
                            <input type="text" class="form-input-custom-sp" name="address" id="address"
                                placeholder="Địa chỉ...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="company_tax">MST</label>
                            <input type="text" class="form-input-custom-sp" name="company_tax" id="company_tax"
                                placeholder="MST công ty/ Cá Nhân...">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="tabs mb-4">
                            <ul class="nav nav-tabs" id="supplierTabs" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" id="sales-tab" data-toggle="tab" href="#sales"
                                        role="tab" aria-controls="sales" aria-selected="false">Mua Hàng</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="invoice-tab" data-toggle="tab" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="false">Hóa đơn</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="notes-tab" data-toggle="tab" href="#notes" role="tab"
                                        aria-controls="notes" aria-selected="false">Ghi chú nội bộ</a>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content" id="supplierTabsContent">

                            <div class="tab-pane fade show active" id="sales" role="tabpanel"
                                aria-labelledby="sales-tab">
                                <!-- Content for Bán hàng và Mua hàng -->

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="employer">Người Phụ Trách :</label>
                                    </div>
                                    <div>
                                        <input type="text" id="employer" name="employer"
                                            class="form-input-custom-sp" placeholder="Nhập tên Người Phụ Trách">
                                    </div>

                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="terms">Điều khoản thanh toán :</label>
                                    </div>
                                    <div>
                                        <select name="terms" class="form-control form-input-custom-sp" id="terms">

                                            @foreach (list_terms() as $key => $term)
                                                <option value="{{ $key }}">{{ $term }}</option>
                                            @endforeach

                                        </select>
                                    </div>
                                </div>
                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="payments">Hình thức thanh toán :</label>
                                    </div>
                                    <div>
                                        <select class="form-control form-input-custom-sp" name="payments" id="payments">
                                            <option>ALIPAY</option>
                                            <option>TK CÁ NHÂN</option>
                                            <option>TK CÔNG TY</option>
                                            <option>WE CHAT</option>
                                            <option>VND</option>
                                            <option>USD</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="industry">Ngành nghề :</label>
                                    </div>
                                    <div>
                                        <input type="text" name="industry" id="industry"
                                            class="form-input-custom-sp" placeholder="Nhập Ngành Nghề">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="invoice" role="tabpanel" aria-labelledby="invoice-tab">
                                <!-- Content for Hóa đơn -->

                                <h5>Tài Khoản Ngân Hàng</h5>

                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Số Tài Khoản</th>
                                            <th>Tên Ngân Hàng</th>
                                            <th>Chủ Tài Khoản</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bankAccountsList">
                                        <!-- Bank accounts will be appended here -->
                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-secondary" data-toggle="modal"
                                    data-target="#addBankAccountModal">Thêm Tài Khoản Ngân Hàng</button>

                            </div>
                            <div class="tab-pane fade" id="notes" role="tabpanel" aria-labelledby="notes-tab">
                                <!-- Content for Ghi chú nội bộ -->
                                <textarea style="border:1px solid #f1f1f1; outline:none; border-radius: 8px" name="note" id="note"
                                    cols="50" rows="5" placeholder="Ghi Chú"></textarea>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-success" type="submit">Thêm Mới</button>
                </form>

            </div>
        </div>
    </div>



    <!-- Modal for adding bank account -->
    <div class="modal fade" id="addBankAccountModal" tabindex="-1" role="dialog"
        aria-labelledby="addBankAccountModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBankAccountModalLabel">Thêm Tài Khoản Ngân Hàng</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="modal_bank_name">Tên Ngân Hàng</label>
                        <input type="text" class="form-control" id="modal_bank_name"
                            placeholder="Nhập tên ngân hàng">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_number">Số Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_number"
                            placeholder="Nhập số tài khoản">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_holder">Chủ Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_holder"
                            placeholder="Nhập tên chủ tài khoản">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="saveBankAccount">Lưu</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            var bankAccountIndex = 0;

            $('#saveBankAccount').click(function() {
                var bankName = $('#modal_bank_name').val();
                var accountNumber = $('#modal_account_number').val();
                var accountHolder = $('#modal_account_holder').val();

                if (bankName && accountNumber && accountHolder) {
                    var newBankAccountRow = `
                    <tr>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_number]" value="${accountNumber}">${accountNumber}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][bank_name]" value="${bankName}">${bankName}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_holder]" value="${accountHolder}">${accountHolder}</td>
                    </tr>
                `;
                    $('#bankAccountsList').append(newBankAccountRow);
                    bankAccountIndex++;
                    $('#addBankAccountModal').modal('hide');
                    $('#modal_bank_name').val('');
                    $('#modal_account_number').val('');
                    $('#modal_account_holder').val('');
                } else {
                    alert('Vui lòng điền đầy đủ thông tin.');
                }
            });
        });
    </script>
@endsection
