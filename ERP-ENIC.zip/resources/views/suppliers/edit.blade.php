@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/supplier.css') }}">
@endsection
@section('content')
    <style>
        .table-custom th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #111;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
            background-color: #f1f3f5;
        }

        .table-custom td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            color: #111;
            vertical-align: top;
        }

        .table-custom tbody tr:hover {
            background-color: #f8f9fa;
            transition: background-color 0.2s ease;
        }

        /* Số thứ tự căn giữa */
        .table-custom td:first-child {
            text-align: center;
            font-weight: 500;
            color: #111;
        }

        /* Làm nổi bật header */
        .table-custom thead tr {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        /* Định dạng các cột dài */
        .table-custom td:nth-child(2),
        .table-custom td:nth-child(3),
        .table-custom td:nth-child(10),
        .table-custom td:nth-child(11) {
            max-width: 250px;
            white-space: normal;
            word-break: break-word;
        }

        .table-responsive #table2_wrapper {
            box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
            background-color: #fff;
        }
    </style>

    <div class="container-fluid mt-5">
        <div class="row justify-content-center">
            <div class="col-md-12 box__new-supplier">
                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif
                <form class="form row" action="{{ route('supplier.update', [$supplier->id]) }}" method="POST"
                    enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="col-md-4 box__new-supplier-item">
                        <h2 class="title_h2">Thông Tin Nhà Cung Cấp</h2>
                        <div class="form-group">
                            <label class="label__sp" for="username">Tên Nhà Cung Cấp<small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="username" required value="{{ $supplier->username ?? '' }}"
                                class="form-input-custom-sp" id="username" placeholder="Nhập vào tên cá nhân...">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="sp_code">Mã Nhà Cung Cấp <small style="color: red">
                                    (*)</small></label>
                            <input type="text" name="sp_code" required class="form-input-custom-sp" id="sp_code"
                                placeholder="Mã nhà cung cấp..." value="{{ $supplier->sp_code ?? '' }}">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="phone_number">Số Điện Thoại </label>
                            <input type="text" class="form-input-custom-sp" name="phone_number" id="phone_number"
                                placeholder="Số điện thoại..." value="{{ $supplier->phone_number ?? '' }}">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="email">Email </label>
                            <input type="email" class="form-input-custom-sp" name="email" id="email"
                                placeholder="Email..." value="{{ $supplier->email ?? '' }}">
                        </div>
                    </div>
                    <div class="col-md-4 box__new-supplier-item">
                        <div class="form-group">
                            <label class="label__sp" for="company_name">Tên Công Ty</label>
                            <input type="text" class="form-input-custom-sp" name="company_name" id="company_name"
                                placeholder="Tên công ty..." value="{{ $supplier->company_name ?? '' }}">
                        </div>
                        <div class="form-group">
                            <label class="companion_day" for="companion_day">Ngày Hợp Tác</label>
                            <input type="date" class="form-input-custom-sp" name="companion_day" id="companion_day"
                                placeholder="Ví dụ: Ngày" value="{{ $supplier->companion_day ?? '' }}">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="website">Website</label>
                            <input type="text" class="form-input-custom-sp" name="website" id="website"
                                placeholder="Ví dụ enic.vn" value="{{ $supplier->website ?? '' }}">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="address">Địa Chỉ </label>
                            <input type="text" class="form-input-custom-sp" name="address" id="address"
                                placeholder="Địa chỉ..." value="{{ $supplier->address ?? '' }}">
                        </div>

                        <div class="form-group">
                            <label class="label__sp" for="company_tax">MST</label>
                            <input type="text" class="form-input-custom-sp" name="company_tax" id="company_tax"
                                placeholder="MST công ty/ Cá Nhân..." value="{{ $supplier->company_tax ?? '' }}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="tabs mb-4">
                            <ul class="nav nav-tabs" id="supplierTabs" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link active" id="sales-tab" data-toggle="tab" href="#sales"
                                        role="tab" aria-controls="sales" aria-selected="false">Mua Hàng</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="invoice-tab" data-toggle="tab" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="false">Thanh Toán</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="notes-tab" data-toggle="tab" href="#notes" role="tab"
                                        aria-controls="notes" aria-selected="false">Ghi chú nội bộ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="more-tab" data-toggle="tab" href="#more" role="tab"
                                        aria-controls="notes" aria-selected="false">Mở rộng</a>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content" id="supplierTabsContent">

                            <div class="tab-pane fade show active" id="sales" role="tabpanel"
                                aria-labelledby="sales-tab">
                                <!-- Content for Bán hàng và Mua hàng -->


                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="employer">Người Phụ Trách Dự Toán
                                            :</label>
                                    </div>
                                    <div>
                                        <div class="form-group">
                                            <select class="form-control select3_init" name="forecaster_id"
                                                id="forecaster_id">
                                             <option value="">Chọn</option>
                                                @foreach ($list_forecaster as $item)
                                                    <option value="{{ $item->id }}"
                                                        @if ($supplier->forecaster_id == $item->id) selected @endif>
                                                        {{ $item->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="employer">Người Phụ Trách Mua Hàng
                                            :</label>
                                    </div>
                                    <div>
                                        <div class="form-group">
                                            <select class="form-control select3_init" name="employer_id"
                                                id="employer_id">
                                                <option value="">Chọn</option>
                                                @foreach ($list_purchaser as $item)
                                                    <option value="{{ $item->id }}"
                                                        @if ($supplier->employer_id == $item->id) selected @endif>
                                                        {{ $item->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="terms">Điều khoản thanh toán :</label>
                                    </div>
                                    <div>
                                        <select name="terms" class="form-control select3_init form-input-custom-sp"
                                            id="terms">
                                            <option value="">Chọn</option>
                                            @foreach (list_terms() as $key => $term)
                                                <option value="{{ $key }}"
                                                    @if ($supplier->terms == $key) selected @endif>{{ $term }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="payments">Hình thức thanh toán :</label>
                                    </div>
                                    <div>
                                        <select class="form-control form-input-custom-sp select3_init" name="payments"
                                            id="payments">
                                            <option value="">Chọn</option>
                                            <option @if ($supplier->payments == 'ALIPAY') selected @endif>ALIPAY</option>
                                            <option @if ($supplier->payments == 'TK CÁ NHÂN') selected @endif>TK CÁ NHÂN</option>
                                            <option @if ($supplier->payments == 'TK CÔNG TY') selected @endif>TK CÔNG TY</option>
                                            <option @if ($supplier->payments == 'WE CHAT') selected @endif>WE CHAT</option>
                                            <option @if ($supplier->payments == 'VND') selected @endif>VND</option>
                                            <option @if ($supplier->payments == 'USD') selected @endif>USD</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="industry">Ngành nghề :</label>
                                    </div>
                                    <div>
                                        <input type="text" name="industry" id="industry"
                                            class="form-input-custom-sp" placeholder="Nhập Ngành Nghề"
                                            value="{{ $supplier->industry ?? '' }}">
                                    </div>
                                </div>

                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="status">Trạng thái :</label>
                                    </div>
                                    <div class="form-group">

                                        <select class="form-control" name="status" id="status">
                                            <option value="1" {{ $supplier->status == 1 ? 'selected' : '' }}>Đang
                                                hoạt
                                                động</option>
                                            <option value="0" {{ $supplier->status == 0 ? 'selected' : '' }}>Tạm
                                                ngừng
                                            </option>
                                        </select>
                                    </div>
                                </div>


                                <div class="box__sales-item">

                                    <div>
                                        <label class="label__sp" for="deposit">Đặt Cọc :</label>
                                    </div>
                                    <div>
                                        <input type="text" name="deposit" id="deposit" class="form-input-custom-sp"
                                            placeholder="Vd: 20%..." value="{{ $supplier->deposit ?? '' }}">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="invoice" role="tabpanel" aria-labelledby="invoice-tab">
                                <!-- Content for Hóa đơn -->
                                <h5>Tài Khoản Ngân Hàng</h5>

                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Số Tài Khoản</th>
                                            <th>Tên Ngân Hàng</th>
                                            <th>Chủ Tài Khoản</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bankAccountsList">


                                        @foreach ($list_bank_accounts as $index => $item)
                                            <tr>
                                                <td><input type="hidden"
                                                        name="bank_accounts[{{ $index }}][account_number]"
                                                        value="{{ $item->account_number ?? '' }}">{{ $item->account_number ?? '' }}
                                                </td>
                                                <td><input type="hidden"
                                                        name="bank_accounts[{{ $index }}][bank_name]"
                                                        value="{{ $item->bank_name ?? '' }}">{{ $item->bank_name ?? '' }}
                                                </td>
                                                <td><input type="hidden"
                                                        name="bank_accounts[{{ $index }}][account_holder]"
                                                        value="{{ $item->account_holder ?? '' }}">{{ $item->account_holder ?? '' }}
                                                </td>
                                            </tr>
                                        @endforeach

                                        <!-- Bank accounts will be appended here -->
                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-secondary" data-toggle="modal"
                                    data-target="#addBankAccountModal">Thêm Tài Khoản Ngân Hàng</button>

                            </div>
                            <div class="tab-pane fade" id="notes" role="tabpanel" aria-labelledby="notes-tab">
                                <!-- Content for Ghi chú nội bộ -->
                                <textarea style="border:1px solid #f1f1f1; outline:none; border-radius: 8px" name="note" id="note"
                                    cols="50" rows="5" placeholder="Ghi Chú">{{ $supplier->note ?? '' }}</textarea>
                            </div>
                            <div class="tab-pane fade" id="more" role="tabpanel" aria-labelledby="more-tab">


                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="peak_season">Mùa cao điểm :</label>
                                    </div>
                                    <div>
                                        <textarea id="peak_season" name="peak_season" class="form-input-custom-sp" placeholder="Mùa cao điểm">{{ $supplier->peak_season ?? '' }}</textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="holiday_schedule">Lịch Nghỉ Tết, Lễ :</label>
                                    </div>
                                    <div>
                                        <textarea id="holiday_schedule" name="holiday_schedule" class="form-input-custom-sp" placeholder="Nhập lịch nghỉ">{{ $supplier->holiday_schedule ?? '' }}</textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="packaging_specifications">Quy Cách Đóng Gói
                                            :</label>
                                    </div>
                                    <div>
                                        <textarea id="packaging_specifications" name="packaging_specifications" class="form-input-custom-sp"
                                            placeholder="Nhập quy cách đóng gói">{{ $supplier->packaging_specifications ?? '' }}</textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="production_time">Thời Gian Sản Xuất :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="production_time" name="production_time"
                                            class="form-input-custom-sp" placeholder="Nhập số ngày sản xuất"
                                            value="{{ $supplier->production_time ?? '' }}">
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="shipping_time">Thời Gian Vận Chuyển :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="shipping_time" name="shipping_time"
                                            class="form-input-custom-sp" placeholder="Nhập số ngày vận chuyển"
                                            value="{{ $supplier->shipping_time ?? '' }}">
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="total_lead_time">Tổng Thời Gian Về Kho Dự Kiến
                                            :</label>
                                    </div>
                                    <div>
                                        <input min="1" type="text" id="total_lead_time" name="total_lead_time"
                                            class="form-input-custom-sp" placeholder="Nhập tổng thời gian"
                                            value="{{ $supplier->total_lead_time ?? '' }}">
                                    </div>
                                </div>


                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="exclusive_rights">Độc Quyền :</label>
                                    </div>
                                    <div>
                                        <select id="exclusive_rights" name="exclusive_rights"
                                            class="form-input-custom-sp">
                                            <option value="0"
                                                {{ isset($supplier->exclusive_rights) && $supplier->exclusive_rights == 0 ? 'selected' : '' }}>
                                                Không</option>
                                            <option value="1"
                                                {{ isset($supplier->exclusive_rights) && $supplier->exclusive_rights == 1 ? 'selected' : '' }}>
                                                Có</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="warranty_preorder">Thống Nhất Hàng Bảo Hành Trước
                                            Khi Xảy Ra Lỗi :</label>
                                    </div>
                                    <div>
                                        <textarea id="warranty_preorder" name="warranty_preorder" class="form-input-custom-sp"
                                            placeholder="Nhập thông tin bảo hành trước khi có lỗi">{{ $supplier->warranty_preorder ?? '' }}</textarea>
                                    </div>
                                </div>

                                <div class="box__sales-item">
                                    <div>
                                        <label class="label__sp" for="warranty_postorder">Thống Nhất Hàng Bảo Hành Sau Khi
                                            Xảy Ra Lỗi :</label>
                                    </div>
                                    <div>
                                        <textarea id="warranty_postorder" name="warranty_postorder" class="form-input-custom-sp"
                                            placeholder="Nhập thông tin bảo hành sau khi có lỗi">{{ $supplier->warranty_postorder ?? '' }}</textarea>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <button type="submit" class="btn__updated-info">Cập Nhật <i class="far fa-save"></i></button>

                    <a style="background-color: #086597; color:#fff" href="{{ route('supplier.index') }}"
                        class="btn__updated-info ml-2">Danh Sách <i class="fas fa-stream"></i></a>
                </form>

            </div>

            <h2 class="mt-5">Sản Phẩm Của Xưởng Đang Sản Xuất</h2>

            <div class="table-responsive">
                <table class="table-custom " id="table2">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Mã NCC</th>
                            <th>Sản Phẩm</th>
                            <th>Danh Mục</th>
                            <th>Phiên Bản (model)</th>
                            <th>Màu Sắc</th>
                            <th>Kích Thước</th>
                            <th>Key Sale</th>
                            <th>Sku</th>
                            <th>Note(Sản Phẩm)</th>
                            <th>Note(Sale)</th>
                            <th>Trạng Thái</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $temp = 0;
                        @endphp
                        @forelse ($productBySupplier as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr>
                                <td>{{ $temp }}</td>
                                <td>{{ $item->supplier_id ?? '' }}</td>
                                <td>{{ $item->product_name ?? '' }}</td>
                                <td>{{ $item->product_variant ?? '' }}</td>
                                <td>{{ $item->model_version ?? '' }}</td>
                                <td>{{ $item->color ?? '' }}</td>
                                <td>{{ $item->size ?? '' }}</td>
                                <td>{{ $item->sale_key ?? '' }}</td>
                                <td>{{ $item->sku ?? '' }}</td>
                                <td>{{ $item->product_note ?? '' }}</td>
                                <td>{{ $item->sale_note ?? '' }}</td>
                                <td style="width: 120px;">
                                    @if ($item->status == 1)
                                        <span style="    font-size: 15px; font-weight: 700;" class=" text-success">Đang
                                            hoạt động</span>
                                    @else
                                        <span style="    font-size: 15px; font-weight: 700;" class=" text-danger">Đã
                                            ngừng</span>
                                    @endif
                                </td>

                                <td class="text-center">
                                    <a href="{{ route('forecastProduct.edit', ['id' => $item->id]) }}"><i
                                            class="far fa-edit"></i></a>
                                </td>
                            </tr>
                        @empty
                            <td>Chưa tìm thấy sản phẩm tương ứng</td>
                        @endforelse


                    </tbody>
                </table>
            </div>

        </div>
    </div>



    <!-- Modal for adding bank account -->
    <div class="modal fade" id="addBankAccountModal" tabindex="-1" role="dialog"
        aria-labelledby="addBankAccountModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBankAccountModalLabel">Thêm Tài Khoản Ngân Hàng</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="modal_bank_name">Tên Ngân Hàng</label>
                        <input type="text" class="form-control" id="modal_bank_name"
                            placeholder="Nhập tên ngân hàng">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_number">Số Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_number"
                            placeholder="Nhập số tài khoản">
                    </div>
                    <div class="form-group">
                        <label for="modal_account_holder">Chủ Tài Khoản</label>
                        <input type="text" class="form-control" id="modal_account_holder"
                            placeholder="Nhập tên chủ tài khoản">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    <button type="button" class="btn btn-primary" id="saveBankAccount">Lưu</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            var bankAccountIndex = 0;

            $('#saveBankAccount').click(function() {
                var bankName = $('#modal_bank_name').val();
                var accountNumber = $('#modal_account_number').val();
                var accountHolder = $('#modal_account_holder').val();

                if (bankName && accountNumber && accountHolder) {
                    var newBankAccountRow = `
                    <tr>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_number]" value="${accountNumber}">${accountNumber}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][bank_name]" value="${bankName}">${bankName}</td>
                        <td><input type="hidden" name="bank_accounts[${bankAccountIndex}][account_holder]" value="${accountHolder}">${accountHolder}</td>
                    </tr>
                `;
                    $('#bankAccountsList').append(newBankAccountRow);
                    bankAccountIndex++;
                    $('#addBankAccountModal').modal('hide');
                    $('#modal_bank_name').val('');
                    $('#modal_account_number').val('');
                    $('#modal_account_holder').val('');
                } else {
                    alert('Vui lòng điền đầy đủ thông tin.');
                }
            });
        });
    </script>
@endsection
