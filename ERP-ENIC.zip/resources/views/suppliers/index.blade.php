@extends('layouts.enic')
@section('content')
    <style>
        .supplier-container {
            background-color: #f8f9fa;
            margin-top: 100px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .supplier-header {
            background-color: #ffffff;
            border-bottom: 1px solid #e9ecef;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .supplier-card {
            transition: all 0.3s ease;
            margin-bottom: 15px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            overflow: hidden;
        }

        .supplier-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .supplier-card.inactive .supplier-card-body {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: #494b4c;
        }

        .supplier-card-body {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: #fff;
        }

        .supplier-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: #007bff;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
            flex-shrink: 0;
        }

        .supplier-info {
            flex-grow: 1;
        }

        .supplier-info h5 {
            font-size: 18px;
            font-weight: 600;
        }

        .supplier-info p {
            font-size: 14px;
        }

        .supplier-actions {
            display: flex;
            justify-content: flex-end;
            padding: 10px;
            background-color: #f1f3f5;
            border-top: 1px solid #e9ecef;
            gap: 10px;
        }

        .supplier-card.inactive {
            background-color: #6c757d;
            color: #fff !important;
        }

        .supplier-card.inactive p {
            color: #fff !important;
        }

        #searchInput {
            border-radius: 20px;
            padding: 10px 20px;
        }
    </style>

    <div class="container-fluid p-4">
        <div class="supplier-container">
            <div class="supplier-header">
                <h2 class="mb-0">Quản Lý Nhà Cung Cấp</h2>
                <div class="d-flex" style="gap: 10px">
                    <a href="{{ route('supplier.add') }}" class="btn btn-primary">
                        <i class="fas fa-plus mx-1"></i>Thêm Mới
                    </a>
                    <a href="{{ route('supplier.import') }}" class="btn btn-success">
                        <i class="fas fa-file-excel mx-1"></i>Nhập Excel
                    </a>
                </div>
            </div>

            <div class="p-3">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <input type="text" id="searchInput" class="form-control" placeholder="Tìm kiếm nhà cung cấp...">
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-primary status-filter-btn active"
                                data-status="all">
                                <i class="fas fa-list mx-1"></i>Tất Cả
                            </button>
                            <button type="button" class="btn btn-outline-primary status-filter-btn" data-status="active">
                                <i class="fas fa-check-circle mx-1"></i>Đang Hoạt Động
                            </button>
                            <button type="button" class="btn btn-outline-primary status-filter-btn" data-status="inactive">
                                <i class="fas fa-stop-circle mx-1"></i>Ngừng Hoạt Động
                            </button>
                        </div>
                    </div>
                </div>

                <div class="row" id="supplierGrid">
                    @forelse ($suppliers as $supplier)
                        <div class="col-md-4 supplier-search-item" data-name="{{ strtolower($supplier->company_name) }}"
                            data-code="{{ strtolower($supplier->sp_code) }}"
                            data-employer="{{ strtolower($supplier->employer) }}"
                            data-status="{{ $supplier->status == 1 ? 'active' : 'inactive' }}">
                            <div class="supplier-card {{ $supplier->status == 0 ? 'inactive' : '' }}">
                                <div class="supplier-card-body">
                                    <div class="supplier-avatar">
                                        {{ !empty($supplier->company_name) ? strtoupper(substr($supplier->company_name, 0, 1)) : 'SP' }}
                                    </div>
                                    <div class="supplier-info">
                                        <h5 class="mb-1">{{ $supplier->company_name }}</h5>
                                        <p class="mb-1">
                                            Mã SP: {{ $supplier->sp_code }}
                                            <span
                                                class="badge text-white {{ $supplier->status == 1 ? 'bg-success' : 'bg-danger' }} ms-2">
                                                {{ $supplier->status == 1 ? 'Hoạt Động' : 'Ngừng' }}
                                            </span>
                                        </p>
                                        <p class="text-dark">
                                            Người Quản Lý: {{ $supplier->user->name ?? 'Chưa xác định' }}
                                        </p>
                                    </div>
                                </div>
                                <div class="supplier-actions">

                                    @if ($supplier->status == 1)
                                        <a href="{{ route('supplier.index') }}?status=0&id={{ $supplier->id }}"
                                            class="btn btn-sm btn-outline-success">
                                            <i style="font-size: 20px" class="fas fa-toggle-on"></i>
                                        </a>
                                    @elseif($supplier->status == 0)
                                        <a href="{{ route('supplier.index') }}?status=1&id={{ $supplier->id }}"
                                            class="btn btn-sm btn-outline-dark">
                                            <i style="font-size: 20px" class="fas fa-toggle-off"></i>
                                        </a>
                                    @endif

                                    <a href="{{ route('supplier.edit', [$supplier->id]) }}"
                                        class="btn btn-sm btn-outline-primary me-2">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('supplier.delete', [$supplier->id]) }}" method="GET"
                                        class="delete-form d-inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-outline-danger delete-btn">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center py-5">
                            <i class="fas fa-box-open fa-3x text-dark mb-3"></i>
                            <p class="text-dark">Chưa có nhà cung cấp nào được thêm</p>
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        // Success Notification
        @if (session('success'))
            Swal.fire({
                title: 'Thông Báo',
                text: '{{ session('success') }}',
                icon: 'success',
                confirmButtonText: 'OK',
                timer: 3000,
                timerProgressBar: true
            });
        @endif

        // Status Filter Functionality
        const statusFilterBtns = document.querySelectorAll('.status-filter-btn');
        const supplierItems = document.querySelectorAll('.supplier-search-item');
        const searchInput = document.getElementById('searchInput');

        function filterSuppliers(searchTerm, status) {
            supplierItems.forEach(item => {
                const name = item.dataset.name;
                const code = item.dataset.code;
                const employer = item.dataset.employer;
                const itemStatus = item.dataset.status;
                const matchesSearch = name.includes(searchTerm) || code.includes(searchTerm) || employer.includes(
                    searchTerm);
                const matchesStatus = status === 'all' || itemStatus === status;

                if (matchesSearch && matchesStatus) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // Status Filter Event Listeners
        statusFilterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                statusFilterBtns.forEach(b => b.classList.remove('active'));

                // Add active class to clicked button
                this.classList.add('active');

                // Get current search term and selected status
                const searchTerm = searchInput.value.toLowerCase();
                const status = this.dataset.status;

                // Apply filtering
                filterSuppliers(searchTerm, status);
            });
        });

        // Search Event Listener
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const activeStatusBtn = document.querySelector('.status-filter-btn.active');
            const status = activeStatusBtn.dataset.status;

            filterSuppliers(searchTerm, status);
        });

        // Delete Confirmation
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                Swal.fire({
                    title: 'Xác Nhận Xóa',
                    text: 'Bạn có chắc chắn muốn xóa nhà cung cấp này?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Xóa',
                    cancelButtonText: 'Hủy'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
@endsection
