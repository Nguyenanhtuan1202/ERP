<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Đơn Hàng</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }


        td[colspan="3"] {
            min-width: 400px;
            /* Độ rộng tối thiểu */
            white-space: pre-wrap;
            /* Xuống dòng khi nội dung dài */
            word-break: break-word;
            /* Ngắt từ nếu quá dài */
            text-align: left;
            /* Căn trái để dễ đọc */
        }
    </style>
</head>

<body>
    <h2>Đơn {{ $purchaseOrderNew->total_quantity }} | {{ $purchaseOrderNew->po_id ?? '' }}</h2>

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Key Chuẩn (Sale)</th>
                <th>Mã SKU</th>
                <th>Đơn {{ $purchaseOrderNew->total_quantity }} </th>
                <th>SL Xuất</th>
                <th colspan="3">Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($purchaseOrder as $key => $item)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $item->product->name }}</td>
                    <td>{{ $item->sku }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td></td>
                    <td colspan="3"></td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>

</html>
