@extends('layouts.enic')
@section('content')
    <div class="midde_cont" style="margin-top: 100px">
        <div class="container-fluid">
            <div class="row column_title">
                <style>
                    .return__back {
                        display: inline-block;
                        padding: 8px 25px;
                        background-color: #0caf60;
                        border-radius: 22px;
                        color: #fff;
                        font-weight: 700;
                        margin-bottom: 20px;
                    }
                </style>

                @if (session('success'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('success') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                @if (session('error'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Lỗi',
                                text: '{{ session('error') }}',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#d33',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                <div class="col-md-12">
                    <div class="page_title">
                        <nav aria-label="breadcrumb" class="mt-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}">DashBoard</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('forecaster.index') }}">Danh sách </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Thêm Mới</li>
                            </ol>
                        </nav>
                    </div>
                    <a class="return__back" href="{{ route('forecaster.index') }}">Quay Lại <i
                            class="fas fa-undo-alt"></i>
                    </a>
                </div>
            </div>

            <!-- row -->
            <form action="{{ route('forecaster.save') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row column1">
                    <div class="col-md-12">
                        <div class="white_shd full margin_bottom_30">

                            <div class="full price_table padding_infor_info">
                                <div class="row">
                                    <div class="col-md-12 sider__bar-left">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('username')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="username">Họ Và Tên</label>
                                                    <input class="form-control" id="username" type="text"
                                                        name="username" value="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('email')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="email">Email</label>
                                                    <input class="form-control" required id="email" type="text"
                                                        name="email" value="">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('phone')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="phone">Số Điện Thoại</label>
                                                    <input class="form-control" required id="phone" type="text"
                                                        name="phone" value="">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('password')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="password">Mật Khẩu</label>
                                                    <input class="form-control" required id="password" type="password"
                                                        name="password" value="">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn__add my-3">Thêm Mới <i
                                                class="fas fa-plus"></i></button>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- end row -->
                </div>
            </form>
            <!-- footer -->
        </div>
        <!-- end dashboard inner -->
    </div>
@endsection
