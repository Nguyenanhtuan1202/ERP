@extends('layouts.enic')
@section('content')
    <div style="padding: 10px 30px; margin-top: 100px;" class="">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">

                        <h3 class="title__highlight">
                            <i class="fas fa-desktop"></i> Danh sách nhân viên kho
                        </h3>

                        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px">

                            <a class="add__expert" href="{{ route('warehousingmanager.create') }}">Thêm Mới <i
                                    class="fas fa-user-plus"></i></a>
                        </div>

                        @if (session('success'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('success') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>

                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                <thead class="thead__custom">
                                    <tr>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            STT</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Tên Nhân Viên</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Email</th>
                                        <th style="font-size: 14px"
                                            class=" text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Số Điện Thoại</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Quản Lý</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @php
                                        $temp = 0;
                                    @endphp

                                    @foreach ($data as $item)
                                        @php
                                            $temp++;
                                        @endphp
                                        <tr>

                                            <td class="align-middle text-center ">
                                                {{ $temp }}
                                            </td>

                                            {{-- <td class="align-middle text-center ">
                                                <img style="max-width: 100px;"
                                                    src="{{ asset('uploads/product/' . $item->images ?? '') }}"
                                                    alt="{{ $item->name ?? '' }}">
                                            </td> --}}
                                            <td class="align-middle  ">
                                                {{ $item->name ?? '' }}
                                            </td>
                                            <td class="align-middle ">
                                                {{ $item->email ?? '' }}
                                            </td>

                                            <td class="align-middle  ">
                                                {{ $item->phone ?? '' }}
                                            </td>


                                            <td class="align-middle">
                                                <a href="{{ route('warehousingmanager.edit', [$item->id ?? '']) }}"
                                                    class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="edit agent"
                                                    style="font-size: 12px; font-weight: bold; color: #ffffff; background-color: #35cbdc; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Edit
                                                </a>
                                                <a onclick="return confirm('Bạn có muốn xóa nhân viên này không ?')"
                                                    href="{{ route('warehousingmanager.delete', [$item->id ?? '']) }}"
                                                    class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="delete agent"
                                                    style="font-size: 12px; display: block; margin-top: 5px; font-weight: bold; color: #ffffff; background-color: #dc3545; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Delete
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
