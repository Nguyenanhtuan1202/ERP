@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/purchaseorder.css') }}">
@endsection
@section('content')
    <div class="container-fluid my-5">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h2 class="mb-3">Tổng quan đơn hàng</h2>
                <p class="text-muted">Xem đơn hàng theo thời gian: Hôm nay, Tuần này, Tháng này, Tất cả hoặc lọc theo tháng
                    cụ thể</p>
            </div>
        </div>

        <!-- Bộ lọc -->
        <div class="row mb-4">
            <div class="col-md-4 offset-md-4">
                <select id="filterType" class="form-control">
                    <option value="all">Tất cả</option>
                    <option value="day">Hôm nay</option>
                    <option value="week">Tuần này</option>
                    <option value="month">Tháng này</option>
                    <option value="custom_month">Lọc theo tháng</option>
                </select>
            </div>
        </div>

        <!-- Select chọn tháng, ẩn mặc định -->
        <div class="row mb-4" id="monthFilterContainer" style="display: none;">
            <div class="col-md-4 offset-md-4">
                <select id="filterMonth" class="form-control">
                    <option value="">Chọn tháng</option>
                    <option value="1">Tháng 1</option>
                    <option value="2">Tháng 2</option>
                    <option value="3">Tháng 3</option>
                    <option value="4">Tháng 4</option>
                    <option value="5">Tháng 5</option>
                    <option value="6">Tháng 6</option>
                    <option value="7">Tháng 7</option>
                    <option value="8">Tháng 8</option>
                    <option value="9">Tháng 9</option>
                    <option value="10">Tháng 10</option>
                    <option value="11">Tháng 11</option>
                    <option value="12">Tháng 12</option>
                </select>
            </div>
        </div>

        <!-- Khu vực hiển thị kết quả -->
        <div id="orderItemsContainer">
            @if ($orderItems->count())
                @include('purchase_orders.items_table', ['orderItems' => $orderItems])
            @else
                <div class="alert alert-info text-center">
                    Không có dữ liệu order item.
                </div>
            @endif
        </div>
    </div>
@endsection
@section('js')
    <script>
        $(document).ready(function() {
            // Khi thay đổi bộ lọc chính
            $('#filterType').on('change', function() {
                var filter = $(this).val();
                // Hiển thị select chọn tháng nếu chọn "custom_month"
                if (filter === 'custom_month') {
                    $('#monthFilterContainer').show();
                } else {
                    $('#monthFilterContainer').hide();
                    // Gửi ajax ngay nếu không phải lọc theo tháng
                    fetchData(filter, '');
                }
            });

            // Khi chọn tháng từ select
            $('#filterMonth').on('change', function() {
                var selectedMonth = $(this).val();
                var filter = $('#filterType').val();
                if (filter === 'custom_month') {
                    fetchData(filter, selectedMonth);
                }
            });

            // Hàm gửi AJAX
            function fetchData(filter, month) {
                $.ajax({
                    url: '{{ route('orders.filter') }}', // Route này cần được định nghĩa trong routes/web.php
                    type: 'GET',
                    data: {
                        filter: filter,
                        month: month // gửi thêm tháng nếu có
                    },
                    beforeSend: function() {
                        // Bạn có thể hiển thị loading spinner tại đây nếu cần
                    },
                    success: function(response) {
                        // Cập nhật nội dung trả về vào container
                        $('#orderItemsContainer').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error("Lỗi: " + error);
                        alert("Đã có lỗi xảy ra. Vui lòng thử lại sau.");
                    }
                });
            }
        });
    </script>
@endsection
