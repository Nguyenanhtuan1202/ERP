@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/purchaseorder.css') }}">
@endsection
@section('content')
    <div class="container-fluid">
        <div class="quote-request-container">
            @if (session('success'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('success') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif



            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: '{{ session('error') }}',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif

            <div class="row align-items-center justify-content-between listPurchaseOrder" style="width: 100%;">
                <div class="col-auto">
                    <div class="page-header-title">
                        <h4 class="m-b-10"> Create Purchase
                        </h4>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">
                            Purchase
                        </li>

                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a class="addNew" href="{{ route('purchaseorder.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang <i
                                class="fas fa-sync-alt"></i></a>

                        <a style="background: #199fb7; box-shadow: none" class="addNew"
                            href="{{ route('purchaseorder.index') }}">Danh sách đơn hàng <i class="fas fa-list"></i></a>
                    </div>
                </div>
            </div>

            <form action="{{ route('purchase_orders.store') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="header">
                    <h1><i class="fa fa-star"></i>
                        Tạo Đơn Hàng Mới
                    </h1>

                </div>

                <div class="form-section">
                    <div class="form-group">
                        <label for="po_id">Mã Đơn Hàng <span> (Purchase Order)</span></label>
                        <input required type="text" class="form-controller-custompo" id="po_id" name="po_id"
                            placeholder="Nhập mã đơn hàng">
                    </div>
                    <div class="form-group">
                        <label for="supplier_id">Nhà cung cấp</label>
                        <input required class="form-controller-custompo" type="text" id="supplier_search"
                            class="form-control" placeholder="Tên, MST, email, hoặc mã">
                        <input type="hidden" id="supplier_id" name="supplier_id">
                        <div id="supplier_list" class="list-group mt-2"></div>
                    </div>



                    <div
                        style="display: flex; align-items: center; gap: 10px; padding: 10px; border: 1px solid #ddd; border-radius: 8px; background-color: #f9f9f9;">
                        <label for="prioritize" style="font-weight: bold; font-size: 16px; color: #333; margin: 0px;">Đơn
                            hàng ưu
                            tiên</label>
                        <input type="checkbox" id="prioritize" name="prioritize" value="1"
                            style="width: 20px; height: 20px; cursor: pointer; accent-color: #ff9800;">
                    </div>




                </div>





                <div class="tabs">
                    <button class="tab active">Sản phẩm</button>

                </div>

                <div class="table-section">
                    <table id="productTable">
                        <thead>
                            <tr>
                                <th>SKU</th>
                                <th>Sản Phẩm</th>
                                <th>Số Lượng</th>
                                <th>Đơn Giá</th>
                                <th>Thuế</th>
                                <th>Thành Tiền</th>
                            </tr>
                        </thead>
                        <tbody id="sku_results">

                        </tbody>
                    </table>

                </div>

                <div class="box__process_multiple-sku row mt-3">
                    <div class="col-md-6">
                        <textarea name="skus" id="skus" class="text__area-custom" rows="10" placeholder="Dán Mã SKU Vào Đây"></textarea>
                    </div>
                    <div class="col-md-6">
                        <textarea name="quantities" id="quantities" class="text__area-custom" rows="10"
                            placeholder="Dán Số Lượng Tương Ứng"></textarea>
                    </div>
                    <button type="button" class="btn btn-primary check__skus">Kiểm Tra</button>

                    <!-- Phần hiển thị số SKU -->
                    <div class="col-12 mt-2">
                        <p id="skuCountDisplay" style="font-weight:bold;"></p>
                        <p id="qtyCountDisplay" style="font-weight:bold;"></p>
                    </div>
                </div>


                <div class="form-section mt-5">

                    <div class="form-group">
                        <label for="ware_housing">Công Suất Xưởng <small>(Số Lượng/Ngày)</small> </label>
                        <input type="text" class="form-controller-custompo" id="factory_capacity" name="factory_capacity"
                            placeholder="Nhập công suất xưởng">
                    </div>


                    <div class="form-group">
                        <label for="order_date">Ngày đặt hàng </label>
                        <input class="form-controller-custompo" required type="datetime-local" id="order_date"
                            name="order_date" value="{{ now()->format('Y-m-d\TH:i') }}">
                    </div>
                    <div class="form-group">
                        <label class="" for="expected_date">Ngày hàng về dự kiến</label>
                        <input class="form-controller-custompo" required type="date" id="expected_date"
                            name="expected_date">
                    </div>
                    <div class="form-group">
                        <label class="" for="date_sale">Ngày hàng về dự kiến cho sale</label>
                        <input class="form-controller-custompo" required type="date" id="date_sale" name="date_sale">
                    </div>

                    <div class="form-group">
                        <label for="ware_housing">Kho</label>

                        <select class="form-control" name="ware_housing" id="ware_housing">
                            <option>HCM</option>
                            <option>HN</option>
                        </select>
                    </div>
                </div>


                <div class="footer">
                    <textarea name="note" placeholder="Ghi Chú:" id="" class="mt-3 form-control" cols="180"
                        rows="10"></textarea>
                    <div class="total" style="color: #064b8f">
                        <div class="mt-3">Tổng Tiền: <span class="total__all" id="total">0 ₫</span></div>
                    </div>

                    <input type="hidden" name="total" id="total_amount" value="">
                </div>


                <button type="submit" class="add__po"> Thêm Mới</button>
            </form>

            <!-- Hidden form for printing -->
            <div id="printSection" style="display:none;">
                <h4>Thông Tin Đơn Hàng</h4>
                <p>Nhà cung cấp: <span id="print_supplier_name"></span></p>
                <table class="table mt-3">
                    <thead>
                        <tr>
                            <th>Mã SKU</th>
                            <th>Sản Phẩm</th>
                            <th>Số Lượng</th>
                            <th>Giá Thành</th>
                            <th>Thuế</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody id="print_sku_results">
                        <!-- Results will be appended here -->
                    </tbody>
                </table>
                <div class="total" style="color: #064b8f">
                    <div class="mt-3">Tổng Tiền: <span id="print_total">0 ₫</span></div>
                </div>
            </div>


        </div>



    </div>
@endsection


@section('js')
    <script>
        // Thêm đoạn code này vào phần JavaScript đã có
        $(document).ready(function() {
            // Các hàm JavaScript khác của bạn vẫn giữ nguyên...

            // Bắt sự kiện khi người dùng thay đổi giá trị công suất xưởng
            $('#factory_capacity').on('change', function() {
                // Lấy giá trị công suất xưởng
                var factoryCapacity = parseInt($(this).val());

                // Kiểm tra giá trị hợp lệ
                if (isNaN(factoryCapacity) || factoryCapacity <= 0) {
                    alertNotify('Vui lòng nhập công suất xưởng hợp lệ.');
                    return;
                }

                // Tính tổng số lượng sản phẩm trong đơn hàng hiện tại
                var currentOrderQuantity = 0;
                $('#sku_results tr').each(function() {
                    var qty = parseInt($(this).find('td:eq(2)').text());
                    if (!isNaN(qty)) {
                        currentOrderQuantity += qty;
                    }
                });

                // Nếu chưa có sản phẩm nào, hiện thông báo
                if (currentOrderQuantity <= 0) {
                    alertNotify('Vui lòng thêm sản phẩm vào đơn hàng trước.');
                    return;
                }

                // Gọi AJAX để tính toán ngày dự kiến
                $.ajax({
                    url: '{{ route('purchase-orders.calculate-expected-date') }}',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        factory_capacity: factoryCapacity,
                        current_order_quantity: currentOrderQuantity,
                        prioritize: $('#prioritize').is(':checked') ? 1 :
                            0 // Kiểm tra xem đơn hàng có ưu tiên không
                    },
                    success: function(response) {
                        if (response.success) {
                            // Cập nhật ngày dự kiến
                            $('#expected_date').val(response.expected_date);

                            // Kích hoạt sự kiện change để cập nhật ngày dự kiến cho sale
                            $('#expected_date').trigger('change');

                            // Hiển thị thông báo chi tiết nếu cần
                            if (response.message) {
                                Swal.fire({
                                    title: 'Thông tin dự đoán',
                                    text: response.message,
                                    icon: 'info',
                                    confirmButtonText: 'OK',
                                    confirmButtonColor: '#3085d6'
                                });
                            }
                        } else {
                            alertNotify(response.message ||
                                'Có lỗi xảy ra khi tính toán ngày dự kiến');
                        }
                    },
                    error: function() {
                        alertNotify('Đã xảy ra lỗi khi kết nối với máy chủ');
                    }
                });
            });
        });

        $(document).ready(function() {
            $('#addRow').click(function() {
                var newRow = `<tr>
                <td>
                    <input type="text" class="form-control sku-input" placeholder="Nhập mã SKU">
                    <div class="sku-suggestions"></div>
                </td>
                <td>
                    <input type="tel" class="form-control quantity-input" placeholder="Nhập số lượng">
                </td>
                <td>
                    <input type="text" class="form-control price-input" placeholder="Nhập đơn giá">
                </td>
                <td>
                    <input type="text" class="form-control tax-input" placeholder="Thuế">
                </td>
                <td>
                    <input type="text" class="form-control total-input" placeholder="Thành tiền">
                </td>
                <td>
                    <button type="button" class="btn btn-danger remove-row">Xóa</button>
                </td>
            </tr>`;
                $('#productTable tbody').append(newRow);
            });

            $(document).on('click', '.remove-row', function() {
                $(this).closest('tr').remove();
            });

            $(document).on('input', '.sku-input', function() {
                var input = $(this);
                var query = input.val();
                if (query.length > 2) {
                    $.ajax({
                        url: '{{ route('list_products') }}',
                        data: {
                            sku: query
                        },
                        success: function(data) {
                            var suggestions = input.siblings('.sku-suggestions');
                            suggestions.empty();
                            data.forEach(function(product) {
                                suggestions.append(
                                    '<div class="suggestion-item" data-sku="' +
                                    product.sku + '" data-price="' + product.price +
                                    '">' + product.name + ' (' + product.sku +
                                    ')</div>');
                            });
                        }
                    });
                }
            });

            $(document).on('click', '.suggestion-item', function() {
                var item = $(this);
                var sku = item.data('sku');
                var price = item.data('price');
                var input = item.closest('td').find('.sku-input');
                input.val(sku);
                input.closest('tr').find('.price-input').val(price);
                item.closest('.sku-suggestions').empty();
                calculateTotal(input.closest('tr'));
            });

            $(document).on('input', '.quantity-input, .price-input, .tax-input', function() {
                calculateRowTotal($(this).closest('tr'));
                calculateTotal();
            });

            function calculateRowTotal(row) {
                var quantity = parseFloat(row.find('.quantity-input').val()) || 0;
                var price = parseFloat(row.find('.price-input').val()) || 0;
                var tax = parseFloat(row.find('.tax-input').val()) || 0;
                var total = quantity * price;
                if (tax > 0) {
                    total += total * (tax / 100);
                }
                row.find('.total-input').val(total.toFixed(2));
            }

            function calculateTotal() {
                var total = 0;
                $('#productTable tbody tr').each(function() {
                    var rowTotal = parseFloat($(this).find('.total-input').val()) || 0;
                    total += rowTotal;
                });
                $('#total').text(formatCurrency(total) + ' ₫');
                $('#total_amount').val(total);
            }
        });

        function formatCurrency(number) {
            return number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,').split('.')[0];
        }
        /* Danh sách nhà cung cấp */
        $(document).ready(function() {
            $('#supplier_search').on('input', function() {
                var query = $(this).val();
                if (query.length > 2) {
                    $.ajax({
                        url: '{{ route('suppliers.search') }}',
                        type: 'GET',
                        data: {
                            query: query
                        },
                        success: function(data) {
                            $('#supplier_list').empty();
                            if (data.length > 0) {
                                data.forEach(function(supplier) {
                                    $('#supplier_list').append(
                                        '<a href="#" class="list-group-item list-group-item-action" data-id="' +
                                        supplier.id + '">' + supplier.username +
                                        ' (' +
                                        supplier.sp_code + ')</a>');
                                });
                            } else {
                                $('#supplier_list').append(
                                    '<div class="list-group-item">Không tìm thấy nhà cung cấp</div>'
                                );
                            }
                        }
                    });
                } else {
                    $('#supplier_list').empty();
                }
            });
            /* End xử lý nhà cung cấp */

            $(document).on('click', '.list-group-item', function(e) {

                console.log($(this).data('sp_code'));
                e.preventDefault();
                var supplierId = $(this).data('id');
                var supplierSpCode = $(this).data('sp_code');
                var supplierName = $(this).text();
                $('#supplier_id').val(supplierId);
                $('#supplier_search').val(supplierName);
                $('#supplier_list').empty();
            });

            /* check mã sku*/
            $('.check__skus').click(function() {

                var skuText = $('#skus').val().trim();
                var quantityText = $('#quantities').val().trim();


                // Nếu không nhập giá trị SKU hoặc số lượng thì hiển thị thông báo và đặt số SKU, số lượng là 0
                if (skuText === "" || quantityText === "") {
                    alertNotify('Vui lòng nhập mã SKU và số lượng tương ứng.');
                    $('#skuCountDisplay').text('Tổng số mã SKU tải lên: 0');
                    $('#qtyCountDisplay').text('Tổng số lượng sản phẩm: 0');
                    return; // Dừng xử lý
                }
                // Tách từng dòng, loại bỏ dòng trống
                var skus = skuText.split('\n').filter(function(item) {
                    return item.trim() !== "";
                });
                var quantities = quantityText.split('\n').filter(function(item) {
                    return item.trim() !== "";
                });

                // Cập nhật số lượng SKU đã tải lên
                var skuCount = skus.length;

                $('#skuCountDisplay').text('Tổng số mã SKU tải lên: ' + skuCount);
                // Kiểm tra nếu số dòng của SKU không bằng số dòng của số lượng
                if (skus.length !== quantities.length) {
                    alertNotify('Số lượng SKU và số lượng tương ứng không khớp.')
                }
                // Tính tổng số lượng qty
                var totalQty = 0;
                quantities.forEach(function(qty) {
                    totalQty += parseFloat(qty) || 0;
                });

                $('#qtyCountDisplay').text('Tổng số lượng sản phẩm: ' + totalQty);

                $.ajax({
                    url: '{{ route('purchase-orders.check-skus') }}',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        skus: skus,
                        quantities: quantities
                    },
                    success: function(data) {
                        $('#sku_results').empty();
                        var totalAmount = 0;
                        data.forEach(function(item, index) {
                            var tax = 0; // Assuming 10% tax
                            var total = (item.price * item.quantity);
                            totalAmount += parseFloat(total);
                            $('#sku_results').append('<tr><td>' + item.sku +
                                '</td><td>' + item.name +
                                '</td><td>' + item.quantity + '</td><td>' + item
                                .price + '</td><td>' + tax + '</td><td>' +
                                formatCurrency(total) +
                                '</td></tr>');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][sku]" value="' + item.sku + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][name]" value="' + item.name + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][quantity]" value="' + item.quantity + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][price]" value="' + item.price + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][id]" value="' + item.id + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][tax]" value="' + tax + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][total]" value="' + total + '">');
                        });
                        $('#total').text(formatCurrency(totalAmount));
                        $('#total_amount').val(totalAmount);
                    }
                });
            });

            function alertNotify(message) {
                Swal.fire({
                    title: 'Thông báo',
                    position: "top-end",
                    text: message,
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 3000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
                return false;
            }

            /* Thay đổi ngày dự kiến cho sale */
            $('#expected_date').on('change', function() {
                var expectedDate = new Date($(this).val());
                expectedDate.setDate(expectedDate.getDate() + 5);
                var dateSale = expectedDate.toISOString().split('T')[0];
                $('#date_sale').val(dateSale);
            });

        });
    </script>
@endsection
