@if ($orderItems->count())

    @php
        $temp = 0;
    @endphp


    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Thông tin Order Items</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="table3">
                    <thead class="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Purchase Order</th>
                            <th>SKU</th>
                            <th>Số lượng</th>
                            <th>Đơn giá</th>
                            <th>Tổng tiền</th>
                            <th>Ngày Về Dự Kiến</th>
                            <th>Ngày về Cho Sale</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orderItems as $item)
                            @php
                                $temp++;
                            @endphp
                            <tr>
                                <td>{{ $temp }}</td>
                                <td>{{ $item->purchaseOrder->po_id }}</td>
                                <td>{{ $item->sku }}</td>
                                <td>{{ $item->quantity }}</td>
                                <td>{{ number_format($item->unit_price, 2) }}</td>
                                <td>{{ number_format($item->subtotal, 2) }}</td>
                                <td>{{ \Carbon\Carbon::parse($item->expected_date)->format('d/m/Y') }}</td>
                                <td>{{ \Carbon\Carbon::parse($item->date_sale)->format('d/m/Y') }}</td>
                                <td>
                                    @if ($item->complete_order == 1)
                                        <span class="badge badge-success"> Đã Hoàn thành</span>
                                    @else
                                    <span class="badge badge-warning">Đang sản xuất</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@else
    <div class="alert alert-info text-center">
        Không có dữ liệu đơn hàng.
    </div>
@endif





<script>
    $(document).ready(function() {
        for (let i = 0; i <= 1000; i++) {
            let table = $(`#table${i}`);
            if (table.length && table.is('table')) {
                table.DataTable();
            }
        }
    });
</script>
