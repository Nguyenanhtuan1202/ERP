@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/purchaseorder.css') }}">
@endsection
@section('content')
    <div class="container-fluid">
        <div class="quote-request-container">


            @if (session('success'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('success') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif


            <form action="{{ route('purchaseorder.update', ['id' => $purchaseOrder->id]) }}" method="POST"
                enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="header-top">
                    <a style="background-color: #da0015;" href="{{ route('purchaseorder.add') }}" class="new__po class__function-advance"> <i
                            class="far fa-plus-square"></i> Tạo Mới</a>

                    <a style="background-color: #064b8f" href="{{ route('purchaseorder.index') }}"
                        class="class__function-advance"> <i class="fas fa-list"></i> Danh sách đơn hàng</a>
                    <a style="background-color: #0a7b4c" href="{{ route('purchaseorder.export', ['id' => $purchaseOrder->id]) }}"
                        class="send__remind class__function-advance"><i class="far fa-file-excel"></i> Xuất Excel</a>
                    <a style="background-color: #111" class="return" href="{{ route('purchaseorder.index') }}">Quay lại <i class="fas fa-undo-alt"></i></a>
                </div>



                <div class="header">
                    <h1><i class="fa fa-star"></i>
                        Thông Tin Đơn Hàng
                    </h1>
                    <p>Mã đơn hàng <span class="status ml-2"
                            style="background-color: #0caf60; padding: 10px 20px; border-radius: 10px; color: #fff; font-weight: 700">#{{ $purchaseOrder->po_id ?? '' }}</span>
                    </p>


                </div>


                <div class="row mb-4" style="background-color: #f5f5f5; border-radius: 10px; padding: 10px;">
                    <div class="col-md-4 box__info-suppliers">
                        <h4 class="my-2">Thông Tin Nhà Cung Cấp</h4>
                        <p> <span style="font-weight: 600;">Tên Người Liên Hệ:
                            </span>{{ $purchaseOrder->supplier->username ?? '' }}</p>
                        <p><span style="font-weight: 600;">Công Ty:
                            </span>{{ $purchaseOrder->supplier->company_name ?? '' }}</p>
                        <p> <span style="font-weight: 600;">Số Điện Thoại: </span>
                            {{ $purchaseOrder->supplier->phone_number ?? '' }}</p>
                        <p> <span style="font-weight: 600;">Email: </span> {{ $purchaseOrder->supplier->email ?? '' }}</p>
                        <p> <span style="font-weight: 600;">Địa Chỉ: </span> {{ $purchaseOrder->supplier->address ?? '' }}
                        </p>
                        <p> <span style="font-weight: 600;">Thanh Toán: </span>
                            {{ $purchaseOrder->supplier->payments ?? '' }}</p>
                    </div>
                    <div class="col-md-4">
                        <p><span style="font-weight: 600">Kho:</span> {{ $purchaseOrder->ware_housing ?? '' }}</p>
                    </div>
                    {{-- <div class="col-md-4">
                        <p><Strong>QR CODE ĐƠN HÀNG</Strong></p>
                        <img class="qr__code" src="data:image/png;base64,{{ $purchaseOrder->qr_code }}" alt="QR Code">

                    </div> --}}
                </div>


                <div class="form-section">
                    <div class="form-group" style="display: none">
                        <label for="po_id">Mã Đơn Hàng <span> (Purchase Order)</span></label>
                        <input style="background-color: #ddd;" readonly type="hidden" class="form-controller-custompo"
                            id="po_id" name="po_id" placeholder="Nhập mã đơn hàng"
                            value="{{ $purchaseOrder->po_id ?? '' }}">
                    </div>
                    <div class="form-group" style="display: none">
                        <label for="supplier_id">Nhà cung cấp</label>
                        <input style="background-color: #ddd;" readonly class="form-controller-custompo" type="hidden"
                            id="supplier_search" class="form-control" placeholder="Tên, MST, email, hoặc mã"
                            value="{{ $purchaseOrder->supplier->username ?? '' }}">
                        <input type="hidden" id="supplier_id" name="supplier_id">
                        <div id="supplier_list" class="list-group mt-2"></div>
                    </div>

                    <div class="form-group" style="display: none">
                        <label for="order_date">Hạn đặt hàng </label>
                        <input class="form-controller-custompo" style="background-color: #ddd;" required type="hidden"
                            readonly id="order_date" name="order_date" value="{{ $purchaseOrder->order_date ?? '' }}">
                    </div>
                    <div class="form-group">
                        <label class="" for="expected_date">Ngày hàng về dự kiến</label>
                        <input class="form-controller-custompo" required type="date"
                            value="{{ $purchaseOrder->expected_date ?? '' }}" id="expected_date" name="expected_date">
                    </div>

                    <div class="form-group">
                        <label class="" for="date_sale">Ngày hàng về dự kiến cho sale</label>
                        <input class="form-controller-custompo" required type="date"
                            value="{{ $purchaseOrder->date_sale ?? '' }}" id="date_sale" name="date_sale">
                    </div>


                    <div
                        style="display: flex; align-items: center; gap: 10px; padding: 10px; border: 1px solid #ddd; border-radius: 8px; background-color: #f9f9f9;">
                        <label for="prioritize" class="prioritize"
                            style="font-weight: bold; font-size: 16px; color: #333; margin: 0px;">Đơn
                            hàng ưu
                            tiên</label>

                        <input type="checkbox" id="prioritize" name="prioritize" value="1"
                            style="width: 20px; height: 20px; cursor: pointer; accent-color: #ff9800;"
                            @if (isset($purchaseOrder->prioritize) && $purchaseOrder->prioritize == 1) checked @endif>
                    </div>

                </div>


                <div class="box__list-po-order">

                    <div class="tabs">
                        <button style="outline: none" type="button" class="tab active btn__show-list-po">DANH SÁCH SẢN
                            PHẨM
                            CỦA ĐƠN HÀNG <span style="color: #db61bb">{{ $purchaseOrder->po_id ?? '' }}</span> <span
                                style="font-size: 13px; font-weight: 400; text-decoration: underline; font-style: italic; color: rgb(168, 26, 26); ">(Nhấn
                                vào để xem chi tiết)</span> </button>

                    </div>

                    <div class="table-section table-section__po" style="display: none;">
                        <table id="productTable" class="table-responsive">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Sản Phẩm</th>
                                    <th>Mã SKU</th>
                                    <th>Số Lượng</th>
                                    <th>Đơn Giá</th>
                                    <th>Thành Tiền</th>
                                    <th>Ngày Về Dự Kiến</th>
                                    <th>Ngày Về Dự Kiến Cho Sale</th>
                                </tr>
                            </thead>
                            <tbody id="sku_results">


                                @php
                                    $total = 0;
                                    $total_qty = 0;
                                    $temp = 0;
                                @endphp
                                @foreach ($purchaseOrder->items as $product)
                                    @php
                                        $total += $product->subtotal;
                                        $total_qty += $product->quantity;
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <td>{{ $temp }}</td>
                                        <td>
                                            <input type="text" readonly class=" sku-input form-controller-custompo"
                                                placeholder="Nhập mã SKU" value="{{ $product->product->name ?? '' }}">

                                        </td>
                                        <td>
                                            <input type="text" readonly class=" sku-input form-controller-custompo"
                                                placeholder="Nhập mã SKU" value="{{ $product->sku ?? '' }}">

                                        </td>
                                        <td>
                                            <input type="tel" readonly class="form-controller-custompo quantity-input"
                                                placeholder="Nhập số lượng" value="{{ $product->quantity }}">
                                        </td>
                                        <td>
                                            <input type="text" readonly class="form-controller-custompo price-input"
                                                placeholder="Nhập đơn giá"
                                                value="{{ number_format($product->unit_price ?? '') }}">
                                        </td>

                                        <td>
                                            <input readonly type="text" class="form-controller-custompo total-input"
                                                placeholder="Thành tiền"
                                                value="{{ number_format($product->subtotal ?? '') }}">
                                        </td>


                                        <td>
                                            {{ $product->expected_date ?? '' }}

                                        </td>
                                        <td>
                                            {{ $product->date_sale ?? '' }}

                                        </td>

                                    </tr>
                                @endforeach

                                <tr>
                                    <td colspan="3" style="text-align: center;">
                                        <strong style="color:rgb(168, 26, 26)"> Tổng SL: {{ $total_qty }}</strong>
                                    </td>

                                    <td colspan="9" style="text-align: center; "> <strong
                                            style="color:rgb(168, 26, 26)"> Tổng Tiền:
                                            {{ number_format($total) }}</strong> </td>
                                </tr>
                        </table>
                    </div>
                </div>
                {{-- Xử lý hàng về  --}}
                <div >
                    <h3 class="mt-3 title__check">KIỂM TRA HÀNG VỀ</h3>
                    <div class="table-section">
                        <table class="table-responsive" id="table1">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Sản Phẩm</th>
                                    <th class="text-center">Mã SKU</th>
                                    <th class="text-center">SL Đặt Đơn</th>
                                    <th class="text-center">Số Lượng Dự Kiến</th>
                                    <th class="text-center">Số Lượng Thực Tế</th>
                                    <th class="text-center">Ngày Về Dự Kiến</th>
                                    <th class="text-center">Ngày Về Sale</th>
                                    <th class="text-center">Trạng Thái</th>
                                    <th class="text-center">Kho</th>
                                </tr>
                            </thead>
                            <tbody id="sku_results">

                                @php
                                    $temp = 0;
                                @endphp

                                @foreach ($purchaseOrder->items as $product)
                                    @php
                                        $temp++;
                                    @endphp
                                    <tr>
                                        <td>{{ $temp }}</td>
                                        <td>
                                            <input type="hidden" name="product_id" id="product_id" readonly
                                                class=" sku-input form-controller-custompo" placeholder=""
                                                value="{{ $product->product->name ?? '' }}">
                                            <span>{{ $product->product->name ?? '' }}</span>
                                        </td>
                                        <td class="text-center">
                                            <input type="hidden" name="sku" id="sku" readonly
                                                class=" sku-input form-controller-custompo" placeholder=""
                                                value="{{ $product->sku ?? '' }}">
                                            <span>{{ $product->sku ?? '' }}</span>
                                        </td>
                                        <td class="text-center">
                                            <input type="hidden" name="quantity" id="quantity" readonly
                                                class="form-controller-custompo quantity-input" placeholder=""
                                                value="{{ $product->quantity }}">

                                            <span>{{ $product->quantity ?? '' }}</span>
                                        </td>

                                        <td class="text-center">
                                            <input type="hidden" name="qty_forecasting" id="qty_forecasting" readonly
                                                class="form-controller-custompo quantity-input" placeholder=""
                                                value="{{ $product->qty_forecasting }}">
                                            @if ($product->qty_forecasting != 0)
                                                <span style="color: #111; ">{{ $product->qty_forecasting ?? '' }}</span>
                                            @else
                                                <span style="color: #111; ">{{ $product->qty_forecasting ?? '' }}</span>
                                            @endif

                                        </td>
                                        <td class="text-center">
                                            <input type="hidden" name="qty_reality" id="qty_reality" readonly
                                                class="form-controller-custompo quantity-input" placeholder=""
                                                value="{{ $product->qty_reality }}">
                                            @if ($product->qty_reality == $product->quantity)
                                                <span
                                                    style="color: #0caf60; font-weight: 700 ">{{ $product->qty_reality ?? '' }}</span>
                                            @else
                                                <span>{{ $product->qty_reality ?? '' }}</span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            <input type="hidden" readonly id="expected_date"
                                                class="form-controller-custompo quantity-input" placeholder=""
                                                value="{{ $product->expected_date ?? '' }}">
                                            <span>{{ date('d-m-Y', strtotime($product->expected_date ?? '')) }}</span>
                                        </td>
                                        <td class="text-center">
                                            <input type="hidden" readonly id="date_sale"
                                                class="form-controller-custompo quantity-input" placeholder=""
                                                value="{{ $product->date_sale ?? '' }}">

                                            <span>{{ date('d-m-Y', strtotime($product->date_sale ?? '')) }}</span>
                                        </td>
                                        <td class="text-center">
                                            @if ($product->status == 'Đã hoàn thành')
                                                <span
                                                    style=" background-color: #0CAF60;font-size: 13px;padding: 5px 7px;border-radius: 6px;font-weight: 400; color: #fff;">
                                                    {{ $product->status ?? '' }}
                                                </span>
                                            @else
                                                <span class="production__order"
                                                    style="    background-color: #ff1905;font-size: 13px;padding: 5px 7px;border-radius: 6px;font-weight: 400; color: #fff;">
                                                    {{ $product->status ?? '' }}
                                                </span>
                                            @endif

                                        </td>
                                        <td class="text-center">
                                            <input readonly type="hidden" id="ware_housing" name="ware_housing"
                                                class="form-controller-custompo total-input" placeholder=""
                                                value="{{ $product->ware_housing ?? '' }}">
                                            <span>{{ $product->ware_housing ?? '' }}</span>
                                        </td>
                                    </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
                <button type="submit" class="add__poNew mt-3 mb-3 ml-3"> Cập Nhật <i
                        class="far fa-save ml-1"></i></button>
            </form>
            <!-- Hidden form for printing -->
            <div id="printSection" style="display:none;">
                <h4>Thông Tin Đơn Hàng</h4>
                <p>Nhà cung cấp: <span id="print_supplier_name"></span></p>
                <table class="table mt-3">
                    <thead>
                        <tr>
                            <th>Mã SKU</th>
                            <th>Số Lượng</th>
                            <th>Giá Thành</th>
                            <th>Thuế</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody id="print_sku_results">
                        <!-- Results will be appended here -->
                    </tbody>
                </table>
                <div class="total" style="color: #064b8f">
                    <div class="mt-3">Tổng Tiền: <span id="print_total">0 ₫</span></div>
                </div>
            </div>


        </div>



    </div>
@endsection


@section('js')
    <script>
        $(document).ready(function() {
            $('#addRow').click(function() {
                var newRow = `<tr>
                <td>
                    <input type="text" class="form-control sku-input" placeholder="Nhập mã SKU">
                    <div class="sku-suggestions"></div>
                </td>
                <td>
                    <input type="tel" class="form-control quantity-input" placeholder="Nhập số lượng">
                </td>
                <td>
                    <input type="text" class="form-control price-input" placeholder="Nhập đơn giá">
                </td>
                <td>
                    <input type="text" class="form-control tax-input" placeholder="Thuế">
                </td>
                <td>
                    <input type="text" class="form-control total-input" placeholder="Thành tiền">
                </td>
                <td>
                    <button type="button" class="btn btn-danger remove-row">Xóa</button>
                </td>
            </tr>`;
                $('#productTable tbody').append(newRow);
            });

            $(document).on('click', '.remove-row', function() {
                $(this).closest('tr').remove();
            });

            $(document).on('input', '.sku-input', function() {
                var input = $(this);
                var query = input.val();
                if (query.length > 2) {
                    $.ajax({
                        url: '{{ route('list_products') }}',
                        data: {
                            sku: query
                        },
                        success: function(data) {
                            var suggestions = input.siblings('.sku-suggestions');
                            suggestions.empty();
                            data.forEach(function(product) {
                                suggestions.append(
                                    '<div class="suggestion-item" data-sku="' +
                                    product.sku + '" data-price="' + product.price +
                                    '">' + product.name + ' (' + product.sku +
                                    ')</div>');
                            });
                        }
                    });
                }
            });

            $(document).on('click', '.suggestion-item', function() {
                var item = $(this);
                var sku = item.data('sku');
                var price = item.data('price');
                var input = item.closest('td').find('.sku-input');
                input.val(sku);
                input.closest('tr').find('.price-input').val(price);
                item.closest('.sku-suggestions').empty();
                calculateTotal(input.closest('tr'));
            });

            $(document).on('input', '.quantity-input, .price-input, .tax-input', function() {
                calculateRowTotal($(this).closest('tr'));
                calculateTotal();
            });

            function calculateRowTotal(row) {
                var quantity = parseFloat(row.find('.quantity-input').val()) || 0;
                var price = parseFloat(row.find('.price-input').val()) || 0;
                var tax = parseFloat(row.find('.tax-input').val()) || 0;
                var total = quantity * price;
                if (tax > 0) {
                    total += total * (tax / 100);
                }
                row.find('.total-input').val(total.toFixed(2));
            }

            function calculateTotal() {
                var total = 0;
                $('#productTable tbody tr').each(function() {
                    var rowTotal = parseFloat($(this).find('.total-input').val()) || 0;
                    total += rowTotal;
                });
                $('#total').text(formatCurrency(total) + ' ₫');
                $('#total_amount').val(total);
            }



        });


        function formatCurrency(number) {
            return number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,').split('.')[0];
        }



        /* Danh sách nhà cung cấp */

        $(document).ready(function() {
            $('#supplier_search').on('input', function() {
                var query = $(this).val();
                if (query.length > 2) {
                    $.ajax({
                        url: '{{ route('suppliers.search') }}',
                        type: 'GET',
                        data: {
                            query: query
                        },
                        success: function(data) {
                            $('#supplier_list').empty();
                            if (data.length > 0) {
                                data.forEach(function(supplier) {
                                    $('#supplier_list').append(
                                        '<a href="#" class="list-group-item list-group-item-action" data-id="' +
                                        supplier.id + '">' + supplier.username +
                                        ' (' +
                                        supplier.sp_code + ')</a>');
                                });
                            } else {
                                $('#supplier_list').append(
                                    '<div class="list-group-item">Không tìm thấy nhà cung cấp</div>'
                                );
                            }
                        }
                    });
                } else {
                    $('#supplier_list').empty();
                }
            });

            $(document).on('click', '.list-group-item', function(e) {

                console.log($(this).data('sp_code'));
                e.preventDefault();
                var supplierId = $(this).data('id');
                var supplierSpCode = $(this).data('sp_code');
                var supplierName = $(this).text();
                $('#supplier_id').val(supplierId);
                $('#supplier_search').val(supplierName);
                $('#supplier_list').empty();
            });

            /* Multiple SKUS */

            $('.check__skus').click(function() {

                if ($('#skus').val() == "" || $('#quantities').val() == "") {
                    alertNotify('Vui lòng nhập mã SKU và số lượng tương ứng.');

                }
                var skus = $('#skus').val().split('\n');
                var quantities = $('#quantities').val().split('\n');

                if (skus.length !== quantities.length) {
                    alertNotify('Số lượng SKU và số lượng tương ứng không khớp.')
                }

                $.ajax({
                    url: '{{ route('purchase-orders.check-skus') }}',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        skus: skus,
                        quantities: quantities
                    },
                    success: function(data) {
                        $('#sku_results').empty();
                        var totalAmount = 0;
                        data.forEach(function(item, index) {
                            var tax = 0; // Assuming 10% tax
                            var total = (item.price * item.quantity);
                            totalAmount += parseFloat(total);
                            $('#sku_results').append('<tr><td>' + item.sku +
                                '</td><td>' + item.quantity + '</td><td>' + item
                                .price + '</td><td>' + tax + '</td><td>' +
                                formatCurrency(total) +
                                '</td></tr>');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][sku]" value="' + item.sku + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][quantity]" value="' + item.quantity + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][price]" value="' + item.price + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][id]" value="' + item.id + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][tax]" value="' + tax + '">');
                            $('#sku_results').append(
                                '<input type="hidden" name="products[' + index +
                                '][total]" value="' + total + '">');
                        });
                        $('#total').text(formatCurrency(totalAmount));
                        $('#total_amount').val(totalAmount);
                    }
                });
            });

            function alertNotify(message) {
                Swal.fire({
                    title: 'Thông báo',
                    position: "top-end",
                    text: message,
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 3000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
                return false;
            }

            /* Ẩn hiện danh sách đặt hàng */

            $(document).ready(function() {
                $('.btn__show-list-po').click(function() {
                    $('.table-section__po').toggle();
                });
            });


        });


        function printPurchaseOrder() {
            var supplierName = $('#supplier_search').val();
            var supplierSpCode = $('#supplier_sp_code').val();
            var total = $('#total').text();

            $('#print_supplier_name').text(supplierName);
            $('#print_supplier_sp_code').text(supplierSpCode);
            $('#print_total').text(total);

            $('#print_sku_results').html($('#sku_results').html());

            var printContents = document.getElementById('printSection').innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
@endsection
