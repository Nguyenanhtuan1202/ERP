@extends('layouts.enic')
@section('content')
    <div style="padding: 10px 30px; margin-top: 60px;" class="listPurchaseOrder">
        <div class="row">
            <div class="row align-items-center justify-content-between mt-5" style="width: 100%;">
                <div class="col-auto">

                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">
                            Purchase
                        </li>

                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a style="background-color: #ffc107; display: inline-block; padding: 5px 15px; margin-right: 10px;border-radius: 20px;    font-weight: 600;"
                            href="{{ route('purchaseorder.allitems') }}">Tất cả đơn hàng</a>
                        <a class="addNew" href="{{ route('purchaseorder.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Làm Mới Trang <i
                                class="fas fa-sync-alt"></i></a>

                    </div>
                </div>
            </div>

            {{-- Phân tích dữ liệu --}}

            <div class="row">


                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header pb-0" style="background: none; border:none">

                            <div class="row align-items-center justify-content-start mb-3 mt-1" style="width: 100%;">

                                <div class="col-auto">
                                    <div class="d-flex">
                                        <a class="allPo" > <i
                                                class="fas fa-tasks"></i>
                                            Tổng Số Đơn Đặt Hàng {{ $purchaseOrders->count() }} </a>
                                    </div>
                                </div>
                            </div>


                            @if (session('success'))
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        Swal.fire({
                                            title: 'Thông báo',
                                            text: '{{ session('success') }}',
                                            icon: 'success',
                                            confirmButtonText: 'OK',
                                            confirmButtonColor: '#3085d6',
                                            background: '#fff',
                                            timer: 5000, // Tự động đóng sau 5 giây
                                            timerProgressBar: true,
                                        });
                                    });
                                </script>
                            @endif
                        </div>

                        <div class="card-body px-0 pt-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0 table__customs table-responsive" id="table5">
                                    <thead class="thead__custom">
                                        <tr>
                                            <th  style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                STT</th>

                                            <th  style="font-size: 14px"
                                                class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                MÃ ĐƠN HÀNG</th>
                                            <th  style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                NHÀ CUNG CẤP</th>
                                            <th style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                SỐ LƯỢNG</th>
                                            <th style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                                NGÀY ĐẶT HÀNG</th>
                                            <th style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                                NGÀY DỰ KIẾN VỀ</th>
                                            <th style="font-size: 14px"
                                                class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                                NGÀY DỰ KIẾN VỀ CHO SALE</th>

                                            <th style="font-size: 14px"
                                                class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                TỔNG ĐƠN</th>
                                            <th style="font-size: 14px"
                                                class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                TRẠNG THÁI</th>
                                            <th style="font-size: 14px"
                                                class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                XOÁ ĐƠN</th>
                                        </tr>
                                    </thead>
                                    <tbody class="tbodyPo">

                                        @foreach ($purchaseOrders as $key => $purchaseOrder)
                                            <tr>
                                                <td >{{ $key + 1 }}</td>
                                                <td  class="text-center"> <a class="purchase-order"
                                                        href="{{ route('purchaseorder.edit', [$purchaseOrder->id]) }}">
                                                        {{ $purchaseOrder->po_id ?? '' }}</a> </td>
                                                <td > <a
                                                        href="{{ route('supplier.edit', [$purchaseOrder->supplier->id ?? '']) }}">{{ $purchaseOrder->supplier->username ?? '' }}</a>
                                                </td>
                                                <td class="align-middle text-center">

                                                    @if ($purchaseOrder->getTotalQtyProduction() == $purchaseOrder->total_quantity)
                                                        <span
                                                            style="    background-color: #28a745; color: #fff;padding: 5px 15px; border-radius: 4px"
                                                            class="total__quantity">{{ $purchaseOrder->getTotalQtyProduction() }}
                                                            /
                                                            {{ $purchaseOrder->total_quantity ?? '' }}</span>
                                                    @else
                                                        <span
                                                            class="total__quantity">{{ $purchaseOrder->getTotalQtyProduction() }}
                                                            /
                                                            {{ $purchaseOrder->total_quantity ?? '' }}</span>
                                                    @endif

                                                </td>
                                                <td>{{ date('d-m-Y', strtotime($purchaseOrder->order_date ?? '')) }}</td>

                                                <td
                                                    class="date-cell {{ strtotime($purchaseOrder->expected_date ?? '') <= strtotime(date('Y-m-d')) ? 'text-danger' : 'text-success' }}">
                                                    {{ date('d-m-Y', strtotime($purchaseOrder->expected_date ?? '')) }}
                                                </td>
                                                <td
                                                    class="date-cell {{ strtotime($purchaseOrder->date_sale ?? '') <= strtotime(date('Y-m-d')) ? 'text-danger' : 'text-success' }}">
                                                    {{ date('d-m-Y', strtotime($purchaseOrder->date_sale ?? '')) }}
                                                </td>

                                                <td class="text-center">
                                                    {{ number_format($purchaseOrder->total_amount ?? '') }}
                                                </td>
                                                <td class="text-center">
                                                    @if ($purchaseOrder->status == 0)
                                                        <span class="badge badge-pill badge-primary"
                                                            style="font-size: 13px; padding: 5px 10px">Chờ xác nhận</span>
                                                    @elseif ($purchaseOrder->getTotalQtyProduction() < $purchaseOrder->total_quantity)
                                                        <span class="badge badge-pill badge-warning"
                                                            style="font-size: 13px; padding: 5px 10px">Đang sản xuất</span>
                                                    @elseif ($purchaseOrder->getTotalQtyProduction() == $purchaseOrder->total_quantity)
                                                        <span class="badge badge-pill badge-success"
                                                            style="font-size: 13px; padding: 5px 10px">Đã hoàn thành</span>
                                                    @endif
                                                </td>

                                                <td class="text-center">
                                                    <a onclick="return confirm('Bạn có muốn xóa đơn hàng này không ?')"
                                                        href="{{ route('purchaseorder.delete', ['id' => $purchaseOrder->id]) }}"
                                                        style="color:#ea233a; font-size: 20px;">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>

                                            </tr>
                                        @endforeach



                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-md-4">
                    <h2>Thống kê Đơn hàng theo Tuần & Tháng</h2>

                    <!-- Bộ lọc thời gian -->
                    <div>

                        <label for="start_date">Từ ngày:</label>
                        <input class="form-control" type="date" id="start_date">
                    </div>

                    <div>
                        <label for="end_date">Đến ngày:</label>
                        <input class="form-control" type="date" id="end_date">
                        <button class="btn btn-primary mt-3" onclick="filterData()">Lọc</button>
                    </div>


                    <!-- Biểu đồ -->
                    <canvas id="weeklyChart"></canvas>
                    <canvas id="monthlyChart"></canvas>
                </div>


                <div class="col-md-4">


                    <h2>Sản phẩm đặt nhiều nhất</h2>

                    <!-- Bộ lọc: chọn năm và tháng -->
                    <div style="margin-bottom: 20px;">
                        <label for="yearFilter">Năm:</label>
                        <select class="form-control" id="yearFilter"></select>

                        <label for="monthFilterNew">Tháng:</label>
                        <select class="form-control" id="monthFilterNew"></select>

                        <button class="btn btn-primary my-2" id="filterBtn">Lọc</button>
                    </div>

                    <!-- Canvas hiển thị biểu đồ -->
                    <canvas id="topProductsChart"></canvas>




                </div>


                <div class="col-md-4">


                    <!-- Mức độ phân tán đơn hàng -->
                    <h2>Mức độ phân tán đơn hàng</h2>
                    <canvas id="supplierOrderDistributionChart"></canvas>
                </div>


                <div class="col-md-6">
                    <!-- Nhà cung cấp có nhiều đơn hàng nhất -->
                    <h2>Nhà cung cấp có nhiều đơn hàng nhất</h2>
                    <canvas id="topSuppliersChart"></canvas>
                </div>

                <div class="col-md-6">
                    <!-- Tổng số lượng sản phẩm theo nhà cung cấp -->
                    <h2>Tổng số lượng sản phẩm theo nhà cung cấp</h2>
                    <canvas id="supplierTotalQuantityChart"></canvas>
                </div>




                <div class="col-md-12">


                    <h2>Thống kê SKU & Tỉ lệ tăng trưởng theo tháng (Năm {{ date('Y') }})</h2>
                    <canvas id="monthlySkuGrowthChart" width="800" height="400"></canvas>

                </div>





            </div>








        </div>
    </div>
@endsection

@section('js')
    <script>
        $('.resetPage').click(function() {
            location.reload();
        });
    </script>

    <script>
        /* Tổng đơn theo tuần tháng */
        // Nhận dữ liệu từ Laravel
        const weeklyOrders = @json($data['weeklyOrders']);
        const monthlyOrders = @json($data['monthlyOrders']);

        let weeklyChart, monthlyChart;

        // Vẽ biểu đồ ban đầu
        function drawCharts(filteredWeeklyOrders = weeklyOrders, filteredMonthlyOrders = monthlyOrders) {
            const weeklyLabels = filteredWeeklyOrders.map(order => "Tuần " + order.week);
            const weeklyData = filteredWeeklyOrders.map(order => order.total_orders);

            const monthlyLabels = filteredMonthlyOrders.map(order => `${order.month}/${order.year}`);
            const monthlyData = filteredMonthlyOrders.map(order => order.total_orders);

            if (weeklyChart) weeklyChart.destroy();
            if (monthlyChart) monthlyChart.destroy();

            weeklyChart = new Chart(document.getElementById('weeklyChart').getContext('2d'), {
                type: 'bar',
                data: {
                    labels: weeklyLabels,
                    datasets: [{
                        label: 'Số đơn hàng theo tuần',
                        data: weeklyData,
                        backgroundColor: 'blue'
                    }]
                }
            });

            monthlyChart = new Chart(document.getElementById('monthlyChart').getContext('2d'), {
                type: 'bar',
                data: {
                    labels: monthlyLabels,
                    datasets: [{
                        label: 'Số đơn hàng theo tháng',
                        data: monthlyData,
                        backgroundColor: 'red',
                        fill: false
                    }]
                }
            });
        }

        drawCharts(); // Vẽ biểu đồ lần đầu

        // Lọc dữ liệu theo ngày
        function filterData() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;

            if (!startDate || !endDate) {
                alert("Vui lòng chọn khoảng thời gian!");
                return;
            }

            const start = new Date(startDate);
            const end = new Date(endDate);

            const filteredWeeklyOrders = weeklyOrders.filter(order => {
                const orderDate = parseWeekToDate(order.week);
                return orderDate >= start && orderDate <= end;
            });

            const filteredMonthlyOrders = monthlyOrders.filter(order => {
                const orderDate = new Date(order.year, order.month - 1); // Month starts from 0
                return orderDate >= start && orderDate <= end;
            });

            drawCharts(filteredWeeklyOrders, filteredMonthlyOrders);
        }

        // Chuyển đổi WEEK (YYYYWW) về ngày đầu tuần
        function parseWeekToDate(weekString) {
            // Đảm bảo weekString là chuỗi
            const weekStr = String(weekString);

            if (weekStr.length < 6) {
                console.error("Dữ liệu tuần không hợp lệ:", weekString);
                return new Date(); // Trả về ngày hiện tại nếu dữ liệu lỗi
            }

            const year = parseInt(weekStr.substring(0, 4), 10);
            const week = parseInt(weekStr.substring(4, 6), 10);

            // Ngày 1 tháng 1 của năm
            const firstDayOfYear = new Date(year, 0, 1);
            const daysToAdd = (week - 1) * 7;

            return new Date(firstDayOfYear.setDate(firstDayOfYear.getDate() + daysToAdd));
        }

        function renderChart(id, type, labels, data, labelName, backgroundColor, borderColor) {
            new Chart(document.getElementById(id), {
                type: type,
                data: {
                    labels: labels,
                    datasets: [{
                        label: labelName,
                        data: data,
                        backgroundColor: backgroundColor,
                        borderColor: borderColor,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true
                }
            });
        }


        renderChart(
            "supplierTotalQuantityChart",
            "bar",
            {!! json_encode($data['supplierTotalQuantity']->pluck('supplier_name')) !!}, // Hiển thị tên nhà cung cấp
            {!! json_encode($data['supplierTotalQuantity']->pluck('total_quantity')) !!},
            "Tổng số lượng sản phẩm",
            'rgba(54, 162, 235, 0.5)',
            'rgba(54, 162, 235, 1)'
        );


        renderChart(
            "topSuppliersChart",
            "bar",
            {!! json_encode($data['topSuppliersByOrders']->pluck('supplier_name')) !!}, // Lấy tên nhà cung cấp
            {!! json_encode($data['topSuppliersByOrders']->pluck('total_orders')) !!},
            "Số đơn hàng",
            'rgba(255, 206, 86, 0.5)',
            'rgba(255, 206, 86, 1)'
        );

        renderChart(
            "supplierOrderDistributionChart",
            "pie",
            {!! json_encode($data['supplierOrderDistribution']->pluck('supplier_name')) !!}, // Hiển thị tên nhà cung cấp
            {!! json_encode($data['supplierOrderDistribution']->pluck('order_percentage')) !!},
            "Tỷ lệ đơn hàng giữa các nhà cung cấp"
        );
    </script>


    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const pivotData = {!! json_encode($data['monthlySkuGrowth']) !!};

            const ctx = document.getElementById("monthlySkuGrowthChart").getContext("2d");
            new Chart(ctx, {
                data: pivotData,
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: "Tổng SKU & Tỉ lệ tăng trưởng theo tháng"
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: "Tháng"
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: "Tổng SKU"
                            }
                        },
                        growthRate: {
                            position: "right",
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: "Tỉ lệ tăng trưởng (%)"
                            },
                            grid: {
                                drawOnChartArea: false
                            },
                            ticks: {
                                callback: function(value) {
                                    return value !== null ? value + "%" : "";
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>




    <script>
        // Dữ liệu từ backend (đã được xử lý trong action)
        const topProductsData = {!! json_encode($data['topProducts']) !!};

        // Hàm khởi tạo dropdown lọc năm, tháng dựa trên dữ liệu
        function initFilters() {
            const yearFilter = document.getElementById('yearFilter');
            const monthFilterNew = document.getElementById('monthFilterNew');

            // Lấy các năm duy nhất từ dữ liệu
            const years = [...new Set(topProductsData.map(item => item.year))].sort();
            years.forEach(year => {
                const opt = document.createElement('option');
                opt.value = year;
                opt.textContent = year;
                yearFilter.appendChild(opt);
            });

            // Tạo dropdown cho tháng từ 1 đến 12
            for (let m = 1; m <= 12; m++) {
                const opt = document.createElement('option');
                opt.value = m;
                opt.textContent = m;
                monthFilterNew.appendChild(opt);
            }

            // Đặt giá trị mặc định: năm mới nhất và tháng hiện tại
            if (years.length > 0) {
                yearFilter.value = years[years.length - 1];
            }
            const currentMonth = new Date().getMonth() + 1;
            monthFilterNew.value = currentMonth;
        }

        // Hàm lọc dữ liệu dựa trên năm, tháng được chọn
        function filterTopProducts() {
            const selectedYear = document.getElementById('yearFilter').value;
            const selectedMonth = document.getElementById('monthFilterNew').value;

            // Lọc dữ liệu: chỉ giữ các dòng có year và month khớp
            const filtered = topProductsData.filter(item => {
                return item.year == selectedYear && item.month == selectedMonth;
            });

            renderChart(filtered);
        }

        // Hàm vẽ biểu đồ với dữ liệu đã lọc
        function renderChart(filteredData) {
            // Tạo mảng labels (SKU) và dữ liệu (total_quantity)
            const labels = filteredData.map(item => item.sku);
            const quantities = filteredData.map(item => item.total_quantity);

            // Nếu đã có biểu đồ, huỷ biểu đồ cũ
            if (window.topProductsChart && typeof window.topProductsChart.destroy === 'function') {
                window.topProductsChart.destroy();
            }

            const ctx = document.getElementById('topProductsChart').getContext('2d');
            window.topProductsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Tổng số lượng SKU',
                        data: quantities,
                        backgroundColor: 'rgba(255, 159, 64, 0.5)',
                        borderColor: 'rgba(255, 159, 64, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: `Sản phẩm đặt nhiều nhất năm ${document.getElementById('yearFilter').value}, tháng ${document.getElementById('monthFilterNew').value}`
                        }
                    }
                }
            });
        }

        // Gán sự kiện cho nút lọc
        document.getElementById('filterBtn').addEventListener('click', filterTopProducts);

        // Khởi tạo dropdown và vẽ biểu đồ ban đầu
        initFilters();
        filterTopProducts();
    </script>
@endsection
