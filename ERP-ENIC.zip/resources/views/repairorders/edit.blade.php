@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/repairorders.css') }}">
@endsection
@section('content')

    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000,
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000,
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="container" style="margin-top: 100px">



        <div class="row align-items-center justify-content-between listPurchaseOrder"
            style="width: 100%; margin-bottom: 40px;">
            <div class="col-auto">
                <div class="page-header-title">

                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('repairorders.index') }}">Danh Sách</a></li>
                    <li class="breadcrumb-item active">
                        Cập Nhật
                    </li>
                </ul>
            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ route('repairorders.create') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                    <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang <i
                            class="fas fa-sync-alt"></i></a>
                    <a style="background: #199fb7; box-shadow: none" class="addNew"
                        href="{{ route('repairorders.index') }}">Danh
                        Sách <i class="fas fa-list"></i></a>
                </div>
            </div>
        </div>


        <h1 class="mb-4">Chỉnh Sửa Phiếu Sửa Chữa / Bảo Hành</h1>
        <form action="{{ route('repairorders.update', $order->id) }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}

            <div class="accordion" id="repairOrderAccordion">
                <!-- Thông tin đơn hàng cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button style="color: #fff; font-weight: 700;"  class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic"
                                aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin đơn hàng cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                        data-parent="#repairOrderAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Mã đơn (nếu có)</label>
                                <input type="text" name="order_code" value="{{ old('order_code', $order->order_code) }}"
                                    class="form-control" placeholder="Nhập mã đơn hoặc để trống cho bảo hành">
                            </div>
                            <div class="form-group">
                                <label>Tên khách hàng (nếu có)</label>
                                <input type="text" name="customer_name"
                                    value="{{ old('customer_name', $order->customer_name) }}" class="form-control"
                                    placeholder="Nhập tên khách hàng">
                            </div>
                            <div class="form-group">
                                <label>Số điện thoại khách (nếu có)</label>
                                <input type="text" name="customer_phone"
                                    value="{{ old('customer_phone', $order->customer_phone) }}" class="form-control"
                                    placeholder="Nhập số điện thoại">
                            </div>
                            <div class="form-group">
                                <label>Địa Chỉ (nếu có)</label>
                                <input type="text" name="address" value="{{ old('address', $order->address) }}"
                                    class="form-control" placeholder="Nhập địa chỉ">
                            </div>
                            <div class="form-group">
                                <label>Ghi Chú (nếu có)</label>
                                <textarea name="note" id="note" class="form-control" rows="3">{{ old('note', $order->note) }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Thông tin sản phẩm -->
                <div class="card">
                    <div class="card-header" id="headingProduct">
                        <h2 class="mb-0">
                            <button style="color: #fff; font-weight: 700;" class="btn btn-link collapsed" type="button" data-toggle="collapse" 
                                data-target="#collapseProduct" aria-expanded="false" aria-controls="collapseProduct">
                                Thông tin sản phẩm
                            </button>
                        </h2>
                    </div>
                    <div id="collapseProduct" class="collapse" aria-labelledby="headingProduct"
                        data-parent="#repairOrderAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Loại sản phẩm</label>
                                <select name="product_category" id="product_category" class="form-control">
                                    <option value="sản phẩm"
                                        {{ old('product_category', $order->product_category) == 'sản phẩm' ? 'selected' : '' }}>
                                        Sản phẩm</option>
                                    <option value="linh kiện"
                                        {{ old('product_category', $order->product_category) == 'linh kiện' ? 'selected' : '' }}>
                                        Linh kiện (kính, gương...)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Mã SKU</label>
                                <input type="text" name="sku" id="sku" value="{{ old('sku', $order->sku) }}"
                                    class="form-control" placeholder="Nhập mã SKU (bỏ trống nếu là linh kiện)">
                            </div>
                            <div class="form-group">
                                <label>Tên sản phẩm</label>
                                <input type="text" name="product_name" id="product_name" required
                                    value="{{ old('product_name', $order->product_name) }}" class="form-control"
                                    placeholder="Nhập tên sản phẩm hoặc tên linh kiện">
                            </div>
                            <div class="form-group">
                                <label>Số lượng</label>
                                <input required type="number" name="quantity"
                                    value="{{ old('quantity', $order->quantity) }}" class="form-control" min="1">
                            </div>
                            <div class="form-group">
                                <label>Loại vật liệu</label>
                                <select name="product_type" class="form-control">
                                    <option value="inox"
                                        {{ old('product_type', $order->product_type) == 'inox' ? 'selected' : '' }}>Inox
                                    </option>
                                    <option value="nhôm"
                                        {{ old('product_type', $order->product_type) == 'nhôm' ? 'selected' : '' }}>Nhôm
                                    </option>
                                    <option value="khác"
                                        {{ old('product_type', $order->product_type) == 'khác' ? 'selected' : '' }}>Khác
                                    </option>
                                </select>
                            </div>
                            <div class="form-group block__image">
                                <label for="files_image">Thư Viện Ảnh</label> <br>
                                @if ($order->arr_picture)
                                    @php
                                        $images = unserialize($order->arr_picture);
                                    @endphp
                                    <div class="mb-3">
                                        @foreach ($images as $image)
                                            <img src="{{ asset('uploads/RepairOrder/' . $image) }}"
                                                class="thumbnail__image" alt="Image">
                                        @endforeach
                                    </div>
                                @endif
                                <svg style="fill: #d3dbe2; width:120px" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 80 80">
                                    <path
                                        d="M80 57.6l-4-18.7v-23.9c0-1.1-.9-2-2-2h-3.5l-1.1-5.4c-.3-1.1-1.4-1.8-2.4-1.6l-32.6 7h-27.4c-1.1 0-2 .9-2 2v4.3l-3.4.7c-1.1.2-1.8 1.3-1.5 2.4l5 23.4v20.2c0 1.1.9 2 2 2h2.7l.9 4.4c.2.9 1 1.6 2 1.6h.4l27.9-6h33c1.1 0 2-.9 2-2v-5.5l2.4-.5c1.1-.2 1.8-1.3 1.6-2.4zm-75-21.5l-3-14.1 3-.6v14.7zm62.4-28.1l1.1 5h-24.5l23.4-5zm-54.8 64l-.8-4h19.6l-18.8 4zm37.7-6h-43.3v-51h67v51h-23.7zm25.7-7.5v-9.9l2 9.4-2 .5zm-52-21.5c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5zm0-8c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3zm-13-10v43h59v-43h-59zm57 2v24.1l-12.8-12.8c-3-3-7.9-3-11 0l-13.3 13.2-.1-.1c-1.1-1.1-2.5-1.7-4.1-1.7-1.5 0-3 .6-4.1 1.7l-9.6 9.8v-34.2h55zm-55 39v-2l11.1-11.2c1.4-1.4 3.9-1.4 5.3 0l9.7 9.7c-5.2 1.3-9 2.4-9.4 2.5l-3.7 1h-13zm55 0h-34.2c7.1-2 23.2-5.9 33-5.9l1.2-.1v6zm-1.3-7.9c-7.2 0-17.4 2-25.3 3.9l-9.1-9.1 13.3-13.3c2.2-2.2 5.9-2.2 8.1 0l14.3 14.3v4.1l-1.3.1z">
                                    </path>
                                </svg>
                                <input name="arr_picture[]" class="gallery" accept="image/*" id="files_image"
                                    type="file" multiple />
                                <output id="result_image"></output>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Thông tin bảo hành/sửa chữa -->
                <div class="card">
                    <div class="card-header" id="headingWarranty">
                        <h2 class="mb-0">
                            <button  style="color: #fff; font-weight: 700;" class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseWarranty" aria-expanded="false" aria-controls="collapseWarranty">
                                Thông tin bảo hành/sửa chữa
                            </button>
                        </h2>
                    </div>
                    <div id="collapseWarranty" class="collapse" aria-labelledby="headingWarranty"
                        data-parent="#repairOrderAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Chọn Xưởng Bảo Hành</label>
                                <select required name="supplier_id" class="form-control">
                                    @foreach ($suppliers as $item)
                                        <option value="{{ $item->id }}"
                                            {{ old('supplier_id', $order->supplier_id) == $item->id ? 'selected' : '' }}>
                                            {{ $item->username }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Loại dịch vụ</label>
                                <select name="repair_type" class="form-control">
                                    <option value="Bảo hành"
                                        {{ old('repair_type', $order->repair_type) == 'Bảo hành' ? 'selected' : '' }}>Bảo
                                        hành</option>
                                    <option value="Sửa chữa"
                                        {{ old('repair_type', $order->repair_type) == 'Sửa chữa' ? 'selected' : '' }}>Sửa
                                        chữa</option>
                                </select>
                                <small class="form-text text-muted">Nếu chọn Inox/Nhôm, hệ thống sẽ tự động gán Sửa
                                    chữa.</small>
                            </div>
                            <div class="form-group">
                                <label>Ngày bảo hành</label>
                                <input required type="date" name="warranty_date"
                                    value="{{ old('warranty_date', $order->warranty_date) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Ngày hoàn thành</label>
                                <input type="date" name="completion_date"
                                    value="{{ old('completion_date', $order->completion_date) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Trạng thái thanh toán</label>
                                <select required name="is_paid" class="form-control">
                                    <option value="1" {{ old('is_paid', $order->is_paid) ? 'selected' : '' }}>Có tính
                                        phí</option>
                                    <option value="0" {{ !old('is_paid', $order->is_paid) ? 'selected' : '' }}>Miễn
                                        phí (Bảo hành)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3">
                <button type="submit" class="btn btn-success">Cập nhật Phiếu</button>
                <a href="{{ route('repairorders.index') }}" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
@endsection

@section('js')
    <script>
        // Hiển thị preview ảnh khi upload file mới
        window.onload = function() {
            if (window.File && window.FileList && window.FileReader) {
                var filesInput = document.getElementById("files_image");
                filesInput.addEventListener("change", function(event) {
                    var files = event.target.files;
                    var output = document.getElementById("result_image");
                    output.innerHTML = "";
                    for (var i = 0; i < files.length; i++) {
                        var file = files[i];
                        if (!file.type.match('image'))
                            continue;
                        var picReader = new FileReader();
                        picReader.addEventListener("load", function(event) {
                            var picFile = event.target;
                            var div = document.createElement("div");
                            div.innerHTML = "<img class='thumbnail__image' src='" + picFile.result +
                                "' title='" + picFile.name + "'/>";
                            output.insertBefore(div, null);
                        });
                        picReader.readAsDataURL(file);
                    }
                });
            } else {
                console.log("Your browser does not support File API");
            }
        }

        // Điều chỉnh trạng thái các trường dựa theo loại sản phẩm
        document.addEventListener("DOMContentLoaded", function() {
            const categorySelect = document.getElementById('product_category');
            const skuInput = document.getElementById('sku');
            const productNameInput = document.getElementById('product_name');

            if (categorySelect && skuInput && productNameInput) {
                categorySelect.addEventListener("change", function() {
                    if (this.value.trim().toLowerCase() === "linh kiện") {
                        skuInput.value = "";
                        skuInput.disabled = true;
                    } else {
                        skuInput.disabled = false;
                    }
                });
            }
        });
    </script>
@endsection
