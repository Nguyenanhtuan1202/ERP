@extends('layouts.enic')
@section('css')
    <link rel="stylesheet" href="{{ asset('css/repairorders.css') }}">
@endsection
@section('content')

    <div class="container-fluid" style="margin-top: 100px">

        <div class="row align-items-center justify-content-between listPurchaseOrder"
            style="width: 100%; margin-bottom: 40px;">
            <div class="col-auto">
                <div class="page-header-title">

                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('repairorders.index') }}">Danh Sách</a></li>
                  
                </ul>
            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ route('repairorders.create') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                    <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang <i
                            class="fas fa-sync-alt"></i></a>
                    <a style="background: #199fb7; box-shadow: none" class="addNew"
                        href="{{ route('repairorders.index') }}">Danh
                        Sách <i class="fas fa-list"></i></a>
                </div>
            </div>
        </div>


        <h1>Danh Sách Phiếu Sửa Chữa / Bảo Hành</h1>
     


        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000,
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000,
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <table class="table table-bordered table-hover" id="table1">
            <thead>
                <tr>
                    <th>ID</th>

                    <th>Khách Hàng</th>
                    <th>SĐT</th>
                    <th>SKU</th>
                    <th>Tên Sản Phẩm</th>
                    <th>Số Lượng</th>

                    <th>Loại Dịch Vụ</th>
                    <th>Ngày Bảo Hành</th>
                    <th>Ngày Hoàn Thành</th>
                    <th>Thanh Toán</th>
                    <th>Hình Ảnh</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $order)
                    <tr>
                        <td>{{ $order->id }}</td>

                        <td>{{ $order->customer_name }}</td>
                        <td>{{ $order->customer_phone }}</td>
                        <td>{{ $order->sku ?? 'Không có SKU' }}</td>
                        <td>
                            @if ($order->product_category === 'phụ kiện')
                                Phụ kiện linh kiện
                            @else
                                {{ $order->product_name }}
                            @endif
                        </td>
                        <td>{{ $order->quantity }}</td>

                        <td>{{ $order->repair_type }}</td>
                        <td>{{ $order->warranty_date }}</td>
                        <td>{{ $order->completion_date ?? 'Chưa hoàn thành' }}</td>
                        <td>
                            @if ($order->is_paid)
                                Có tính phí
                            @else
                                Miễn phí
                            @endif
                        </td>
                        <td>
                            @if ($order->arr_picture)
                                @php
                                    $images = unserialize($order->arr_picture);
                                @endphp
                                @if (is_array($images))
                                    @foreach ($images as $image)
                                        <img src="{{ asset('uploads/RepairOrder/' . $image) }}" alt="Image"
                                            class="thumb-img">
                                    @endforeach
                                @endif
                            @else
                                -
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('repairorders.edit', ['id' => $order->id]) }}"
                                class="btn mb-2 btn-primary btn-sm btn-action btn-custom ">Sửa</a>


                            <a class="btn btn-danger btn-sm btn-action btn-custom"
                                onclick="return confirm('Bạn có chắc chắn xóa?')"
                                href="{{ route('repairorders.delete', ['id' => $order->id]) }}">Xoá</a>


                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
