@extends('layouts.admin')
@section('content')
    <div class="midde_cont">
        <div class="container-fluid">
            <div class="row column_title">


                <div class="col-md-12">

                    <div class="page_title">


                        <nav aria-label="breadcrumb" class="mt-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{ url('/') }}">DashBoard</a></li>
                                <li class="breadcrumb-item"><a href="{{ route('product.list') }}">Danh sách </a></li>
                                <li class="breadcrumb-item active" aria-current="page">Thêm Mới</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- row -->
            <form action="{{ url('furniture/save') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row column1">
                    <div class="col-md-12">
                        <div class="white_shd full margin_bottom_30">
                            <div class="full graph_head">
                                <div class="heading1 margin_0">
                                    <h2>Thêm Mới Sản Phẩm</h2>

                                    @if (session('status'))
                                        <script>
                                            document.addEventListener('DOMContentLoaded', function() {
                                                Swal.fire({
                                                    title: 'Thông báo',
                                                    text: '{{ session('status') }}',
                                                    icon: 'success',
                                                    confirmButtonText: 'OK',
                                                    confirmButtonColor: '#3085d6',
                                                    background: '#fff',
                                                    timer: 5000, // Tự động đóng sau 5 giây
                                                    timerProgressBar: true,
                                                });
                                            });
                                        </script>
                                    @endif

                                </div>
                            </div>
                            <div class="full price_table padding_infor_info">
                                <div class="row">
                                    <div class="col-md-8 sider__bar-left">
                                        <div class="form-group">
                                            @error('title')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="name">Tên Sản Phẩm(*)</label>
                                            <input class="form-control" type="text" name="title" id="name"
                                                placeholder="Nhập vào tên sản phẩm...." value="{{ old('name') }}">
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">

                                                <div class="form-group">
                                                    @error('cat_id')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="cat_id">Chọn Loại Sản Phẩm</label>
                                                    <select name="cat_id" class="form-control select3_init" id="cat_id">

                                                        {!! $htmlOption !!}
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="arr_custom6">Key Chuẩn Sale:</label>
                                                    <input class="form-control" type="text" name="arr_custom6"
                                                        id="arr_custom6" placeholder="Nhập..."
                                                        value="{{ old('arr_custom6') }}">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    @error('brand')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                    <label for="cat_id">Nhãn Hiệu</label>
                                                    <select name="cat_id" class="form-control select3_init" id="cat_id">
                                                        <option value="1">Enic</option>
                                                        <option value="2">Chilux</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="arr_custom5">Giá Bán Lẻ :</label>
                                                    <input class="form-control" type="text" name="arr_custom5"
                                                        id="arr_custom5"placeholder="Nhập giá..."
                                                        value="{{ old('arr_custom5') }}">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="arr_custom5">Giá Bán Buôn:</label>
                                                    <input class="form-control" type="text" name="arr_custom5"
                                                        id="arr_custom5"placeholder="Nhập giá..."
                                                        value="{{ old('arr_custom5') }}">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="arr_custom5">Giá Nhập:</label>
                                                    <input class="form-control" type="text" name="arr_custom5"
                                                        id="arr_custom5"placeholder="Nhập giá..."
                                                        value="{{ old('arr_custom5') }}">
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group" style="display: flex; flex-wrap: wrap; gap: 10px;">
                                                    @foreach ($attributes as $attribute)
                                                        <div class="mb-3" style="width: 300px;">
                                                            <label
                                                                class="form-label">{{ $attribute->description ?? '' }}</label>
                                                            <select style="width: 300px;"
                                                                name="attributes[{{ $attribute->id }}][]"
                                                                class="form-select select3_init" multiple>
                                                                @foreach ($attribute->values as $value)
                                                                    <option value="{{ $value->id }}">
                                                                        {{ $value->value }}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                            <small class="form-text text-muted">Giữ phím Ctrl (hoặc Cmd trên
                                                                Mac) để chọn nhiều giá trị.</small>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>

                                        </div>

                                        <div class="form-group">
                                            @error('status')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="status">Trạng thái hiển thị (*)</label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="status"
                                                    id="exampleRadios1" value="1" checked>
                                                <label class="form-check-label" for="exampleRadios1">
                                                    Hiện
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="status"
                                                    id="exampleRadios2" value="2">
                                                <label class="form-check-label" for="exampleRadios2">
                                                    Ẩn
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            @error('weight')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="weight">Thứ tự ưu tiên(*)</label>
                                            <input class="form-control" type="number" min="0" name="weight"
                                                id="weight" value="{{ old('weight') }}">
                                        </div>
                                    </div>

                                    <div class="col-md-4 sider__bar-right">
                                        <div class="form-group block__image">
                                            @error('image')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="cat_image">Hình Ảnh(*)</label>
                                            <input class="form-control-file" style="width:100%" type="file"
                                                id="cat_image" name="image" accept="image/*"
                                                onchange="loadFile(event)">
                                            <img style="margin-top: 10px; border-radius:10px; max-width:350px"
                                                src="{{ asset('uploads/no-image.jpg') }}" id="output" />
                                            <script>
                                                var loadFile = function(event) {
                                                    var output = document.getElementById('output');
                                                    output.src = URL.createObjectURL(event.target.files[0]);
                                                    output.onload = function() {
                                                        URL.revokeObjectURL(output.src)
                                                    }
                                                };
                                            </script>
                                        </div>

                                        <div class="form-group block__image">
                                            <label for='files'>Thư Viện Ảnh </label> <br>

                                            <svg style="fill: #d3dbe2; width:120px" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 80 80">
                                                <path
                                                    d="M80 57.6l-4-18.7v-23.9c0-1.1-.9-2-2-2h-3.5l-1.1-5.4c-.3-1.1-1.4-1.8-2.4-1.6l-32.6 7h-27.4c-1.1 0-2 .9-2 2v4.3l-3.4.7c-1.1.2-1.8 1.3-1.5 2.4l5 23.4v20.2c0 1.1.9 2 2 2h2.7l.9 4.4c.2.9 1 1.6 2 1.6h.4l27.9-6h33c1.1 0 2-.9 2-2v-5.5l2.4-.5c1.1-.2 1.8-1.3 1.6-2.4zm-75-21.5l-3-14.1 3-.6v14.7zm62.4-28.1l1.1 5h-24.5l23.4-5zm-54.8 64l-.8-4h19.6l-18.8 4zm37.7-6h-43.3v-51h67v51h-23.7zm25.7-7.5v-9.9l2 9.4-2 .5zm-52-21.5c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5zm0-8c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3zm-13-10v43h59v-43h-59zm57 2v24.1l-12.8-12.8c-3-3-7.9-3-11 0l-13.3 13.2-.1-.1c-1.1-1.1-2.5-1.7-4.1-1.7-1.5 0-3 .6-4.1 1.7l-9.6 9.8v-34.2h55zm-55 39v-2l11.1-11.2c1.4-1.4 3.9-1.4 5.3 0l9.7 9.7c-5.2 1.3-9 2.4-9.4 2.5l-3.7 1h-13zm55 0h-34.2c7.1-2 23.2-5.9 33-5.9l1.2-.1v6zm-1.3-7.9c-7.2 0-17.4 2-25.3 3.9l-9.1-9.1 13.3-13.3c2.2-2.2 5.9-2.2 8.1 0l14.3 14.3v4.1l-1.3.1z">
                                                </path>
                                            </svg>
                                            <input name="arr_picture[]" class="gallery" accept="image/*"
                                                id='files_image' type='file' multiple />
                                            <output id='result_image' />

                                        </div>

                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            @error('desc')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <label for="ckeditor1">Mô Tả Ngắn</label>
                                            <textarea name="desc" class="form-control ckeditor" id="ckeditor1" cols="30" rows="3">{!! old('desc') !!}</textarea>
                                        </div>

                                    </div>

                                </div>
                                <button type="submit" class="btn__add">Thêm mới <i class="fas fa-plus"></i></button>
                            </div>

                        </div>

                    </div>
                    <!-- end row -->
                </div>
            </form>
            <!-- footer -->

        </div>
        <!-- end dashboard inner -->
    </div>
@endsection



@section('js')
    <script type="text/javascript">
        window.onload = function() {
            //Check File API support
            if (window.File && window.FileList && window.FileReader) {
                var filesInput = document.getElementById("files_image");
                filesInput.addEventListener("change", function(event) {
                    var files = event.target.files; //FileList object
                    var output = document.getElementById("result_image");
                    for (var i = 0; i < files.length; i++) {
                        var file = files[i];
                        //Only pics
                        if (!file.type.match('image'))
                            continue;
                        var picReader = new FileReader();
                        picReader.addEventListener("load", function(event) {
                            var picFile = event.target;
                            var div = document.createElement("div");
                            div.innerHTML = "<img class='thumbnail__image' src='" + picFile.result +
                                "'" +
                                "title='" + picFile.name + "'/>";
                            output.insertBefore(div, null);
                        });
                        //Read the image
                        picReader.readAsDataURL(file);
                    }
                });
            } else {
                console.log("Your browser does not support File API");
            }
        }
    </script>
@endsection
