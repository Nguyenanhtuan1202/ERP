@extends('layouts.enic')
@section('content')
    <div style="padding: 10px 20px; margin-top: 100px;">


        <div class="row align-items-center justify-content-between listPurchaseOrder mt-3 ml-2" style="width: 100%;">
            <div class="col-auto">
                <div class="page-header-title">

                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('product.list') }}">Danh Sách</a></li>
                </ul>
            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ route('product.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                    <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang
                        <i class="fas fa-sync-alt"></i></a>
                    <a style="background: #199fb7; box-shadow: none" class="addNew" href="{{ route('product.list') }}">Danh
                        Sách <i class="fas fa-list"></i></a>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">

                        <h3 class="title__highlight">
                            <i class="fas fa-desktop"></i> Danh sách sản phẩm
                        </h3>

                        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px">

                            {{-- <a class="add__expert" href="{{ route('product.add') }}">Thêm Mới <i
                                    class="fas fa-user-plus"></i></a> --}}

                            <a href="{{ route('product.import_excel') }}" class="add__expert"
                                style="background-color: #17a2b8">Nhập File Excel <i class="fas fa-file-import"></i></a>

                            <a href="{{ route('product.export.FileExcel') }}" class="add__expert"
                                style="background-color: rgb(18, 161, 75)">Xuất File Excel <i
                                    class="fas fa-file-export"></i></a>
                        </div>

                        @if (session('status'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('status') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>

                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                <thead class="thead__custom">
                                    <tr>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            STT</th>
                                        {{-- <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Hình Ảnh</th> --}}
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Tên Sản Phẩm</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Sku</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Giá Bán</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Model</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Color</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Size</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Type</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                            Type 2</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Quản Lý</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @php
                                        $temp = 0;
                                    @endphp

                                    @foreach ($data as $item)
                                        @php
                                            $temp++;
                                        @endphp
                                        <tr>

                                            <td class="align-middle text-center ">
                                                {{ $temp }}
                                            </td>

                                            {{-- <td class="align-middle text-center ">
                                                <img style="max-width: 100px;"
                                                    src="{{ asset('uploads/product/' . $item->images ?? '') }}"
                                                    alt="{{ $item->name ?? '' }}">
                                            </td> --}}
                                            <td class="align-middle text-center ">
                                                {{ $item->name ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->sku ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ number_format($item->price ?? '') . 'vnđ' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->tier ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->color ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->size ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->type ?? '' }}
                                            </td>


                                            <td class="align-middle text-center ">
                                                {{ $item->type2 ?? '' }}
                                            </td>

                                            <td class="align-middle">
                                                <a href="{{ url('/admin/product/edit/' . $item->id) }}"
                                                    class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="edit agent"
                                                    style="font-size: 12px; font-weight: bold; color: #ffffff; background-color: #35cbdc; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Edit
                                                </a>
                                                <a onclick="return confirm('Bạn có muốn xóa sản phẩm này không ?')"
                                                    href="{{ url('/admin/product/delete/' . $item->id) }}"
                                                    class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="delete agent"
                                                    style="font-size: 12px; display: block; margin-top: 5px; font-weight: bold; color: #ffffff; background-color: #dc3545; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Delete
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
