@extends('layouts.enic')

@section('content')
    <style>
        .box__view-import {
            box-shadow: 0 6px 30px rgba(182, 186, 203, 0.3);
            margin-bottom: 24px;
            transition: box-shadow 0.2s ease-in-out;
            background-color: #fff;
            padding: 10px 20px;
            margin-top: 25px;
            border-radius: 8px;

        }

        .btn__uploads {
            border: none;
            padding: 10px 30px;
            border-radius: 7px;
            background: linear-gradient(141.55deg, #0CAF60 3.46%, #0CAF60 99.86%), #0CAF60;
            color: #fff;
            box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
            font-weight: 600;
        }

        .custom__inputimport {
            border: 1px solid #28a745;
            border-radius: 5px;
            padding: 8px 16px;
            width: 200px;
            margin-right: 8px;
            outline: none;
        }

        .custom__td {
            border: 1px solid #28a745;
            border-radius: 5px;
            padding: 8px 16px;
            margin-right: 8px;
            outline: none;
        }

        .custom__inputimport:hover {
            background-color: #28a745;
            color: #fff;
            transition: all 0.5s cubic-bezier();
            cursor: pointer;
        }

        .tr__custom__inputimport {
            overflow-y: scroll;
        }

        .uploadsData {
            border: none;
            padding: 10px 30px;
            border-radius: 7px;
            background: linear-gradient(141.55deg, #0CAF60 3.46%, #0CAF60 99.86%), #0CAF60;
            color: #fff;
            box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
            font-weight: 600;
        }

        .box__show-recent {
            height: 600px;
            overflow-x: scroll;
        }

        #previewTable {
            height: 600px;
            overflow-x: scroll;
        }


        .guild_uploads {
            background-color: #ffd454;
            padding: 10px 20px;
            border: 2px dashed #111;
            border-radius: 6px;
        }
    </style>
    <div class="container-fluid box__view-import" style="margin-top: 100px">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="col-md-12 guild_uploads">
            <h3>Hướng dẫn upload dữ liệu</h3>

            <a class="downloadFileImport" download href="{{ asset('import/product.xlsx') }}">Tải Xuống
                File Mẫu </a>
        </div>
        <div class="row">
            {{-- <div class="col-md-12">
                <h2>Dữ liệu cập nhật gần đây</h2>

                <div class="box__show-recent">
                    <table class="">
                        <tr>
                            <td class="custom__td">STT</td>
                            <td class="custom__td">Name</td>
                            <td class="custom__td">SKU</td>
                            <td class="custom__td">PRICE</td>
                        </tr>

                        @php
                            $temp = 0;
                        @endphp
                        @foreach ($data as $item)
                            @php
                                $temp++;
                            @endphp

                            <tr>
                                <td class="custom__td">{{ $temp }}</td>
                                <td class="custom__td">{{ $item->name ?? '' }}</td>
                                <td class="custom__td">{{ $item->sku ?? '' }}</td>
                                <td class="custom__td">{{ $item->price ?? '' }}</td>
                            </tr>
                        @endforeach

                    </table>
                </div>




            </div> --}}

            <div class="col-md-6">
                <h2>Import File Excel và Hiển Thị Thông Tin</h2>

                <form id="uploadForm" enctype="multipart/form-data" class="mt-4">
                    @csrf
                    <input type="file" class="file__uploads" name="file" id="file" required>
                    <button type="submit" class="btn__uploads">Upload <i class="fas fa-file-upload"></i></button>
                </form>




                <div id="previewTable" style="margin-top: 20px; display: none;">
                    <h2>Preview Data</h2>
                    <form id="saveForm" action="{{ route('upload.ImportFileExcel') }}" method="POST"
                        enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <table id="dataTable" class="table-responsive" style="height: 500px">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Sku</th>
                                    <th>Price</th>
                                    <th>Color</th>
                                    <th>Size</th>
                                    <th>Type</th>
                                    <th>Type2</th>
                                    <th>Material</th>
                                    <th>Tier</th>
                                    <th>Tier Code</th>
                                    <th>Style</th>
                                    <th>Style Code</th>
                                    <th>Weight</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                        <button class="uploadsData my-3" type="submit">Lưu <i class="fas fa-cloud-upload-alt"></i></button>
                    </form>
                </div>

            </div>

        </div>

    </div>
@endsection


@section('js')
    <script>
        $('#uploadForm').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('upload.FileExcel') }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        let rows = response.data;
                        let tableBody = $('#dataTable tbody');
                        tableBody.empty(); // Clear existing data

                        rows.forEach((row, index) => {
                            let html = `
                    <tr class ="tr__custom__inputimport">
                        <td><input class="custom__inputimport" colspan="2" type="text" name="data[${index}][name]" value="${row.name ?? ''}"></td>
                        <td><input class="custom__inputimport" type="text" name="data[${index}][sku]" value="${row.sku ?? ''}"></td>
                        <td><input class="custom__inputimport" type="text" name="data[${index}][price]" value="${row.price ?? ''}"></td>
                         <td><input class="custom__inputimport" type="text" name="data[${index}][color]" value="${row.color ?? ''}"></td>
                          <td><input class="custom__inputimport" type="text" name="data[${index}][size]" value="${row.size ?? ''}"></td>
                           <td><input class="custom__inputimport" type="text" name="data[${index}][type]" value="${row.type ?? ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][type2]" value="${row.type2 ?? ''}"></td>
                             <td><input class="custom__inputimport" type="text" name="data[${index}][material]" value="${row.material ?? ''}"></td>
                              <td><input class="custom__inputimport" type="text" name="data[${index}][tier]" value="${row.tier ?? ''}"></td>
                              <td><input class="custom__inputimport" type="text" name="data[${index}][tier_code]" value="${row.tier_code ?? ''}"></td>
                             <td><input class="custom__inputimport" type="text" name="data[${index}][style]" value="${row.style ?? ''}"></td>
                              <td><input class="custom__inputimport" type="text" name="data[${index}][style_code]" value="${row.style_code ?? ''}"></td>
                              <td><input class="custom__inputimport" type="text" name="data[${index}][weight]" value="${row.weight ?? ''}"></td>
                    </tr>
                    `;
                            tableBody.append(html);
                        });

                        $('#previewTable').show();
                    } else {
                        alert(response.message);
                    }
                }
            });
        });
    </script>
@endsection
