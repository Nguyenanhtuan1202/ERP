@extends('layouts.enic')

@section('content')
    <div class="container-fluid">
        <div style="margin-top: 100px">
            <div class="row align-items-center justify-content-between listPurchaseOrder mt-3 ml-2" style="width: 100%; ">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('product.list') }}">Danh Sách</a></li>
                        <li class="breadcrumb-item active">
                            Cập Nhật
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <div class="d-flex">
                        <a class="addNew" href="{{ route('product.add') }}">Tạo Mới <i class="fas fa-plus"></i></a>
                        <a style="background: #322c2d; box-shadow: none" class="settingNew" href="">Tải lại trang
                            <i class="fas fa-sync-alt"></i></a>
                        <a style="background: #199fb7; box-shadow: none" class="addNew"
                            href="{{ route('product.list') }}">Danh
                            Sách <i class="fas fa-list"></i></a>
                    </div>
                </div>
            </div>
        </div>


        <div class="box___expert">



            <div class="form-container-custom">
                @if (session('status'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Thông báo',
                                text: '{{ session('status') }}',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#3085d6',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif
                @if (session('error'))
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire({
                                title: 'Lỗi',
                                text: '{{ session('error') }}',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#d33',
                                background: '#fff',
                                timer: 5000, // Tự động đóng sau 5 giây
                                timerProgressBar: true,
                            });
                        });
                    </script>
                @endif

                <form action="{{ url('/admin/product/update/' . $data->id ?? '') }}" method="POST"
                    enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <h2>Cập nhật sản phẩm </h2>

                    <div class="form-group">
                        <label for="name">Tên sản Phẩm:</label>
                        <input type="text" id="name" name="name" required value="{{ $data->name ?? '' }}">
                    </div>



                    <div class="form-group">
                        <label for="images">Hình ảnh sản phẩm:</label>
                        <input type="file" id="images" name="images" accept="image/*" onchange="loadFile2(event)">
                        <img style="max-width: 200px; border-radius: 8px;margin-top: 6px"
                            src="{{ asset('uploads/product/' . $data->images ?? '') }}" alt="{{ $data->name ?? '' }}"
                            id="output2">
                        <script>
                            var loadFile2 = function(event) {
                                let output = document.getElementById('output2');
                                output.src = URL.createObjectURL(event.target.files[0]);
                                output.onload = function() {
                                    URL.revokeObjectURL(output.src)
                                }
                            };
                        </script>
                    </div>


                    <button class="mt-4" type="submit">
                        Cập Nhật
                    </button>

                </form>
            </div>


        </div>

    </div>
@endsection
