@extends('layouts.master')

@section('content')

    <div class="site-wrapper-reveal">

        <div class="login-register-page-area section-space--ptb_80">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6 m-auto">
                        <div class="login-content">

                            <div class="login-header mb-40">
                                <h3 class="mb-2">Đăng ký tài khoản</h3>
                                @if (session('status'))

                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    {{ session('status') }}
                                   
                                </div>
                            @endif
                            </div>
                            <form action="{{url('/add-customer')}}" method="POST">
                                {{ csrf_field() }}
                                <input type="text" name="name" placeholder="Họ Và Tên">
                                <input type="email" name="email" placeholder="Email">
                                <input type="password" name="password" placeholder="Mật khẩu">
                                <div class="remember-forget-wrap">
                                </div>
                                <div class="button-box mt-4">
                                    <button type="submit" class="btn-primary btn-large">Đăng Ký</button>
                                </div>
                                <div class="member-register mt-5">
                                    <p> <a href="{{ url('/customer-login') }}">Đăng nhập ngay</a></p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
