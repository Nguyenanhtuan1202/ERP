@extends('layouts.master')


@section('content')
    <div class="site-wrapper-reveal">

        <div class="about-history-area">
            <div class="container">
                <div class="row">


                    <div class="col-md-8">
                        <div class="platform-content-box mb-3" data-aos="fade-up"
                            style="border:1px solid #ffc4a0; border-radius:10px; padding:10px">
                            <div class="platform-icon">
                                <img src="{{ asset('uploads/customer/' . $infoCustomer->image) }}" alt="">
                            </div>
                            <div class="platform-content">

                                <h3 class="title">Thông tin cá nhân</h3>

                                @if (session('status'))

                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        {{ session('status') }}

                                    </div>

                                @endif
                                <p style="font-weight:bold">{{ $infoCustomer->name }}
                                </p>
                                <p style="font-weight:bold">{{ $infoCustomer->email }}
                                </p>

                                <button class="btn btn-info btn-update-info-customer">Cập nhật thông tin</button>
                            </div>
                        </div>

                        <div class="row update_info_customer" style="display:none">
                            <div class="col-md-6">

                                <h5 class="mt-3">Cập nhật thông tin cá nhân</h5>
                                <form action="{{ url('update-info-customer/' . $infoCustomer->id) }}" method="post"
                                    enctype="multipart/form-data">

                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="">Họ và tên</label>
                                        <input type="text" name="name" value="{{ $infoCustomer->name }}" id=""
                                            class="form-control" placeholder="" aria-describedby="helpId">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email</label>
                                        <input type="text" name="email" value="{{ $infoCustomer->email }}"
                                            class="form-control" placeholder="" aria-describedby="helpId">

                                    </div>
                                    <div class="form-group">
                                        <label for="image">Hình Đại Diện </label>
                                        <input class="form-control-file @error('image') is-invalid @enderror"
                                            style="width:100%" type="file" name="image" accept="image/*"
                                            onchange="loadFile(event)">
                                        <img style="margin-top: 10px; border-radius:10px; max-width:50%"
                                            src="{{ asset('uploads/add.png') }}" id="output" />
                                        <script>
                                            var loadFile = function(event) {
                                                var output = document.getElementById('output');
                                                output.src = URL.createObjectURL(event.target.files[0]);
                                                output.onload = function() {
                                                    URL.revokeObjectURL(output.src)
                                                }
                                            };
                                        </script>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-3"> Cập nhật </button>
                                </form>
                            </div>

                            <div class="col-md-6">
                                <h5 class="mt-3">Đổi mật khẩu</h5>
                                <form action="" method="post">

                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label for="">Mật khẩu cũ</label>
                                        <input type="hidden" id="customer_id" value="{{ $infoCustomer->id }}">
                                        <input type="password" name="old_pass" id="old_pass" class="form-control"
                                            placeholder="" aria-describedby="helpId">

                                    </div>
                                    <div class="form-group">
                                        <label for="">Mật khẩu mới</label>
                                        <input type="password" name="new_pass" id="new_pass" class="form-control"
                                            placeholder="" aria-describedby="helpId">

                                    </div>
                                    <div class="form-group">
                                        <label for="">Xác nhận lại mật khẩu</label>
                                        <input type="password" name="re_pass" id="re_pass" class="form-control"
                                            placeholder="" aria-describedby="helpId">

                                    </div>

                                    <button type="button" class="btn btn-primary mt-3 change-password"> Cập nhật</button>
                                </form>
                            </div>
                            <button class="btn btn-primary mt-3 cancel-update-info">Thoát</button>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="plateform-image-box" data-aos="fade-up">
                            <div class="plateforem-image">
                                <img src="{{ asset('uploads/customer/' . $infoCustomer->image) }}" alt="">

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="bunzo-history-area section-space--pt_60">


            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="bunzo-row">
                            <div class="bunzo-col-6" data-aos="fade-up">
                                <h2 class="bunzo-history-title">Bình luận gần đây </h2>
                            </div>
                            <div class="bunzo-col-6">

                                @foreach ($customer_comment as $item)


                                    @foreach ($post_all as $post_item)
                                        @if ($item->post_id == $post_item->id)
                                            <div class="single-history-item" data-aos="fade-up">
                                                <h3 style="font-size: 16px" class="title mb-20"><a
                                                        href="{{ url('tin-tuc/' . $post_item->slug) }}"> Tên bài viết:
                                                        {{ $post_item->title }}</a> </h3>
                                                <img style="width:100px"
                                                    src="{{ asset('uploads/post/' . $post_item->image) }}" alt="">
                                                <p><span style="font-weight:bold"> Nội dung bình luận :</span>
                                                    {{ $item->comment_content }}
                                                </p>
                                            </div>
                                        @endif
                                    @endforeach
                                @endforeach


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

@section('js')
    <script type="text/javascript">
        $(document).ready(function() {
            $(".btn-update-info-customer").click(function(e) {


                $(".update_info_customer").css("display", 'flex');
                e.preventDefault();

            });

            $(".cancel-update-info").click(function(e) {


                $(".update_info_customer").css("display", 'none');
                e.preventDefault();
            });


            /*  Change password*/
            $(".change-password").click(function() {


                var re_pass = $("#re_pass").val();
                var old_pass = $("#old_pass").val();
                var new_pass = $("#new_pass").val();
                var customer_id = $("#customer_id").val();
                var _token = $('input[name ="_token"]').val();
                $.ajax({
                    method: "POST",
                    url: "/change-password",
                    data: {
                        re_pass: re_pass,
                        customer_id: customer_id,
                        old_pass: old_pass,
                        new_pass: new_pass,
                        _token: _token
                    },
                    success: function(data) {
                        $("#re_pass").val("");
                        $("#old_pass").val("");
                        $("#new_pass").val("");
                        alertify.success(data);
                    }
                });

            });

        });
    </script>

@endsection
@endsection
