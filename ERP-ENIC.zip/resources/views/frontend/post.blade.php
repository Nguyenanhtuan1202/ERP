@extends('layouts.master')


@section('title')
    {{ $data['post']->meta_seo ?? '' }}
@endsection
@section('meta')
    <meta name="description" content=" {{ $data['post']->desc_seo ?? '' }}" />
    <meta name="keywords" content=" {{ $data['post']->key_seo ?? '' }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" name="title" content="{{ $data['post']->meta_seo ?? '' }}" />
    <meta property="og:description" content="{{ $data['post']->desc_seo ?? '' }}" />
    <meta property="og:url" content={{ $data['url'] ?? '' }} />
    <link rel="canonical" href="{{ $data['url'] ?? '' }}" />
    <link rel="amphtml" href="{{ $data['url'] ?? '' }}" />
    <meta property="og:image" content={{ asset('uploads/post/' . $data['post']->image ?? '') }} />
@endsection

@section('content')
    <main>
        <!-- About US Start -->
        <div class="progress-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>


        <div class="about-area about-area-custom">
            <div class="container">

                <div class="row">
                    <div class="col-lg-9">
                        <!-- Trending Tittle -->
                        <div class="about-right mb-90  ">
                            <div class="box__intro-post">


                                <div style="display: flex; gap:10px; align-items: center">
                                    <div> <i class="far fa-calendar-alt"></i> </div>
                                    <div>{{date('d-m-Y', strtotime($data['post']->updated_at ?? ""))}}</div>
                                </div>


                                <div style="display: flex; gap:10px; align-items: center">
                                    <div> <i class="fas fa-clock"></i> Thời gian đọc: </div>
                                    <div id="reading-time"></div>
                                </div>

                                <div style="display: flex; gap:10px; align-items: center">
                                    <div> <i class="fas fa-eye"></i> Lượt xem: </div>
                                    <div>{{ $data['post']->post_view ?? '' }}</div>
                                </div>




                                <div style="display: flex; gap:10px; align-items: center">
                                    <div> <i class="fas fa-user"></i> </div>
                                    <div>{{ $data['post']->user->name ?? '' }}</div>
                                </div>
                            </div>

                            <div class="blog__content">
                                @if ($data['post']->link_youtube != NULL || $data['post']->link_youtube != '')
                                <div class=" lazyYT open-video-youtube "
                                data-youtube-id="{{ get_youtube_code($data['post']->link_youtube ?? '') }}"
                                data-modal-target="defaultModal" data-modal-toggle="defaultModal"
                                data-title="{{ $data['post']->title ?? '' }}">
                                <div class="box__icon">
                                    <div class="video-item">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="55" height="38.07"
                                            viewBox="0 0 55 38.07">
                                            <image id="Youtube_logo" width="55" height="38.07"
                                                xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoAAAAG7CAYAAABTmCTQAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAksUlEQVR42u3debSkZX0n8O97e6H3ZodGkAZxRdyQBqJsgjFqk2VO2snEANnUyZkAkog6JyrMCY7tiCPoMYqZOIEjkwlDJpPQLomAssoii2zNbiP73ju90TV/vO9NX9ruvnXvreWtqs/nnDpVfW/dqurf+3L59vP8nudNAAAYKIUSAK3USGYlmbKdb09OMnsHPz4nyaTtfG9qkpkt/KjLy4/bViuTvLzV19Yk2bDV19YVyUvOHkAAhP4PStOTTNsqFA0lmTviaTuP+O90ZDgaGbJmJNmpejwt5etuHZgmVT8//N/9zmN8j5FGvhbts6EKiyO9XIXKrb3YZPhcnWTjiD+vSLK5CsLLq69trJ6XJOuyJZiO/Nkx/VzxyvcEBECoVSCbXYWmuSOC1Jzqa3OyJbDNrULb3K3C1HCQmlsFueEwNRykZlavNTKwwSAZLTgOh8zh8Lq8ev7yEeF3+Pnrk6ytgua6bBlZXZVk0/B7FdsOxyAAKgE9GNSmVyFqbsrQNrO67VyFrRnV/c4jvje7ev7wz44MeztVXwP603jC4/rqucur+zUj/rymuq1KsqIoQyoIgLCD8DY327/NSbLLDr43HOKGVBKokZeqQLiyug2HxZF/XlMFy1Uj/rytcGnKHAGQ2oa4KUl2TbJbdb+t224j7odD3S6qBzCqDSmnrkfeXtjG137p+xYTIQAylkA3M8le1W2P6rb3iMd7JNl9RLibrWoAtbRutJC4na8/W/zyoiEEQHow1M1Ism8V5PYdEfD2qsLcHknmVffTVQxg4D1b3Z5L8nR1e6762lMjvv+0xTUCIJ0PdlOrADcvyT47uN/b8QWgTdanHDl8IsmTW90/XD1+vNiy2hsBkFEC3k5JXpXkwOo2HOqG/zw/FkEA0BvWjQiFW9+eLMrvIQAORMArkrw6yeuSvDbJ/lWoG77fS5UAGBArqjB4X5KlSe6tHt9vQYsA2KtBb5cq5L2+uh9503MHANu3OckjVRi8PclPk9xcJL9QGgGwLkFvTpK3jri9oQp9e6gOALTUM0lurgLhj5NcW5SbdyMAtjXs7ZfkbdXtrdX9geoIAF3xYpLvJ7ksyQ8sOhEAWxX43pDk15O8N8k7Uu6BBwDUz6YkVydZkuSfi+QhJREAmw18Q0neVYW+30i5SAMA6D33JPnHJBcWyQPKIQBuK/jtm+TDST6S5DUqAgB95ZYk30ryd0V5PWYBcIBD35Qki5L8UZJjY289AOh3a5L8XZIvF+WWMwLgAAW/2Un+MMmfp1zUAQAMXBzId5OcXySXC4D9faT3SfLxJB9LuXULAMANSc4qkn8VAPsr+M1OOdr3ydiAGQDYtiuSfKoo+wUFwB4OftOS/GmS/xzbtwAATcWH/H2SvyjKS9QJgD129H4ryXkpr7kLADAW65Kck+RLRbJBAKx/8NsnyflJftu5CwBM0ANJ/qQop4f7Sl9sfdJIJjeSP0t50WjhDwBohdcm+WEj+Va1pqBv9PwIYCPZP8l3krzbeQoAtMmyJB8ukuv74S/T0yOAjXIj59uEPwCgzeYnuaqRnN1IJvX6X6YnRwCrYdivJznJ+QgAdNgVSf5DkTwrAHYu/L0myT8neZPzDwDokseS/Gav7hvYU1PAjeToJD8R/gCALts35ZTwvxMA2xv+Tk055LqHcw4AqIGZSS5tJJ/ptQ9e+yngRvkZz08ZAAEA6ujrSU4rks0C4MTD36Qk30ryh84rAKDm/leS3y+SjQLg+MPf1CQXx8bOAEDvWJJkUVFeTk4AHGP4m5Hk/yV5r/MIAOgx/5Lk1+t8HeHaLQJpJFOSXCL8AQA96n1J/r6RTBYAmwt/k5JclOSDzh0AoIf9ZpK/adR0x5XafKhqte+3kvyOcwYA6AMnJzlXANyxxbHaFwDoL2c0ktPq9qFqsQikUV7T9yLnCADQh15OcmKRfF8A3BL+Dk1yTZLpzg8AoE+9mOTwInlg4ANgo7yO3k1J5jkvAIA+tzTJkUWyotsfpGs9gNV2L/8g/AEAA+KNSb5Zhw/SzUUg5yRZ4FwAAAbI7zSSU7r9IboyBdxIjklyRcp9/wAABsmaJO8okvsHJgA2kt2T/CzJPo4/ADCgbknyK926XFw3poC/JfwBAAPu0CSf7Nabd3QEsJH8VpL/65gDAGR9krcWyX19GwAbyewk96Tc+gUAgOTHSd5TJI1Ovmknp4D/UvgDAHiFY5N8uNNv2pERwEbyjpQbPlv1CwDwSs8keW2RrOzUG3ZqBPBLwh8AwDbtmeTMTr5h20cAG8kHkyxxbAEAtuulJK8rksc68WZtHQFslK9/jmMKALBD05P8RaferK0jgI3kpCQXOaYAAKPamOTNnbhCSNtGABvJ5CT/xbEEAGjKlCSf7sQbtXMKeFGSAxxLAICm/V6jA9vmtTMAftwxBAAYkylJ/rTdb9KWHsBG8p4kVziGAABjtjLJq4tkRbveoF0jgJ9w7AAAxmVOkj9o5xu0fASwUfb9PZQOXmcYAKDP3FMkB7frxdsxAvgHwh8AwIS8qZEs6IkA2CiD3+85ZgAAE9a2aeCWjtQ1kuOTXO54AQBM2Iok+xTJ2la/cKungH/fsQIAaIm5SU5sxwu3LAA2kqlJfsOxAgBomd+sdQBMcmyS2Y4TAEDLvL8aZKttADzRMQIAaKm5SY6ucwD8oGMEANByLW+xa0kAbCRvTrkBNAAArdXyQbZWjQAe59gAALTFAY1kvzoGwAWODQBA27yrjgHwcMcFAGBAAmAj2TXJQY4LAEDbvLtWATDl9G/huAAAtM0hjXJLmNoEQNO/AADtNamVmatVI4AAALRXy/oAWxEAD3U8AADa7ohWvdCEevcaybwkTzgeAABt90KS3YukMdEXmugI4NsdCwCAjtg1yYGteKGJBsC3ORYAAB1zWB0C4FsdBwCAwQqApoABAHosAI57EUgjmZVkRVp3OTkAAHZsbZK5RbJpIi8ykfB2iPAHANBRM5K8YaIvMpEAd7BjAADQcW8TAAEABsuEF+EKgAAAAqAACABQY2+b6AuMaxVwI5mbZLn6AwB0xbwieWq8PzzeEUCjfwAA3TOhaWABEABAAGzKG9UdAGCwAuDr1B0AoGsmNBsrAAIA9J7XN5JJHQuAjWRykvnqDgDQNdOSHNCxAFi92RR1BwDoqnGvyRhPADT9CwDQfW8SAAEABktHRwBfq94AAIMVAA9SbwCA7gfAxjgv6zueADhfvQEAum52kn3bHgCrlLmfegMA1MK4ZmbHOgI4L+W+MwAAdN+41maMNQDOV2cAgMEKgPurMwDAYAXA+eoMAFAbHekBNAIIAFCjANgYx64uAiAAQO/aKePYCsYUMABAbxtzH2DTAbDaA/DVagwAUCtj7gMcywjgHklmqDEAQK3Mb2cAnK++AACDFQAtAAEAGLAAOF99AQBq54B2BkAjgAAA9bNnY4zrNARAAIDeVow1p5kCBgDofWPKaWMJgPuqLQBALY2pD7CpANhIpifZWW0BAGqpLVPA89QVAKC29mlHANxbXQEAautVAiAAwGBpywigKWAAgPpqywjgXuoKAFBbsxrJnFYHQFPAAAD11vQ0sClgIFm0KDnoIHUA6G1NTwMbAQSSY49N7rknOf/8ZO5c9QDoTS0fARQAod9NmZKcdlry0EPJ6acnkyapCUBvad0IYKO8wPCeagoDYrfdkvPOS+68M3nf+9QDoHe0dARw9yRT1RQGzBvfmPzgB8lllyUHHqgeAAMWAE3/wiBbuDBZurTsD5wzRz0A6quli0AEQBh0U6eW/YH33pt89KP6AwHqyQgg0Abz5iUXXJDcdFNy1FHqAVCz39KNJhf4NvMkewACr/SOdyRXX132Bx5wgHoA1MOUJHu0KgC6DBywbQsXJnffnSxenMyerR4A3dfUNLARQGBipk9PPvWpLf2BQ0NqAtA9TS0EaXYbGIBR/s25T9kfeOONybvepR4AXfpt3KoAuJtaAk175zuTa65JLrkk2X9/9QDorKYW7wqAQOsVRbJoUXl94cWLk1mz1ASgM5qauW0mAO6qlsC4zJixpT/w5JPLYAhAOzU1cLfDANgolxP7pzswMa96VXLhhckNNyRHHqkeAO3TkhHA3ZL4JzvQGgsWJNddV/YHvvrV6gHQehMfAYzpX6DVRvYHnn12Mm2amgC0TktGAAVAoD1mzkzOOiu5/379gQCt05IRQCuAgfbab7+yP/AnP0kOP1w9ACZmViMZdWrFCCBQD4cfnlx/fXLRRcnee6sHwPiNOoAnAAL1MTSUnHRS8uCD+gMBBEBgoAz3B955Z7lgBAABEBgQBx1Ubhlz5ZXJW96iHgDNGXUlsAAI1N9xxyW33Vb2B+65p3oA7NiERwCtAgbqYbg/8L77ysvL7bSTmgBsmxFAoM/svHOyeLH+QIDt0wMI9KnXvrbsD7z88uSQQ9QDoIUB0BQwUG/HH5/cemtywQXJHnuoB8BEpoAbyZQks9QQqL3Jk5OPfnRLf+DUqWoCDLIJjQCa/gV6yy67lP2Bd9yRfPCD6gEMqgktApmrfkBPev3rkyVLkh/+MDn4YPUABs2ERgBnqx/Q0044odw/8IILkt13Vw9gUMxpjLLOQwAE+tuUKVv6A08/vewXBOhvRUZZxyEAAoNh112T884r9w98//vVA+h3swVAgGFveEPyve8ll12WvOY16gEIgFuxBQzQvxYuTJYuTc4/P5lrzRsgADb1gwA9b8qU5LTTkoceKvsDJ01SE6BfzBEAAXZkt93K/sCbb06OOUY9gH5gBBCgKW9/e/LjH5f9gQceqB7AQAZAPYDAYBrZHzhnjnoAAxUAjQACg2vq1LI/8N57y30E9QcCvUUPIMC4zZtXXknkxhuTo45SD6BXGAEEmLBDD02uvrrsD5w/Xz0AARBgYCxcmNxzT7J4cTLbr0mg/wKgRSAA2zJ9evKpT23pDxwaUhOgbwKgf9oC7Mg++2zpD3zXu9QDqBOLQADa6p3vTK65JrnkkmT//dUDqIOxjwA2yq/PUDuAJhVFsmjRlv7AWbpogB4LgElmZsejgwBsy4wZZX/g0qXJySeXwRCg88Y1BWz6F2Ai9t03ufDC5IYbkiOPVA+g08Y1AmjuAqAVFixIrrsuueiiclNpgA4FwEZSjDUATlM3gBYpiuSkk5IHHkjOPjuZ5lcs0HaTdpTnBECATpk5MznrrOT++/UHAp2wkwAIUBf77Vf2B155ZfK2t6kH0C5GAAFq59hjk1tuKfsD99pLPYBWMwIIUEtDQ2V/4IMPlv2BO+2kJkCrjHkE0G8ggE6aNavsD7zrrnJDaYCJMwII0BMOOqi8pNwVVyRveYt6ABOhBxCgp7znPcltt5X9gXvuqR7AeBgBBOg5w/2B991XXl5OfyAwNnoAAXrWzjsnixcnd9yhPxAYCyOAAD3vda8r+wN/+MPkzW9WD2A0RgAB+sYJJ5T9gRdckOyxh3oAGWueMwII0IsmT04++tEt/YFTp6oJ0HSeEwABetkuu2zpD/zAB9QDGMkIIEBfe/3rk+9+t+wPPPhg9QB2mOf0AAL0k+H+wPPPL1cPA4PMCCDAwJgyJTnttOShh5LTT08mTVITEAAFQICBsOuuyXnnJXfemfzar6kHDB6LQAAG1hvfmHz/+8lllyWveY16wOAY8wigHkCAfrNwYbJ0adkfOHeuekD/swgEgOgPBAFwhwFwspoB9LHddiv7A2++OTn6aPWAPv0nnwAIwC97+9uTq64q+wMPPFA9oL8MjfUb5gQABsnI/sA5c9QDBEAABsLUqWV/4L33ltcZHhpSExiwAOi/eoBBNW9ecsEFyU03Je9+t3pA75o01gBoBBBg0B16aHLNNWV/4Pz56gG9xxQwAOO0cGFyzz3J4sXJ7NnqAQIgAANh+vTkU58qF4roDwQBEIAB8qpXlf2BN9yQ/MqvqAfU25h7AP3TDoDtO+yw5Nprk0suSfbfXz2gnowAAtBiRZEsWlT2B559djlNDAiAAAyAGTOSs85K7r8/OfnkMhgCAiAAA2DffZMLLyz7A484Qj1AAARgYCxYkFx/fXLRRcnee6sHdI9FIAB0UFEkJ52UPPhg2R84bZqaQOcZAQSgC2bOfGV/ICAAAjAg9tuv7A/80Y+St75VPUAABGBgHHtscuutZX/gXnupB7SXHkAAamJo6JX9gTvtpCbQpv/amv5Gw+gfAJ0wa1bZH3jXXeWG0kD3AmCM/gHQSQcdVF5S7oorkre8RT2gSwHQFu4AdN573pPceGNy1FFqAa1RjCUANtQLgI678srk8MOTa65RC2iNTWMJgJvVC4COeeCB5EMfSo4/PrnjDvWA1nl5e9+YLAAC0BWrVydf/nLyhS8k69erB3QzABZJo1FOA+sFBKD1Nm9OLr44OfPM5Omn1QPqEACH//OM7WAAaLUf/Sg544zkZz9TC+hiABzaQQAEgNZ49NHklFPKlb7CH3Q9AE4WAAFomzVrknPPTRYvTtatUw/orE0CIACd02gk3/lO8slPJk89pR7QHWMeAbQXIADjc+ONycc/ntxwg1pATQOgHkAAWuOxx8o+vyOPFP6g5gHQFDAAE7N2bfKlLyVf/GLy0kvqAQIgAH2r0UguvTT5xCeSX/xCPUAABKCv3Xxz2ed3/fVqAT0YAPUAAtC8xx8v+/wOP1z4g/qzDQwAE7B2bfK1ryXnnFNewxfoBaaAARinJUuSU09Nli1TC+iTAGgKGIBtu+WW5KijkhNPFP5AAASgrz3xRPKxjyULFiTXXqse0IcB0BQwAKUNG5JvfjP57GeTlSvVAwRAAPrakiXJaaclP/+5WsAABEBTwACD7NZbk2OOKfv8hD/oNxvGGgA3qBlAH3vuuXIj5wULkquvVg/oT9u9NuP2poDXqxlAH9q4MfnGN/T5wWBYLwACDLolS8pRv4ceUgsYDNsdARwSAAH63NKlyfvfX/b5CX8wSNYJgACD5oUXyhG/Qw5JfvAD9QAB8N+YAgboN8N9fmedlSxfrh4wuCwCARgIl19ejvrdfbdaAGOeArYNDEAvue++5IMfTN77XuEPGGYRCEBfGu7ze/Obk+99Tz2AkfQAAvSVTZuSb387+cxnkmefVQ9AAAToa5dfnpxxRnLXXWoB7IgpYICed//9yYc+VPb5CX/A6IwAAvSs5cuTxYuT885L1vv1DAiAAP1r8+bk4ouTT3wieeYZ9QDGyj6AAD3lyivLPr877lALYLxcCg6gJzz4YNnnd/zxwh8wUUYAAWpt9erky19OvvAFfX5AK2wudnBhDwEQoKu/oqs+vzPPTJ5+Wj2AVlm3o28KgADd8uMfl31+t9+uFkBHA6AeQIBOe/TR5JRTkuOOE/6ArgRAI4AAnbJmTXLuueWefuvWqQfQTqvHEwDXqhtAizQayXe+k3zyk8lTT6kH0AkrxxMAV6kbQAvcdFPy8Y8nP/mJWgC1CYDb6wFcrW4AE/DYY2Wf3xFHCH9A7QLgZAEQoIXWrk2+9KXki19MXnpJPQABEKBvNRrJpZeW+/k98oh6AN22ajwBUA8gQLNuvrns87v+erUA6mLsPYBFsim2ggHYsccfTz72sbLPT/gD6mVcI4BJOQ28k/oBbOWll5KvfjX5/OeTVSZMgFoaVw/gcADcTf0ARliyJDn11GTZMrUA6myH/zodGu8PAgyUW25Jjj46OfFE4Q/oBePaBzCxEhggefLJss9vwYLkmmvUA+iLADjaFDDAYNqwIfnmN5PPfjZZuVI9AAEQoK8tWZKcfnry8MNqAfSqcfcACoDAYLnttuSYY8o+P+EP6G16AAF26Pnny42cDzssufpq9QD6PgDuaArYKmCgv23cmHzjG8nnPpesWKEeQL94Ocna8QbANeoH9K0lS8pRv4ceUgug36wqksaOnmAKGBgsS5cmH/hA2ecn/AH9adStCwRAYDC88EI54nfIIcn3v68eQD8btY1PDyDQ34b7/M46K1m+XD2AQTBqU7MACPSvyy8vR/3uvlstgEHy/GhP2NEU8AvqB/Sk++5LFi5M3vte4Q8YRM+O9oTJAiDQN158MfniF5OvfKW8lBvAYBp1BFAABHrfpk3Jt7+dfOYzybPPqgcgAE4wADaSFOoI1NYVVyRnnJHceadaAJSeG+0J2+0BLJKNsRUMUFf335986EPJCScIfwCvNKERwKQcBZytjkBtLF+eLF6cnHdesn69egC0KQDur45A123enFx8cfKJTyTPPKMeANs36hTwaAHweTUEuu7KK8s+vzvuUAuA0U1oH8DESmCgmx58sOzzO/544Q+gOY1m8lszU8AAnbVmTXLuuckXvqDPD2BsVhTJJgEQ6B3DfX5nnpk8/bR6AIzdc808abQA+KI6Ah1x1VXldXtvv10tAMavqfUbegCB7nr00eSUU5LjjhP+ACauJSOAAiDQHsN9fosXJ+vWqQdAazQ1AmgbGKCzGo3k0kuTP//zcvQPgNoFQCOAQOvcdFPZ5/eTn6gFQBcDoB5AoP0ee6zs8zviCOEPoL1a0gNoChgYv7Vrk699LTnnnGT1avUAaL+JTwEXyYZGsibJTPUEmjbc53fmmckjj6gHQOc8O+EAOCJJCoBAc37607LP77rr1AKg855o5klDTTznKbUERv+V80TysY8lhx8u/AHUPAA2MwL4pFoC2/XSS8lXv5p8/vPJqlXqAdA9K4qyda8lAdAIILBtS5Ykp56aLFumFgDd90SzT2xmCtgIIPBKt96aHH10cuKJwh+AAAj0tSefLPv8FixIrrlGPQBq9lu62SeaAgZGt2FD8s1vJp/9bLJypXoA1FPTI4AWgQA7tmRJcvrpycMPqwVAvTWd2UwBA9t2223JsceWfX7CH0AvaGkP4NNJNqspDIjnny83cj7ssOSqq9QDoA8D4KhTwEWysZG8kGR3dYU+tnFj8o1vJJ/7XLJihXoA9J6mZ22LZp7USO5Icoi6Qp9atKic8n3wQbUA6F0zi2RtKwPgvyT5VXUFAKilF4tk12afPNTk8ywEAQCorzFltWYDoL0AAQDq64mxPNkIIACAALhNRgABAAYsABoBBACor7b0AAqAAAD19bgACAAwWH7e8gBYJKuTPK+2AAADEgDH88IAAHTEiiJ5UQAEABgcY85oYwmAy9QXAGCwAqARQACA+lnWzgC4TH0BAGrHCCAAgADYugC4LElDjQEAamVZ2wJgkayLawIDAAxOABzvGwAA0DbPVhfsaGsA1AcIAFAf48pmAiAAQO9a1okAuEydAQBqwwggAIAAKAACAPSzZZ0IgI8meVmtAQBqof0jgEWyMcljag0A0HWbkjzS9gBYeVi9AQC67uEiWd+pAHi/egMAdN3S8f7geALgfeoNADBYAfBe9QYAEAABAOiRAFiM9QcaZWhcnWS6ugMAdEUjyc5FsnI8PzzmEcAi2ZzkQXUHAOiax8cb/sYVACumgQEAumfpRH54vAHQSmAAgAELgHepOwDAYAXAO9UdAKA3A2Axnh9qJJOTrEoyTf0BADpuryJ5Zrw/PK4RwKK8+LCFIAAAnffCRMLfuANgxTQwAEDnLZ3oCwiAAAACYNPuUH8AgMEKgLaCAQDovAlnsGIiP9xInkyyt+MAANAxe3VzEUiS3OoYAAB0zOMTDX+tCIA/dRwAADrmtla8yEQD4C2OAwBAx9wuAAIACICdDYBF8njKhSAAAAxCAKxYCAIA0H4rkzxclwB4s+MBANB2txVJoy4B8HrHAwCg7W5s1Qu1IgDekORlxwQAoK1aNus64QBYJKuS3OmYAAC01U21CYCV6xwTAIC2eaZIflG3AKgPEACgfW5s5YsZAQQAqL+W7rrSkgBYJI+khcOSAAC8wg21C4CV7zo2AAAttzrJNXUNgP/s+AAAtNwPimRdXQPgj1JuCQMAQOtc1uoXbFkALJL1Sf7FMQIAaJmXk3yvtgGw8k+OEwBAy1xbJM/VPQD+Y0wDAwC0ykXteNGWBsAiWZPk/zhWAAAT1rZcNdSG1/yfjhcAwIRdWrRpZrXlAbBIrk1yr2MGADAhf9uuFx5q0+t+2zEDABi3B5Jc1WsB8IIkKxw7AIBx+XKRNHoqABbJyiR/49gBAIzZM2nT6t+2BsDKV5JscAwBAMbk60XyUk8GwCJ5LMkljiEAQNPWJvmrdr/JUJtf/7+mvIQJAACj+0Y7rvyxtaLdb9BI/jrJHzueAAA7tDzJQUXyfLvfaKgDf5mzUg5nAgCwfV/sRPjrSAAskieSfM0xBQDYrieSfLVTb1Z04k0ayS4pNzTczfEFAPglHymS/9GpN+vEFHCK5MUkn3RsAQB+yU3p8FXUik69UaN8r8uTvMdxBgBIkmxKcliR3N7JNx3q1BtVlzP5kyTrHGsAgCTJlzod/joaAKsQeH+S/+ZYAwDk4SR/2Y03Ljr9ho1kSpJrkyxw3AGAAbU5yfFF8uNuvPlQp9+wSDYm+XCSVY49ADCg/rJb4a/KY93RSD6S5FuOPwAwYG5K8u5qUGywAmAVAv93kn/vPAAABsSKJG8vkp9380MMdbkI/zHlwhAAgH63Ockp3Q5/XQ+ARXnR419PeQ8A0M8+VyT/VIcPUtThQzSSX03y3SSTnRsAQB/6hySLqn2Ru26oDh+iSP41yaedGwBAH7otycl1CX9V9qqPRvLVJKc6TwCAPvFgkqOL5Mk6fai6BcAiyV8n+SPnCwDQ4x5PclQdFn3UOgBWIXBSkr9Lssh5AwD0qOeSHFMk99TxwxV1/FCNZKckS5Kc4PwBAHrMiiQnFMlP6/oBh+r4oYpkfZKFSf7ROQQA9JAXkryvzuGvtgFwRAhclORC5xIA0AOeTDnte2PdP+hQnT9ckbyc5A+SnO+cAgBq7OGU1/e9qxc+7FDdP2C1Z84ZSc5KjfbPAQCoXJfkyKIMgT2h6KXqNpLfTvK3SWY61wCAGrg4yR8Xybpe+tBDvfRhi+TSJL+SZJnzDQDoopeTfLpIfq/Xwl+VqXpPI9kr5V6Bxzn/AIAOezrJSUXyw179Cwz14ocuysIfn+TjSTY4DwGADrk8ydt7Ofz1bACsQmCjKFcHvzvJA85HAKCN1if5dMo9/p7s9b9M0Q9HpJHMTvLfU15DuHCOAgAtdGuSPyySn/XLX2ioH/4SRbKqSD6S5OgkdztPAYAWWJty1G9BP4W/Kjv1l0YyJcmfJTk7yTTnLgAwDt9N8p+K5JF+/Mv17XRpI3lNks8n+VBMCwMAzbkr5fYu3+3nv2TfB6NG8uYkX0iy0DkNAGzHo0nOSfI31aVo+9rAjIw1kl9N8l+SHOEcBwAqTyQ5N8lfFeVK34EwcFOjjeTQJKcn+d0kk5z3ADCQHkjy9SQX9OKVPATA8QfBN6RcLPK7cW1hABiQ//3nyiRfSfK9ovzzQCqcCZmesj/woymvLmLBCAD0l8eTfCfJXxfJQ8oh7GwdBl+b5OQkv5XkYBUBgJ71fJIlVfC7skg2K4kA2EwYnJ9y4ciJ1f1UVQGAWvt5ksuq21VFslFJBMCJhMG5SQ5LuYBk+HagygBA12xIcnuSm5LcmOTGolzYgQDY1lC4SxUE35nkbUleX92mqw4AtNTLKXv3fjoi8N02SNu2CID1D4b7JHlTyhHCg6vHByeZpzoAMKonk9yd5J4R97cW5XV5EQB7LhjuluSAlL2FB2x1m59kJ1UCYEA8l3JE7+Hq/oEq6C0tkjXKIwAOSjgsUo4QDgfCfVOOJL66ut83yV5JhlQLgB6wIeXWKw+PCHnDt4eLZIUSCYA0FxKnJNk7yX5VKHxV9XheddszyR7VPQC0y6aU07S/SHn93Mer+1+MePzUIG+yLADSjaA4eUQY3Ke636sKicOP90o5Jb1bkmmqBkDKHrsnkzyd5JkqzD2b5Knq68+MCHcvK5cASG8HxllVENwjye7V491HBMTdq+/tlmTXlFvizFY5gNpbl7LX7vkqyD1bPR7+2nDYezrJE3rvBEAYLTROqoLgzim3wxl+PHerx9u6H77pZwRozoYkLyZZXt2PfPzCiED3XHV7NslzAh0CIHUMkbO3ERC3FxZ3TjIn5XT1nCQzq8dzVRLoAcuTrEqysrpfVX1tZXVbsZ1w92KS5YIcAiD8cpAcGQZnpNyIe/jxtCo8Tq9uw4+npRy5HPl42lbPsaE3DJ412TLatj5lT9yq6msrkryUclp1RfW1VdVzVm8V6v4t7BXlPQiA0EPhcucqGM6oQuX06vFO1f3klCOZQ9kyGrlz9d/V7Or7w8/f+meK6rnb+hlgi83ZsmXI2iqYNaqwtWlECFtfBbcNVZBbXT1eXoW2l6pQtqG6Hw5zy5NsKMrngwAIdC14NhMa51bBc2RoHH5+tnpOkkxNOVrazPfmpOzzTMrth2Y1+T16w/DI1kjDAWqkVVXA2tZzXqzuh4NVqiDV2Or1V1QBbjiUpQpfLyfZmC2ha3X155ezZcRsTVH+HCAAAjUOriPD6MhR0e3ZZZTvjwyp2zIyjG7LrCqkttPwKFIrNRPGRgauYSNHyoZtKsqfBQAAYJD9f1nLx9vhs/OMAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDIxLTEwLTE1VDA3OjUwOjAxKzAwOjAwKX+OjwAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyMS0xMC0xNVQwNzo1MDowMSswMDowMFgiNjMAAAAASUVORK5CYII=" />
                                        </svg>

                                        <div class="ring-alo-ph-circle">

                                        </div>
                                    </div>
                                </div>

                                <img src="" alt="picture"
                                    style="width: 100%; height: 100%; object-fit: cover; border-radius: 10px">
                            </div>


                            <div id="box__video-show">
                                <div class="box__item-videos">
                                    <div style="position: relative; width: 90%; height: 600px;">
                                        <div class="video__about_us rounded-[10px]" style="position: relative; padding-top: 56.25%; height: 100%;">
                                                <iframe allowfullscreen title="{{ $data['post']->title ?? '' }}"
                                                    style="border-radius: 10px"
                                                    src="https://www.youtube.com/embed/{{ get_youtube_code($data['post']->link_youtube ?? '') }}?autoplay=0&loop=1&mute=0&rel=0&showinfo=0&autohide=1&controls=1&playlist={{ get_youtube_code($data['post']->link_youtube ?? '') }}">
                                                </iframe>
                                        </div>
                                        <div class="close__youtube">
                                            <i style="font-size: 35px;" class="fas fa-times"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                @endif
                              



                                {!! html_entity_decode($data['post']->content ?? '') !!}
                            </div>

                        </div>

                    </div>

                    <div class="col-lg-3">
                        <div class="sticky-srcoll">
                            <div class="sticky__box">
                                @foreach ($data['post_relative'] as $item)
                                    <div class="trand-right-single d-flex trand-right-single-custom">
                                        <div class="trand-right-img">
                                            <a href="{{ route('details.post', $item->url ?? '') }}">
                                                <img alt="{{ $item->title ?? '' }}"
                                                    src="{{ asset('uploads/post/' . $item->image) }}"
                                                    alt="{!! html_entity_decode($item->title ?? '') !!}">
                                            </a>
                                        </div>
                                        <div class="trand-right-cap">
                                            <a href="{{ url('danh-muc/' . $item->category[0]->url ?? '') }}"
                                                class="color1">{{ $item->category[0]->title ?? '' }}</a>
                                            <h4><a class="trand-right-single-custom-title"
                                                    href="{{ route('details.post', $item->url ?? '') }}">{!! html_entity_decode($item->title ?? '') !!}</a>
                                            </h4>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <!-- About US End -->
    </main>


@section('js')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="{{ asset('/frontend/assets/js/jquery.sticky.js') }}"></script>
    <script src="https://www.youtube.com/iframe_api"></script>
    <script type="text/javascript">
        Fancybox.bind("[data-fancybox]", {

        });

        const imgElements = document.querySelectorAll('.blog__content img');
        // Lặp qua từng thẻ img và thêm thẻ a bao quanh nó
        imgElements.forEach((imgElement) => {
            const aElement = document.createElement('a');
            aElement.setAttribute('href', imgElement.getAttribute(
                'src')); // Đặt href cho thẻ a bằng đường dẫn của hình ảnh
            aElement.setAttribute('data-fancybox', 'contentImage'); // Đặt data-fancybox để sử dụng FancyBox

            // Di chuyển hình ảnh vào trong thẻ a
            imgElement.parentNode.insertBefore(aElement, imgElement);
            aElement.appendChild(imgElement);
        });




        $(document).ready(function() {
            var wordsPerMinute = 250; // Trung bình 1 phút đọc được 200- 300 từ
            var content = $("body").text();
            var wordCount = content.trim().split(/\s+/).length; // Đếm chiều dài toàn bộ text
            var readingTime = Math.ceil(wordCount /
                wordsPerMinute); // Thời gian đọc bằng Chiều dài text / số từ đọc được trong 1 phút

            if (readingTime < 1) {
                readingTime = 1;
            }

            if (readingTime === 1) {
                $("#reading-time").text("Cần 1 phút để đọc");
            } else {
                $("#reading-time").text(readingTime + " phút để đọc");
            }
        });

        function progressBarScroll() {
            let winScroll = document.body.scrollTop || document.documentElement.scrollTop,
                height = document.documentElement.scrollHeight - document.documentElement.clientHeight,
                scrolled = (winScroll / height) * 100;
            document.getElementById("progressBar").style.width = scrolled + "%";
        }

        window.onscroll = function() {
            progressBarScroll();
        };



        $(function() {
            var height = 0;
            var bottom = 0;
            if ($(window).width() > 767) {
                height = 70;
                bottom = $("#footer__custom").innerHeight();
            } else {
                height = $(".nav__mobile").innerHeight();
                bottom = $("#footer__custom").innerHeight() + 100;
            }

            $('.sticky-srcoll').sticky({
                topSpacing: height,
                bottomSpacing: bottom
            });
        });




        function getYouTubeThumbnail(videoId) {
            return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        }
        var player;

        function onYouTubeIframeAPIReady(id) {
            player = new YT.Player('iframe-youtube', {
                height: '390',
                width: '640',
                videoId: id,
                playerVars: {
                    autoplay: 1, // Auto-play the video on load
                    mute: 0,
                    controls: 1, // Show pause/play buttons in player
                    showinfo: 1, // Hide the video title
                    modestbranding: 1, // Hide the Youtube Logo
                    loop: 1, // Run the video in a loop
                    fs: 0, // Hide the full screen button
                    // cc_load_policy: 0, // Hide closed captions
                    // iv_load_policy: 3,  // Hide the Video Annotations
                    playlist: id,
                    autohide: 1, // Hide video controls when playing
                    playsinline: 1, //forbid fullscreen on ios
                }
            });
        }

        const videoId = $('.lazyYT').data('youtube-id');
        const thumbnailUrl = getYouTubeThumbnail(videoId);
        $('.lazyYT img').prop('src', thumbnailUrl);



        $(document).on('click', '.lazyYT', function() {
            $('.video-popup').hide();
            $('.video-title').text($(this).data('title'));
            onYouTubeIframeAPIReady($(this).data('youtube-id'));

        })


        $(".video-item").on('click', function() {
            $("#box__video-show").show();
        });


        $(".close__youtube").on('click', function() {
            $("#box__video-show").hide();
        });
    </script>
@endsection


@endsection
