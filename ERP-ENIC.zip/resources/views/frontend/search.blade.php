@extends('layouts.master')


@section('title')
    {{ $keyword ?? '' }}
@endsection
@section('meta')
    <meta name="description" content=" {{ $keyword ?? '' }}" />
    <meta name="keywords" content=" {{ $keyword ?? '' }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" name="title" content="{{ $keyword ?? '' }}" />
    <meta property="og:description" content="{{ $keyword ?? '' }}" />
    <meta property="og:url" content={{ $keyword ?? '' }} />
    <link rel="canonical" href="{{ $url ?? '' }}" />
    <link rel="amphtml" href="{{ $url ?? '' }}" />
    <meta property="og:image" content= "" />
@endsection



@section('content')
    <main>
        <!-- Whats New Start -->
        <section class="whats-news-area pt-50 pb-20">
            <div class="container">
                {{-- <div class="short__categories">
                    <h2>{{ $data['category']->title ?? '' }}</h2>

                    <div>{!! html_entity_decode($data['category']->content ?? '') !!}</div>
                </div> --}}

                <div class="row">
                    @forelse ($searchInfo as $item)
                        <div class="col-md-4">
                            <div class="single-what-news single-what-news__custom">
                                <div class="what-img what-img__custom animation__image">
                                    <a href="{{ route('details.post', $item->url ?? '') }}">
                                        <img src="{{ asset('uploads/post/' . $item->image ?? '') }}"
                                            alt="{{ $item->title ?? '' }}">
                                    </a>
                                </div>
                                <div class="what-cap what__cap-custom">

                                    <h4><a class="text__title-post"
                                            href="{{ route('details.post', $item->url ?? '') }}">{{ $item->title ?? '' }}</a>
                                    </h4>

                                    <div class="desc__short-custom">{!! html_entity_decode($item->desc ?? '') !!}</div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="box__no-search">
                            <img src="{{asset('uploads/search-new.png')}}" alt="search">
                            <p>Không tìm thấy kết quả tìm kiếm với từ khoá  <strong>{{ $keyword ?? '' }}</strong></p>
                        </div>
                    
                    @endforelse
                </div>
            </div>
        </section>

        @if ($searchInfo->lastPage() > 1)
            <div class="col-md-12">
                {{ $searchInfo->links('common.Paging') ?? '' }}
            </div>
        @endif

    </main>
@endsection
