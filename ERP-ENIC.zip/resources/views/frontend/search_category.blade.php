@extends('layouts.master')

@section('content')

    <div class="site-wrapper-reveal">
        <!-- Blog Details Wrapper Start -->
        <div class="blog-details-wrapper section-space--ptb_80">
            <div class="container">
                <div class="row row--17">

                    @if ($searchInfo->count() > 1)
                        @foreach ($searchInfo as $item)
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <!-- Single Following Post Start -->
                                <div class="single-following-post" data-aos="fade-up">
                                    <a href="{{ url('tin-tuc/' . $item->slug) }}" class="following-post-thum">
                                        <img src="{{ asset('uploads/post/' . $item->image) }}" alt="">
                                    </a>
                                    <div class="following-post-content">
                                        <div class="following-blog-post-top">
                                            <div class="following-blog-post-author">
                                                <a style="font-size: 12px;"
                                                    href="{{ url('tac-gia/' . $item->user->id) }}">
                                                    Đăng
                                                    bởi {{ $item->user->name }}</a>
                                            </div>
                                        </div>
                                        <h5 class="following-blog-post-title">
                                            <a href="{{ url('tin-tuc/' . $item->slug) }}">{{ $item->title }}
                                            </a>
                                        </h5>
                                        <div class="following-blog-post-meta">
                                            <div class="post-meta-left-side">
                                                <span class="post-date">
                                                    <i class="icofont-ui-calendar"></i>
                                                    <a>{{ $item->updated_at }}</a>
                                                </span>

                                                <i class="far fa-eye"></i> {{ $item->post_view }} &ensp;
                                                <i class="fas fa-comment"></i>
                                                {{ $item->post_comment_count }}
                                            </div>

                                        </div>
                                    </div>
                                </div><!-- Single Following Post End -->
                            </div>
                        @endforeach


                        {{ $searchInfo->links('pagination::bootstrap-4') }}
                    @else
                        <h3>  Không tìm thấy kết quả nào phù hợp với từ khóa  <span style="color: red">{{$keyword}}</span></h3>
                        <ul>
                            <li>Kiểm tra lỗi chính tả của từ khóa đã nhập</li>
                            <li>Thử lại bằng từ khóa khác</li>
                            <li>Thử lại bằng những từ khóa tổng quát hơn</li>
                            <li>Thử lại bằng những từ khóa ngắn gọn hơn</li>
                        </ul>
                    @endif


                </div>
            </div>
        </div>




    </div>
@endsection
