@extends('layouts.master')
@section('title')
    {{ $data['meta_donate']->meta_seo ?? '' }}
@endsection
@section('meta')
    <meta name="description" content=" {{ $data['meta_donate']->desc_seo ?? '' }}" />
    <meta name="keywords" content=" {{ $data['meta_donate']->key_seo ?? '' }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" name="title" content="{{ $data['meta_donate']->meta_seo ?? '' }}" />
    <meta property="og:description" content="{{ $data['meta_donate']->desc_seo ?? '' }}" />
    <meta property="og:url" content={{ $data['url'] ?? '' }} />
    <link rel="canonical" href="{{ $data['url'] ?? '' }}" />
    <link rel="amphtml" href="{{ $data['url'] ?? '' }}" />
    <meta property="og:image" content={{ asset('uploads/menu/' . $data['meta_donate']->image ?? '') }} />
@endsection


@section('content')
    <section class="contact-section">
        <div class="container">



            <div class="row">
                <div style="display: flex; align-items: center; justify-content: center; width: 100%; gap: 10px">

                    <div style="display: flex; align-items: baseline">
                        <img style="width: 30px; height: 30px;" draggable="false" role="img" class="emoji" alt="✌️"
                            src="https://s.w.org/images/core/emoji/14.0.0/svg/270c.svg">

                        <h3> Mời TECHMARK một ly</h3>
                    </div>

                    <img style="width: 30px; height: 30px;" src="{{ asset('uploads/coffee.png') }}" alt="beer">
                </div>


                <p style="padding: 0px 20px;">Nếu bạn thấy những chia sẻ trên blog này hữu ích hãy mời chúng tôi một ly cà phê để có động lực ra nhiều
                    bài hướng dẫn mới nhé. Trân trọng biết ơn bạn!</p>


                <div class="wrapper__donate row">
                    <div class="col-md-6">
                        <div class="donate__box">
                            <img src="{{ asset('uploads/momo.jpg') }}" alt="momo">
                            <h3 class="text-center mt-5">SDT: 033.587.5867</h3>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="donate__box">
                            <img src="{{ asset('uploads/vietcombank.jpg') }}" alt="momo">
                            <h3 class="text-center mt-5">STK Vietcombank : 043.1000.244.033</h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
@endsection
