@extends('layouts.master')

@section('content')
    <div class="site-wrapper-reveal">

        <div class="login-register-page-area section-space--ptb_80">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6 m-auto">
                        <div class="login-content">

                            <div class="login-header mb-40">
                                <h5 class="text-center">Đăng Nhập</h5>
                            </div>
                            @if (session('status'))

                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    {{ session('status') }}

                                </div>
                            @endif
                            <form action="{{ url('check-login') }}" method="POST">
                                {{ csrf_field() }}
                                <input type="email" name="email" placeholder="Email" value="{{ old('email') }}">
                                <input type="password" name="password" placeholder="Mật Khẩu">
                                <button type="submit" class="btn-primary btn-large">Đăng Nhập</button>
                                <div class="member-register mt-5">
                                    <p> Bạn chưa có tài khoản ?<a href="{{ url('/register_customer') }}"> Đăng Ký Ngay</a>
                                    </p>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
