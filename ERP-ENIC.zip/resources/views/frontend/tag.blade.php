@extends('layouts.master')

@section('content')

    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_box text-center">
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Trang chủ</a></li>
                            <li class="breadcrumb-item active">{{ $tag_title }}</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="site-wrapper-reveal">
        <!-- Blog Details Wrapper Start -->
        <div class="blog-details-wrapper section-space--ptb_80">
            <div class="container">
                <div class="row row--17">


                    @foreach ($post_tag as $item)
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <!-- Single Following Post Start -->
                            <div class="single-following-post" data-aos="fade-up">
                                <a href="{{ url('tin-tuc/' . $item->slug) }}" class="following-post-thum">
                                    <img src="{{ asset('uploads/post/' . $item->image) }}" alt="">
                                </a>
                                <div class="following-post-content">
                                    <div class="following-blog-post-top">
                                        <div class="following-blog-post-author">
                                            <a style="font-size: 12px;" href="{{url('tac-gia/'.$item->user->id)}}"> Đăng bởi {{$item->user->name}}</a>
                                        </div>
                                    </div>
                                    <h5 class="following-blog-post-title">
                                        <a href="{{ url('tin-tuc/' . $item->slug) }}">{{ $item->title }}
                                        </a>
                                    </h5>
                                    <div class="following-blog-post-meta">
                                        <div class="post-meta-left-side">
                                            <span class="post-date">
                                                <i class="icofont-ui-calendar"></i>
                                                <a href="#">{{ $item->updated_at }}</a>
                                            </span>

                                            <i class="far fa-eye"></i> {{ $item->post_view }} &ensp;
                                            <i class="fas fa-comment"></i>
                                            {{ $item->post_comment_count }}
                                        </div>

                                    </div>
                                </div>
                            </div><!-- Single Following Post End -->
                        </div>
                    @endforeach


                </div>
            </div>
        </div> <!-- Blog Details Wrapper End -->

    </div>


@endsection
