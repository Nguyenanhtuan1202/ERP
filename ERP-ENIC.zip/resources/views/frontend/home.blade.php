@extends('layouts.master')
@section('title')
    {{ $data['menu_home']->meta_seo ?? '' }}
@endsection
@section('meta')
    <meta name="description" content=" {{ $data['menu_home']->desc_seo ?? '' }}" />
    <meta name="keywords" content=" {{ $data['menu_home']->key_seo ?? '' }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" name="title" content="{{ $data['menu_home']->meta_seo ?? '' }}" />
    <meta property="og:description" content="{{ $data['menu_home']->desc_seo ?? '' }}" />
    <meta property="og:url" content={{ $data['url'] ?? '' }} />
    <link rel="canonical" href="{{ $data['url'] ?? '' }}" />
    <link rel="amphtml" href="{{ $data['url'] ?? '' }}" />
    <meta property="og:image" content={{ asset('uploads/menu/' . $data['menu_home']->image ?? '') }} />
@endsection

@section('content')
    <main>
        <!-- Trending Area Start -->
        <div class="trending-area fix">
            <div class="container">
                <div class="trending-main">
                    <!-- Trending Tittle -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="trending-tittle">
                                <strong>Trending now</strong>
                                <!-- <p>Rem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                                <div class="trending-animated">
                                    <ul id="js-news" class="js-hidden">
                                        @foreach ($data['news'] as $item)
                                            <li class="news-item">

                                                <a
                                                    href="{{ route('details.post', $item->url ?? '') }}">{{ $item->title ?? '' }}</a>
                                            </li>
                                        @endforeach


                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <!-- Trending Top -->


                            @foreach ($data['post_news_1'] as $key => $item)
                                <div class="trending-top mb-30">
                                    <div class="trend-top-img">
                                        <a href="{{ route('details.post', $item->url ?? '') }}">
                                            <img src="{{ asset('uploads/post/' . $item->image) }}"
                                                alt="{{ $item->title ?? '' }}">
                                        </a>
                                        <div class="trend-top-cap">
                                            <a href="{{ url('danh-muc/' . $item->category[0]->url ?? '') }}"
                                                class="color1">{{ $item->category[0]->title ?? '' }}</a>
                                            <h2><a
                                                    href="{{ route('details.post', $item->url ?? '') }}">{!! html_entity_decode($item->title ?? '') !!}<br></a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            @endforeach

                            <!-- Trending Bottom -->
                            <div class="trending-bottom">
                                <div class="row">

                                    @foreach ($data['post_news_2'] as $item)
                                        <div class="col-lg-4">
                                            <div class="single-bottom mb-35">
                                                <div class="trend-bottom-img mb-30">
                                                    <a href="{{ route('details.post', $item->url ?? '') }}">
                                                        <img src="{{ asset('uploads/post/' . $item->image) }}"
                                                            alt="{{ $item->title ?? '' }}">
                                                    </a>
                                                </div>
                                                <div class="trend-bottom-cap">
                                                    <a href="{{ url('danh-muc/' . $item->category[0]->url ?? '') }}"
                                                        class="color1">{{ $item->category[0]->title ?? '' }}</a>
                                                    <h4><a
                                                            href="{{ route('details.post', $item->url ?? '') }}">{!! html_entity_decode($item->title ?? '') !!}</a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        <!-- Riht content -->
                        <div class="col-lg-4">
                            @foreach ($data['siderbarright'] as $item)
                                <div class="trand-right-single d-flex">
                                    <div class="trand-right-img">
                                        <a href="{{ route('details.post', $item->url ?? '') }}">
                                            <img src="{{ asset('uploads/post/' . $item->image) }}"
                                                alt="{!! html_entity_decode($item->title ?? '') !!}">
                                        </a>
                                    </div>
                                    <div class="trand-right-cap">
                                        <a href="{{ url('danh-muc/' . $item->category[0]->url ?? '') }}"
                                            class="color1">{{ $item->category[0]->title ?? '' }}</a>
                                        <h4><a
                                                href="{{ route('details.post', $item->url ?? '') }}">{!! html_entity_decode($item->title ?? '') !!}</a>
                                        </h4>
                                    </div>
                                </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- End Weekly-News -->
        <!-- Whats New Start -->
        <section class="whats-news-area pt-50 pb-20">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row d-flex justify-content-between">
                            <div class="col-lg-12 col-md-12">
                                <div class="section-tittle mb-30">
                                    <h3>Whats New</h3>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <!-- Nav Card -->
                                <div class="tab-content" id="nav-tabContent">
                                    <!-- card one -->
                                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                                        aria-labelledby="nav-home-tab">
                                        <div class="whats-news-caption">
                                            <div class="row">

                                                @foreach ($data['post_news_all'] as $item)
                                                    <div class="col-lg-12 col-md-12">
                                                        <div class="single-what-news single-what-news-custom">
                                                            <div class="what-img">
                                                                <a href="{{ route('details.post', $item->url ?? '') }}">
                                                                    <img src="{{ asset('uploads/post/' . $item->image) }}"
                                                                        alt="{{ $item->title ?? '' }}">
                                                                </a>
                                                            </div>
                                                            <div class="what-cap">
                                                                <a href="{{ url('danh-muc/' . $item->category[0]->url ?? '') }}"
                                                                    class="color1">{{ $item->category[0]->title ?? '' }}</a>
                                                                <h4><a class="text__title-post"
                                                                        href="{{ route('details.post', $item->url ?? '') }}">{!! html_entity_decode($item->title ?? '') !!}</a>
                                                                </h4>
                                                               
                                                                <div class="desc__short-custom">{!! html_entity_decode($item->desc ?? '') !!}</div>

                                                                <small>{{ $item->updated_at->diffForHumans() }}</small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach



                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- End Nav Card -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <!-- Section Tittle -->
                        <div class="section-tittle mb-40">
                            <h3 class="category__title">DANH MỤC</h3>
                        </div>

                        <ul class="list__categories">

                            @foreach ($data['category'] as $item)
                                <li>
                                    <a href="{{ url('danh-muc/' . $item->url ?? '') }}">{{ $item->title ?? '' }}</a>
                                </li>
                            @endforeach


                        </ul>
                        <!-- Flow Socail -->

                        <!-- New Poster -->
                        <div class="news-poster d-none d-lg-block">
                            <img src="public/frontend/assets/img/news/news_card.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--  Recent Articles start -->
        <div class="recent-articles">
            <div class="container">
                <div class="recent-wrapper">
                    <!-- section Tittle -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-tittle mb-30">
                                <h3>TIPS & TRICKS </h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="recent-active dot-style d-flex dot-style">

                                @foreach ($data['tips'] as $item)
                                    <div class="col-md-4">
                                        <div class="single-what-news single-what-news__custom">
                                            <div class="what-img what-img__custom animation__image">
                                                <a href="{{ route('details.post', $item->url ?? '') }}">
                                                    <img src="{{ asset('uploads/post/' . $item->image ?? '') }}"
                                                        alt="{{ $item->title ?? '' }}">
                                                </a>
                                            </div>
                                            <div class="what-cap what__cap-custom">

                                                <h4><a class="text__title-post"
                                                        href="{{ route('details.post', $item->url ?? '') }}">{{ $item->title ?? '' }}</a>
                                                </h4>

                                                <div class="desc__short-custom">{!! html_entity_decode($item->desc ?? '') !!}</div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- End pagination  -->
    </main>
@endsection
