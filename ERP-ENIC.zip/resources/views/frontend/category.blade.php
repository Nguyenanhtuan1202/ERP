@extends('layouts.master')


@section('title')
    {{ $data['menus']->meta_seo ?? '' }}
@endsection
@section('meta')
    <meta name="description" content=" {{ $data['menus']->desc_seo ?? '' }}" />
    <meta name="keywords" content=" {{ $data['menus']->key_seo ?? '' }}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" name="title" content="{{ $data['menus']->meta_seo ?? '' }}" />
    <meta property="og:description" content="{{ $data['menus']->desc_seo ?? '' }}" />
    <meta property="og:url" content={{ $data['url'] ?? '' }} />
    <link rel="canonical" href="{{ $data['url'] ?? '' }}" />
    <link rel="amphtml" href="{{ $data['url'] ?? '' }}" />
    <meta property="og:image" content={{ asset('uploads/menu/' . $data['menus']->image ?? '') }} />
@endsection



@section('content')

    <main>
        <!-- Whats New Start -->
        <section class="whats-news-area pt-50 pb-20" style="margin-top: 60px">
            <div class="container">
                <div class="short__categories">
                    <h2>{{ $data['category']->title ?? '' }}</h2>

                    <div>{!! html_entity_decode($data['category']->content ?? '') !!}</div>
                </div>

                <div class="row">
                    @foreach ($data['post__category'] as $item)
                        <div class="col-md-4">
                            <div class="single-what-news single-what-news__custom">
                                <div class="what-img what-img__custom animation__image">
                                    <a href="{{ route('details.post', $item->url ?? '') }}">
                                        <img src="{{ asset('uploads/post/' . $item->image ?? '') }}"
                                            alt="{{ $item->title ?? '' }}">
                                    </a>
                                </div>
                                <div class="what-cap what__cap-custom">

                                    <h4><a class="text__title-post"
                                            href="{{ route('details.post', $item->url ?? '') }}">{{ $item->title ?? '' }}</a>
                                    </h4>

                                    <div class="desc__short-custom">{!! html_entity_decode($item->desc ?? '') !!}</div>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </section>
        <!-- Whats New End -->


        {{-- <!--Start pagination -->
        <div class="pagination-area pb-45 text-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="single-wrap d-flex justify-content-center">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-start">
                                    <li class="page-item"><a class="page-link" href="#"><span
                                                class="flaticon-arrow roted"></span></a></li>
                                    <li class="page-item active"><a class="page-link" href="#">01</a></li>
                                    <li class="page-item"><a class="page-link" href="#">02</a></li>
                                    <li class="page-item"><a class="page-link" href="#">03</a></li>
                                    <li class="page-item"><a class="page-link" href="#"><span
                                                class="flaticon-arrow right-arrow"></span></a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}


        @if ($data['post__category']->lastPage() > 1)
        <div class="col-md-12">
            {{ $data['post__category']->links('common.Paging') ?? '' }}
        </div>
    @endif




        <!-- End pagination  -->
    </main>
@endsection
