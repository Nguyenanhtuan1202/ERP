@extends('layouts.master')

@section('content')
    
<div class="site-wrapper-reveal">
    <!-- Blog Details Wrapper Start -->
    <div class="blog-details-wrapper section-space--ptb_80">
        <div class="container">
            <div class="row row--17">
                <div class="blog-details-col-8">


                    <div class="masonry-activation">
                        <div class="row mesonry-list">
                            <div class="masonary-sizer col-1"></div>
                            <!-- Author Blog Post Wrap Start -->
                        


                            @foreach ($postOfAuthor as $item)
                            <div class="author-blog-post-wrap masonary-item cat--2 mb-2" >
                                <a href="{{ url('tin-tuc/' . $item->slug) }}">
                                    <img src="{{asset('uploads/post/'.$item->image)}}" alt="">
                                </a>
                                <div class="author-blog-post-content">
                                    <div class="blog-details-meta-box">
                                        <div class="post-meta-left-side mb-2">
                                            <div class="blog-post-category">

                                                @foreach ($item->category as $item_cat)
                                                <a href="{{url('danh-muc/'.$item_cat->slug)}}" class="btn-medium lifesytle ">{{$item_cat->title}}</a> <br>
                                                @endforeach
                                                
                                            </div>
                                            <div class="blog-post-author">
                                                <a> Tác giả {{$item->user->name}}</a>
                                            </div>
                                        </div>
                                        <div class="post-right-side mb-2">
                                            <span class="post-meta-left-side">
                                            
                                            </span>
                                           
                                        </div>
                                    </div>
                                    <h3 class="title mb-2">
                                        <a href="{{ url('tin-tuc/' . $item->slug) }}">{{ $item->title }}
                                        </a>
                                    </h3>
                                    <p class="mb-2">{!!$item->desc!!}</p>

                                    <div class="author-post-bottom-area">
                                        <div class="author-post-action-box">
                                            <div class="author-action">
                                                <i class="far fa-eye"></i> {{ $item->post_view }}
                                            </div>
                                            <div class="author-action">
                                                <img src="/public/frontend/assets/images/icons/message.png" alt="">
                                                <span class="count">{{$item->post_comment_count}}</span>
                                                &ensp;
                                                <span class="post-date">
                                                    <i class="icofont-ui-calendar"></i> 
                                                    <a >{{$item->updated_at}}</a>
                                                </span>
                                            </div>
                                        </div>
                                       
                                    </div>

                                </div>
                            </div><!-- Author Blog Post Wrap End -->   
                            @endforeach
                  


                            {{$postOfAuthor->links("pagination::bootstrap-4")}}

                        </div>
                    </div>
                </div>
                <div class="blog-details-col-4 sticky-top">
                    <div class="following-author-area">
                        <div class="author-image" data-aos="fade-up">
                            <img src="/public/frontend/assets/images/author/author-01.png" alt="">
                        </div>
                        <div class="author-title">
                            <h4><a>{{$author->name}}</a></h4>
                            <p>{{$author->email}}</p>
                        </div>
                        <div class="author-details">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div> <!-- Blog Details Wrapper End -->

    <!-- Trending Topic Area End -->
</div>
@endsection