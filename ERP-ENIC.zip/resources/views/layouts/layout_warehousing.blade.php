<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('backend/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/style_factory.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/select2.min.css') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('erp/mua-hang.png') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css.map') }}">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <title>Phần Mềm Quản Lý </title>
    {{-- <script src="https://cdn.ckeditor.com/ckeditor5/31.1.0/classic/ckeditor.js"></script> --}}
    <script src="{{ asset('backend/js/ckeditor/ckeditor.js') }}"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.css">
    @yield('css')

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>



    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css"
        integrity="sha512-H9jrZiiopUdsLpg94A333EfumgUBpO9MdbxStdeITo+KEIMaNfHNvwyjjDJb+ERPaRS6DpyRlKbvPUasNItRyw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body style="">
    <div id="warpper" class="nav-fixed container-fu">
        <nav class="topnav shadow navbar-light bg-white d-flex">
            <div class="navbar-brand">
                <a href="{{ url('/dashboard') }}" style="text-transform: uppercase">
                    <img width="120px" style="width: 120px;" src="{{ asset('erp/logo-white.png') }}"
                        alt="logo-white.png">
                </a>

            </div>
            <div class="nav-right ">
                <div class="btn-group mr-auto">

                </div>
                <div class="btn-group">
                    <button style="color:#fff; font-weight:bold; font-size:17px" type="button"
                        class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ Auth::user()->name }}
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a style="color: black" class="dropdown-item" href="{{ url('admin/user/info') }}"> Thông Tin
                            Tài khoản <i style="color: black" class="fas fa-user-check"></i></a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            {{ __('Logout') }} <i style="color: black" class="fas fa-sign-out-alt"></i>
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </div>
            </div>
        </nav>

        <!-- end nav  -->
        <div id="page-body" class="d-flex mt-5">
            @yield('content')
        </div>

        <div class="bottom-nav">
            <a href="{{ url('/') }}" class="active"><i class="fas fa-home"></i> Trang Chủ</a>
            <a href="{{ route('delivery.showdelivery') }}"><i class="fas fa-truck-moving"></i> Hàng Về Kho</a>
            <a href="{{ route('delivery.orderReceived') }}"><i class="fas fa-outdent"></i>Hàng Đã Nhận</a>
            {{-- <a href="{{ route('notes.index') }}"><i class="fas fa-edit"></i> Ghi Chú</a> --}}
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="{{ asset('backend/js/select2.min.js') }}"></script>
    <script src="{{ asset('backend/js/app.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-select.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Query Data Table -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"
        integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('ab2f1ccfac30f66a82de', {
            cluster: 'ap1'
        });

        var audioPath = "{{ asset('audio/livechat.mp3') }}"; // Gán URL vào biến JavaScript
        var channel = pusher.subscribe('notify-ware-housing');

        channel.bind('form-submit-ware-housing', function(data) {
            // Phát âm thanh thông báo
            var audio = new Audio(audioPath);
            audio.play().catch(error => console.error("Không thể phát âm thanh:", error));

            // Hiển thị thông báo với SweetAlert2
            Swal.fire({
                title: 'Thông báo',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#3085d6',
                background: '#fff',
                allowOutsideClick: false, // Không cho phép đóng bằng cách click ra ngoài
                allowEscapeKey: false, // Không cho phép đóng bằng phím ESC
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.reload(); // Chỉ reload nếu người dùng bấm "OK"
                }
            });
        });

        $(document).ready(function() {
            for (let i = 0; i <= 1000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }
        });
    </script>
    @yield('js')
</body>

</html>
