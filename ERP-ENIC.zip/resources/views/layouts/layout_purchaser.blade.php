<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('backend/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/select2.min.css') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('erp/enic.png') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css.map') }}">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <title>ERP ENIC</title>
    {{-- <script src="https://cdn.ckeditor.com/ckeditor5/31.1.0/classic/ckeditor.js"></script> --}}
    <script src="{{ asset('backend/js/ckeditor/ckeditor.js') }}"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.css">


    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">


    @yield('css')


</head>

<body>
    <div id="warpper" class="nav-fixed container-fu">
        <nav class="topnav shadow navbar-light bg-white d-flex">
            <div class="navbar-brand">
                <a href="{{ url('/dashboard') }}" style="text-transform: uppercase">
                    <img width="120px" style="width: 120px;" src="{{ asset('erp/logo-white.png') }}"
                        alt="logo-white.png">
                </a>

            </div>
            <div class="nav-right ">
                <div class="btn-group mr-auto">

                </div>
                <div class="btn-group">
                    <button style="color:#fff; font-weight:bold; font-size:17px" type="button"
                        class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ Auth::user()->name }}
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a style="color: black" class="dropdown-item" href="{{ url('admin/user/info') }}"> Thông Tin
                            Tài khoản <i style="color: black" class="fas fa-user-check"></i></a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            {{ __('Logout') }} <i style="color: black" class="fas fa-sign-out-alt"></i>
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </div>


                <div>
                    <div class="nav-item dropdown">
                        <a style="margin-right: 20px" class="nav-link" data-toggle="dropdown">
                            <i style="font-size: 22px; color: #fff; cursor: pointer !important;"
                                class="far fa-bell"></i>
                            @php
                                $unreadCount = \App\Models\Notification::where('user_id', Auth::id())
                                    ->where('is_read', false)
                                    ->count();
                            @endphp
                            @if ($unreadCount > 0)
                                <span class="badge badge-warning navbar-badge">{{ $unreadCount }}</span>
                            @endif
                        </a>
                        <div style="max-height: 350px; overflow-y: scroll;"
                            class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            @foreach (\App\Models\Notification::where('user_id', Auth::id())->orderBy('created_at', 'desc')->get() as $notification)
                                <div class="dropdown-item notification-item" data-id="{{ $notification->id }}">
                                    <div class="d-flex justify-content-between align-items-center" style="gap: 10px">
                                        <div style="display: flex; gap: 5px; align-items: center;">
                                            @if (!$notification->is_read)
                                                <i class="fas fa-envelope mr-2"></i>
                                            @else
                                                <i class="fas fa-envelope-open mr-2 text-muted"></i>
                                            @endif
                                            <div
                                                style="width: 300px; overflow-wrap: break-word; white-space: normal; word-break: break-all; font-size: 14px; line-height: 25px;">
                                                {{ $notification->message }}
                                            </div>


                                            <br>
                                            <small
                                                class="text-muted">{{ $notification->created_at->diffForHumans() }}</small>
                                        </div>
                                        <div>
                                            @if (!$notification->is_read)
                                                <a href="#" style="font-size: 12px" class="mark-read"
                                                    title="Đã đọc">
                                                    Đã đọc <i class="fas fa-check-circle text-success"></i>
                                                </a>
                                            @endif
                                            <a href="#" style="font-size: 12px" class="delete-notification ml-2"
                                                title="Xóa">
                                                Xoá <i class="fas fa-trash-alt text-danger"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end nav  -->
        <div id="page-body" class="d-flex">

            <div class="container-fluid" style="margin-top: 100px">
                @yield('content')

                <div id="chatboxAI">
                    <!-- AI Chat Button -->
                    <div class="chat-button" id="chatButton">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                    </div>


                    <!-- AI Chat Container -->
                    <div class="chat-container" id="chatContainer">
                        <div class="chat-header">
                            <div class="chat-title">Trợ lý ảo thông minh</div>
                            <div class="close-chat" id="closeChat">&times;</div>
                        </div>
                        <div class="chat-messages" id="chatMessages">
                            <div class="message bot">
                                <div class="ai-avatar">AI</div>
                                <div class="message-content">
                                    Dạ, xin chào {{ Auth::user()->name ?? 'quý khách' }}! Em là trợ lý AI. Em có thể
                                    giúp gì cho
                                    anh/chị hôm nay ạ?
                                </div>
                            </div>
                        </div>
                        <div id="errorContainer" class="error-message" style="display: none;"></div>
                        <div class="chat-input">
                            <input type="text" id="messageInput" placeholder="Nhập tin nhắn của bạn...">
                            <button class="send-button" id="sendButton">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="22" y1="2" x2="11" y2="13"></line>
                                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="{{ asset('backend/js/select2.min.js') }}"></script>
    <script src="{{ asset('backend/js/app.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-select.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Query Data Table -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            let chatSessionId = "{{ session()->getId() }}";

            const chatButton = document.getElementById('chatButton');
            const chatContainer = document.getElementById('chatContainer');
            const closeChat = document.getElementById('closeChat');
            const sendButton = document.getElementById('sendButton');
            const messageInput = document.getElementById('messageInput');
            const chatMessages = document.getElementById('chatMessages');
            const errorContainer = document.getElementById('errorContainer');

            // Get CSRF token for Laravel AJAX requests
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Lấy URL route từ Laravel
            const processAiRoute = "{{ route('productManagement.processAi') }}";
            const createSessionRoute = "{{ route('productManagement.create-session') }}";

            chatButton.addEventListener('click', function() {

                chatContainer.classList.add('chat-active');

                // Tạo session mới khi mở chat box (nếu chưa có)
                if (chatSessionId) {
                    createChatSession();
                }
            });

            closeChat.addEventListener('click', function() {
                chatContainer.classList.remove('chat-active');
            });

            sendButton.addEventListener('click', sendMessage);
            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });

            // Hàm tạo session chat mới

            function createChatSession() {
                $.ajax({
                    url: "{{ route('productManagement.create-session') }}",
                    method: 'POST',
                    contentType: 'application/json',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    data: JSON.stringify({
                        user_id: "{{ Auth::id() ?? '' }}", // Lấy ID người dùng nếu đã đăng nhập, nếu không thì là 'guest'
                        user_info: {
                            ip: "{{ request()->ip() }}",
                            user_agent: navigator.userAgent,
                            page: window.location.href
                        }
                    }),
                    dataType: 'json',
                    success: function(data) {
                        if (data.success) {
                            chatSessionId = data.session_id;
                            console.log("Chat session created with ID:", chatSessionId);

                            // Lưu tin nhắn chào mừng ban đầu
                            // saveMessage(
                            //     "Dạ, xin chào quý khách! Em là trợ lý AI. Em có thể giúp gì cho anh/chị hôm nay ạ?",
                            //     'bot');
                        } else {
                            console.error("Failed to create chat session:", data.message);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error("Error creating chat session:", textStatus, errorThrown);
                    }
                });
            }




            function sendMessage() {
                const message = messageInput.value.trim();
                if (message === '') return;

                // Add user message
                addMessage(message, 'user');

                // Lưu tin nhắn người dùng vào database
                saveMessage(message, 'user');

                messageInput.value = '';

                // Show typing indicator
                const typingIndicator = document.createElement('div');
                typingIndicator.className = 'message bot';
                typingIndicator.innerHTML = `
<div class="ai-avatar">AI</div>
<div class="message-content typing-indicator">
<div class="typing-dot"></div>
<div class="typing-dot"></div>
<div class="typing-dot"></div>
</div>
`;
                chatMessages.appendChild(typingIndicator);
                chatMessages.scrollTop = chatMessages.scrollHeight;

                // Hide any previous errors
                errorContainer.style.display = 'none';

                // Send message using AJAX
                $.ajax({
                    url: processAiRoute,
                    method: 'POST',
                    data: {
                        keyword: message,
                        session_id: chatSessionId
                    },
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    dataType: 'json',
                    success: function(data) {
                        // Remove typing indicator
                        chatMessages.removeChild(typingIndicator);

                        if (data.success) {
                            // Add AI response
                            addMessage(data.data, 'bot');

                            // Lưu tin nhắn AI vào database
                            saveMessage(data.data, 'bot');
                        } else {
                            // Show error
                            showError(data.message || 'Có lỗi xảy ra khi xử lý tin nhắn.');
                        }
                    },
                    error: function(xhr, status, error) {
                        // Remove typing indicator
                        chatMessages.removeChild(typingIndicator);

                        // Show error message
                        console.error('AJAX Error:', error);
                        showError('Không thể kết nối với máy chủ. Vui lòng thử lại sau.');
                    }
                });
            }


            // Hàm lưu tin nhắn vào database
            function saveMessage(content, sender_type) {
                if (!chatSessionId) return;

                fetch("{{ route('productManagement.save-message') }}", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            session_id: chatSessionId,
                            content: content,
                            sender_type: sender_type
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (!data.success) {
                            console.error("Failed to save message:", data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error saving message:', error);
                    });
            }

            function addMessage(text, sender) {
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}`;

                if (sender === 'bot') {
                    messageDiv.innerHTML = `
    <div class="ai-avatar">AI</div>
    <div class="message-content">${formatMessage(text)}</div>
`;
                } else {
                    messageDiv.innerHTML = `
    <div class="message-content">${formatMessage(text)}</div>
    <div class="user-avatar">Bạn</div>
`;
                }

                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            function showError(message) {
                errorContainer.textContent = message;
                errorContainer.style.display = 'block';
            }

            function formatMessage(text) {
                // Format message text (e.g., convert line breaks to <br>)
                return text.replace(/\n/g, '<br>');
            }

            // Handle connection errors by adding a retry option
            window.addEventListener('online', function() {
                // Remove error message if the connection is restored
                if (errorContainer.style.display !== 'none') {
                    errorContainer.style.display = 'none';
                    addMessage('Kết nối đã được khôi phục. Bạn có thể tiếp tục cuộc hội thoại.',
                        'bot');
                }
            });
        });


        /* End AI Trợ Lý */

        $(document).ready(function() {
            // Đánh dấu thông báo đã đọc
            $('.mark-read').click(function(e) {
                e.preventDefault();
                e.stopPropagation(); // Ngăn dropdown đóng khi click vào nút
                var li = $(this).closest('.notification-item');
                var id = li.data('id');
                var markReadUrl = "{{ route('notifications.markAsRead', ['id' => ':id']) }}".replace(':id',
                    id);
                $.ajax({
                    url: markReadUrl,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            // Loại bỏ nút "Đã đọc" và chuyển icon thành envelope-open
                            li.find('.mark-read').remove();
                            li.find('i').removeClass('fa-envelope').addClass(
                                'fa-envelope-open text-muted');
                        }
                    }
                });
            });

            // Xóa thông báo
            $('.delete-notification').click(function(e) {
                e.preventDefault();
                e.stopPropagation(); // Ngăn dropdown đóng khi click vào nút
                var li = $(this).closest('.notification-item');
                var id = li.data('id');
                var deleteUrl = "{{ route('notifications.destroy', ['id' => ':id']) }}".replace(':id', id);
                $.ajax({
                    url: deleteUrl,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            li.remove();
                        }
                    }
                });
            });
        });
    </script>




    <script type="text/javascript">
        $('.select2_init').select2({

            'placeholder': 'Chọn vai trò'
        });
        $('.select3_init').select2({

            'placeholder': 'Chọn'
        });

        $(document).ready(function() {
            for (let i = 0; i <= 1000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }
        });
    </script>

    <script>
        $(".checkbox_wrapper").on('click', function() {

            $(this).parents('.card-check').find('.checkbox_child').prop('checked', $(this).prop('checked'));
        });
    </script>




    {{-- 
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('ab2f1ccfac30f66a82de', {
            cluster: 'ap1'
        });

        var channel = pusher.subscribe('notify-channel-enic');
        channel.bind('form-submit-enic', function(data) {
            Swal.fire({
                title: 'Thông báo',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#3085d6',
                background: '#fff',
                // timer: 5000, // Tự động đóng sau 5 giây
                // timerProgressBar: true,
            });
        });
    </script> --}}




    @yield('js')

</body>

</html>
