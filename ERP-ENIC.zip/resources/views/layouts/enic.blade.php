<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('backend/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/select2.min.css') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('erp/enic.png') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap-select.css.map') }}">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <title>ERP ENIC</title>
    {{-- <script src="https://cdn.ckeditor.com/ckeditor5/31.1.0/classic/ckeditor.js"></script> --}}
    <script src="{{ asset('backend/js/ckeditor/ckeditor.js') }}"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.css">


    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">


    @yield('css')


</head>



<body>
    <div id="warpper" class="nav-fixed container-fluid">
        <nav class="topnav shadow navbar-light bg-white d-flex">
            <div class="navbar-brand">
                <a href="{{ url('/dashboard') }}" style="text-transform: uppercase">
                    <img width="120px" style="width: 120px;" src="{{ asset('erp/logo-white.png') }}"
                        alt="logo-white.png">
                </a>

            </div>
            <div class="nav-right ">
                <div class="btn-group mr-auto">

                </div>
                <div class="btn-group">
                    <button style="color:#fff; font-weight:bold; font-size:17px" type="button"
                        class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ Auth::user()->name }}
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a style="color: black" class="dropdown-item" href="{{ url('admin/user/info') }}"> Thông Tin
                            Tài khoản <i style="color: black" class="fas fa-user-check"></i></a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            {{ __('Logout') }} <i style="color: black" class="fas fa-sign-out-alt"></i>
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </div>


                <div>
                    <div class="nav-item dropdown">
                        <a style="margin-right: 20px" class="nav-link" data-toggle="dropdown">
                            <i style="font-size: 22px; color: #fff; cursor: pointer !important;"
                                class="far fa-bell"></i>
                            @php
                                $unreadCount = \App\Models\Notification::where('user_id', Auth::id())
                                    ->where('is_read', false)
                                    ->count();
                            @endphp
                            @if ($unreadCount > 0)
                                <span class="badge badge-warning navbar-badge">{{ $unreadCount }}</span>
                            @endif
                        </a>
                        <div style="max-height: 350px; overflow-y: scroll;"
                            class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            @foreach (\App\Models\Notification::where('user_id', Auth::id())->orderBy('created_at', 'desc')->get() as $notification)
                                <div class="dropdown-item notification-item" data-id="{{ $notification->id }}">
                                    <div class="d-flex justify-content-between align-items-center" style="gap: 10px">
                                        <div style="display: flex; gap: 5px; align-items: center;">
                                            @if (!$notification->is_read)
                                                <i class="fas fa-envelope mr-2"></i>
                                            @else
                                                <i class="fas fa-envelope-open mr-2 text-muted"></i>
                                            @endif
                                            <div
                                                style="width: 300px; overflow-wrap: break-word; white-space: normal; word-break: break-all; font-size: 14px; line-height: 25px;">
                                                {{ $notification->message }}
                                            </div>


                                            <br>
                                            <small
                                                class="text-muted">{{ $notification->created_at->diffForHumans() }}</small>
                                        </div>
                                        <div>
                                            @if (!$notification->is_read)
                                                <a href="#" style="font-size: 12px" class="mark-read"
                                                    title="Đã đọc">
                                                    Đã đọc <i class="fas fa-check-circle text-success"></i>
                                                </a>
                                            @endif
                                            <a href="#" style="font-size: 12px" class="delete-notification ml-2"
                                                title="Xóa">
                                                Xoá <i class="fas fa-trash-alt text-danger"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown-divider"></div>
                            @endforeach

                        </div>
                    </div>




                </div>


            </div>
        </nav>
        <!-- end nav  -->
        <div id="page-body" class="d-flex">

            <div class="container-fluid">
                @yield('content')
            </div>


        </div>


    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="{{ asset('backend/js/select2.min.js') }}"></script>
    <script src="{{ asset('backend/js/app.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-select.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Query Data Table -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).ready(function() {
            // Đánh dấu thông báo đã đọc
            $('.mark-read').click(function(e) {
                e.preventDefault();
                e.stopPropagation(); // Ngăn dropdown đóng khi click vào nút
                var li = $(this).closest('.notification-item');
                var id = li.data('id');
                var markReadUrl = "{{ route('notifications.markAsRead', ['id' => ':id']) }}".replace(':id',
                    id);
                $.ajax({
                    url: markReadUrl,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            // Loại bỏ nút "Đã đọc" và chuyển icon thành envelope-open
                            li.find('.mark-read').remove();
                            li.find('i').removeClass('fa-envelope').addClass(
                                'fa-envelope-open text-muted');
                        }
                    }
                });
            });

            // Xóa thông báo
            $('.delete-notification').click(function(e) {
                e.preventDefault();
                e.stopPropagation(); // Ngăn dropdown đóng khi click vào nút
                var li = $(this).closest('.notification-item');
                var id = li.data('id');
                var deleteUrl = "{{ route('notifications.destroy', ['id' => ':id']) }}".replace(':id', id);
                $.ajax({
                    url: deleteUrl,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            li.remove();
                        }
                    }
                });
            });
        });
    </script>




    <script type="text/javascript">
        $('.select2_init').select2({

            'placeholder': 'Chọn vai trò'
        });
        $('.select3_init').select2({

            'placeholder': 'Chọn'
        });

        $(document).ready(function() {
            for (let i = 0; i <= 1000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }
        });
    </script>

    <script>
        $(".checkbox_wrapper").on('click', function() {

            $(this).parents('.card-check').find('.checkbox_child').prop('checked', $(this).prop('checked'));
        });
    </script>





    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('ab2f1ccfac30f66a82de', {
            cluster: 'ap1'
        });

        var channel = pusher.subscribe('notify-channel-enic');
        channel.bind('form-submit-enic', function(data) {
            Swal.fire({
                title: 'Thông báo',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#3085d6',
                background: '#fff',
                // timer: 5000, // Tự động đóng sau 5 giây
                // timerProgressBar: true,
            });
        });
    </script>




    @yield('js')

</body>

</html>
