@extends('layouts.admin')

@section('content')
    <style>
        /* Container chính */
        .create-container {
            max-width: 100%;
            margin: 2rem auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Tiêu đề */
        .create-container h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }

        /* Accordion style */
        .accordion .card {
            border: none;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .accordion .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 1rem;
            border-bottom: none;
        }

        .accordion .card-header .btn-link {
            color: #fff;
            text-decoration: none;
            font-size: 1.125rem;
            font-weight: 500;
        }

        .accordion .card-body {
            background-color: #f8f9fa;
            padding: 1.5rem;
        }

        /* Form elements */
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #555;
        }

        .form-control {
            border-radius: 4px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Nút submit */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            font-weight: bold;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 1.5rem auto 0;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>
    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="create-container">
        <h1>Chỉnh sửa Container</h1>
        <form action="{{ route('containers.update', ['id' => $container->id]) }}" method="POST">
            @csrf
            <div class="accordion" id="containerAccordion">
                <!-- Khối Thông tin cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic"
                                aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                        data-parent="#containerAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Số Container</label>
                                <input type="text" name="container_number" class="form-control"
                                    value="{{ old('container_number', $container->container_number) }}" required>
                            </div>
                            <div class="form-group">
                                <label>Loại</label>
                                <select name="type" class="form-control" required>
                                    <option value="20ft" {{ old('type', $container->type) == '20ft' ? 'selected' : '' }}>
                                        20ft</option>
                                    <option value="40ft" {{ old('type', $container->type) == '40ft' ? 'selected' : '' }}>
                                        40ft</option>
                                    <option value="Reefer"
                                        {{ old('type', $container->type) == 'Reefer' ? 'selected' : '' }}>Reefer</option>
                                    <option value="Open Top"
                                        {{ old('type', $container->type) == 'Open Top' ? 'selected' : '' }}>Open Top
                                    </option>
                                    <option value="Flat Rack"
                                        {{ old('type', $container->type) == 'Flat Rack' ? 'selected' : '' }}>Flat Rack
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tình trạng</label>
                                <select name="status" class="form-control" required>
                                    <option value="Đang sử dụng"
                                        {{ old('status', $container->status) == 'Đang sử dụng' ? 'selected' : '' }}>Đang sử
                                        dụng</option>
                                    <option value="Rỗng"
                                        {{ old('status', $container->status) == 'Rỗng' ? 'selected' : '' }}>Rỗng</option>
                                    <option value="Bị hỏng"
                                        {{ old('status', $container->status) == 'Bị hỏng' ? 'selected' : '' }}>Bị hỏng
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin bổ sung -->
                <div class="card">
                    <div class="card-header" id="headingAdditional">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseAdditional" aria-expanded="false" aria-controls="collapseAdditional">
                                Thông tin bổ sung
                            </button>
                        </h2>
                    </div>
                    <div id="collapseAdditional" class="collapse" aria-labelledby="headingAdditional"
                        data-parent="#containerAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Số Seal</label>
                                <input type="text" name="seal_number" class="form-control"
                                    value="{{ old('seal_number', $container->seal_number) }}">
                            </div>
                            <div class="form-group">
                                <label>Vị trí</label>
                                <input type="text" name="location" class="form-control"
                                    value="{{ old('location', $container->location) }}">
                            </div>
                            <div class="form-group">
                                <label>Trọng lượng</label>
                                <input type="number" step="0.01" name="weight" class="form-control"
                                    value="{{ old('weight', $container->weight) }}">
                            </div>
                            <div class="form-group">
                                <label>Kích thước</label>
                                <input type="text" name="dimensions" class="form-control"
                                    value="{{ old('dimensions', $container->dimensions) }}">
                            </div>
                            <div class="form-group">
                                <label>Lô hàng (Shipment)</label>
                                <select name="shipment_id" class="form-control" required>
                                    <option value="">Chọn lô hàng</option>
                                    @foreach ($shipments as $shipment)
                                        <option value="{{ $shipment->id }}"
                                            {{ old('shipment_id', $container->shipment_id) == $shipment->id ? 'selected' : '' }}>
                                            {{ $shipment->tracking_number }} - {{ $shipment->origin_port }} →
                                            {{ $shipment->destination_port }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success">Cập nhật Container</button>
        </form>
    </div>
@endsection
