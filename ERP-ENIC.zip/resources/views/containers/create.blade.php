@extends('layouts.admin')

@section('content')
    <style>
        /* Container chính */
        .create-container {
            max-width: 100%;
            margin: 2rem auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Tiêu đề */
        .create-container h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }

        /* Accordion style */
        .accordion .card {
            border: none;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .accordion .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 1rem;
            border-bottom: none;
        }

        .accordion .card-header .btn-link {
            color: #fff;
            text-decoration: none;
            font-size: 1.125rem;
            font-weight: 500;
        }

        .accordion .card-body {
            background-color: #f8f9fa;
            padding: 1.5rem;
        }

        /* Form elements */
        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #555;
        }

        .form-control {
            border-radius: 4px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Nút submit */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            font-weight: bold;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 1.5rem auto 0;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>


    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="create-container">
        <h1>Thêm Container mới</h1>
        <form action="{{ route('containers.store') }}" method="POST">
            @csrf
            <div class="accordion" id="containerAccordion">
                <!-- Khối Thông tin cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic"
                                aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                        data-parent="#containerAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Số Container</label>
                                <input type="text" value="{{ old('container_number') }}" name="container_number"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Loại</label>
                                <select name="type" class="form-control" required>
                                    <option value="20ft">20ft</option>
                                    <option value="40ft">40ft</option>
                                    <option value="Reefer">Reefer</option>
                                    <option value="Open Top">Open Top</option>
                                    <option value="Flat Rack">Flat Rack</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tình trạng</label>
                                <select name="status" class="form-control" required>
                                    <option value="Đang sử dụng">Đang sử dụng</option>
                                    <option value="Rỗng">Rỗng</option>
                                    <option value="Bị hỏng">Bị hỏng</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin bổ sung -->
                <div class="card">
                    <div class="card-header" id="headingAdditional">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#collapseAdditional" aria-expanded="false" aria-controls="collapseAdditional">
                                Thông tin bổ sung
                            </button>
                        </h2>
                    </div>
                    <div id="collapseAdditional" class="collapse" aria-labelledby="headingAdditional"
                        data-parent="#containerAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Số Seal</label>
                                <input value="{{ old('seal_number') }}" type="text" name="seal_number"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Vị trí</label>
                                <input value="{{ old('location') }}" type="text" name="location" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label>Trọng lượng</label>
                                <input value="{{ old('weight') }}" type="number" step="0.01" name="weight"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Kích thước</label>
                                <input value="{{ old('dimensions') }}" type="text" name="dimensions" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label>Lô hàng (Shipment)</label>
                                <select name="shipment_id" class="form-control" required>
                                    <option value="">Chọn lô hàng</option>
                                    @foreach ($shipments as $shipment)
                                        <option value="{{ $shipment->id }}"
                                            {{ old('shipment_id') == $shipment->id ? 'selected' : '' }}>
                                            {{ $shipment->tracking_number }} - {{ $shipment->origin_port }} →
                                            {{ $shipment->destination_port }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success">Tạo Container</button>
        </form>
    </div>
@endsection
