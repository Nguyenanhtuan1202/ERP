@extends('layouts.admin')

@section('content')
    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Thông báo',
                    text: '{{ session('success') }}',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#3085d6',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Lỗi',
                    text: '{{ session('error') }}',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#d33',
                    background: '#fff',
                    timer: 5000, // Tự động đóng sau 5 giây
                    timerProgressBar: true,
                });
            });
        </script>
    @endif

    <div class="container-fluid">
        <h1 class="mt-3">Danh sách Container</h1>
        <a href="{{ route('containers.create') }}" class="btn btn-primary mb-3">Thêm Container mới</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Số Container</th>
                    <th>Loại</th>
                    <th>Tình trạng</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($containers as $container)
                    <tr>
                        <td>{{ $container->id }}</td>
                        <td>{{ $container->container_number }}</td>
                        <td>{{ $container->type }}</td>
                        <td>{{ $container->status }}</td>
                        <td>
                            <a href="{{ route('containers.show', $container->id) }}" class="btn btn-info btn-sm">Xem</a>
                            <a href="{{ route('containers.edit', $container->id) }}" class="btn btn-warning btn-sm">Sửa</a>
                            <a onclick="return confirm('Bạn có chắc muốn xóa?')"
                                href="{{ route('containers.delete', ['id' => $container->id]) }}"
                                class="btn btn-danger btn-sm">Xoá</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>


    </div>
@endsection
