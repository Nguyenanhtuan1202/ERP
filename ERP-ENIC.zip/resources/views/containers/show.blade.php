@extends('layouts.admin')

@section('content')
<div class="container">
    <style>
        /* Container chính */
        .container-show {
            max-width: 100%;
            margin: 2rem auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        /* Tiêu đề */
        .container-show h1 {
            text-align: center;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }
        /* Grid layout cho thông tin */
        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .detail-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #007bff;
            transition: transform 0.2s;
        }
        .detail-item:hover {
            transform: translateY(-3px);
        }
        .detail-item strong {
            display: block;
            margin-bottom: 5px;
            font-size: 0.9rem;
            color: #555;
        }
        .detail-item p {
            margin: 0;
            font-size: 1rem;
            color: #333;
        }
        /* Các nút hành động */
        .action-buttons {
            text-align: center;
            margin-top: 30px;
        }
        .action-buttons a {
            margin: 0 10px;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.2s;
        }
        .btn-warning {
            background: #ffc107;
            color: #fff;
        }
        .btn-warning:hover {
            background: #e0a800;
        }
        .btn-secondary {
            background: #6c757d;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        @media (max-width: 576px) {
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="container-show">
        <h1>Chi tiết Container</h1>
        <div class="details-grid">
            <div class="detail-item">
                <strong>Số Container:</strong>
                <p>{{ $container->container_number }}</p>
            </div>
            <div class="detail-item">
                <strong>Loại:</strong>
                <p>{{ $container->type }}</p>
            </div>
            <div class="detail-item">
                <strong>Tình trạng:</strong>
                <p>{{ $container->status }}</p>
            </div>
            <div class="detail-item">
                <strong>Số Seal:</strong>
                <p>{{ $container->seal_number }}</p>
            </div>
            <div class="detail-item">
                <strong>Vị trí:</strong>
                <p>{{ $container->location }}</p>
            </div>
            <div class="detail-item">
                <strong>Trọng lượng:</strong>
                <p>{{ $container->weight }} kg</p>
            </div>
            <div class="detail-item">
                <strong>Kích thước:</strong>
                <p>{{ $container->dimensions }}</p>
            </div>
            <div class="detail-item">
                <strong>Lô hàng liên quan:</strong>
                @if($container->shipment)
                    <p>
                        {{ $container->shipment->tracking_number }} <br>
                        {{ $container->shipment->origin_port }} → {{ $container->shipment->destination_port }}
                    </p>
                @else
                    <p>N/A</p>
                @endif
            </div>
        </div>
        <div class="action-buttons">
            <a href="{{ route('containers.edit', ['id' => $container->id]) }}" class="btn btn-warning">Chỉnh sửa</a>
            <a href="{{ route('containers.index') }}" class="btn btn-secondary">Quay lại</a>
        </div>
    </div>
</div>
@endsection
