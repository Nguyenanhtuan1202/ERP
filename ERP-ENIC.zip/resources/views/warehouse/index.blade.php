@extends('layouts.enic')
@section('content')
    <style>
        .table-custom th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #111;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
            background-color: #f1f3f5;
        }

        .table-custom td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            color: #111;
            vertical-align: top;
        }

        .table-custom tbody tr:hover {
            background-color: #f8f9fa;
            transition: background-color 0.2s ease;
        }

        /* Số thứ tự căn giữa */
        .table-custom td:first-child {
            text-align: center;
            font-weight: 500;
            color: #111;
        }

        /* Làm nổi bật header */
        .table-custom thead tr {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        /* Định dạng các cột dài */
        .table-custom td:nth-child(2),
        .table-custom td:nth-child(3),
        .table-custom td:nth-child(10),
        .table-custom td:nth-child(11) {
            max-width: 250px;
            white-space: normal;
            word-break: break-word;
        }
    </style>

    <div style="padding: 10px 30px; margin-top: 100px;" class="container_fluid">
        <div class="row">
            <!-- Danh sách Hàng Tồn Kho (Nháp) -->
            <div class="col-12">
                <div class="card mb-4" style="padding: 15px">
                    <div class="card-header pb-0 mb-3">
                        <h5>Danh sách Hàng Tồn Kho (Nháp)</h5>
                        @if (session('status'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('status') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000,
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>

                    <!-- Button xem lịch sử nhập kho (Popup) -->
                    <div class="mb-3">
                        <button class="btn btn-info" id="btnHistory">
                            Xem lịch sử nhập kho
                        </button>
                    </div>

                    <!-- Form xác nhận tất cả -->
                    <form action="{{ route('warehouse.confirmAll') }}" method="POST"
                        onsubmit="return confirm('Bạn có chắc muốn xác nhận tất cả các bản ghi nháp không?')">
                        @csrf
                        <table class="custom-table table-custom" id="table1">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Mã Đơn Hàng</th>
                                    <th>SKU</th>
                                    <th>Tên Sản Phẩm</th>
                                    <th>Số Lượng Đặt Hàng</th>
                                    <th>Số Lượng Nhận</th>
                                    <th>Ngày Nhập Kho</th>
                                    <th>Ghi Chú</th>
                                    <th>Chọn Kho</th>
                                    <th>Xưởng SX</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($drafts as $draft)
                                    <tr>
                                        <td>
                                            {{ $draft->id }}
                                            <input type="hidden" name="draft_ids[]" value="{{ $draft->id }}">
                                        </td>
                                        <td>{{ $draft->purchase_order_id }}</td>
                                        <td>{{ $draft->sku }}</td>
                                        <td>{{ $draft->name }}</td>
                                        <td>{{ $draft->order_quantity }}</td>
                                        <td>{{ $draft->qty_received }}</td>
                                        <td>
                                            {{ $draft->date_received ? \Carbon\Carbon::parse($draft->date_received)->format('d-m-Y') : '' }}
                                        </td>
                                        <td>
                                            <input type="text" name="notes[{{ $draft->id }}]" class="form-control"
                                                placeholder="Nhập ghi chú">
                                        </td>
                                        <td>
                                            <select class="form-control" name="ware_housing[{{ $draft->id }}]">
                                                <option value="TMĐT - HỒ CHÍ MINH">TMĐT - HỒ CHÍ MINH</option>
                                                <option value="SHOWROOM VẠN PHÚC">SHOWROOM VẠN PHÚC</option>
                                                <option value="SHOWROOM Q1/TB">SHOWROOM Q1/TB</option>
                                                <option value="KHO HẢI PHÒNG">KHO HẢI PHÒNG</option>
                                                <option value="KHO PHƯỚC SƠN">KHO PHƯỚC SƠN</option>
                                                <option value="KHO NHẤT TÍN - HƯNG YÊN">KHO NHẤT TÍN - HƯNG YÊN</option>
                                                <option value="SHOWROOM XÃ ĐÀN">SHOWROOM XÃ ĐÀN</option>
                                                <option value="MĐT - HÀ NỘI">MĐT - HÀ NỘI</option>
                                                <option value="SHOWROOM BÌNH DƯƠNG">SHOWROOM BÌNH DƯƠNG</option>
                                                <option value="KHO ĐÀ NẴNG">KHO ĐÀ NẴNG</option>
                                                <option value="SHOWROOM ĐÀ NẴNG">SHOWROOM ĐÀ NẴNG</option>
                                                <option value="SHOWROOM HẢI PHÒNG">SHOWROOM HẢI PHÒNG</option>
                                            </select>
                                        </td>
                                        <td>{{ $draft->supplier->username ?? '' }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="10">Không có bản ghi nào cần xác nhận.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>

                        @if ($drafts->count() > 0)
                            <button type="submit" class="btn btn-success mt-3">Xác nhận tất cả</button>
                        @endif


                    </form>
                </div>
            </div>

            <!-- Danh sách Hàng Tồn Kho Thực Tế -->
            <div class="col-12">
                <div class="card mb-4" style="padding: 15px">
                    <div class="card-header pb-0 mb-3">
                        <h5>Danh sách Hàng Tồn Kho Thực Tế</h5>
                    </div>
                    <table class="custom-table table-custom" id="table2">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>SKU</th>
                                <th>Tên Sản Phẩm</th>
                                <th>Tổng Số Lượng Tồn Kho</th>
                                <th>Kho</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $temp = 0;
                            @endphp
                            @forelse ($warehouses as $warehouse)
                                @php
                                    $temp++;
                                @endphp
                                <tr>
                                    <td>{{ $temp }}</td>
                                    <td>{{ $warehouse->sku }}</td>
                                    <td>{{ $warehouse->name }}</td>
                                    <td>{{ $warehouse->total_qty }}</td>
                                    <td>{{ $warehouse->warehouse_location ?? '' }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="3">Không có dữ liệu kho thực tế.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal hiển thị lịch sử nhập kho -->
    <div class="modal fade" id="historyModal" tabindex="-1" role="dialog" aria-labelledby="historyModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="historyModalLabel">Lịch sử nhập kho</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Đóng">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Nội dung lịch sử sẽ được load tại đây qua AJAX -->
                    <div id="historyContent">
                        <p>Đang tải dữ liệu...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            $('#btnHistory').on('click', function() {
                $.ajax({
                    url: "{{ route('warehouse.historyIndex') }}",
                    method: 'GET',
                    success: function(data) {
                        $('#historyContent').html(data);
                        $('#historyModal').modal('show');
                    },
                    error: function() {
                        Swal.fire('Lỗi', 'Không thể tải lịch sử nhập kho!', 'error');
                    }
                });
            });

            $('#table1').DataTable();
            $('#table2').DataTable();
        });
    </script>
@endsection
