@extends('layouts.admin')

@section('content')
    <div class="box___expert">
        <div class="form-container-custom">

            <form method="POST" action="{{ url('/admin/warehouse/saveConfirmOrder') }}">
                @csrf
                <table border="1">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>SKU</th>
                            <th>Sản Phẩm</th>
                            <th>Primary Qty</th>
                            <th>SL Dự Kiến</th>
                            <th>SL Thực Tế</th>
                            <th>SL Còn Lại</th>
                            <th>Ngày Đặt Hàng</th>
                            <th>Ngày Về Dự Kiến</th>
                            <th>Ngày Về Cho Sale</th>
                            <th>Kho</th>
                        </tr>
                    </thead>
                    <tbody>

                        <div
                            style="display: flex; justify-content: space-between; width: 100%; gap: 30px; margin-bottom: 20px; align-content: center">
                            <h3>Mã Đơn : {{ $infoPo['po'] }}</h3>
                            <input required style="width: 400px;" name="code_po" type="text" value=""
                                placeholder="Chọn Mã Đơn Ghi Nhớ">
                            <h5>Số Lượng Đơn Hàng : {{ $infoPo['qty'] }} pcs</h5>

                            <input type="hidden" name="po" value="{{ $infoPo['po'] }}">
                            <input type="hidden" name="qty" value="{{ $infoPo['qty'] }}">
                            <input type="hidden" name="date_create" value="{{ $infoPo['date_create'] }}">
                        </div>

                        @php
                            $temp = 0;
                            $total_qty_forecast = 0;
                        @endphp

                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <input style="background-color: #208205; color: #fff;" type="date"
                                    id="date_forecast_first" value="">
                            </td>
                            <td>
                                <input style="background-color: #0796ac; color: #fff;" type="date"
                                    id="select_date_forecast_by_sales" value="">
                            </td>
                            <!-- Các cột khác -->
                        </tr>

                        @foreach ($items as $index => $item)
                            @php
                                $temp++;
                                $total_qty_forecast += $item['quantity'];
                            @endphp
                            <tr>
                                <td>{{ $temp }}</td>
                                <td>
                                    <input type="hidden" name="items[{{ $index }}][sku]"
                                        value="{{ $item['sku'] }}">
                                    {{ $item['sku'] }}
                                </td>
                                <td>
                                    <input type="hidden" name="items[{{ $index }}][name]"
                                        value="{{ $item['name'] }}">
                                    {{ $item['name'] ?: 'Không có thông tin' }}
                                </td>
                                <td>
                                    <input type="hidden" name="items[{{ $index }}][primary_qty]" value="">

                                </td>
                                <td>
                                    <input readonly type="hidden" name="items[{{ $index }}][forecast_qty]"
                                        value=" {{ $item['quantity'] }}">
                                    {{ $item['quantity'] }}
                                </td>
                                <td>
                                    <input readonly type="hidden" name="items[{{ $index }}][actual_qty]"
                                        value="">
                                </td>
                                <td>
                                    <input readonly type="hidden" name="items[{{ $index }}][remain_qty]"
                                        value="">
                                </td>
                                <td>
                                    {{ $infoPo['date_create'] }}
                                </td>
                                <td>
                                    <input type="date" class="date_forecast"
                                        name="items[{{ $index }}][date_forecast]" value="">
                                </td>
                                <td>
                                    <input type="date" class="date_forecast_by_sale"
                                        name="items[{{ $index }}][date_forecast_by_sale]" value="">
                                </td>

                                <td>
                                    <select name="items[{{ $index }}][warehousing]" id="">
                                        <option value="HCM">Kho HCM</option>
                                        <option value="HN">Kho HÀ NỘI</option>
                                    </select>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td> Tổng Số Dự Kiến <h5>{{ $total_qty_forecast }}</h5>
                            </td>
                        </tr>
                    </tfoot>
                </table>
                <button class="mt-4" type="submit">Xác nhận</button>
            </form>
        </div>
    </div>
@endsection
@section('js')
    <script>
        $(document).ready(function() {
            // Khi ngày đầu tiên thay đổi
            $("#date_forecast_first").on("change", function() {

                // Lấy giá trị của ngày được chọn
                let selectedDate = $(this).val();

                if (selectedDate) {
                    // Cập nhật tất cả các trường date_forecast
                    $(".date_forecast").val(selectedDate);

                    // Tính toán ngày + 5 và cập nhật các trường date_forecast_by_sale
                    $(".date_forecast").each(function(index) {
                        const forecastDate = new Date(selectedDate);
                        forecastDate.setDate(forecastDate.getDate() + 5);

                        // Định dạng lại ngày thành YYYY-MM-DD
                        const formattedDate = forecastDate.toISOString().split("T")[0];

                        // Gán giá trị cho trường tương ứng
                        $(this).closest("tr").find(".date_forecast_by_sale").val(formattedDate);
                    });
                }

            });

            $("#select_date_forecast_by_sales").on("change", function() {

                // Lấy giá trị của ngày được chọn
                let selectedDateBySale = $(this).val();
                if (selectedDateBySale) {
                    // Cập nhật tất cả các trường date_forecast_by_sale
                    $(".date_forecast_by_sale").val(selectedDateBySale);
                }
            });

        });
    </script>
@endsection
