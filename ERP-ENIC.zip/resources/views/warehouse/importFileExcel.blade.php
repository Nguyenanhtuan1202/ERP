@extends('layouts.admin')

@section('content')
    <div class="container">
        <h2>Import File Excel và Hiển Thị Thông Tin</h2>


        <form id="uploadForm" enctype="multipart/form-data">
            @csrf
            <input type="file" name="file" id="file" required>
            <button type="submit">Upload</button>
        </form>


        @if (session('status'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('status') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div id="previewTable" style="margin-top: 20px; display: none;">
            <h2>Preview Data</h2>
            <form id="saveForm" action="{{ route('po-items.upload') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <table id="dataTable" class="table-responsive">
                    <thead>
                        <tr>
                            <th>PO</th>
                            <th>Code PO</th>
                            <th>SKU</th>
                            <th>Name</th>
                            <th>Primary Qty</th>
                            <th>Forecast Qty</th>
                            <th>Actual Qty</th>
                            <th>Remain Qty</th>
                            <th>Date Forecast</th>
                            <th>Date Forecast by Sale</th>
                            <th>Warehousing</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <button type="submit">Lưu dữ liệu</button>
            </form>
        </div>




    </div>
@endsection


@section('js')
    <script>
        $('#uploadForm').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('upload.preview') }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        let rows = response.data;
                        let tableBody = $('#dataTable tbody');
                        tableBody.empty(); // Clear existing data

                        rows.forEach((row, index) => {
                            // Kiểm tra và chuyển số thành ngày tháng hợp lệ
                            let dateForecast = row.date_forecast;
                            let dateForecastBySale = row.date_forecast_by_sale;

                            // Chuyển đổi số ngày thành ngày hợp lệ (UNIX timestamp, mốc thời gian: 1970-01-01)
                            if (isNumeric(dateForecast)) {
                                dateForecast = convertExcelDateToDate(dateForecast);
                            }

                            if (isNumeric(dateForecastBySale)) {
                                dateForecastBySale = convertExcelDateToDate(dateForecastBySale);
                            }


                            let html = `
                    <tr>
                        <td><input type="text" name="data[${index}][po]" value="${row.po || ''}"></td>
                        <td><input type="text" name="data[${index}][code_po]" value="${row.code_po || ''}"></td>
                        <td><input type="text" name="data[${index}][sku]" value="${row.sku || ''}"></td>
                        <td><input type="text" name="data[${index}][name]" value="${row.name || ''}"></td>
                        <td><input type="text" name="data[${index}][primary_qty]" value="${row.primary_qty || ''}"></td>
                        <td><input type="text" name="data[${index}][forecast_qty]" value="${row.forecast_qty || ''}"></td>
                        <td><input type="text" name="data[${index}][actual_qty]" value="${row.actual_qty || ''}"></td>
                        <td><input type="text" name="data[${index}][remain_qty]" value="${row.remain_qty || ''}"></td>
                        <td><input type="text" name="data[${index}][date_forecast]" value="${dateForecast || ''}"></td>
                        <td><input type="text" name="data[${index}][date_forecast_by_sale]" value="${dateForecastBySale || ''}"></td>
                        <td><input type="text" name="data[${index}][warehousing]" value="${row.warehousing || ''}"></td>
                    </tr>
                    `;
                            tableBody.append(html);
                        });

                        $('#previewTable').show();
                    } else {
                        alert(response.message);
                    }
                }
            });
        });

        // Kiểm tra nếu là một số
        function isNumeric(value) {
            return !isNaN(value) && value !== null && value !== '';
        }

        // Chuyển số ngày thành ngày hợp lệ từ Unix epoch (1970-01-01)
        function convertExcelDateToDate(excelDate) {
            let baseDate = new Date(1900, 0, 1); // Mốc thời gian Excel (1900-01-01)
            baseDate.setDate(baseDate.getDate() + parseInt(excelDate) - 2); // Excel tính sai năm 1900 là năm nhuận
            let year = baseDate.getFullYear();
            let month = ("0" + (baseDate.getMonth() + 1)).slice(-2); // Thêm số 0 nếu tháng < 10
            let day = ("0" + baseDate.getDate()).slice(-2); // Thêm số 0 nếu ngày < 10
            return `${year}-${month}-${day}`; // Trả về định dạng YYYY-MM-DD
        }
    </script>
@endsection
