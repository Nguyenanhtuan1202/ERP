@extends('layouts.admin')
@section('content')
    <div style="padding: 10px 30px" class="">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">
                        <h3 class="title__highlight">
                            <i class="fas fa-desktop"></i> Danh sách sản phẩm theo đơn
                        </h3>

                        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px">
                            <form action="{{ route('excel_export_warehouse') }}" method="POST">
                                {{ csrf_field() }}
                                <button class="expert_excel" type="submit">
                                    <i style="font-size: 20px; padding-right: 5px" class="far fa-file-excel"></i>
                                    Xuất Excel</button>
                            </form>


                            <h3 style="color:#dc3545">Mã Đơn Hàng: {{ $data_first->po ?? '' }}</h3>

                            <h4 style="color:#0dae8e">{{ $data_first->code_po ?? '' }}</h4>
                        </div>

                        @if (session('status'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('status') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                <thead class="thead__custom">
                                    <tr>
                                        <th style="font-size: 14px"
                                            class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                            STT</th>



                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            SKU</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Tên SP</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            SL Đặt Hàng</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            SL Dự Kiến</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            SL Thực Tế</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            SL Còn Lại</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Ngày Về Dự Kiến</th>

                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Ngày Về Dự Kiến Cho Sale</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Kho</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                            Quản Lý</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @php
                                        $temp = 0;
                                    @endphp

                                    @foreach ($data as $item)
                                        @php
                                            $temp++;
                                        @endphp
                                        <tr>

                                            <td class="align-middle text-center ">
                                                {{ $temp }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->sku ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->name ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->primary_qty ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->forecast_qty ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->actual_qty ?? '' }}
                                            </td>
                                            <td class="align-middle text-center ">
                                                {{ $item->remain_qty ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->date_forecast ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->date_forecast_by_sale ?? '' }}
                                            </td>

                                            <td class="align-middle text-center ">
                                                {{ $item->warehousing ?? '' }}
                                            </td>
                                            <td class="align-middle">

                                                <a href="" class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="edit agent"
                                                    style="font-size: 12px; font-weight: bold; color: #ffffff; background-color: #35cbdc; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Edit
                                                </a>
                                                <a onclick="return confirm('Bạn có muốn xóa kho này không ?')"
                                                    href="" class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="delete agent"
                                                    style="font-size: 12px; display: block; margin-top: 5px; font-weight: bold; color: #ffffff; background-color: #dc3545; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Delete
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
