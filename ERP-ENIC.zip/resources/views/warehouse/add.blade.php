@extends('layouts.admin')

@section('content')
    <div class="box___expert">
        <div class="form-container-custom">
            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif
            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: '{{ session('error') }}',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif

            <form action="{{ url('/admin/warehouse/save') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <h2>Thêm Đơn Hàng Mới</h2>

                <div class="form-group">
                    <label for="name">Mã Đơn:</label>
                    <input type="text" id="name" name="name" required value="{{ old('name') }}">
                </div>

                <div class="form-group">
                    <label for="location">Địa chỉ:</label>
                    <input type="text" id="location" name="location" required value="{{ old('location') }}">
                </div>

                <div class="form-group">
                    <label for="capacity">Số Lượng Đơn Đặt:</label>
                    <input type="text" id="capacity" name="capacity" required value="{{ old('capacity') }}">
                </div>

                <div class="form-group">
                    <label for="agent_id">Chọn Xưởng:</label>
                    <select id="agent_id" name="agent_id" required>
                        <option value="">-- Chọn Xưởng --</option>
                        @foreach ($data['agent'] as $agent)
                            <option value="{{ $agent->id }}" {{ old('agent_id') == $agent->id ? 'selected' : '' }}>
                                {{ $agent->name }}
                            </option>
                        @endforeach
                    </select>
                </div>


                <div class="form-group">
                    <label for="date_create">Ngày Đặt Đơn:</label>
                    <input type="date" id="date_create" name="date_create" required value="{{ old('date_create') }}">
                </div>


                <button class="mt-4" type="submit">
                    Thêm mới
                </button>

            </form>
        </div>
    </div>
@endsection
