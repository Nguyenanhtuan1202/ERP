@extends('layouts.admin')

@section('content')
    <div class="box___expert">
        <div class="form-container-custom">
            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif
            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: '{{ session('error') }}',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif

            <form action="{{ url('/admin/warehouse/saveProcessProduct') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-6">
                        <h3>Mã Đơn : {{ $dataPo['po'] }}</h3>
                        <h5>Số Lượng Đơn Hàng : {{ $dataPo['qty'] }} pcs</h5>
                        <input type="hidden" name="po" value="{{ $dataPo['po'] }}">
                        <input type="hidden" name="qty" value="{{ $dataPo['qty'] }}">
                        <input type="hidden" name="date_create" value="{{ $dataPo['date_create'] }}">
                        @error('sku')
                            <small class="text-danger">({{ $message }})</small>
                        @enderror
                        <label for="skuInput">Danh sách SKU (Mỗi mã SKU một dòng):</label>
                        <textarea class="form-control" style="height: 500px" id="skuInput" name="sku"
                            placeholder="Nhập các mã SKU, mỗi dòng là một mã SKU..."></textarea>
                    </div>
                    <div class="col-md-6">
                        @error('quantity')
                            <small class="text-danger">({{ $message }})</small>
                        @enderror
                        <label for="qtyInput">Danh sách số lượng (Mỗi số lượng một dòng, tương ứng với mã SKU):</label>
                        <textarea class="form-control" style="height: 500px" id="qtyInput" name="quantity"
                            placeholder="Nhập số lượng, mỗi dòng là một số, thứ tự tương ứng với SKU..."></textarea>
                    </div>
                </div>
                <button class="mt-4" type="submit">
                    Kiểm Tra 
                </button>
            </form>
        </div>
    </div>
@endsection



@section('js')
@endsection
