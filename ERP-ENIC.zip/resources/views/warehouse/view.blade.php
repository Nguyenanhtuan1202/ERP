@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="warehouse-details">
            <h2>Thông Tin Kho Hàng</h2>
            <p><strong>Tên Kho:</strong> {{ $data['warehouse']->name ?? '' }}</p>
            <p><strong>Địa Điểm:</strong> {{ $data['warehouse']->location ?? '' }}</p>
            <p><strong>Sức Chứa:</strong> {{ $data['warehouse']->capacity ?? '' }}</p>
            <p><strong>Ngày Tạo:</strong>
                {{ \Carbon\Carbon::parse($data['warehouse']->date_create ?? '')->format('d/m/Y') }}</p>
        </div>

        <div class="agent-details">
            <h3>Thông Tin Đại Lý</h3>
            <p><strong>Tên Đại Lý:</strong> {{ $data['warehouse']->agent->name ?? '' }}</p>
            <p><strong>Địa Chỉ:</strong> {{ $data['warehouse']->agent->address ?? '' }}</p>
            <p><strong>Điện Thoại:</strong> {{ $data['warehouse']->agent->phone ?? '' }}</p>
            <p><strong>Email:</strong> {{ $data['warehouse']->agent->email ?? '' }}</p>
        </div>

        <div class="inventory-list">
            <h3>Danh Sách Sản Phẩm Trong Kho</h3>
            <table id="inventoryTable" class="table">
                <thead>
                    <tr>
                        <th>Tên Sản Phẩm</th>
                        <th>Số Lượng</th>
                        <th>Kho Hàng</th>
                        <th>Địa Chỉ</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($data['inventories'] as $inventory)
                        <tr>
                            <td>{{ $inventory->product->name ?? '' }}</td>
                            <td>{{ number_format($inventory->total_quantity ?? '') }}</td>
                            <td>{{ $inventory->warehouse->name ?? '' }}</td>
                            <td>{{ $inventory->warehouse->location ?? '' }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@section('js')
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f7f7f7;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .warehouse-details,
        .agent-details {
            margin-bottom: 30px;
        }

        h2,
        h3 {
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 2px solid #f1c40f;
        }

        p {
            font-size: 18px;
            color: #555;
            line-height: 1.6;
        }

        .stock-list {
            margin-top: 30px;
        }

        .table {
            width: 100%;
            background-color: #fff;
            border-collapse: collapse;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
        }

        .table th {
            background-color: #3498db;
            color: #fff;
            font-size: 16px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .table tbody tr:hover {
            background-color: #ddd;
            cursor: pointer;
        }
    </style>

    <script>
        // Thêm hiệu ứng cho bảng
        document.addEventListener("DOMContentLoaded", function() {
            const rows = document.querySelectorAll("#inventoryTable tbody tr");

            rows.forEach(row => {
                row.addEventListener("click", function() {
                    // Khi nhấn vào hàng, có thể điều hướng đến trang chi tiết sản phẩm (nếu có)
                    // window.location.href = `/product/${this.dataset.id}`;
                });
            });
        });

        // Nếu muốn thêm DataTables cho bảng (nếu bạn đã cài đặt)
        $(document).ready(function() {
            $('#inventoryTable').DataTable({
                "language": {
                    "sSearch": "Tìm kiếm:",
                    "lengthMenu": "Hiển thị _MENU_ dòng",
                    "info": "Hiển thị _START_ đến _END_ của _TOTAL_ dòng",
                    "paginate": {
                        "first": "Đầu",
                        "last": "Cuối",
                        "next": "Sau",
                        "previous": "Trước"
                    },
                }
            });
        });
    </script>
@endsection
