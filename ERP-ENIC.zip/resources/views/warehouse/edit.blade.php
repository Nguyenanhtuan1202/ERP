@extends('layouts.admin')

@section('content')
    <div class="box___expert">
        <div class="form-container-custom">
            @if (session('status'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Thông báo',
                            text: '{{ session('status') }}',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#3085d6',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif
            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Lỗi',
                            text: '{{ session('error') }}',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            background: '#fff',
                            timer: 5000, // Tự động đóng sau 5 giây
                            timerProgressBar: true,
                        });
                    });
                </script>
            @endif


       
            <form action="{{ url('/admin/warehouse/update/' . $data['edit']->id ?? ' ') }}" method="POST"
                enctype="multipart/form-data">
                {{ csrf_field() }}
                <h2>Cập nhật thông tin kho</h2>

                <div class="form-group">
                    <label for="name">Tên kho:</label>
                    <input type="text" id="name" name="name" required value="{{ $data['edit']->name ?? '' }}">
                </div>

                <div class="form-group">
                    <label for="location">Địa chỉ kho:</label>
                    <input type="text" id="location" name="location" required value="{{ $data['edit']->location ?? '' }}">
                </div>

                <div class="form-group">
                    <label for="capacity">Sức chứa (Diện tích):</label>
                    <input type="text" id="capacity" name="capacity" required value="{{ $data['edit']->capacity ?? '' }}">
                </div>

                <div class="form-group">
                    <label for="agent_id">Chọn đại lý:</label>
                    <select id="agent_id" name="agent_id" required>
                        <option value="">-- Chọn đại lý --</option>
                        @foreach ($data['agent'] as $agent)
                            <option {{ $agent->id == $data['edit']->agent_id ? 'selected' : '' }} value="{{ $agent->id }}"
                                {{ old('agent_id') == $agent->id ? 'selected' : '' }}>
                                {{ $agent->name }}
                            </option>
                        @endforeach
                    </select>
                </div>


                <div class="form-group">
                    <label for="date_create">Ngày Mở Kho:</label>
                    <input type="date" id="date_create" name="date_create" required value="{{ $data['edit']->date_create ?? '' }}">
                </div>



                <button class="mt-4" type="submit">
                    Cập Nhật
                </button>

            </form>
        </div>
    </div>
@endsection
