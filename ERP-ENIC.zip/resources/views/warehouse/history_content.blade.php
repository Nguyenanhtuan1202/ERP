<style>
    /* CSS cho bảng */
    .table-warehouse {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
        background: white;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    .table-warehouse thead th {
        background-color: #2c3e50;
        color: white;
        padding: 16px;
        font-weight: 600;
        border-bottom: 2px solid #34495e;
        font-size: 14px;
    }

    .table-warehouse tbody td {
        padding: 12px;
        vertical-align: top;
        border-bottom: 1px solid #ecf0f1;
        font-size: 14px;
    }

    .table-warehouse tbody tr:hover {
        background-color: #f8f9fa;
    }

    /* Style cho ô chứa nhiều items */
    .detail-items {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-height: 200px;
        overflow-y: auto;
        padding-right: 8px;
    }

    .detail-item {
        display: flex;
        align-items: center;
        padding: 8px;
        background: #f8f9fa;
        border-radius: 4px;
        border: 1px solid #dee2e6;
    }

    .detail-item span {
        flex: 1;
        min-width: 10px;
        padding: 0px 4px;
        font-size: 14px;
        text-align: center;
    }

    .quantity-badge {
        background: #3498db;
        color: white;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.85em;
        font-weight: 500;
    }

    .empty-row td {
        text-align: center;
        padding: 24px !important;
        color: #95a5a6;
        font-size: 14px;
    }
</style>

<table class="table table-bordered table-warehouse" id="table11">
    <thead>
        <tr>
            <th>ID</th>

            <th>SKU</th>
            <th>Tên Sản Phẩm</th>
            <th>Số Lượng</th>
            <th>Ngày Nhập</th>
            <th>Người Nhập</th>
            <th>Kho</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($histories as $history)
            <tr>
                <td>{{ $history->id }}</td>

                <td>
                    <div class="detail-items">
                        @if (isset($history->details) && is_array($history->details))
                            @foreach ($history->details as $detail)
                                <div class="detail-item">
                                    <span>{{ $detail['sku'] ?? '' }}</span>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </td>
                <td>
                    <div class="detail-items">
                        @if (isset($history->details) && is_array($history->details))
                            @foreach ($history->details as $detail)
                                <div class="detail-item">
                                    <span>{{ $detail['product_name'] ?? '' }}</span>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </td>
                <td>
                    <div class="detail-items">
                        @if (isset($history->details) && is_array($history->details))
                            @foreach ($history->details as $detail)
                                <div class="detail-item">
                                    <span class="quantity-badge">{{ $detail['quantity_entered'] ?? 0 }}</span>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </td>
                <td>{{ \Carbon\Carbon::parse($history->entry_time)->format('d-m-Y H:i:s') }}</td>
                <td>{{ $history->user->name ?? 'N/A' }}</td>
                <td class="notes-cell">
                    <div class="detail-items">
                        @if (isset($history->details) && is_array($history->details))
                            @foreach ($history->details as $detail)
                                <div class="detail-item">
                                    <span>{{ $detail['warehouse_location'] ?? '' }}</span>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="8" class="empty-row">Không có lịch sử nhập kho nào.</td>
            </tr>
        @endforelse
    </tbody>
</table>

<script>
    $(document).ready(function() {
        for (let i = 0; i <= 1000; i++) {
            let table = $(`#table${i}`);
            if (table.length && table.is('table')) {
                table.DataTable();
            }
        }
    });
</script>
