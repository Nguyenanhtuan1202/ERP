@extends('layouts.admin')

@section('content')
    <div style="padding: 10px 30px;">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0" style="background: none">
                        <h3 class="title__highlight">
                            <i class="fas fa-cubes"></i> Danh Sách Tồn Kho
                        </h3>


                        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px">

                            <a class="add__expert" href="{{ route('stock.add') }}">Thêm Mới <i
                                    class="fas fa-user-plus"></i></a>
                        </div>

                        @if (session('status'))
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire({
                                        title: 'Thông báo',
                                        text: '{{ session('status') }}',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                        confirmButtonColor: '#3085d6',
                                        background: '#fff',
                                        timer: 5000, // Tự động đóng sau 5 giây
                                        timerProgressBar: true,
                                    });
                                });
                            </script>
                        @endif
                    </div>

                    <div class="card-body px-0 pt-0 pb-2" style="max-width: 1300px; overflow-x: scroll">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 table__customs" id="table1">
                                <thead class="thead__custom">
                                    <tr>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase text-sm font-weight-bolder opacity-7">
                                            Quản Lý</th>

                                        <th style="font-size: 14px"
                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                            STT</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                            Tên Sản Phẩm</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                            Tên Kho</th>
                                        <th style="font-size: 14px"
                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                            Địa Chỉ Kho</th>

                                        <th style="font-size: 14px"
                                            class="text-uppercase text-sm font-weight-bolder opacity-7">
                                            Người Chủ Kho</th>


                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase text-sm font-weight-bolder opacity-7">
                                            Tổng Số Lượng</th>
                                        <th style="font-size: 14px"
                                            class="text-center text-uppercase text-sm font-weight-bolder opacity-7">
                                            Thời gian</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $temp = 0;
                                    @endphp

                                    @foreach ($data['inventories'] as $inventory)
                                        {{-- {{ dd($data['inventories']) }} --}}

                                        @php
                                            $temp++;
                                        @endphp
                                        <tr>

                                            <td class="align-middle text-center">

                                                <a href="{{ route('stock.edit', $inventory->id) }}" class="font-weight-bold"
                                                    data-toggle="tooltip" data-original-title="edit agent"
                                                    style="font-size: 12px; font-weight: bold; color: #ffffff; background-color: #35cbdc; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Xuất kho
                                                </a>
                                                <a onclick="return confirm('Bạn có muốn xóa sản phẩm này không ?')"
                                                    href="{{ url('admin/stock/delete/' . $inventory->id) }}"
                                                    class="font-weight-bold" data-toggle="tooltip"
                                                    data-original-title="delete agent"
                                                    style="font-size: 12px; display: block; margin-top: 5px; font-weight: bold; color: #ffffff; background-color: #dc3545; padding: 10px 20px; border-radius: 5px; text-decoration: none; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); display: inline-block;">
                                                    Xoá
                                                </a>

                                            </td>


                                            <td style="font-size: 15px; " class="align-middle text-center">
                                                {{ $temp }}
                                            </td>
                                            <td style="font-size: 15px; " class="align-middle text-center">
                                                {{ $inventory->product->name ?? 'N/A' }}
                                            </td>

                                            <td style="font-size: 15px; " class="align-middle text-center">
                                                {{ $inventory->warehouse->name ?? 'N/A' }}
                                            </td>
                                            <td style="font-size: 15px;" class="align-middle text-center">
                                                {{ $inventory->warehouse->location ?? 'N/A' }}
                                            </td>
                                            <td style="font-size: 15px; " class="align-middle text-center">
                                                {{ $inventory->warehouse->agent->name ?? 'N/A' }}
                                            </td>


                                            <td style="ffont-size: 15px;" class="align-middle text-center">
                                                {{ $inventory->total_quantity ?? 0 }}
                                            </td>


                                            <td>
                                                @if ($data['stock'])
                                                    <a style="font-size: 13px; font-weight: bold ">Thêm (Nhập) Kho</a>
                                                    @foreach ($data['stock'] as $item)
                                                        @if ($item->warehouse_id == $inventory->warehouse_id && $item->product_id == $inventory->product_id)
                                                            <a
                                                                style="display: block; margin-bottom: 10px;  color: #fff; padding: 3px 7px; font-size: 11px; width: max-content;">
                                                                <span style="background-color: #0d9e69; padding: 3px 7px;">
                                                                    Ngày
                                                                    Nhập Kho: {{ $item->entry_date ?? '' }}</span>
                                                                <span style="background-color: #c11f17; padding: 3px 7px;">|
                                                                    Người Nhập Kho: {{ $item->added_by ?? '' }}</span>
                                                                <span style="background-color: #003b80; padding: 3px 7px;">|
                                                                    Số
                                                                    lượng : {{ $item->quantity ?? '' }}</span>

                                                                <span style="background-color: #003b80; padding: 3px 7px;">|
                                                                    Ghi chú : {{ $item->note ?? '' }}</span>
                                                            </a>
                                                        @endif
                                                    @endforeach
                                                @endif


                                                @if ($data['inventory_logs']->count() > 0)
                                                    <hr>
                                                    <div style="background-color: #f3f3f3; padding: 10px 20px; height: 300px; overflow-y: scroll">
                                                        <a style="font-size: 13px; font-weight: bold ">Cập Nhật (Xuất)
                                                            Kho</a>
                                                        @foreach ($data['inventory_logs'] as $value)
                                                            @if ($value->inventory_id == $inventory->id)
                                                                <a
                                                                    style="display: block; margin-bottom: 10px;  color: #fff; padding: 3px 7px; font-size: 11px; width: max-content;">
                                                                    <span
                                                                        style="background-color: #3396c7; padding: 3px 7px;">
                                                                        Ngày Xuất: {{ $value->date_expert ?? '' }}</span>
                                                                    <a
                                                                        style="display: block; margin-bottom: 10px;  color: #fff; padding: 3px 7px; font-size: 11px; width: max-content;">
                                                                        <span
                                                                            style="background-color: #c733b6; padding: 3px 7px;">
                                                                            Ghi chú: {{ $value->note ?? '' }}</span>

                                                                        <span
                                                                            style="background-color: #298000; padding: 3px 7px;">|
                                                                            Số
                                                                            lượng :
                                                                            {{  $value->quantity_change ?? '' }}</span>
                                                                        <span
                                                                            style="background-color: #bd1910; padding: 3px 7px;">|
                                                                            Người Thực Hiện :
                                                                            {{ $value->updated_by ?? '' }}</span>
                                                                    </a>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                @endif



                                            </td>





                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
