@extends('layouts.admin')

@section('content')
    <div class="mt-5 px-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="title__highlight" style="color: #fff">
                            <i class="fas fa-warehouse"></i> Xuất Kho
                        </h3>
                    </div>

                    @if (session('status'))
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    title: 'Thông báo',
                                    text: '{{ session('status') }}',
                                    icon: 'success',
                                    confirmButtonText: 'OK',
                                    confirmButtonColor: '#3085d6',
                                    background: '#fff',
                                    timer: 5000,
                                    timerProgressBar: true,
                                });
                            });
                        </script>
                    @endif

                    <div class="card-body">
                        <form action="{{ route('stock.update', $inventory->id) }}" method="POST">
                            @csrf


                            <div class="mb-3">
                                <label for="product_name" class="form-label">Sản Phẩm</label>
                                <input type="text" class="form-control" id="product_name" name="product_name"
                                    value="{{ $inventory->product->name }}" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="warehouse_id" class="form-label">Kho</label>
                                <select class="form-control" id="warehouse_id" name="warehouse_id" disabled>
                                    @foreach ($warehouses as $warehouse)
                                        <option value="{{ $warehouse->id }}"
                                            {{ $inventory->warehouse_id == $warehouse->id ? 'selected' : '' }}>
                                            {{ $warehouse->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="total_quantity" class="form-label">Tổng Số Lượng Hiện Tại</label>
                                <input type="number" class="form-control" id="total_quantity" name="total_quantity"
                                    value="{{ $inventory->total_quantity }}" readonly>
                                <small class="form-text text-muted">
                                    Đây là tổng số lượng sản phẩm hiện có trong kho.
                                </small>
                            </div>

                            <div class="mb-3">
                                <label for="quantity" class="form-label">Số Lượng Thay Đổi</label>
                                <input type="number" max="0" class="form-control" id="quantity" name="quantity"
                                    required>
                                <small class="form-text text-muted">
                                    <strong>Hướng dẫn:</strong>

                                    Nếu muốn xuất sản phẩm, nhập giá trị âm (ví dụ: -50 để xuất 50 sản phẩm).
                                </small>
                            </div>


                            <div class="form-group">
                                <label for="date_expert">Ngày Xuất Kho:</label>
                                <input type="date" class="form-control" id="date_expert" name="date_expert" required
                                    value="{{ old('date_expert') }}">
                            </div>


                            <div class="mb-3">
                                <label for="note" class="form-label">Ghi Chú</label>
                                <textarea required class="form-control" id="note" name="note" rows="3"></textarea>
                                <small class="form-text text-muted">
                                    Ghi chú lý do nhập/xuất sản phẩm.
                                </small>
                            </div>


                            <button type="submit" class="btn btn-success">Cập Nhật <i class="far fa-save"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
