@extends('layouts.admin')

@section('content')
    <div class="mt-5 px-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="title__highlight" style="color: #fff"><i class="fas fa-warehouse"></i> Nhập Kho </h3>
                    </div>

                    @if (session('status'))
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire({
                                    title: 'Thông báo',
                                    text: '{{ session('status') }}',
                                    icon: 'success',
                                    confirmButtonText: 'OK',
                                    confirmButtonColor: '#3085d6',
                                    background: '#fff',
                                    timer: 5000, // Tự động đóng sau 5 giây
                                    timerProgressBar: true,
                                });
                            });
                        </script>
                    @endif
                    <div class="card-body">
                        <form action="{{ route('stock.save') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="warehouse_id">Chọn Kho:</label>
                                <select name="warehouse_id" id="warehouse_id" class="form-control" required>
                                    <option value="">--Chọn--</option>
                                    @foreach ($data['warehouse'] as $warehouse)
                                        <option value="{{ $warehouse->id }}">{{ $warehouse->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="product_id">Chọn Sản Phẩm:</label>
                                <select name="product_id" id="product_id" class="form-control" required>
                                    <option value="">--Chọn--</option>
                                    @foreach ($data['product'] as $product)
                                        <option value="{{ $product->id }}">{{ $product->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="entry_date">Ngày Nhập Kho:</label>
                                <input type="date" class="form-control" id="entry_date" name="entry_date" required
                                    value="{{ old('entry_date') }}">
                            </div>


                            <div class="form-group">
                                <label for="quantity">Nhập Số Lượng :</label>
                                <input type="number" min="0" name="quantity" id="quantity" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="note">Ghi Chú :</label>
                                <input type="text" name="note" id="note" class="form-control" required>
                            </div>



                            <button type="submit" class="btn btn-success py-2 px-3">Thêm Mới <i
                                    class="fas fa-plus"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
