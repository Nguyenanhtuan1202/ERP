@extends('layouts.admin')


@php
    use Carbon\Carbon;
@endphp
@section('content')
    <div class="container">
        <div class="header">
            <h3 class="title__highlight">
                <i class="fas fa-cubes"></i> Danh Sách Tồn Kho
            </h3>
            <a class="add__expert" href="{{ route('stock.add') }}">Thêm Mới <i class="fas fa-plus"></i></a>
        </div>

        @if (session('status'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('status') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        timer: 3000,
                    });
                });
            </script>
        @endif

        <div class="table-responsive">
            <table class="table custom-table" id="inventory-table">
                <thead>
                    <tr>
                        <th>Quản Lý</th>
                        <th>STT</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Tên Kho</th>
                        <th>Địa Chỉ Kho</th>
                        <th>Người Chủ Kho</th>
                        <th>Tổng Số Lượng</th>
                        <th>Thời Gian</th>
                    </tr>
                </thead>
                <tbody>

                    @php
                        $temp_export = 5002;

                        $temp_export_total = 1000;

                        $temp_import_total = 15002;
                    @endphp
                    @foreach ($data['inventories'] as $index => $inventory)
                        @php
                            $temp_export++;
                            $temp_export_total++;
                            $temp_import_total++;
                        @endphp

                        <tr>
                            <td class="text-center">
                                <a href="{{ route('stock.edit', $inventory->id) }}" class="btn btn-primary">Xuất kho <i
                                        class="fas fa-file-export"></i></a>
                                <a href="{{ url('admin/stock/delete/' . $inventory->id) }}" class="btn btn-danger"
                                    onclick="return confirm('Bạn có muốn xóa sản phẩm này không?')">Xóa <i
                                        class="fas fa-trash-alt"></i></a>
                            </td>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $inventory->product->name ?? 'N/A' }}</td>
                            <td>{{ $inventory->warehouse->name ?? 'N/A' }}</td>
                            <td>{{ $inventory->warehouse->location ?? 'N/A' }}</td>
                            <td>{{ $inventory->warehouse->agent->name ?? 'N/A' }}</td>
                            <td>{{ number_format($inventory->total_quantity ?? 0) }}</td>
                            <td>
                                <button class="btn btn-info toggle-details btn__import"
                                    data-target="#details-in-{{ $index }}">Quản Lý Nhập Kho </button>
                                <button class="btn btn-info toggle-details btn__export"
                                    data-target="#details-out-{{ $index }}">Quản Lý Xuất Kho</button>
                            </td>
                        </tr>
                        <tr id="details-in-{{ $index }}" class="collapse">
                            <td colspan="12">
                                <div class="details-container">
                                    <h5 class="mt-3">Chi Tiết Nhập Kho Theo Ngày</h5>
                                    <table class="table align-items-center mb-0 table__customs"
                                        id="table{{ $index }}">
                                        <thead class="">
                                            <tr style="background-color: #0e0840 !important">
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    STT</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Ngày Nhập</th>

                                                <th style="font-size: 14px"
                                                    class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Số Lượng</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Người Nhập</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                                    Ghi Chú</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php
                                                $dailyTotalsIn = [];
                                                foreach ($data['stock'] as $item) {
                                                    if (
                                                        $item->warehouse_id == $inventory->warehouse_id &&
                                                        $item->product_id == $inventory->product_id
                                                    ) {
                                                        $date = \Carbon\Carbon::parse($item->entry_date)->format(
                                                            'Y-m-d',
                                                        );
                                                        if (!isset($dailyTotalsIn[$date])) {
                                                            $dailyTotalsIn[$date] = 0;
                                                        }
                                                        $dailyTotalsIn[$date] += $item->quantity;
                                                    }
                                                }
                                            @endphp
                                            @php
                                                $temp = 0;
                                            @endphp

                                            @foreach ($data['stock'] as $item)
                                                @if ($item->warehouse_id == $inventory->warehouse_id && $item->product_id == $inventory->product_id)
                                                    @php
                                                        $temp++;
                                                    @endphp

                                                    <tr>

                                                        <td class="align-middle text-center ">
                                                            {{ $temp }}
                                                        </td>


                                                        <td class="align-middle text-center ">
                                                            {{ \Carbon\Carbon::parse($item->entry_date)->format('d/m/Y') }}
                                                        </td>
                                                        <td class="align-middle text-center ">
                                                            {{ number_format($item->quantity) }}
                                                        </td>
                                                        <td class="align-middle text-center ">
                                                            {{ $item->added_by }}
                                                        </td>
                                                        <td class="align-middle text-center ">
                                                            {{ $item->note }}
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endforeach
                                        </tbody>
                                    </table>
                                    <h5 class="mt-3">Tổng Số Lượng Nhập Theo Ngày</h5>





                                    <table class="table align-items-center mb-0 table__customs"
                                        id="table{{ $temp_import_total }}">
                                        <thead>
                                            <tr style="background-color: #0e0840 !important">
                                                <th>STT</th>
                                                <th>Ngày Nhập</th>
                                                <th>Tổng Nhập</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @php
                                                $temps = 0;
                                            @endphp
                                            @foreach ($dailyTotalsIn as $date => $total)
                                                @php
                                                    $temps++;
                                                @endphp
                                                <tr>
                                                    <td>{{ $temps }}</td>
                                                    <td>{{ \Carbon\Carbon::parse($date)->format('d/m/Y') }}</td>
                                                    <td>{{ number_format($total) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                            </td>
                        </tr>
                        <tr id="details-out-{{ $index }}" class="collapse">
                            <td colspan="12">
                                <div class="details-container">
                                    <h5 class="mt-3">Chi Tiết Số Lượng Xuất Kho Theo Ngày</h5>
                                    <table class="table align-items-center mb-0 table__customs"
                                        id="table{{ $temp_export }}">
                                        <thead class="">
                                            <tr style="background-color: #0e0840 !important">
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    STT</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Ngày Xuất</th>

                                                <th style="font-size: 14px"
                                                    class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Số Lượng</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Người Xuất</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7 ps-2">
                                                    Ghi Chú</th>

                                            </tr>
                                        </thead>
                                        <tbody>

                                            @php
                                                $temp = 0;
                                            @endphp



                                            @foreach ($data['inventory_logs'] as $log)
                                                @if ($log->inventory_id == $inventory->id)
                                                    @php
                                                        $temp++;
                                                    @endphp


                                                    <tr>

                                                        <td class="align-middle text-center ">
                                                            {{ $temp }}
                                                        </td>


                                                        <td class="align-middle text-center ">
                                                            {{ $log->date_expert }}
                                                        </td>
                                                        <td class="align-middle text-center ">
                                                            {{ number_format($log->quantity_change) }}
                                                        </td>
                                                        <td class="align-middle text-center ">
                                                            {{ $log->updated_by }}
                                                        </td>

                                                        <td class="align-middle text-center ">
                                                            {{ $log->note }}
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endforeach

                                        </tbody>
                                    </table>

                                    <h5 class="mt-3">Tổng Số Lượng Xuất Kho Theo Ngày</h5>
                                    <table class="table align-items-center mb-0 table__customs"
                                        id="table{{ $temp_export_total }}">
                                        <thead class="">
                                            <tr style="background-color: #0e0840 !important">
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    STT</th>
                                                <th style="font-size: 14px"
                                                    class="text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Ngày Xuất</th>

                                                <th style="font-size: 14px"
                                                    class="text-center text-uppercase  text-sm font-weight-bolder opacity-7">
                                                    Tổng Số Lượng Xuất</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @php
                                                $temp = 0;
                                            @endphp
                                            @php
                                                $dailyTotalsOut = [];
                                                foreach ($data['inventory_logs'] as $log) {
                                                    if ($log->inventory_id == $inventory->id) {
                                                        $date = \Carbon\Carbon::parse($log->date_expert)->format(
                                                            'Y-m-d',
                                                        );
                                                        if (!isset($dailyTotalsOut[$date])) {
                                                            $dailyTotalsOut[$date] = 0;
                                                        }
                                                        $dailyTotalsOut[$date] += $log->quantity_change;
                                                    }
                                                }
                                            @endphp
                                            @foreach ($dailyTotalsOut as $date => $total)
                                                @php
                                                    $temp++;
                                                @endphp
                                                <tr>

                                                    <td class="align-middle text-center ">
                                                        {{ $temp }}
                                                    </td>
                                                    <td class="align-middle text-center ">
                                                        {{ \Carbon\Carbon::parse($date)->format('d/m/Y') }}
                                                    </td>
                                                    <td class="align-middle text-center ">
                                                        {{ number_format($total) }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>

                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>



        <div class="container mt-4">
            <h4>Tổng Số Lượng Nhập và Xuất Kho Theo Tháng</h4>
            <table class="table custom-table">
                <thead>
                    <tr>
                        <th>Tháng</th>
                        <th>Tổng Nhập</th>
                        <th>Tổng Xuất</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($data['monthly_stock_totals'] as $month => $totals)
                        <tr>
                            <td>{{ $month }}</td>
                            <td>{{ number_format($totals['total_in']) }}</td>
                            <td>{{ number_format($totals['total_out']) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        </div>


        <div class="datepicker-container">
            <input type="text" id="datepicker" placeholder="Select a date">
        </div>
        <div>
            <canvas id="dailyStockChart"></canvas>
        </div>



    </div>




    <style>
        .container {
            padding: 20px;
            max-width: 1300px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }

        .title__highlight {
            color: #343a40;
            font-size: 26px;
            font-weight: bold;
        }

        .add__expert {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .add__expert:hover {
            background-color: #0056b3;
        }

        .table-responsive {
            border-radius: 8px;
            overflow: hidden;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .custom-table thead {
            background-color: #007bff;
            color: white;
            text-align: center;
        }

        .custom-table th,
        .custom-table td {
            padding: 12px;
            border: 1px solid #e0e0e0;
        }

        .custom-table th {
            font-size: 14px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .custom-table tbody tr {
            background-color: #ffffff;
            transition: background-color 0.3s;
        }

        .custom-table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .custom-table tbody tr .btn {
            font-size: 14px;
            padding: 6px 10px;
            margin: 2px;
            border-radius: 4px;
        }

        .custom-table tbody tr .btn-primary {
            background-color: #1156a0;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 15px;
            font-weight: 600;
            text-transform: capitalize;
            border-radius: 8px;
        }

        .custom-table tbody tr .btn-primary:hover {
            background-color: #0056b3;
        }

        .custom-table tbody tr .btn-danger {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 15px;
            font-weight: 600;
            text-transform: capitalize;
            border-radius: 8px;
        }

        .custom-table tbody tr .btn-danger:hover {
            background-color: #c82333;
        }

        .time-display {
            background-color: #28a745;
            color: #fff;
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
        }

        .time-display:hover {
            background-color: #218838;
        }

        .details-container {
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            margin-top: 10px;
            border-left: 5px solid #007bff;
        }

        .details-item {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
        }

        .time-header {
            font-size: 16px;
            font-weight: bold;
            color: #007bff;
            margin-bottom: 8px;
            padding: 6px 12px;
            border-radius: 4px;
            background-color: #e9ecef;
        }

        .time-detail .badge {
            font-size: 13px;
            padding: 6px 10px;
            margin-right: 5px;
            border-radius: 4px;
            display: inline-block;
        }

        .badge.bg-success {
            background-color: #28a745;
            color: white;
        }

        .badge.bg-primary {
            background-color: #007bff;
            color: white;
        }

        .badge.bg-warning {
            background-color: #ffc107;
            color: black;
        }

        .badge.bg-secondary {
            background-color: #6c757d;
            color: white;
        }

        .badge.bg-danger {
            background-color: #dc3545;
            color: white;
        }

        .collapse {
            display: none;
        }

        .collapse.show {
            display: contents;
        }


        .btn__import {
            background-color: #24a642;
            font-size: 15px;
            font-weight: 700;
            display: block;
            margin-bottom: 10px !important;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
        }

        .btn__export {
            background-color: #0e0840;
            font-size: 15px;
            font-weight: 700;
            display: block;

            padding: 10px 20px;
            border: none;
            border-radius: 8px;
        }

        #datepicker {
            margin-top: 20px;
            margin-left: 20px;
            background-color: #e9ecef !important;
            padding: 10px 20px;
            border: none !important;
            border-radius: 10px;
            outline:none;
            box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;
        }
    </style>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleButtons = document.querySelectorAll('.toggle-details');

            toggleButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Ẩn tất cả các phần chi tiết
                    document.querySelectorAll('.collapse').forEach(collapse => {
                        if (collapse !== document.querySelector(this.getAttribute(
                                'data-target'))) {
                            collapse.classList.remove('show');
                        }
                    });

                    // Toggle phần chi tiết của nút đã nhấn
                    const target = document.querySelector(this.getAttribute('data-target'));
                    target.classList.toggle('show');
                });
            });
        });
    </script>
@endsection


@section('js')
    <!-- Thêm JS của Chart.js -->



    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Dữ liệu từ PHP controller
            const dailyStockTotals = @json($data['daily_stock_totals']);

            // Chuyển đổi dữ liệu thành dạng mà Chart.js có thể hiểu
            const labels = Object.keys(dailyStockTotals);
            const totalInData = labels.map(date => dailyStockTotals[date].total_in || 0);
            const totalOutData = labels.map(date => dailyStockTotals[date].total_out || 0);

            // Cấu hình biểu đồ Chart.js
            const ctx = document.getElementById('dailyStockChart').getContext('2d');
            let dailyStockChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                            label: 'Nhập Hàng',
                            data: totalInData,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Xuất Hàng',
                            data: totalOutData,
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed.y !== null) {
                                        label += context.parsed.y;
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Date'
                            },
                            ticks: {
                                autoSkip: false, // Hiển thị tất cả các nhãn trên trục X
                                maxRotation: 90, // Xoay nhãn trục X nếu cần
                                minRotation: 45
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Quantity'
                            },
                            ticks: {
                                callback: function(value) {
                                    return value; // Hiển thị giá trị trên trục Y
                                }
                            }
                        }
                    }
                }
            });

            // Khởi tạo Datepicker
            flatpickr("#datepicker", {
                dateFormat: "Y-m-d",
                onChange: function(selectedDates, dateStr, instance) {
                    if (selectedDates.length > 0) {
                        const selectedDate = dateStr;
                        updateChart(selectedDate);
                    }
                }
            });

            // Cập nhật biểu đồ khi chọn ngày
            function updateChart(date) {
                const filteredLabels = labels.filter(label => label === date);
                const filteredTotalInData = filteredLabels.map(label => dailyStockTotals[label] ? dailyStockTotals[
                    label].total_in : 0);
                const filteredTotalOutData = filteredLabels.map(label => dailyStockTotals[label] ? dailyStockTotals[
                    label].total_out : 0);

                dailyStockChart.data.labels = filteredLabels;
                dailyStockChart.data.datasets[0].data = filteredTotalInData;
                dailyStockChart.data.datasets[1].data = filteredTotalOutData;
                dailyStockChart.update();
            }
        });
    </script>








    <script>
        $(document).ready(function() {
            for (let i = 1000; i <= 5000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }


            for (let i = 5001; i <= 15000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }

            for (let i = 15001; i <= 20000; i++) {
                let table = $(`#table${i}`);
                if (table.length && table.is('table')) {
                    table.DataTable();
                }
            }

        });
    </script>
@endsection
