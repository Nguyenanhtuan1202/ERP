@extends('layouts.layout_warehousing')
@php
    use App\Models\PurchaseOrderItem;
@endphp


@section('content')
    <div class="container-fluid" style="padding: 25px;">
        <style>
            .items__custom {
                height: 40px;
                border-bottom: 1px solid #eee;
                display: flex;
                align-items: center;
            }

            .sumbit__confirm {
                padding: 8px 20px;
                border-radius: 20px;
                background: linear-gradient(141.55deg, #0caf60 3.46%, #0caf60 99.86%), #0caf60;
                color: #fff;
                box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
                font-weight: 600;
                font-size: 15px;
                margin-right: 10px;
                outline: none;
                border: none;
            }

            /* Hiển thị danh sách checkbox theo chiều dọc */
            .checkbox-list {
                display: flex;
                flex-direction: column;
                gap: 10px;
                /* Khoảng cách giữa các checkbox */
            }

            /* Tùy chỉnh checkbox */
            .checkbox-container {
                display: flex;
                align-items: center;
                gap: 10px;
                /* Khoảng cách giữa checkbox và SKU */
                font-size: 14px;
                cursor: pointer;
                margin: 0px;
                height: 33.5px;
                background-color: #fff;
                padding: 0px 20px;
                border-radius: 6px;
                border: 1px solid #0caf60;
            }

            /* Ẩn checkbox mặc định */
            .checkbox-container input {
                position: absolute;
                opacity: 0;
            }

            /* Thiết kế checkbox tùy chỉnh */
            .checkmark {
                position: relative;
                width: 20px;
                height: 20px;
                background-color: #fff;
                border: 2px solid #007bff;
                border-radius: 5px;
                transition: all 0.3s;
            }

            /* Hiệu ứng khi chọn checkbox */
            .checkbox-container input:checked~.checkmark {
                background-color: #007bff;
                border-color: #0056b3;
            }

            /* Dấu check khi chọn */
            .checkmark::after {
                content: "";
                position: absolute;
                display: none;
                left: 7px;
                top: 3px;
                width: 5px;
                height: 10px;
                border: solid white;
                border-width: 0 2px 2px 0;
                transform: rotate(45deg);
            }

            /* Hiển thị dấu check khi checkbox được chọn */
            .checkbox-container input:checked~.checkmark::after {
                display: block;
            }

            /* Định dạng nhãn SKU */
            .sku-label {
                font-size: 14px;
                color: #333;
            }

            .guild_uploads {
                background-color: #ffc30f8c;
                padding: 10px 20px;
                border: 2px dashed #111;
                border-radius: 6px;
            }

            /* CSS cho bảng tùy chỉnh */
            .table-custom {
                width: 100%;
                border-collapse: collapse;
                font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            }

            .table-custom thead {
                background-color: #082e4f;
                color: #fff;
            }

            .table-custom th,
            .table-custom td {
                padding: 0.75rem;
                text-align: center;
                border: 1px solid #dee2e6;
                vertical-align: middle;
            }

            .table-custom tbody tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .table-custom tbody tr:hover {
                background-color: #f1f1f1;
            }

            /* Style cho các đoạn nội dung bên trong ô */
            .item-content {
                margin: 0.25rem 0;
                font-size: 0.95rem;
                line-height: 1.3;
            }

            /* Input & Textarea: thiết kế hiện đại, nhỏ gọn */
            .custom-input,
            .custom-textarea {
                width: 100%;
                padding: 0.5rem;
                font-size: 0.9rem;
                border: 1px solid #ced4da;
                border-radius: 0.25rem;
                text-align: center;
                box-sizing: border-box;
                background-color: #e6e6e6;
                outline: none;
            }

            .custom-inputNew {
                width: 100%;
                padding: 0.5rem;
                font-size: 0.9rem;
                border: 1px solid #0caf60;
                border-radius: 0.25rem;
                text-align: center;
                box-sizing: border-box;
                outline: #0caf60;
            }

            .custom-textarea {
                resize: vertical;
                min-height: 3rem;
            }



            .checkbox-container input {
                margin-right: 0.3rem;
            }

            /* Responsive wrapper */
            .table-responsive {
                overflow-x: auto;
                margin: 1rem 0;
            }

            .input__orderQty {
                background: #17a2b8;
                color: #fff;
            }


            
        </style>
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <div class="row align-items-center justify-content-between listPurchaseOrder mb-3 mt-3 ">

            <div class="col-auto">
                <div class="page-header-title">
                    <h4 style="font-weight: 600; color: #0f2854;"> Danh Sách Các Phiếu Giao Hàng
                    </h4>
                    <div class="col-md-12 mb-3">
                        <div class="guild_uploads">
                            <h3 class="" style="text-decoration: underline">Lưu ý:</h3>
                            <p style="color: #111; font-weight: 400">- B1 Chọn ngày cần Xuất File Excel</p>
                            <p style="color: #111; font-weight: 400">- B2 Chọn Export Excel</p>

                        </div>
                    </div>

                </div>

            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ url('/') }}">Quay Lại Trang Chủ <i class="fas fa-undo-alt"></i></a>
                </div>
            </div>
        </div>



        <div class="table-responsive">
            <table class="table-custom table__delivery-list">
                <thead>
                    <tr>
                        <th>Đơn Hàng</th>
                        <th>SKU</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Ngày Nhận Hàng</th>
                        <th>SL Đặt Hàng</th>
                        <th>SL Đã Giao</th>
                        <th>SL Xưởng Làm Dư</th>
                        <th>Trạng Thái</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($data as $orderId => $items)
                        @php
                            $purchaseOrder = $items->first()->purchaseOrder ?? null;

                            $poId = $purchaseOrder->po_id ?? '';
                        @endphp
                        <tr>
                            <!-- Cột Đơn Hàng -->
                            <td>
                                <div class="item-content font-weight-bold">
                                    Đơn: {{ $purchaseOrder->getTotalQuantityAttribute() ?? '' }} |
                                    {{ $poId }}
                                </div>
                            </td>

                            <!-- Cột SKU -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input mb-1" value="{{ $item->sku ?? '' }}">
                                @endforeach
                            </td>

                            <!-- Cột Tên Sản Phẩm -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input mb-1"
                                        value="{{ $item->productSku->name ?? '' }}">
                                @endforeach
                            </td>

                            <!-- Cột Thời Gian -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input mb-1"
                                        value="{{ date('d-m-Y', strtotime($item->date_received ?? '')) }}">
                                @endforeach
                            </td>

                            <td>
                                @php
                                    $total_qty_order = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $data = PurchaseOrderItem::where(
                                            'purchase_order_id',
                                            $item->purchase_order_id ?? '',
                                        )
                                            ->where('sku', $item->sku)
                                            ->first();
                                        // Kiểm tra nếu $data tồn tại và có purchaseOrder trước khi gọi phương thức
                                    @endphp
                                    <input type="text" readonly class="custom-input mb-1 input__orderQty"
                                        value="{{ $data->quantity ?? '' }}">
                                @endforeach
                            </td>
                            <!-- Cột SL Dự Kiến Giao -->
                            <td>
                                @php
                                    $total_qty_forecast = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $total_qty_forecast += $item->qty;
                                    @endphp
                                    <input type="text" readonly class="custom-input mb-1 qty_forcasting"
                                        value="{{ $item->qty ?? '' }}">
                                @endforeach
                            </td>

                            <td>
                                @php
                                    $total_qty_more = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $total_qty_more += $item->qty_more;
                                    @endphp
                                    <input type="text" readonly class="custom-input mb-1"
                                        value="{{ $item->qty_more ?? '' }} {{ $item->important_note ? '|' : '' }} {{ $item->important_note ?? '' }}">
                                @endforeach
                            </td>
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input mb-1"
                                        value="{{ $item->delivery_notes ?? '' }} ">
                                @endforeach
                            </td>

                        </tr>

                        @if ($purchaseOrder->getTotalQuantityAttribute() == $total_qty_forecast)
                            <tr>

                                <td colspan="4"></td>
                                <td colspan="1"></td>
                                <td style=" background-color: #28a745; color: #fff; font-weight: 600" colspan="1">Đã nhận
                                    đủ SL: {{ $purchaseOrder->getTotalQuantityAttribute() }}
                                </td>
                                <td colspan="1"></td>
                                <td colspan="4"></td>
                            </tr>
                        @else
                            <tr>
                                <td colspan="4"></td>
                                <td colspan="1"> Số Lượng Còn Lại
                                    <span style="color: #dc3545; font-weight: 700; font-size: 22px;">
                                        <br>
                                        {{ $purchaseOrder->getTotalQuantityAttribute() - $total_qty_forecast }}</span>
                                </td>
                                <td colspan="1"> Số Lượng Đã Giao: <span
                                        style="color: #35dc5f; font-weight: 700; font-size: 22px;">
                                        <br>
                                        {{ $total_qty_forecast }}</span>
                                </td>
                                <td colspan="1"> Số Lượng Giao Dư: <span
                                        style="color: #ffc107; font-weight: 700; font-size: 22px;">
                                        <br>
                                        {{ $total_qty_more }}</span>
                                </td>
                                <td colspan="4"></td>
                            </tr>
                        @endif



                    @empty
                        <tr>
                            <td colspan="12" class="text-center">Không tìm thấy thông tin...</td>
                        </tr>
                    @endforelse


                    <input id="date_delivery"
                        style="box-shadow: none; outline: none; background: #1f9195; border:none;padding: 10px 30px; border-radius: 6px; color: #fff; font-weight:600"
                        type="date" name="date_delivery" class="mb-3">
                    @if ($data->count() > 0)
                        <a href="javascript:void(0);" id="export_excel"
                            style="background-color: rgb(15, 153, 63); padding: 12px 20px; border-radius: 6px; color: #fff; margin-left: 10px; font-weight: 600">
                            Export Excel <i class="fas fa-file-export"></i>
                        </a>
                    @endif

                </tbody>
            </table>
        </div>

    </div>
@endsection

@section('js')
    <script>
        document.getElementById("date_delivery").addEventListener("change", function() {
            let selectedDate = this.value;
            if (selectedDate) {
                window.location.href = `?date=${selectedDate}`;
            }
        });


        $(document).ready(function() {
            // Lấy ngày từ URL
            function getDateFromUrl() {
                const urlParams = new URLSearchParams(window.location.search);
                return urlParams.get('date'); // Lấy giá trị của tham số 'date'
            }

            let selectedDate = getDateFromUrl(); // Lấy ngày từ URL
            // Gán ngày từ URL vào input
            if (selectedDate) {
                $("#date_delivery").val(selectedDate);
            }
            $("#export_excel").click(function() {
                if (!selectedDate) {
                    // alert("Không tìm thấy ngày trên URL. Vui lòng chọn ngày trước khi xuất Excel.");

                    Swal.fire({
                        title: 'Lỗi',
                        text: 'Vui lòng chọn ngày trước khi xuất Excel.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                    return;
                }

                // Chuyển hướng đến route export
                window.location.href = "{{ route('export.orders') }}?date=" + selectedDate;
            });
        });
    </script>
@endsection
