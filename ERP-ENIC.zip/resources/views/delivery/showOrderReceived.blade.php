@extends('layouts.layout_warehousing')
@php
    use App\Models\PurchaseOrderItem;
@endphp

@section('css')
    <link rel="stylesheet" href="{{ asset('css/delivery.css') }}">
@endsection

@section('content')
    <div class="container-fluid">
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div style="margin-top: 100px">
            <div class="row align-items-center justify-content-between listPurchaseOrder  ml-2" style="width: 100%; ">
                <div class="col-auto">
                    <div class="page-header-title">

                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                      
                        <li class="breadcrumb-item active">
                            Hàng Về Thực Tế
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>

        <div class="row align-items-center justify-content-between listPurchaseOrder mb-3 ">
            <div class="col-auto">
                <div class="page-header-title">
                    <h4 style="font-weight: 600; color: #0f2854;"> Danh Sách Các Phiếu Giao Hàng
                    </h4>
                    <div class="col-md-12 mb-3">
                        <div class="guild_uploads_cus">
                            <h3 class="" style="text-decoration: underline">Lưu ý:</h3>
                            <p style="color: #111; font-weight: 400">- B1 Chọn ngày cần Xuất File Excel</p>
                            <p style="color: #111; font-weight: 400">- B2 Chọn Export Excel</p>

                        </div>
                    </div>

                </div>
            </div>
           
        </div>
        <div class="table-responsive" style="padding-bottom: 50px">
            <table class="table-custom_cus table table-striped d-block d-md-table">
                <thead>
                    <tr>
                        <th>Đơn Hàng</th>
                        <th>SKU</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Ngày Nhận Hàng</th>
                        <th>SL Đặt Hàng</th>
                        <th>SL Đã Giao</th>
                        <th>SL Xưởng Làm Dư</th>
                        <th>Trạng Thái</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($data as $orderId => $items)
                        @php
                            $purchaseOrder = $items->first()->purchaseOrder ?? null;

                            $poId = $purchaseOrder->po_id ?? '';
                        @endphp
                        <tr>
                            <!-- Cột Đơn Hàng -->
                            <td>
                                <div class="item-content_cus font-weight-bold">
                                    Đơn: {{ $purchaseOrder->getTotalQuantityAttribute() ?? '' }} |
                                    {{ $poId }} | {{ $purchaseOrder->supplier->username ?? '' }}
                                </div>
                            </td>

                            <!-- Cột SKU -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input_cus mb-1" value="{{ $item->sku ?? '' }}">
                                @endforeach
                            </td>

                            <!-- Cột Tên Sản Phẩm -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input_cus mb-1"
                                        value="{{ $item->productSku->name ?? '' }}">
                                @endforeach
                            </td>

                            <!-- Cột Thời Gian -->
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input_cus mb-1"
                                        value="{{ date('d-m-Y', strtotime($item->date_received ?? '')) }}">
                                @endforeach
                            </td>

                            <td>
                                @php
                                    $total_qty_order = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $data = PurchaseOrderItem::where(
                                            'purchase_order_id',
                                            $item->purchase_order_id ?? '',
                                        )
                                            ->where('sku', $item->sku)
                                            ->first();
                                        // Kiểm tra nếu $data tồn tại và có purchaseOrder trước khi gọi phương thức
                                    @endphp
                                    <input type="text" readonly class="custom-input_cus mb-1 input__orderQty_cus"
                                        value="{{ $data->quantity ?? '' }}">
                                @endforeach
                            </td>
                            <!-- Cột SL Dự Kiến Giao -->
                            <td>
                                @php
                                    $total_qty_forecast = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $total_qty_forecast += $item->qty;
                                    @endphp
                                    <input type="text" readonly class="custom-input_cus mb-1 qty_forcasting"
                                        value="{{ $item->qty ?? '' }}">
                                @endforeach
                            </td>

                            <td>
                                @php
                                    $total_qty_more = 0;
                                @endphp
                                @foreach ($items as $item)
                                    @php
                                        $total_qty_more += $item->qty_more;
                                    @endphp
                                    <input type="text" readonly class="custom-input_cus mb-1"
                                        value="{{ $item->qty_more ?? '' }} {{ $item->important_note ? '|' : '' }} {{ $item->important_note ?? '' }}">
                                @endforeach
                            </td>
                            <td>
                                @foreach ($items as $item)
                                    <input type="text" readonly class="custom-input_cus mb-1"
                                        value="{{ $item->delivery_notes ?? '' }} ">
                                @endforeach
                            </td>

                        </tr>

                        <tr>
                            <td colspan="5"></td>
                            <td style="background-color: #082e4f; color: #fff;" colspan="1">{{ $total_qty_forecast ?? '' }}</td>
                            <td colspan="3"></td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="12" class="text-center">Không tìm thấy thông tin...</td>
                        </tr>
                    @endforelse


                    <input id="date_delivery"
                        style="box-shadow: none; outline: none; background: #1f9195; border:none;padding: 10px 30px; border-radius: 6px; color: #fff; font-weight:600"
                        type="date" name="date_delivery" class="mb-3">
                    @if ($data->count() > 0)
                        <a href="javascript:void(0);" id="export_excel"
                            style="background-color: rgb(15, 153, 63); padding: 12px 20px; border-radius: 6px; color: #fff; margin-left: 10px; font-weight: 600">
                            Export Excel <i class="fas fa-file-export"></i>
                        </a>
                    @endif

                </tbody>
            </table>
        </div>


    </div>
@endsection

@section('js')
    <script>
        document.getElementById("date_delivery").addEventListener("change", function() {
            let selectedDate = this.value;
            if (selectedDate) {
                window.location.href = `?date=${selectedDate}`;
            }
        });


        $(document).ready(function() {
            // Lấy ngày từ URL
            function getDateFromUrl() {
                const urlParams = new URLSearchParams(window.location.search);
                return urlParams.get('date'); // Lấy giá trị của tham số 'date'
            }

            let selectedDate = getDateFromUrl(); // Lấy ngày từ URL
            // Gán ngày từ URL vào input
            if (selectedDate) {
                $("#date_delivery").val(selectedDate);
            }
            $("#export_excel").click(function() {
                if (!selectedDate) {
                    // alert("Không tìm thấy ngày trên URL. Vui lòng chọn ngày trước khi xuất Excel.");

                    Swal.fire({
                        title: 'Lỗi',
                        text: 'Vui lòng chọn ngày trước khi xuất Excel.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                    return;
                }

                // Chuyển hướng đến route export
                window.location.href = "{{ route('export.orders') }}?date=" + selectedDate + "&supplier="
            });
        });
    </script>
@endsection
