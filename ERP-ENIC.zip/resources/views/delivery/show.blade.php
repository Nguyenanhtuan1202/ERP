@extends('layouts.layout_factory')
@section('content')
    <div class="container-fluid" style="padding: 25px;">
        <style>
            .items__custom {
                border: 1px solid #17a2b8;
                border-radius: 8px;
                text-align: center;
                font-weight: 600;
                color: #17a2b8;
                padding: 5px 20px;
            }
        </style>
        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <div class="row align-items-center justify-content-between listPurchaseOrder mb-3 mt-3 ">

            <div class="col-auto">
                <div class="page-header-title">
                    <h4 style="font-weight: 600; color: #0f2854;"> Danh Sách Các Đơn Hàng Đang Giao
                    </h4>
                </div>
            </div>
            <div class="col-auto">
                <div class="d-flex">
                    <a class="addNew" href="{{ url('/') }}">Quay Lại Trang Chủ <i class="fas fa-undo-alt"></i></a>
                </div>
            </div>
        </div>


        <div class="">


            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Đơn Hàng</th>
                        <th>SKU</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Số Lượng Giao</th>
                        <th>Thời Gian Giao Hàng</th>
                        <th>Trạng Thái</th>
                    </tr>
                </thead>
                <tbody>



                    @forelse ($data as $orderId => $items)
                        @php
                            $purchaseOrder = $items->first()->purchaseOrder ?? null;
                            $poId = $purchaseOrder->po_id ?? '';
                        @endphp
                        <tr>
                            <td><strong>Đơn: {{ $purchaseOrder->getTotalQuantityAttribute() ?? '' }} |
                                    {{ $poId }}</strong></td>
                            <td>
                                @foreach ($items as $item)
                                    <p class="items__custom">{{ $item->sku ?? '' }}</p>
                                @endforeach
                            </td>
                            <td>
                                @foreach ($items as $item)
                                    <p class="items__custom">{{ $item->productSku->name ?? '' }}</p>
                                @endforeach
                            </td>
                            <td>
                                @foreach ($items as $item)
                                    <p class="items__custom">{{ $item->qty ?? '' }}</p>
                                @endforeach
                            </td>
                            <td>
                                @foreach ($items as $item)
                                    <p class="items__custom">
                                        {{ date('d-m-Y | H:i', strtotime($item->date_delivery ?? '')) }}
                                    </p>
                                @endforeach
                            </td>
                            <td class="items__custom">
                                <p>Đang Giao</p>
                                <img style="max-width: 200px; border-radius: 6px" src="{{ asset('/erp/ofd.gif') }}"
                                    alt="Giao Hàng">
                            </td>
                        </tr>
                    @empty
                        <td colspan="10" class="text-center">Chưa có sản phẩm nào có thể giao...</td>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection
