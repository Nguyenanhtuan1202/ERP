@extends('layouts.layout_warehousing')
@php
    use App\Models\PurchaseOrderItem;
    use App\Models\DeliveryDraft;
@endphp

@section('css')
    <link rel="stylesheet" href="{{ asset('css/delivery.css') }}">
@endsection

@section('content')
    <div class="container-fluid">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif


        <div class="row align-items-center  listPurchaseOrder mb-3 mt-5 ">
            <div class="col-auto">
                <div class="page-header-title">
                    <div class="col-md-12">
                        <h4 class="title__listOrder" style="font-weight: 600; color: #0f2854;"> Danh Sách Các Đơn Hàng Nhận Từ
                            Xưởng
                        </h4>
                    </div>
                    <div class="col-md-12 mb-3">
                        <div class="guild_uploads">
                            <h3 class="">Lưu ý:</h3>
                            <p style="color: #111">- Click vào <strong style="color: red">Lỗi / Sai số lượng
                                </strong> nếu xưởng giao thiếu hoặc dư</p>
                            <p style="color: #111">- Ghi chú<strong> Đã nhận đủ/ Hàng giao dư/ Hàng chưa giao </strong></p>
                            <p style="color: #111">- Sau khi kiểm tra số lượng nhận hàng thực thế hãy Nhấn vào <strong> Nhận
                                    Hàng </strong> để xác nhận đã nhận hàng xưởng
                                giao.</p>
                        </div>
                    </div>

                </div>

            </div>
            <div class="col-auto mobile_hidden">
                <div class="d-flex">
                    <a class="addNew" href="{{ url('/') }}">Quay Lại Trang Chủ <i class="fas fa-undo-alt"></i></a>
                </div>
            </div>
        </div>

        <form action="{{ route('processOrder') }}" method="POST">
            {{ csrf_field() }}
            <div class="table-responsive">

                <table class="table-custom-new table table-striped d-block d-md-table">
                    <thead>
                        <tr>
                            <th>Đơn Hàng</th>
                            <th>SKU</th>
                            <th>Tên Sản Phẩm</th>
                            <th>Hình SP</th>
                            <th>SL Đặt</th>
                            <th>Đã Nhận</th>
                            <th>SL Giao</th>

                            <th>SL Nhận <span><input style="width: 20px; height: 20px;" class="checkAllQty" type="checkbox"
                                        name="" id=""></span> </th>
                            <th>Ghi Chú <span><input style="width: 20px; height: 20px;" class="checkAllNote" type="checkbox"
                                        name="" id=""></span></th>
                            <th>Lỗi / Sai số lượng</th>

                            <th>Hình Xưởng Gửi</th>
                            <th>Ngày Giao</th>
                            <th>Bổ Sung</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($data as $orderId => $items)
                            @php
                                $purchaseOrder = $items->first()->purchaseOrder ?? null;

                                $poId = $purchaseOrder->po_id ?? '';
                            @endphp
                            <tr>
                                <!-- Cột Đơn Hàng -->
                                <td>
                                    <div class="item-content font-weight-bold">
                                        Đơn: {{ $purchaseOrder->getTotalQuantityAttribute() ?? '' }} |
                                        {{ $poId }} | {{ $purchaseOrder->supplier->username ?? '' }}
                                    </div>
                                </td>

                                <!-- Cột SKU -->
                                <td>
                                    @foreach ($items as $item)
                                        <input type="text" readonly class="custom-input mb-1"
                                            value="{{ $item->sku ?? '' }}">
                                    @endforeach
                                </td>

                                <!-- Cột Tên Sản Phẩm -->
                                <td>
                                    @foreach ($items as $item)
                                        <input type="text" readonly class="custom-input mb-1 product-input"
                                            value="{{ $item->productSku->name ?? '' }}" onclick="showPopup(this)">
                                    @endforeach
                                </td>

                                <!-- Popup -->
                                <div id="productPopup" class="popup hidden">
                                    <div class="popup-content">
                                        <span class="close-btn" onclick="closePopup()">&times;</span>
                                        <p id="popupText"></p>
                                    </div>
                                </div>

                                {{-- Hình ảnh của sản phẩm {{ $item->productSku->images ?? '' }} --}}
                                <td>
                                    @foreach ($items as $key => $item)
                                        <button style="border:none; width: 70px; padding: 0px;">
                                            <a class="box__img"
                                                href="{{ asset('uploads/product/' . $item->productSku->images ?? '') }}"
                                                data-fancybox="{{ $key }}">
                                                <img src="{{ asset('uploads/product/' . $item->productSku->images ?? '') }}"
                                                    alt="" style="">
                                            </a>
                                        </button>
                                    @endforeach
                                </td>

                                <td>
                                    @php
                                        $total_qty_order = 0;
                                    @endphp
                                    @foreach ($items as $item)
                                        @php
                                            $data = PurchaseOrderItem::where(
                                                'purchase_order_id',
                                                $item->purchase_order_id ?? '',
                                            )
                                                ->where('sku', $item->sku)
                                                ->first();
                                            // Kiểm tra nếu $data tồn tại và có purchaseOrder trước khi gọi phương thức
                                        @endphp
                                        <input type="text" readonly class="custom-input mb-1 input__order "
                                            value="{{ $data->quantity ?? '' }}">
                                    @endforeach
                                </td>

                                <td>
                                    @php
                                        $total_qty_order = 0;
                                    @endphp
                                    @foreach ($items as $item)
                                        @php
                                            $data = PurchaseOrderItem::where(
                                                'purchase_order_id',
                                                $item->purchase_order_id ?? '',
                                            )
                                                ->where('sku', $item->sku)
                                                ->first();
                                            // Kiểm tra nếu $data tồn tại và có purchaseOrder trước khi gọi phương thức
                                        @endphp

                                        @if ($data->qty_reality == 0)
                                        @else
                                            <input type="text" readonly class="custom-input mb-1  input__orderQty"
                                                value="{{ $data->qty_reality ?? '' }}">
                                        @endif
                                    @endforeach
                                </td>

                              

                                <!-- Cột SL Dự Kiến Giao -->
                                <td>
                                    @php
                                        $total_qty_forecast = 0;
                                    @endphp
                                    @foreach ($items as $item)
                                        @php
                                            $total_qty_forecast += $item->qty;
                                        @endphp
                                        <input type="text" readonly class="custom-input mb-1 qty_forcasting"
                                            value="{{ $item->qty ?? '' }}">
                                    @endforeach
                                </td>



                                <!-- Cột SL Nhận Thực Tế -->
                                <td>
                                    @foreach ($items as $key => $item)
                                        @php
                                            $data = PurchaseOrderItem::with('product', 'purchaseOrder')
                                                ->where('purchase_order_id', $item->purchase_order_id ?? '')
                                                ->where('sku', $item->sku)
                                                ->first();

                                            $delivery = DeliveryDraft::where(
                                                'purchase_order_id',
                                                $item->purchase_order_id ?? '',
                                            )
                                                ->where('sku', $item->sku)
                                                ->orderBy('id', 'desc')
                                                ->first();
                                        @endphp



                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][supplier_id]"
                                            value="{{ $delivery->supplier_id ?? '' }}">

                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][supplier_name]"
                                            value="{{ $delivery->supplier->username ?? '' }}">

                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][date_delivered]"
                                            value="{{ $delivery->date_delivery ?? '' }}">
                                        <input type="hidden" name="data[{{ $orderId }}][{{ $key }}][name]"
                                            value="{{ $data->product->name ?? '' }}">
                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][order_quantity]"
                                            value="{{ $data->quantity ?? '' }}">
                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][purchase_order_code]"
                                            value="{{ $item->purchaseOrder->po_id ?? '' }}">
                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][purchase_order_id]"
                                            value="{{ $item->purchase_order_id ?? 'SKU' }}">
                                        <input type="hidden" name="data[{{ $orderId }}][{{ $key }}][sku]"
                                            value="{{ $item->sku ?? '' }}">
                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][qty_more]"
                                            value="{{ $item->qty_more ?? '' }}">
                                        <input type="hidden"
                                            name="data[{{ $orderId }}][{{ $key }}][supplier_id]"
                                            value="{{ $item->supplier_id ?? '' }}">
                                        <input type="number" min="0" required
                                            class="custom-inputNew mb-1 qty_reality"
                                            name="data[{{ $orderId }}][{{ $key }}][qty]"
                                            placeholder="SL nhận">
                                    @endforeach
                                </td>

                                <!-- Cột SL Bổ Sung (Nếu có) -->


                                <!-- Cột Ghi Chú -->
                                <td>
                                    @foreach ($items as $key => $item)
                                        <input type="text" required class="custom-inputNew mb-1 delivery_notes"
                                            name="data[{{ $orderId }}][{{ $key }}][delivery_notes]"
                                            placeholder="Ghi chú">
                                    @endforeach
                                </td>

                                <!-- Cột Lỗi / Sai số lượng -->
                                <td>
                                    <div class="checkbox-list">
                                        @foreach ($items as $key => $item)
                                            <label class="checkbox-container checkbox-container-error">
                                                <input type="checkbox" class="custom-checkbox"
                                                    name="data[{{ $orderId }}][{{ $key }}][is_error]"
                                                    value="1" placeholder="{{ $item->sku ?? 'SKU' }}">
                                                <span class="checkmark"></span>
                                                <span class="sku-label">{{ $item->sku ?? 'SKU' }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                </td>



                                <td>
                                    @foreach ($items as $key => $item)
                                        @php
                                            // Kiểm tra dữ liệu ảnh; nếu không rỗng, giải mã JSON thành mảng
                                            if (!empty($item->images)) {
                                                $images = json_decode($item->images, true);
                                                if (!is_array($images)) {
                                                    $images = [$item->images];
                                                }
                                                // Tạo group ID duy nhất cho FancyBox cho mỗi item
                                                $groupId = 'imageGroup' . $key;
                                            }
                                        @endphp

                                        @if (!empty($item->images))
                                            <!-- Nút "Hình ảnh" được hiển thị khi có dữ liệu ảnh -->
                                            <button type="button" class="btn btn-sm view-image custom-inputNew"
                                                style=" border: 1px solid #ccc; padding: 6px 10px; margin-bottom: 5px"
                                                data-group="{{ $groupId }}">
                                                <img width="24px" src="{{ asset('/erp/apple.png') }}"
                                                    alt="picture.png">
                                            </button>

                                            <!-- Các liên kết ẩn chứa ảnh thuộc nhóm FancyBox -->
                                            {{-- Hình ảnh xưởng chụp, gửi đi kèm --}}
                                            @foreach ($images as $img)
                                                <a href="{{ asset($img) }}" data-fancybox="{{ $groupId }}"
                                                    style="display: none;">
                                                    <img src="{{ asset($img) }}" alt="Image"
                                                        style="width: 50px; height: 50px;">
                                                </a>
                                            @endforeach
                                        @else
                                            <!-- Nếu không có ảnh, hiển thị nút "Không hình" -->
                                            <button type="button" class="btn btn-sm custom-inputNew"
                                                style=" border: 1px solid #ccc; padding: 6px 10px; margin-bottom: 5px">
                                                <img width="24px" src="{{ asset('/erp/no-pictures.png') }}"
                                                    alt="no-pictures.png">
                                            </button>
                                        @endif
                                    @endforeach
                                </td>

                                <!-- Cột Thời Gian -->
                                <td>
                                    @foreach ($items as $item)
                                        <input type="text" readonly class="custom-input mb-1"
                                            value="{{ date('d-m-Y', strtotime($item->date_delivery ?? '')) }}">
                                    @endforeach
                                </td>

                                {{-- Giao bổ sung --}}
                                <td>
                                    @foreach ($items as $item)
                                        @if ($item->qty_more != null || $item->qty_more != '' || $item->qty_more != 0)
                                            <input type="text" readonly class="custom-input mb-1"
                                                value="{{ $item->important_note ? 'SL:' : '' }}{{ $item->qty_more ?? '' }} {{ $item->important_note ? '|' : '' }} {{ $item->note ?? '' }}">
                                        @endif
                                    @endforeach
                                </td>

                            </tr>
                            <tr>

                                <td colspan="5"></td>
                                <td colspan="2"> Số lượng giao: <span
                                        style="color: #dc3545; font-weight: 700; font-size: 22px;">

                                        {{ $total_qty_forecast }}</span>

                                </td>
                                <td colspan="6"></td>
                            </tr>

                        @empty
                            <tr>
                                <td colspan="13" class="text-center">Chưa có đơn giao hàng mới...</td>
                            </tr>
                        @endforelse

                        @if ($data->count() > 0)
                            <button type="submit" class="sumbit__confirm mb-3"
                                style="box-shadow: none; outline: none; background: #28a745 ; padding: 10px 30px; border-radius: 6px">
                                Nhận Hàng <i class="fas fa-check"></i>
                            </button>
                        @endif

                    </tbody>
                </table>
            </div>
        </form>



    </div>
@endsection


@section('js')
    <script>
        document.querySelector(".sumbit__confirm").addEventListener("click", function(event) {
            event.preventDefault(); // Ngăn form submit ngay lập tức

            let qtyInput = document.querySelector(".qty_reality"); // Lấy input số lượng nhận
            let qtyValue = qtyInput.value.trim(); // Lấy giá trị input và xóa khoảng trắng

            // Kiểm tra nếu input rỗng
            if (qtyValue === "") {
                Swal.fire({
                    title: "Lỗi!",
                    text: "Vui lòng nhập số lượng nhận thực tế!",
                    icon: "error",
                    confirmButtonText: "OK",
                    confirmButtonColor: "#d33"
                });
                return; // Dừng lại, không thực hiện xác nhận
            }

            // Nếu số lượng hợp lệ (bao gồm cả trường hợp nhập "0"), hiển thị xác nhận
            Swal.fire({
                title: "Xác nhận",
                text: "Nếu SL giao thiếu hoặc dư hãy tick vào SL Lỗi/ Giao Sai, bạn có chắc chắn muốn xác nhận không?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Xác nhận",
                cancelButtonText: "Hủy"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Gửi form khi người dùng nhấn "Xác nhận"
                    document.querySelector(".sumbit__confirm").closest("form").submit();
                }
            });
        });


        /* Hiển Thị Nút Xem Hình Ảnh */
        $(document).ready(function() {
            // Khi nút "Hình ảnh" được nhấn
            $('.view-image').on('click', function() {
                var group = $(this).data('group');
                // Kích hoạt click vào thẻ <a> đầu tiên trong group đó để mở FancyBox
                $('[data-fancybox="' + group + '"]').first().trigger('click');
            });

            // Nếu FancyBox không tự động bind, bạn có thể bind theo cách sau:
            Fancybox.bind('[data-fancybox]', {
                // Tùy chọn nếu cần, ví dụ: Toolbar: false, Thumbs: false,...
            });
        });

        $(document).ready(function() {
            // Khi checkbox header "checkAllQty" thay đổi trạng thái
            $('.checkAllQty').change(function() {
                if ($(this).is(':checked')) {
                    // Duyệt qua từng hàng trong tbody của bảng có class "table-custom-new"
                    $('.table-custom-new tbody tr').each(function() {
                        // Tìm các input dự kiến sử dụng class qty_forcasting trong hàng hiện tại
                        var predictedInputs = $(this).find('input.qty_forcasting');
                        // Tìm các input nhận thực tế sử dụng class qty_reality trong hàng hiện tại
                        var actualInputs = $(this).find('input.qty_reality');
                        // Với mỗi input dự kiến, lấy giá trị và gán vào input nhận thực tế có cùng chỉ số
                        predictedInputs.each(function(index) {
                            var predictedValue = $(this).val();
                            actualInputs.eq(index).val(predictedValue);
                        });
                    });
                } else {
                    // Nếu checkbox bị bỏ chọn, xóa giá trị của tất cả các input nhận thực tế
                    $('.table-custom-new tbody tr').each(function() {
                        $(this).find('input.qty_reality').val('');
                    });
                }
            });

        });


        $(document).ready(function() {
            $('.checkAllNote').change(function() {
                if ($(this).is(':checked')) {
                    // Khi checkbox được chọn, điền "đã nhận đủ" vào tất cả các input ghi chú
                    $('.table-custom-new tbody tr').each(function() {
                        $(this).find('input[name*="[delivery_notes]"]').val(
                            "Đã Nhận Đủ");
                    });
                } else {
                    // Khi checkbox bị bỏ chọn, xóa giá trị của các input ghi chú
                    $('.table-custom-new tbody tr').each(function() {
                        $(this).find('input[name*="[delivery_notes]"]').val("");
                    });
                }
            });
        });


        function showPopup(input) {
            const popup = document.getElementById('productPopup');
            const popupText = document.getElementById('popupText');

            // Hiển thị tên sản phẩm từ input
            popupText.textContent = input.value;

            // Hiển thị popup
            popup.style.display = 'block';
        }

        function closePopup() {
            document.getElementById('productPopup').style.display = 'none';
        }
        // Đóng popup khi nhấn ra ngoài
        window.onclick = function(event) {
            const popup = document.getElementById('productPopup');
            if (event.target === popup) {
                popup.style.display = 'none';
            }
        };
    </script>
@endsection
