@extends('layouts.layout_warehousing')
@section('content')
    <style>
        .table-custom th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #2d3436;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
            background-color: #f1f3f5;
        }

        .table-custom td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            color: #495057;
            vertical-align: top;
        }

        .table-custom tbody tr:hover {
            background-color: #f8f9fa;
            transition: background-color 0.2s ease;
        }

        /* Số thứ tự căn giữa */
        .table-custom td:first-child {
            text-align: center;
            font-weight: 500;
            color: #6c757d;
        }

        /* Làm nổi bật header */
        .table-custom thead tr {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        /* Định dạng các cột dài */
        .table-custom td:nth-child(2),
        .table-custom td:nth-child(3),
        .table-custom td:nth-child(10),
        .table-custom td:nth-child(11),
        .table-custom td:nth-child(12),
        {
        max-width: 250px;
        white-space: normal;
        word-break: break-word;
        }
    </style>
    <div class="container-fluid" style="padding: 25px;">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="col-auto">

            <div class="d-flex ml-3 mt-4">
                <a style="background:#17a2b8; box-shadow:none; padding: 10px 20px; border-radius: 10px;color: #fff;font-weight: 500;margin-right: 10px;"
                    href="{{ route('forecastProduct.import_excel') }}">Nhập
                    File Excel
                    <i class="fas fa-file-upload"></i> </a>
                <a style="background: rgb(23, 145, 88);box-shadow:none;padding: 10px 20px; border-radius: 10px;color: #fff;font-weight: 500;margin-right: 10px;"
                    href="{{ route('forecastProduct.export') }}">Xuất File Excel
                    <i class="fas fa-file-download"></i> </a>
            </div>
        </div>


        <div class="table-responsive">
            <table class="table-custom " id="table2">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nhà Cung Cấp</th>
                        <th>Sản Phẩm</th>
                        <th>MẪU (PHÂN LOẠI)</th>
                        <th>PHIÊN BẢN (model)</th>
                        <th>Key Sale</th>
                        <th>Sku</th>
                        <th>Giá</th>
                        <th>Trạng Thái</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $temp = 0;
                    @endphp
                    @foreach ($forecastProducts as $item)
                        @php
                            $temp++;
                        @endphp
                        <tr>
                            <td>{{ $temp }}</td>
                            <td>{{ $item->supplier_id ?? '' }}</td>
                            <td>{{ $item->product_name ?? '' }}</td>
                            <td>{{ $item->product_variant ?? '' }}</td>
                            <td>{{ $item->model_version ?? '' }}</td>
                            <td>{{ $item->sale_key ?? '' }}</td>
                            <td>{{ $item->sku ?? '' }}</td>
                            <td>{{ $item->price ?? '' }}</td>

                            @if ($item->status == 0)
                                <td class="text-center">
                                    <a style="font-size: 25px;"
                                        href="{{ route('forecastProduct.updateStatus', ['id' => $item->id, 'status' => 1]) }}">
                                        <i class="fas fa-toggle-off"></i>
                                    </a>
                                </td>
                            @elseif($item->status == 1)
                                <td class="text-center">
                                    <a style="font-size: 25px; color:green"
                                        href="{{ route('forecastProduct.updateStatus', ['id' => $item->id, 'status' => 0]) }}"><i
                                            class="fas fa-toggle-on"></i></a>
                                </td>
                            @endif

                            <td>
                                <a style="width: 80px; font-size: 14px; gap: 5px;display: flex; align-items: center;"
                                    class="btn btn-info"
                                    href="{{ route('forecastProduct.edit', ['id' => $item->id]) }}">Edit <i
                                        class="far fa-edit"></i></a>
                            </td>
                        </tr>
                    @endforeach


                </tbody>
            </table>
        </div>

    </div>
@endsection

@section('js')
@endsection
