@extends('layouts.enic')

@section('content')
    @php
        use Carbon\Carbon;
    @endphp
    <style>
        /* Typography & Base Styling */
        body {
            background-color: #f8fafc;
            color: #2d3748;
            line-height: 1.6;
        }

        /* Container Styling */
        .container-fluid {
            padding: 20px;
            background-color: #fff;
        }

        /* Card Advanced Styling */
        #update__info-product.card {
            border: none;
            border-radius: 10px;
            box-shadow:
                0 4px 6px rgba(0, 0, 0, 0.05),
                0 1px 3px rgba(0, 0, 0, 0.03);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

       

        #update__info-product .card-header {
            background: linear-gradient(135deg, #17a2b8 0%, #17a2b8 100%);
           
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        #update__info-product .card-title {
            font-weight: 600;
            margin: 0;
        }

        /* Form Control Advanced Styling */
        #update__info-product .form-control {
            border: 1px solid #dee2e6;
            border-radius: 3px;
            padding: 12px 15px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
        }

        #update__info-product .form-control:focus {
            border-color: #3182ce;
            box-shadow:
                0 0 0 3px rgba(49, 130, 206, 0.1),
                0 1px 3px rgba(0, 0, 0, 0.05);
            outline: none;
        }

        #update__info-product .form-label {
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }

        #update__info-product .form-label i {
            margin-right: 8px;
            color: #3182ce;
        }

        /* Input Group Styling */
        #update__info-product .input-group-text {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-right: none;
            color: #718096;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        }

        /* Select Styling */
        #update__info-product .select2-container .select2-selection--single {
            height: 46px !important;
            border: 1px solid #0a5d6a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }

        #update__info-product .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 46px;
            color: #2d3748;
        }

        /* Button Styling */
        #update__info-product .btn-primary {
            background: linear-gradient(135deg, #237536, #2a7f3d);
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(49, 130, 206, 0.15),
        }

        #update__info-product .btn-primary:hover {
            transform: translateY(-3px);
            background: linear-gradient(135deg, #2c5282, #1a365d);
            box-shadow:
                0 6px 12px rgba(49, 130, 206, 0.2),
                0 3px 6px rgba(0, 0, 0, 0.12);
        }

        /* Image Upload Styling */
        #update__info-product .custom-file-input {
            cursor: pointer;
            border: 1px dashed #e2e8f0;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s ease;
        }

        #update__info-product .custom-file-input:hover {
            background-color: rgba(49, 130, 206, 0.05);
            border-color: #3182ce;
        }

        /* Responsive Image Preview */
        #update__info-product .img-thumbnail {
            max-height: 250px;
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        #update__info-product .img-thumbnail:hover {
            transform: scale(1.03);
        }

        /* Breadcrumb Styling */
        .breadcrumb {
            background: transparent;
            padding: 10px 0;
            margin-bottom: 20px;
        }

        .breadcrumb-item a {
            color: #718096;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: #3182ce;
        }

        /* Error Validation Styling */
        #update__info-product .is-invalid {
            border-color: #e53e3e !important;
            box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.1) !important;
        }

        #update__info-product .invalid-feedback {
            color: #e53e3e;
            font-size: 0.85rem;
            margin-top: 5px;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            #update__info-product .card {
                margin-bottom: 15px;
            }

            #update__info-product .form-control {
                font-size: 0.9rem;
                padding: 10px 12px;
            }
        }



        /* Lịch sử chỉnh sửa */

        .historyModal__Product .product-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 6px;
        }

        .btn__customproductHistory.btn-history {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn__customproductHistory.btn-history:hover {
            background-color: #0056b3;
        }

        .historyModal__Product.modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .historyModal__Product .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
            height: 500px;
            overflow-y: scroll;
            position: relative;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .historyModal__Product .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .historyModal__Product .modal-header h2 {
            margin: 0;
            color: #333;
        }

        .historyModal__Product .close-btn {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .historyModal__Product .close-btn:hover {
            color: #333;
        }

        .historyModal__Product .history-summary {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .historyModal__Product .history-item {
            background-color: #f9f9f9;
            border-left: 4px solid #007bff;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 4px;
            transition: transform 0.3s ease;
        }

        .historyModal__Product .history-item:hover {
            transform: translateX(10px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .historyModal__Product .history-item-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .historyModal__Product .history-field {
            font-weight: bold;
            color: #007bff;
        }

        .historyModal__Product .history-time {
            color: #6c757d;
            font-size: 0.9em;
        }

        .historyModal__Product .history-changes {
            display: flex;
            align-items: center;
        }

        .historyModal__Product .old-value,
        .historyModal__Product .new-value {
            word-wrap: break-word;
            overflow-wrap: break-word !important;
            max-width: 288px;
            display: inline-block;
            line-height: 1.4;
        }

        .historyModal__Product .old-value {
            text-decoration: line-through;
            color: #dc3545;
            margin-right: 15px;
        }

        .historyModal__Product .history-user {
            margin-top: 10px;
            color: #6c757d;
            font-size: 0.9em;
        }
    </style>

    <div class="container-fluid px-4" style="margin-top: 80px">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="row mb-4 align-items-center">
            <div class="col-md-6">
                <h2 class="h3 mb-0">Update Product Forecast</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 bg-transparent p-0 pt-2">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('forecastProduct.index') }}">Danh Sách Sản Phẩm</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Cập Nhật</li>
                    </ol>
                </nav>
            </div>


            <div class="mt-6 col-md-6">
                <button onclick="openHistoryModal()" class="btn-history btn__customproductHistory">
                    <i class="fas fa-history"></i> Xem Lịch Sử Chỉnh Sửa
                </button>
            </div>


            {{-- Hiển Thị Lịch Sử  Chỉnh Sửa --}}
            <div id="historyModal" class="modal historyModal__Product">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>
                            <i class="fas fa-clipboard-list"></i> Lịch Sử Chỉnh Sửa Sản Phẩm
                        </h2>
                        <span class="close-btn" onclick="closeHistoryModal()">&times;</span>
                    </div>
                    @if ($data['totalEdits'] > 0)
                        <div class="history-summary">
                            <div>
                                <strong>Tổng Số Lần Chỉnh Sửa:</strong> {{ $data['totalEdits'] ?? '0' }} Lần
                            </div>
                            <div>
                                <strong>Lần Chỉnh Sửa Gần Nhất:</strong> {{ $data['latestEditTime'] ?? '' }}
                            </div>
                        </div>
                    @endif
                    <div class="history-list">
                        @forelse($data['productHistories'] as $item)
                            <div class="history-item">
                                <div class="history-item-header">
                                    <span class="history-field">
                                        <i class="fas fa-tag"></i> {{ $item->product->sale_key ?? '' }}
                                    </span>
                                    <span class="history-time">
                                        <i class="fas fa-clock"></i>
                                        {{ $item->changed_at ? Carbon::parse($item->changed_at)->diffForHumans() : 'Unknown Time' }}
                                    </span>
                                </div>
                                <div class="history-changes">
                                    <span>Từ:</span>
                                    <span class="old-value">{{ $item->old_value ?? '' }}</span>
                                    <span>Sang:</span>
                                    <span class="new-value">{{ $item->new_value ?? '' }}</span>
                                </div>
                                <div class="history-user">
                                    <i class="fas fa-user"></i>
                                    Người Chỉnh Sửa: {{ $item->user->name ?? 'Admin' }}
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3">
                                <i class="fas fa-history"></i> Chưa có lịch sử chỉnh sửa
                            </div>
                        @endforelse
                    </div>

                </div>
            </div>


        </div>

        <div class="card shadow-sm" id="update__info-product">
            <div class="card-body">
                <form id="productForecastForm" action="{{ route('forecastProduct.update', $forecastProduct->id) }}"
                    method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Product Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="supplier_id" class="form-label">Nhà Cung Cấp</label>
                                            <select name="supplier_id" id="supplier_id" class="form-control select3_init">
                                                @foreach ($list_supplier as $supplier)
                                                    <option value="{{ $supplier->sp_code }}"
                                                        {{ old('supplier_id', $forecastProduct->supplier_id) == $supplier->sp_code ? 'selected' : '' }}>
                                                      {{$supplier->sp_code}} - {{ $supplier->company_name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('supplier_id')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-6">
                                            <label for="product_name" class="form-label">Danh Mục Sản Phẩm</label>
                                            <input type="text"
                                                class="form-control @error('product_name') is-invalid @enderror"
                                                id="product_name" name="product_name"
                                                value="{{ old('product_name', $forecastProduct->product_name) }}" required>
                                            @error('product_name')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>

                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="product_variant" class="form-label">Mẫu (Phân Loại)</label>
                                            <input type="text" class="form-control" id="product_variant"
                                                name="product_variant"
                                                value="{{ old('product_variant', $forecastProduct->product_variant) }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="model_version" class="form-label">Phiên Bản ( Model)</label>
                                            <input type="text" class="form-control" id="model_version"
                                                name="model_version"
                                                value="{{ old('model_version', $forecastProduct->model_version) }}">
                                        </div>

                                        <div class="col-md-12 mt-2">
                                            <label for="sale_key" class="form-label">Key Chuẩn Sale</label>
                                            <input readonly type="text"
                                                class="form-control @error('sale_key') is-invalid @enderror" id="sale_key"
                                                name="sale_key" value="{{ old('sale_key', $forecastProduct->sale_key) }}"
                                                required>
                                            @error('sale_key')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="color" class="form-label">Màu Sắc</label>
                                            <input type="text" class="form-control" id="color" name="color"
                                                value="{{ old('color', $forecastProduct->color) }}">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="size" class="form-label">Kích Thước</label>
                                            <input type="text" class="form-control" id="size" name="size"
                                                value="{{ old('size', $forecastProduct->size) }}">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="sku" class="form-label">SKU</label>
                                            <input readonly type="text" class="form-control" id="sku"
                                                name="sku" value="{{ old('sku', $forecastProduct->sku) }}">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Pricing Details</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="price" class="form-label">Giá (Mua)</label>
                                            <div class="input-group">
                                                <input type="number" step="0.01" class="form-control "
                                                    id="price" name="price"
                                                    value="{{ old('price', $forecastProduct->price) }}" required>

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="unit" class="form-label">Đơn Vị</label>
                                            <select name="unit" id="unit" class="form-control">
                                                <option value=""
                                                    {{ old('unit', $forecastProduct->unit) == '' ? 'selected' : '' }}>
                                                    Select Unit</option>
                                                <option value="RMB"
                                                    {{ old('unit', $forecastProduct->unit) == 'RMB' ? 'selected' : '' }}>
                                                    RMB</option>
                                                <option value="USD"
                                                    {{ old('unit', $forecastProduct->unit) == 'USD' ? 'selected' : '' }}>
                                                    USD</option>
                                                <option value="VND"
                                                    {{ old('unit', $forecastProduct->unit) == 'VND' ? 'selected' : '' }}>
                                                    VND</option>
                                            </select>
                                        </div>

                                        <div class="col-md-4">
                                            <label for="price_vn" class="form-label">Giá Việt Nam</label>
                                            <div class="input-group">
                                                <input type="number" step="1" class="form-control format-number"
                                                    id="price_vn" name="price_vn"
                                                    value="{{ old('price_vn', $forecastProduct->price_vn) }}">
                                                <input type="hidden" class="real-value"><br><br>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="warehouse_price" class="form-label">Giá Nhập Về Kho</label>
                                            <div class="input-group">
                                                <input type="number" step="0.01" class="form-control"
                                                    id="warehouse_price" name="warehouse_price"
                                                    value="{{ old('warehouse_price', $forecastProduct->warehouse_price) }}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="selling_price" class="form-label">Giá Bán</label>
                                            <div class="input-group">
                                                <input type="number" step="0.01" class="form-control"
                                                    id="selling_price" name="selling_price"
                                                    value="{{ old('selling_price', $forecastProduct->selling_price) }}">
                                            </div>
                                        </div>
                                    </div>

                                </div>



                            </div>


                        </div>

                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Logistics & Shipping</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="length_cm" class="form-label">Chiều Dài Thùng Carton (cm)</label>
                                            <input type="number" step="0.1" class="form-control" id="length_cm"
                                                name="length_cm"
                                                value="{{ old('length_cm', $forecastProduct->length_cm) }}">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="width_cm" class="form-label">Chiều Rộng Carton (cm)</label>
                                            <input type="number" step="0.1" class="form-control" id="width_cm"
                                                name="width_cm"
                                                value="{{ old('width_cm', $forecastProduct->width_cm) }}">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="height_cm" class="form-label">Chiều Cao Carton (cm)</label>
                                            <input type="number" step="0.1" class="form-control" id="height_cm"
                                                name="height_cm"
                                                value="{{ old('height_cm', $forecastProduct->height_cm) }}">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="quantity_per_carton" class="form-label">Số Lượng Sản Phẩm Mỗi
                                                Thùng</label>
                                            <input type="number" class="form-control" id="quantity_per_carton"
                                                name="quantity_per_carton"
                                                value="{{ old('quantity_per_carton', $forecastProduct->quantity_per_carton) }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="cbm_per_ctn" class="form-label">Thể tích thùng (CBM)</label>
                                            <input type="number" step="0.01" class="form-control" id="cbm_per_ctn"
                                                name="cbm_per_ctn"
                                                value="{{ old('cbm_per_ctn', $forecastProduct->cbm_per_ctn) }}">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="quantity_per_container" class="form-label">Số Lượng Sản Phẩm Mỗi
                                                Container </label>
                                            <input type="number" class="form-control" id="quantity_per_container"
                                                name="quantity_per_container"
                                                value="{{ old('quantity_per_container', $forecastProduct->quantity_per_container) }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="freight_cost_per_cubic_meter" class="form-label">Cước vận chuyển
                                                trên mỗi CBM</label>
                                            <div class="input-group">

                                                <input type="number" step="0.01" class="form-control"
                                                    id="freight_cost_per_cubic_meter" name="freight_cost_per_cubic_meter"
                                                    value="{{ old('freight_cost_per_cubic_meter', $forecastProduct->freight_cost_per_cubic_meter) }}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="import_tax" class="form-label">Thuế nhập khẩu</label>
                                            <input type="number" step="0.01" class="form-control" id="import_tax"
                                                name="import_tax"
                                                value="{{ old('import_tax', $forecastProduct->import_tax) }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="additional_costs" class="form-label">Chi phí phát sinh
                                                khác</label>
                                            <div class="input-group">

                                                <input type="number" step="0.01" class="form-control"
                                                    id="additional_costs" name="additional_costs"
                                                    value="{{ old('additional_costs', $forecastProduct->additional_costs) }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Additional Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="product_note" class="form-label">Ghi Chú Sản Phẩm</label>
                                        <textarea class="form-control" id="product_note" name="product_note" rows="3">{{ old('product_note', $forecastProduct->product_note) }}</textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label for="image" class="form-label">Hình Ảnh Sản Phẩm</label>
                                        <input type="file" class="form-control" id="image" name="image"
                                            onchange="loadFile2(event)" accept="image/*">
                                        <div class="mt-2">
                                            <img style="max-width: 200px; border-radius: 8px;margin-top: 6px"
                                                src="{{ asset('uploads/forecast_products/' . $forecastProduct->image) }}"
                                                alt="{{ $forecastProduct->sku ?? '' }}" id="output2">
                                            <script>
                                                var loadFile2 = function(event) {
                                                    let output = document.getElementById('output2');
                                                    output.src = URL.createObjectURL(event.target.files[0]);
                                                    output.onload = function() {
                                                        URL.revokeObjectURL(output.src)
                                                    }
                                                };
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 text-end">
                            <a href="{{ route('forecastProduct.index') }}" class="btn btn-secondary"
                                style="padding: 10px 15px">
                                <i class="fas fa-arrow-left"></i>Back to List
                            </a>
                            <button type="button" id="submitBtn" class="btn btn-primary">
                                <i class="fas fa-save"></i> Cập Nhật
                            </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $('.select3_init').select2({
            'placeholder': 'Chọn'
        });

        document.addEventListener('DOMContentLoaded', function() {
            const submitBtn = document.getElementById('submitBtn');
            const productForecastForm = document.getElementById('productForecastForm');

            submitBtn.addEventListener('click', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Xác Nhận Cập Nhật',
                    text: 'Bạn có chắc chắn muốn cập nhật thông tin sản phẩm?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#007bff',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Xác Nhận',
                    cancelButtonText: 'Hủy Bỏ',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Optional: Add loading state to button
                        submitBtn.innerHTML =
                            '<i class="fas fa-spinner fa-spin"></i> Đang Cập Nhật';
                        submitBtn.disabled = true;

                        // Submit the form
                        productForecastForm.submit();
                    }
                });
            });
        });



        function openHistoryModal() {
            document.getElementById('historyModal').style.display = 'block';
        }

        function closeHistoryModal() {
            document.getElementById('historyModal').style.display = 'none';
        }

        // Đóng modal khi click ngoài modal
        window.onclick = function(event) {
            var modal = document.getElementById('historyModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
@endsection
