@extends('layouts.enic')

@section('content')
    <style>
        /* Global Color Palette */
        :root {
            --primary-color: #0CAF60;
            --primary-color-light: #10d771;
            --background-light: #f4f7fa;
            --text-color: #333;
            --border-color: #e0e6ed;
            --shadow-subtle: rgba(99, 114, 130, 0.16);
        }

        /* Container Styling */
        .box__view-import {
            background-color: var(--background-light);
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-top: 40px;
            transition: all 0.3s ease;
        }

        .box__view-import:hover {
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.08);
            transform: translateY(-5px);
        }

        /* Guild Upload Section */
        .guild_uploads {
            background: linear-gradient(145deg, #f0f9ff 0%, #f5fcff 100%);
            border: 2px dashed var(--primary-color);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .guild_uploads:hover {
            border-style: solid;
            box-shadow: 0 5px 20px rgba(12, 175, 96, 0.1);
        }

        .downloadFileImport {
            display: inline-block;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            padding: 10px 20px;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .downloadFileImport:hover {
            background-color: var(--primary-color);
            color: white;
        }

        /* Button Styling */
        .btn__uploads,
        .uploadsData {
            background: linear-gradient(141.55deg, var(--primary-color) 3.46%, var(--primary-color-light) 99.86%);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 35px;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 8px 15px rgba(12, 175, 96, 0.3);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn__uploads:hover,
        .uploadsData:hover {
            background: linear-gradient(141.55deg, var(--primary-color-light) 3.46%, var(--primary-color) 99.86%);
            box-shadow: 0 10px 20px rgba(12, 175, 96, 0.4);
            transform: translateY(-2px);
        }

        /* Input Styling */
        .file__uploads {
            border: 2px dashed var(--border-color);
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            margin-right: 15px;
            transition: all 0.3s ease;
        }

        .file__uploads:hover {
            border-color: var(--primary-color);
        }

        .custom__inputimport {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            background-color: white;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .custom__inputimport:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(12, 175, 96, 0.1);
        }

        /* Table Styling */
        #dataTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
            background-color: white;
        }

        #dataTable thead {
            background-color: var(--background-light);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        #dataTable th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: var(--text-color);
            border-bottom: 2px solid var(--border-color);
        }

        #dataTable tbody tr {
            transition: all 0.3s ease;
        }

        #dataTable tbody tr:hover {
            background-color: rgba(12, 175, 96, 0.05);
            transform: scale(1.01);
        }

        /* Scrollbar Styling */
        #previewTable,
        .box__show-recent {
            max-height: 600px;
            overflow-y: auto;
        }

        /* Scrollbar for Webkit browsers */
        #previewTable::-webkit-scrollbar,
        .box__show-recent::-webkit-scrollbar {
            width: 8px;
        }

        #previewTable::-webkit-scrollbar-track,
        .box__show-recent::-webkit-scrollbar-track {
            background: var(--background-light);
        }

        #previewTable::-webkit-scrollbar-thumb,
        .box__show-recent::-webkit-scrollbar-thumb {
            background-color: var(--primary-color);
            border-radius: 20px;
        }
    </style>

    <div class="container-fluid box__view-import" style="margin-top: 100px">

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        <div class="col-md-12 guild_uploads">
            <h3>Hướng dẫn upload dữ liệu</h3>

            <a class="downloadFileImport" download href="{{ asset('import/forcastProduct.xlsx') }}">Tải Xuống
                File Mẫu </a>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2>Import File Excel và Hiển Thị Thông Tin</h2>

                <form id="uploadForm" enctype="multipart/form-data" class="mt-4">
                    @csrf
                    <input type="file" class="file__uploads" name="file" id="file" required>
                    <button type="submit" class="btn__uploads">Upload <i class="fas fa-file-upload"></i></button>
                </form>

                <div id="previewTable" style="margin-top: 20px; display: none;">
                    <h2>Preview Data</h2>
                    <form id="saveForm" action="{{ route('forecastProduct.ImportFileExcel') }}" method="POST"
                        enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <table id="dataTable" class="table-responsive" style="height: 500px">
                            <thead>
                                <tr>
                                    <th>Mã Nhà Cung Cấp</th>
                                    <th>Sản Phẩm</th>
                                    <th>Mẫu (Phân Loại)</th>
                                    <th>Phiên Bản (Model) </th>
                                    <th>Màu Sắc</th>
                                    <th>Kích Thước</th>
                                    <th>Key Chuẩn (Sale)</th>
                                    <th>Sku</th>
                                    <th>Note ( Sản Phẩm)</th>
                                    <th>Note ( Sale)</th>
                                    <th>Hình Ảnh</th>
                                    <th>Giá</th>
                                    <th>Unit</th>
                                    <th>Giá VN</th>
                                    <th>Chiều dài (cm) Thùng Carton</th>
                                    <th>Chiều rộng (cm) Thùng Carton</th>
                                    <th>Chiều cao (cm) Thùng Carton</th>
                                    <th>Số lượng sản phẩm mỗi thùng</th>
                                    <th>Thể tích thùng (CBM)</th>
                                    <th>Số lượng sản phẩm mỗi container</th>
                                    <th>Cước vận chuyển trên mỗi CBM</th>
                                    <th>Thuế nhập khẩu</th>
                                    <th>Chi phí phát sinh khác</th>
                                    <th>Giá nhập về kho</th>
                                    <th>Giá bán</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                        <button class="uploadsData my-3" type="submit">Lưu <i class="fas fa-cloud-upload-alt"></i></button>
                    </form>
                </div>

            </div>

        </div>

    </div>
@endsection


@section('js')
    <script>
        $('#uploadForm').on('submit', function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            $.ajax({
                url: "{{ route('forecastProduct.uploadPreview') }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        let rows = response.data;
                        let tableBody = $('#dataTable tbody');
                        tableBody.empty(); // Clear existing data

                        rows.forEach((row, index) => {
                            let html = `
                        <tr class="tr__custom__inputimport">
                            <td><input class="custom__inputimport" type="text" name="data[${index}][supplier_id]" value="${row.supplier_id || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][product_name]" value="${row.product_name || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][product_variant]" value="${row.product_variant || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][model_version]" value="${row.model_version || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][color]" value="${row.color || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][size]" value="${row.size || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][sale_key]" value="${row.sale_key || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][sku]" value="${row.sku || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][product_note]" value="${row.product_note || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][sale_note]" value="${row.sale_note || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][image]" value="${row.image || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][price]" value="${row.price || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][unit]" value="${row.unit || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][price_vn]" value="${row.price_vn || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][length_cm]" value="${row.length_cm || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][width_cm]" value="${row.width_cm || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][height_cm]" value="${row.height_cm || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][quantity_per_carton]" value="${row.quantity_per_carton || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][cbm_per_ctn]" value="${row.cbm_per_ctn || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][quantity_per_container]" value="${row.quantity_per_container || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][freight_cost_per_cubic_meter]" value="${row.freight_cost_per_cubic_meter || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][import_tax]" value="${row.import_tax || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][additional_costs]" value="${row.additional_costs || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][warehouse_price]" value="${row.warehouse_price || ''}"></td>
                            <td><input class="custom__inputimport" type="text" name="data[${index}][selling_price]" value="${row.selling_price || ''}"></td>
                        </tr>
                        `;
                            tableBody.append(html);
                        });

                        $('#previewTable').show();
                    } else {
                        alert(response.message);
                    }
                }
            });
        });
    </script>
@endsection
