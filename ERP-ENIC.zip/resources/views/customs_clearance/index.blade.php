@extends('layouts.admin')

@section('content')
    <div class="container">
        <h1>Danh sách Hồ sơ Hải quan</h1>
        <a href="{{ route('customs_clearance.create') }}" class="btn btn-primary mb-3">Thêm hồ sơ mới</a>
        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <table class="table table-bordered" id="table1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Số tờ khai</th>
                    <th>Trạng thái</th>
                    <th>Lệ phí</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($clearances as $clearance)
                    <tr>
                        <td>{{ $clearance->id }}</td>
                        <td>{{ $clearance->declaration_number }}</td>
                        <td>{{ $clearance->status }}</td>
                        <td>{{ $clearance->fees }}</td>
                        <td>
                            <a href="{{ route('customs_clearance.show', ['id' => $clearance->id]) }}"
                                class="btn btn-info btn-sm">Xem</a>
                            <a href="{{ route('customs_clearance.edit', ['id' => $clearance->id]) }}"
                                class="btn btn-warning btn-sm">Sửa</a>
                            <a href="{{ route('customs_clearance.delete', ['id' => $clearance->id]) }}"
                                class="btn btn-danger btn-sm">Sửa</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

       
    </div>
@endsection
