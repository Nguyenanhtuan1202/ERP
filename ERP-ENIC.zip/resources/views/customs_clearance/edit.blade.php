@extends('layouts.admin')

@section('content')
<div class="container">
    <style>
        /* Container chính */
        .edit-customs-container {
            max-width: 900px;
            margin: 3rem auto;
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            font-family: 'Roboto', sans-serif;
        }
        .edit-customs-container h1 {
            text-align: center;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 30px;
            color: #2c3e50;
        }
        /* Accordion styles */
        .accordion .card {
            border: none;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 1.5rem;
            border: 1px solid #e1e1e1;
        }
        .accordion .card-header {
            background: #2980b9;
            color: #fff;
            padding: 15px 20px;
        }
        .accordion .card-header h2 {
            margin: 0;
            font-size: 1.2rem;
        }
        .accordion .card-header .btn-link {
            color: #fff;
            text-decoration: none;
            width: 100%;
            text-align: left;
            font-weight: 500;
        }
        .accordion .card-body {
            background: #f9f9f9;
            padding: 25px;
            border-top: 1px solid #e1e1e1;
        }
        /* Form fields */
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: 600;
            color: #34495e;
            margin-bottom: 8px;
            display: block;
        }
        .form-control {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 12px;
            font-size: 1rem;
            width: 100%;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color: #2980b9;
            box-shadow: 0 0 8px rgba(41, 128, 185, 0.2);
        }
        /* Button */
        .btn-success {
            background: #27ae60;
            border: none;
            padding: 12px 30px;
            font-size: 1.1rem;
            border-radius: 5px;
            color: #fff;
            display: block;
            margin: 30px auto 0;
            transition: background 0.3s ease;
        }
        .btn-success:hover {
            background: #219150;
        }
    </style>
    <div class="edit-customs-container">
        <h1>Chỉnh sửa Hồ sơ Hải quan</h1>
        <form action="{{ route('customs_clearance.update', ['id' => $customsClearance->id]) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="accordion" id="customsAccordion">
                <!-- Khối Thông tin cơ bản -->
                <div class="card">
                    <div class="card-header" id="headingBasic">
                        <h2 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseBasic" aria-expanded="true" aria-controls="collapseBasic">
                                Thông tin cơ bản
                            </button>
                        </h2>
                    </div>
                    <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic" data-parent="#customsAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Số tờ khai</label>
                                <input type="text" name="declaration_number" class="form-control" value="{{ old('declaration_number', $customsClearance->declaration_number) }}" required>
                            </div>
                            <div class="form-group">
                                <label>Ngày thông quan</label>
                                <input type="date" name="clearance_date" class="form-control" value="{{ old('clearance_date', $customsClearance->clearance_date) }}">
                            </div>
                            <div class="form-group">
                                <label>Trạng thái</label>
                                <select name="status" class="form-control" required>
                                    <option value="Chờ duyệt" {{ old('status', $customsClearance->status)=='Chờ duyệt' ? 'selected' : '' }}>Chờ duyệt</option>
                                    <option value="Thông quan" {{ old('status', $customsClearance->status)=='Thông quan' ? 'selected' : '' }}>Thông quan</option>
                                    <option value="Bị từ chối" {{ old('status', $customsClearance->status)=='Bị từ chối' ? 'selected' : '' }}>Bị từ chối</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Khối Thông tin bổ sung -->
                <div class="card">
                    <div class="card-header" id="headingAdditional">
                        <h2 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseAdditional" aria-expanded="false" aria-controls="collapseAdditional">
                                Thông tin bổ sung
                            </button>
                        </h2>
                    </div>
                    <div id="collapseAdditional" class="collapse" aria-labelledby="headingAdditional" data-parent="#customsAccordion">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Lệ phí</label>
                                <input type="number" step="0.01" name="fees" class="form-control" value="{{ old('fees', $customsClearance->fees) }}">
                            </div>
                            <div class="form-group">
                                <label>Chứng từ (Documents)</label>
                                @if($customsClearance->documents)
                                    <p>File hiện tại: {{ $customsClearance->documents }}</p>
                                @endif
                                <input type="file" name="file_contract" class="form-control">
                                <!-- Nếu cần hỗ trợ upload nhiều file, bạn có thể sử dụng name="file_contract[]" và attribute multiple -->
                            </div>
                            <div class="form-group">
                                <label>Ghi chú</label>
                                <textarea name="notes" class="form-control">{{ old('notes', $customsClearance->notes) }}</textarea>
                            </div>
                            <div class="form-group">
                                <label>Lô hàng (Shipment)</label>
                                <select name="shipment_id" class="form-control" required>
                                    <option value="">Chọn lô hàng</option>
                                    @foreach($shipments as $shipment)
                                        <option value="{{ $shipment->id }}" {{ old('shipment_id', $customsClearance->shipment_id)==$shipment->id ? 'selected' : '' }}>
                                            {{ $shipment->tracking_number }} - {{ $shipment->origin_port }} → {{ $shipment->destination_port }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label>ID hồ sơ (id_hs)</label>
                                <input type="text" name="id_hs" class="form-control" value="{{ old('id_hs', $customsClearance->id) }}" required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-success">Cập nhật Hồ sơ Hải quan</button>
        </form>
    </div>
</div>
@endsection
