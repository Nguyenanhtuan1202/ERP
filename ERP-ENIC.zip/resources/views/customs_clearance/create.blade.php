@extends('layouts.admin')

@section('content')
    <div class="container">
        <style>
            /* Container chính */
            .create-customs-container {
                max-width: 100%;
                margin: 3rem auto;
                background: #fff;
                padding: 40px;
                border-radius: 12px;
                box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
                font-family: 'Roboto', sans-serif;
            }

            .create-customs-container h1 {
                text-align: center;
                font-size: 2.5rem;
                font-weight: 700;
                margin-bottom: 30px;
                color: #2c3e50;
            }

            /* Accordion styles */
            .accordion .card {
                border: none;
                border-radius: 8px;
                overflow: hidden;
                margin-bottom: 1.5rem;
                border: 1px solid #e1e1e1;
            }

            .accordion .card-header {
                background: #2980b9;
                color: #fff;
                padding: 15px 20px;
            }

            .accordion .card-header h2 {
                margin: 0;
                font-size: 1.2rem;
            }

            .accordion .card-header .btn-link {
                color: #fff;
                text-decoration: none;
                width: 100%;
                text-align: left;
                font-weight: 500;
            }

            .accordion .card-body {
                background: #f9f9f9;
                padding: 25px;
                border-top: 1px solid #e1e1e1;
            }

            /* Form fields */
            .form-group {
                margin-bottom: 20px;
            }

            .form-group label {
                font-weight: 600;
                color: #34495e;
                margin-bottom: 8px;
                display: block;
            }

            .form-control {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 12px;
                font-size: 1rem;
                width: 100%;
                transition: border-color 0.3s ease;
            }

            .form-control:focus {
                border-color: #2980b9;
                box-shadow: 0 0 8px rgba(41, 128, 185, 0.2);
            }

            /* Button */
            .btn-success {
                background: #27ae60;
                border: none;
                padding: 12px 30px;
                font-size: 1.1rem;
                border-radius: 5px;
                color: #fff;
                display: block;
                margin: 30px auto 0;
                transition: background 0.3s ease;
            }

            .btn-success:hover {
                background: #219150;
            }
        </style>

        @if (session('success'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Thông báo',
                        text: '{{ session('success') }}',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif

        @if (session('error'))
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Lỗi',
                        text: '{{ session('error') }}',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        background: '#fff',
                        timer: 5000, // Tự động đóng sau 5 giây
                        timerProgressBar: true,
                    });
                });
            </script>
        @endif



        <div class="create-customs-container">
            <h1>Thêm Hồ sơ Hải quan mới</h1>
            <form action="{{ route('customs_clearance.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="accordion" id="customsAccordion">
                    <!-- Khối Thông tin cơ bản -->
                    <div class="card">
                        <div class="card-header" id="headingBasic">
                            <h2 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse"
                                    data-target="#collapseBasic" aria-expanded="true" aria-controls="collapseBasic">
                                    Thông tin cơ bản
                                </button>
                            </h2>
                        </div>
                        <div id="collapseBasic" class="collapse show" aria-labelledby="headingBasic"
                            data-parent="#customsAccordion">
                            <div class="card-body">
                                <div class="form-group">
                                    <label>Số tờ khai</label>
                                    <input type="text" name="declaration_number" class="form-control"
                                        value="{{ old('declaration_number') }}" required>
                                </div>
                                <div class="form-group">
                                    <label>Ngày thông quan</label>
                                    <input type="date" name="clearance_date" class="form-control"
                                        value="{{ old('clearance_date') }}">
                                </div>
                                <div class="form-group">
                                    <label>Trạng thái</label>
                                    <select name="status" class="form-control" required>
                                        <option value="Chờ duyệt" {{ old('status') == 'Chờ duyệt' ? 'selected' : '' }}>Chờ
                                            duyệt</option>
                                        <option value="Thông quan" {{ old('status') == 'Thông quan' ? 'selected' : '' }}>Thông
                                            quan</option>
                                        <option value="Bị từ chối" {{ old('status') == 'Bị từ chối' ? 'selected' : '' }}>Bị từ
                                            chối</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Khối Thông tin bổ sung -->
                    <div class="card">
                        <div class="card-header" id="headingAdditional">
                            <h2 class="mb-0">
                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                    data-target="#collapseAdditional" aria-expanded="false"
                                    aria-controls="collapseAdditional">
                                    Thông tin bổ sung
                                </button>
                            </h2>
                        </div>
                        <div id="collapseAdditional" class="collapse" aria-labelledby="headingAdditional"
                            data-parent="#customsAccordion">
                            <div class="card-body">
                                <div class="form-group">
                                    <label>Lệ phí</label>
                                    <input type="number" step="0.01" name="fees" class="form-control"
                                        value="{{ old('fees') }}">
                                </div>
                                <div class="form-group">
                                    <label>Chứng từ (Documents)</label>
                                    <input required type="file" name="documents[]" class="form-control" multiple>
                                </div>

                                <div class="form-group">
                                    <label>Ghi chú</label>
                                    <textarea name="notes" class="form-control">{{ old('notes') }}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Lô hàng (Shipment)</label>
                                    <select name="shipment_id" class="form-control" required>
                                        <option value="">Chọn lô hàng</option>
                                        @foreach ($shipments as $shipment)
                                            <option value="{{ $shipment->id }}"
                                                {{ old('shipment_id') == $shipment->id ? 'selected' : '' }}>
                                                {{ $shipment->tracking_number }} - {{ $shipment->origin_port }} →
                                                {{ $shipment->destination_port }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Tạo Hồ sơ Hải quan</button>
            </form>
        </div>
    </div>
@endsection
