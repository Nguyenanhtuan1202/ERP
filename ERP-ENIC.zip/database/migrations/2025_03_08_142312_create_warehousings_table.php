<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWarehousingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('warehousings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('purchase_order_id')->nullable();
            $table->string('sku')->nullable();
            $table->string('name')->nullable();
            $table->integer('order_quantity')->default(0);
            $table->integer('qty_received')->default(0); // Số lượng đã nhập kho (xác nhận)
            $table->integer('qty_more')->default(0);     // Số lượng vượt (nếu có)
            $table->date('entry_date')->nullable()->comment('Ngày nhập kho'); // Ngày nhập kho (lịch sử)
            $table->timestamp('date_received')->nullable()->comment('Thời gian xác nhận nhập kho');
            $table->unsignedBigInteger('supplier_id')->nullable();
            $table->text('delivery_notes')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('warehousings');
    }
}
