<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHistoryWarehousesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('history_warehouses', function (Blueprint $table) {
            $table->id();
            // Nếu bạn muốn liên kết với kho chính, lưu lại warehouse_id (có thể null nếu lưu nhiều dòng chi tiết)
            $table->unsignedBigInteger('warehouse_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            // Cột details sẽ lưu thông tin JSON chứa nhiều SKU và số lượng tương ứng
            $table->json('details')->nullable()->comment('Lưu chi tiết nhập kho: danh sách các đối tượng chứa sku, product_name, quantity_entered, ...');
            $table->timestamp('entry_time')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('history_warehouses');
    }
}
