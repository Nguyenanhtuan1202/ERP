<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDepositPaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deposit_payments', function (Blueprint $table) {
            $table->id();
            // Liên kết đến đơn hàng, giả sử bảng orders có trường id kiểu unsignedBigInteger
            $table->unsignedBigInteger('order_id');
            // Số tiền thanh toán, sử dụng kiểu decimal với độ chính xác 15,2 (tùy chỉnh theo yêu cầu)
            $table->decimal('amount', 15, 2);
            // Thời điểm thanh toán
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            // Thiết lập khoá ngoại (foreign key) liên kết đến bảng orders, xóa theo cascade khi đơn hàng bị xóa
            $table->foreign('order_id')->references('id')->on('orders')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deposit_payments');
    }
}
