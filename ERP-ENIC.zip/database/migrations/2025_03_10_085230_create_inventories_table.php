<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInventoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inventories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->onDelete('cascade');
            $table->integer('shipping_time')->nullable()->comment('Thời gian vận chuyển (số ngày)');
            $table->integer('total_warehouse_time')->nullable()->comment('Tổng thời gian hàng về kho (số ngày)');
            $table->integer('stock_in_warehouse')->nullable()->comment('Tồn trong kho');
            $table->integer('goods_in_transit')->nullable()->comment('Hàng đang load về');
            $table->integer('goods_ordered_stored')->nullable()->comment('Hàng đang đặt+lưu kho');
            $table->integer('reserved_stock')->nullable()->comment('SL hàng giữ tồn kho');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inventories');
    }
}
