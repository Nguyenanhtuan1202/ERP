<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliveriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deliveries', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('purchase_order_id');
            $table->string('sku');
            $table->integer('qty');
            $table->dateTime('date_delivery');
            $table->string('status')->nullable();
            $table->string('tracking_number')->nullable();
            $table->text('delivery_address')->nullable();
            $table->string('receiver_name')->nullable();
            $table->string('receiver_contact')->nullable();
            $table->text('delivery_notes')->nullable();
            $table->enum('delivery_method', ['Standard', 'Express'])->default('Standard')->nullable();
            $table->string('carrier')->nullable();
            $table->decimal('delivery_fee', 10, 2)->default(0);
            $table->timestamps();

            $table->foreign('purchase_order_id')->references('id')->on('purchase_orders')
                ->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deliveries');
    }
}
