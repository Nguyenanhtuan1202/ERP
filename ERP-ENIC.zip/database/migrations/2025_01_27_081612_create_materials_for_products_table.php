<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMaterialsForProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('materials_for_products', function (Blueprint $table) {
            $table->id();
            $table->integer('tier_code'); // Mã tier_code
            $table->string('size',100); // Kích thước
            $table->string('color',100); // Màu sắc
            $table->string('sku',100); // Mã SKU của vật tư
            $table->string('name'); // Tên vật tư
            $table->integer('quantity'); // Số lượng
            $table->string('total_price',200); // Thành tiền
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('materials_for_products');
    }
}
