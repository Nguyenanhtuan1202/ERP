<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePartnersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('partners', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            // Nếu bảng này không dùng cho authentication chính, bạn có thể để password nullable hoặc bỏ qua trường này
            $table->string('password')->nullable();
            // Các vai trò: khách hàng, hãng tàu, kế toán, nhân viên hải quan, nhân viên kho, đại lý logistics, admin
            $table->enum('role', ['customer', 'carrier', 'accountant', 'customs_officer', 'warehouse_staff', 'logistics_agent', 'admin']);
            $table->string('phone')->nullable();
            $table->string('address')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('partners');
    }
}
