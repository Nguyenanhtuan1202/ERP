<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWarehouseDraftsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('warehouse_drafts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('purchase_order_id')->nullable();
            $table->string('sku')->nullable();
            $table->string('name')->nullable();
            $table->integer('order_quantity')->default(0);
            $table->integer('qty_received')->default(0);
            $table->integer('qty_more')->default(0);
            $table->dateTime('date_received')->nullable();
            $table->text('delivery_notes')->nullable();
            $table->unsignedBigInteger('supplier_id')->nullable();
            $table->tinyInteger('status')->default(0); // 0: draft, 1: confirmed
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('warehouse_drafts');
    }
}
