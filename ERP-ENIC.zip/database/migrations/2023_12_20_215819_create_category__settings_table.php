<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCategorySettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('category__settings', function (Blueprint $table) {
            $table->id();
            $table->string('meta_seo');
            $table->string('key_seo');
            $table->string('desc_seo');
            $table->longText('content');
            $table->integer('num_list');
            $table->integer('num_list_orther');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('category__settings');
    }
}
