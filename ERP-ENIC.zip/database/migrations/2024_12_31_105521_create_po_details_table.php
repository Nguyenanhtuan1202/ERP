<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePoDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('po_details', function (Blueprint $table) {
            $table->id();
            $table->string('po');
            $table->string('code_po');
            $table->string('sku');
            $table->string('name');
            $table->integer('primary_qty')->nullable();
            $table->integer('forecast_qty')->nullable();
            $table->integer('actual_qty')->nullable();
            $table->integer('remain_qty')->nullable();
            $table->date('date_forecast')->nullable();
            $table->date('date_forecast_by_sale')->nullable();
            $table->string('warehousing');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('po_details');
    }
}
