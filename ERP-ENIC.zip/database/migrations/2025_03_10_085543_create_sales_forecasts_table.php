<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalesForecastsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales_forecasts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->onDelete('cascade');
            $table->integer('turnover')->nullable()->comment('Luân chuyển (số lần/chu kỳ)');
            $table->integer('customer_orders')->nullable()->comment('Khách đã đặt');
            $table->float('avg_daily_sales_cycle')->nullable()->comment('SL bán trong 1 chu kỳ/ngày');
            $table->float('avg_daily_sales_recent_week')->nullable()->comment('SL bán trong 1 tuần gần nhất/ngày');
            $table->float('forecast_daily_sales_to_end_T3')->nullable()->comment('Dự toán SL bán được/ngày today đến hết T3');
            $table->float('preorder_daily_tracking_forecast')->nullable()->comment('Dự toán theo dõi/ngày (trước khi đặt)');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales_forecasts');
    }
}
