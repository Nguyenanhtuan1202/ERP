<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRepairOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('repair_orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_code')->nullable()->comment('Mã đơn hàng hoặc "Bảo hành" nếu không có');
            $table->string('customer_name')->nullable()->comment('Tên khách hàng hoặc đối tác');
            $table->string('customer_phone')->nullable()->comment('Số điện thoại khách hàng');

            // Sản phẩm
            $table->string('sku')->nullable()->comment('Mã SKU, có thể NULL nếu là phụ kiện');
            $table->string('product_name')->nullable()->comment('Tên sản phẩm hoặc phụ kiện linh kiện');
            $table->integer('quantity')->default(1)->comment('Số lượng sản phẩm hoặc phụ kiện');
            $table->enum('product_type', ['inox', 'nhôm', 'khác'])->default('khác')->comment('Loại vật liệu');

            // Loại sản phẩm: Sản phẩm chính hay phụ kiện (kính, gương)
            $table->enum('product_category', ['sản phẩm', 'phụ kiện'])->default('sản phẩm')->comment('Phân biệt sản phẩm hoặc phụ kiện');

            // Thông tin sửa chữa / bảo hành
            $table->enum('repair_type', ['Bảo hành', 'Sửa chữa'])->default('Bảo hành')->comment('Loại dịch vụ');
            $table->date('warranty_date')->nullable()->comment('Ngày bắt đầu bảo hành hoặc sửa chữa');
            $table->date('completion_date')->nullable()->comment('Ngày hoàn thành bảo hành/sửa chữa');

            // Thanh toán
            $table->boolean('is_paid')->default(true)->comment('Có tính phí không? Bảo hành = miễn phí');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('repair_orders');
    }
}
