<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSupplierDeliveryHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('supplier_delivery_histories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('supplier_id');
            // Nếu đơn hàng chỉ có 1 purchase_order_id, bạn có thể lưu thông tin này
            $table->unsignedBigInteger('purchase_order_id')->nullable();
            // Nếu có nhiều SKU, bạn có thể lưu theo dạng JSON hoặc văn bản
            $table->json('sku_details')->nullable();
            // Tổng số lượng giao của đơn hàng đó cho nhà cung cấp
            $table->integer('total_qty')->default(0);
            // Ghi chú (có thể là thông báo hay chi tiết lỗi nếu có)
            $table->text('notes')->nullable();
            $table->timestamps();

            // Khóa ngoại nếu cần
            $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('supplier_delivery_histories');
    }
}
