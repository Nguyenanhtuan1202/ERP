<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateForecastProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forecast_products', function (Blueprint $table) {
            $table->id();
            $table->string('product_name')->nullable();      // SẢN PHẨM
            $table->string('product_variant')->nullable();     // MẪU (PHÂN LOẠI)
            $table->string('model_version')->nullable();       // PHIÊN BẢN (model)
            $table->string('color')->nullable();               // MÀU SẮC
            $table->string('size')->nullable();                // KÍCH THƯỚC
            $table->string('sale_key')->nullable();            // KEY CHUẨN (sale)
            $table->string('sku')->unique();                   // SKU
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forecast_products');
    }
}
