<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShipmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shipments', function (Blueprint $table) {
            $table->id();
            $table->string('tracking_number')->unique();
            // Thay customer_id tham chiếu đến bảng partners thay vì users
            $table->foreignId('customer_id')->constrained('partners')->onDelete('cascade');
            // carrier_id có thể nullable và tham chiếu bảng partners
            $table->foreignId('carrier_id')->nullable()->constrained('partners')->onDelete('set null');
            $table->string('vessel_name')->nullable();
            $table->string('voyage_number')->nullable();
            $table->string('origin_port');
            $table->string('destination_port');
            $table->date('departure_date')->nullable();
            $table->date('estimated_arrival')->nullable();
            $table->date('actual_arrival')->nullable();
            $table->enum('status', ['Đang xử lý', 'Đang vận chuyển', 'Đã đến cảng', 'Thông quan', 'Giao hàng thành công']);
            $table->enum('shipment_type', ['FCL', 'LCL'])->default('FCL');
            $table->text('cargo_description')->nullable();
            $table->decimal('total_weight', 10, 2)->nullable();
            $table->decimal('total_volume', 10, 2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shipments');
    }
}
