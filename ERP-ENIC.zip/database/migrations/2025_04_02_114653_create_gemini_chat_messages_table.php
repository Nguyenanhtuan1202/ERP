<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGeminiChatMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gemini_chat_messages', function (Blueprint $table) {
            $table->id();
            $table->string('session_id');  // Liên kết với gemini_chat_sessions
            $table->string('role');        // 'user' hoặc 'assistant'
            $table->text('content');       // Nội dung tin nhắn
            $table->timestamps();

            // Thiết lập khóa ngoại nếu cần
            $table->foreign('session_id')
                ->references('session_id')->on('gemini_chat_sessions')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gemini_chat_messages');
    }
}
