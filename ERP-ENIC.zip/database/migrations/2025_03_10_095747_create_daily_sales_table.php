<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDailySalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_sales', function (Blueprint $table) {
            $table->id();
            $table->date('sale_date')->comment('Ngày bán hàng');
            $table->unsignedBigInteger('product_id')->comment('Khóa ngoại trỏ đến sản phẩm');
            $table->string('sku')->comment('Mã SKU của sản phẩm');
            $table->integer('quantity')->comment('Số lượng bán hàng trong ngày');
            $table->decimal('sale_amount', 10, 2)->nullable()->comment('Doanh thu bán hàng (nếu có)');
            $table->string('sale_channel')->nullable()->comment('Kênh bán hàng, ví dụ: sỉ, lẻ, TMDT');
            $table->unsignedBigInteger('store_id')->nullable()->comment('ID của cửa hàng, nếu áp dụng');
            $table->string('salesperson')->nullable()->comment('Nhân viên bán hàng');
            $table->text('note')->nullable()->comment('Ghi chú về giao dịch bán hàng');
            $table->timestamps();

            // Khóa ngoại liên kết với bảng forecast_products
            $table->foreign('product_id')
                ->references('id')->on('forecast_products')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_sales');
    }
}
