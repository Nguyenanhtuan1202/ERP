<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliveryDraftsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('delivery_drafts', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('purchase_order_id')->unsigned();
            $table->integer('order_quantity')->nullable();
            $table->string('name', 255)->nullable();
            $table->string('sku', 255);
            $table->string('qty', 20)->nullable();
            $table->integer('qty_more')->nullable()->comment('Số Lượng Giao Thêm');
            $table->timestamp('date_delivery')->useCurrent()->useCurrentOnUpdate();
            $table->timestamp('date_received')->nullable();
            $table->string('status', 255)->default('0');
            $table->text('delivery_notes')->nullable();
            $table->text('note')->nullable();
            $table->string('important_note', 255)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('delivery_drafts');
    }
}
