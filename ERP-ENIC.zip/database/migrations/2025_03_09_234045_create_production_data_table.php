<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductionDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('production_data', function (Blueprint $table) {
            $table->id();
            $table->string('ncc')->nullable()->comment('Nhà cung cấp');
            $table->string('product_name')->nullable()->comment('SẢN PHẨM');
            $table->string('variant')->nullable()->comment('MẪU (PHÂN LOẠI)');
            $table->string('model_version')->nullable()->comment('PHIÊN BẢN (MODEL)');
            $table->string('color')->nullable()->comment('MÀU SẮC');
            $table->string('size')->nullable()->comment('KÍCH THƯỚC');
            $table->string('sale_key')->nullable()->comment('KEY CHUẨN (sale)');
            $table->string('sku')->unique()->comment('SKU');
            $table->text('product_note')->nullable()->comment('GHI CHÚ SP');
            $table->text('sale_note')->nullable()->comment('NOTE SALE');
            $table->string('image')->nullable()->comment('HỈNH ẢNH');
            $table->integer('shipping_time')->nullable()->comment('Thời gian vận chuyển (số ngày)');
            $table->integer('total_warehouse_time')->nullable()->comment('Tổng thời gian hàng về kho (số ngày)');
            $table->integer('stock_in_warehouse')->nullable()->comment('Tồn trong kho');
            $table->integer('goods_in_transit')->nullable()->comment('Hàng đang load về');
            $table->integer('goods_ordered_stored')->nullable()->comment('Hàng đang đặt+lưu kho');
            $table->integer('turnover')->nullable()->comment('Luân chuyển (số lần/chu kỳ)');
            $table->integer('customer_orders')->nullable()->comment('Khách đã đặt');
            $table->integer('reserved_stock')->nullable()->comment('SL hàng giữ tồn kho');
            $table->float('avg_daily_sales_cycle')->nullable()->comment('Số lượng bán trong 1 chu kỳ/ngày');
            $table->float('avg_daily_sales_recent_week')->nullable()->comment('Số lượng bán trong 1 tuần gần nhất/ngày');
            $table->float('forecast_daily_sales_to_end_T3')->nullable()->comment('Dự toán SL bán được/ngày today đến hết T3');
            $table->float('preorder_daily_tracking_forecast')->nullable()->comment('Dự toán theo dõi/ngày Theo dõi trước khi đặt');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('production_data');
    }
}
