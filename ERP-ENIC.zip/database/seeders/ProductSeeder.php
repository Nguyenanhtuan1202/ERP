<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\Attribute;
use App\Models\AttributeValue;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Tạo các thuộc tính
        $size = Attribute::create(['name' => 'size']);
        $color = Attribute::create(['name' => 'color']);
        $type = Attribute::create(['name' => 'type']);
        $material = Attribute::create(['name' => 'material']);
        $led = Attribute::create(['name' => 'led']);
        $type2 = Attribute::create(['name' => 'type2']);



        // thường, thông minh	gỗ, inox, nhôm	led viền, led vuông, led thẳng, led thông minh	Mẫu sọc , kính tràm, 2 ngăn

        // Tạo giá trị thuộc tính
        $sizeValues = ['60', '70', '80', '90', '100', '120'];
        foreach ($sizeValues as $value) {
            $size->values()->create(['value' => $value]);
        }

        $colorValues = ['xám', 'đen', 'nâu', 'vàng'];
        foreach ($colorValues as $value) {
            $color->values()->create(['value' => $value]);
        }
        
        $typeValues = ['thường', 'thông minh'];
        foreach ($typeValues as $value) {
            $type->values()->create(['value' => $value]);
        }
        $materialValues = ['gỗ', 'inox'];
        foreach ($materialValues as $value) {
            $material->values()->create(['value' => $value]);
        }

        $ledValues = ['Led Viền', 'Led Vuông', 'Led Thẳng', 'Led Thông Minh'];
        foreach ($ledValues as $value) {
            $led->values()->create(['value' => $value]);
        }

        $type2Values = ['Mẫu Sọc', 'Kính Tràm','2 Ngăn'];
        foreach ($type2Values as $value) {
            $type2->values()->create(['value' => $value]);
        }

    }
}
