<?php


return [

    'access' => [
        'list_post' => 'list_post',
        'add_post' => 'add_post',
        'edit_post' => 'edit_post',
        'delete_post' => 'delete_post',

        'cancel_post' => 'cancel_post',
        'view_post' => 'view_post',
        'excel_expert_post' => 'excel_expert_post',
        'excel_cancel_post' => 'excel_cancel_post',
        'restore_post' => 'restore_post',
        'list_cancel' => 'list_cancel',


        'list_user' => 'list_user',
        'add_user' => 'add_user',
        'edit_user' => 'edit_user',
        'delete_user' => 'delete_user',


        'list_role' => 'list_role',
        'add_role' => 'add_role',
        'edit_role' => 'edit_role',
        'delete_role' => 'delete_role',




        'list_learning_process' => 'list_learning_process',
        'add_learning_process' => 'add_learning_process',
        'delete_learning_process' => 'delete_learning_process',


        'add_agent' => 'add_agent',
        'edit_agent' => 'edit_agent',
        'delete_agent' => 'delete_agent',
        'list_agent' => 'list_agent',
        'view_agent' => 'view_agent',
        'excel_expert_agent' => 'excel_expert_agent',



        'add_warehouse' => 'add_warehouse',
        'edit_warehouse' => 'edit_warehouse',
        'delete_warehouse' => 'delete_warehouse',
        'list_warehouse' => 'list_warehouse',
        'view_warehouse' => 'view_warehouse',
        'excel_warehouse' => 'excel_warehouse',





        'add_purchase' => 'add_purchase',
        'edit_purchase' => 'list_purchase',
        'list_purchase' => 'list_purchase',
        'delete_purchase' => 'delete_purchase',
        'excel_purchase' => 'excel_purchase',


        'add_supplier' => 'add_supplier',
        'edit_supplier' => 'edit_supplier',
        'list_supplier' => 'list_supplier',
        'delete_supplier' => 'delete_supplier',

        'add_production' => 'add_production',
        'edit_production' => 'edit_production',
        'delete_production' => 'delete_production',
        'list_production' => 'list_production',


        'list_delivery' => 'list_delivery',
        'process_delivery' => 'process_delivery',
        'export_excel_delivery' => 'export_excel_delivery',


        'list_product' => 'list_product',
        'import_excel_product' => 'import_excel_product',
        'export_excel_product' => 'export_excel_product',
        'edit_product' => 'edit_product',


        'add_material' => 'add_material',
        'list_material' => 'list_material',
        'update_material' => 'update_material',
        'delete_material' => 'delete_material',
        'import_export_material' => 'import_export_material',

        'add_employee' => 'add_employee',
        'update_employee' => 'update_employee',
        'list_employee' => 'list_employee',
        'delete_employee' => 'delete_employee',


        'add_order' => 'add_order',
        'update_order' => 'update_order',
        'check_auto_order' => 'check_auto_order',
        'detail_order' => 'detail_order',
        'process_order' => 'process_order',
    ]
];
