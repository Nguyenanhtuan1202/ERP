<?php

return [
    'post_spreadsheet_id' => env('POST_SPREADSHEET_ID'),
    'post_sheet_id' => env('POST_SHEET_ID'),
];