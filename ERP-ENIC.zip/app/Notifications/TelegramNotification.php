<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Log;
use NotificationChannels\Telegram\TelegramChannel;
use NotificationChannels\Telegram\TelegramMessage;

class TelegramNotification extends Notification
{
    use Queueable;

    public $id;
    public $messageContent;

    public $token_telegram;

    public function __construct($messageContent, $id, $token_telegram)
    {
        $this->messageContent = $messageContent;
        $this->id = $id;
        $this->token_telegram = $token_telegram;
    }

    public function via($notifiable)
    {
        return [TelegramChannel::class];
    }
    public function toTelegram($notifiable)
    {
        try {
            // Debug: Kiểm tra giá trị của token
            Log::info("Token Telegram được truyền vào: " . $this->token_telegram);

            // Override token
            config(['services.telegram-bot-api.token' => $this->token_telegram]);

            // Debug: Kiểm tra giá trị của config sau khi override
            Log::info("Token Telegram sau khi override: " . config('services.telegram-bot-api.token'));

            // Lấy chat_id từ notifiable hoặc từ giá trị được truyền vào
            $chatId = $this->id;

            // Tạo và trả về TelegramMessage
            return TelegramMessage::create()
                ->to($chatId)->token($this->token_telegram)
                ->content($this->messageContent);
        } catch (\Exception $e) {
            // Log lỗi nếu có
            Log::error("Lỗi khi gửi Telegram notification: " . $e->getMessage());
            return TelegramMessage::create()->content('Error: ' . $e->getMessage());
        }
    }
}
