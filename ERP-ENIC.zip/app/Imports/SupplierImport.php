<?php

namespace App\Imports;

use App\Models\Supplier;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class SupplierImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        return new Supplier([
            'sp_code' => $row['sp_code'],  /* Mã nhà cung cấp */
            'username' => $row['username'],  /* Tên Người Phụ Trách ( Bên Xưởng) */
            'company_name' => $row['company_name'], /* Tên Công Ty*/
            'address' => $row['address'], /* Địa Chỉ */
            'product_manufacturing' => $row['product_manufacturing'], /* Sản Phẩm Sản Xuất */
            'note' => $row['note'], /* Ghi Chú */
            'companion_day' => $row['companion_day'], /* Ngày Hợp Tác */
            'employer' => $row['employer'], /* Nhân Viên Phụ Trách */
        ]);
    }
}
