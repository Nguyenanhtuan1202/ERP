<?php

namespace App\Imports;

use App\Models\ForecastProduct;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ForecastProductImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        return new ForecastProduct([
            'supplier_id' => $row['supplier_id'],
            'product_name' => $row['product_name'],
            'product_variant' => $row['product_variant'],
            'model_version' => $row['model_version'],
            'color' => $row['color'],
            'size' => $row['size'],
            'sale_key' => $row['sale_key'],
            'sku ' => $row['sku '],
            'product_note' => $row['product_note'],
            'sale_note' => $row['sale_note'],
            'image' => $row['image'],
            'price' => $row['price'],
            'unit' => $row['unit'],
            'price_vn' => $row['price_vn'],
            'length_cm' => $row['length_cm'],
            'width_cm' => $row['width_cm'],
            'height_cm' => $row['height_cm'],
            'quantity_per_carton' => $row['quantity_per_carton'],
            'cbm_per_ctn' => $row['cbm_per_ctn'],
            'quantity_per_container' => $row['quantity_per_container'],
            'freight_cost_per_cubic_meter' => $row['freight_cost_per_cubic_meter'],
            'import_tax' => $row['import_tax'],
            'additional_costs' => $row['additional_costs'],
            'warehouse_price' => $row['warehouse_price'],
            'selling_price' => $row['selling_price'],
        ]);
    }
}
