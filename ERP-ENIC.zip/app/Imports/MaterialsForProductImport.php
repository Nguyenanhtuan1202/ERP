<?php

namespace App\Imports;

use App\Models\MaterialsForProducts;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class MaterialsForProductImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        return new MaterialsForProducts([
            'tier_code' => $row['tier_code'],
            'style_code' => $row['style_code'],
            'size' => $row['size'],
            'color' => $row['color'],
            'sku' => $row['sku'],
            'name' => $row['name'],
            'quantity' => $row['quantity'],
            'total_price' => $row['total_price'],
        ]);
    }
}
