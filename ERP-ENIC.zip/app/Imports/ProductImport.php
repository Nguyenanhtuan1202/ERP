<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Carbon\Carbon;

class ProductImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        return new Product([
            'name' => $row['name'],
            'sku' => $row['sku'],
            'price' => $row['price'],
            'color' => $row['color'],
            'weight' => $row['weight'],
            'size' => $row['size'],
            'type' => $row['type'],
            'type2' => $row['type2'],
            'material' => $row['material'],
            'tier' => $row['tier'],
            'tier_code' => $row['tier_code'],
            'style' => $row['style'],
            'style_code' => $row['style_code'],
        ]);
    }
}
