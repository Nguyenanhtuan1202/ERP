<?php

namespace App\Imports;

use App\Models\PoDetails;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Carbon\Carbon;

class PoItemsImport implements ToModel, WithHeadingRow
{


    public function model(array $row)
    {
        return new PoDetails([
            'po' => $row['po'],
            'code_po' => $row['code_po'],
            'sku' => $row['sku'],
            'name' => $row['name'],
            'primary_qty' => $row['primary_qty'],
            'forecast_qty' => $row['forecast_qty'],
            'actual_qty' => $row['actual_qty'],
            'remain_qty' => $row['remain_qty'],
            'date_forecast' => $this->transformDate($row['date_forecast']),
            'date_forecast_by_sale' => $this->transformDate($row['date_forecast_by_sale']),
            'warehousing' => $row['warehousing'],
        ]);
    }

    private function transformDate($value)
    {
        // Kiểm tra nếu giá trị là số, xử lý theo kiểu serial date của Excel
        if (is_numeric($value)) {
            return Carbon::instance(\PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($value))->format('Y-m-d');
        }

        // Trả về giá trị gốc nếu đã là định dạng ngày hợp lệ
        try {
            return Carbon::parse($value)->format('Y-m-d');
        } catch (\Exception $e) {
            return null; // Nếu không hợp lệ, trả về null
        }
    }
}
