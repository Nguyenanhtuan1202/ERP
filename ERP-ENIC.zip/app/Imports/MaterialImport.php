<?php

namespace App\Imports;

use App\Models\Material;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class MaterialImport implements ToModel, WithHeadingRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        return new Material([
            'name' => $row['name'],
            'sku' => $row['sku'],
            'material_categories_id' => $row['material_categories_id'],
            'unit' => $row['unit'],
            'packaging' => $row['packaging'],
            'price_cost' => $row['price_cost'],
            'price_in_stock' => $row['price_in_stock'],
            'description' => $row['description'],
        ]);
    }
}
