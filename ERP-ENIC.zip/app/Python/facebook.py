import requests
from bs4 import BeautifulSoup
import time
import csv
import re
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

class FacebookGroupScraper:
    def __init__(self, group_url):
        self.group_url = 'https://www.facebook.com/groups/dcgr.net'
        self.members_url = f"{group_url}/members/near_you"
        self.driver = None
        self.members_data = []
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0'
        ]
    
    def setup_driver(self):
        """Set up the Chrome WebDriver with appropriate options"""
        chrome_options = Options()
        # Using a random user agent to avoid detection
        user_agent = random.choice(self.user_agents)
        chrome_options.add_argument(f"user-agent={user_agent}")
        
        # Additional options to make browser less detectable
        chrome_options.add_argument("--disable-notifications")
        chrome_options.add_argument("--disable-infobars")
        chrome_options.add_argument("--mute-audio")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        
        # Remove navigator.webdriver flag
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.maximize_window()
        
        # Additional step to mask WebDriver usage
        self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {"userAgent": user_agent})
        self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    
    def navigate_to_members_page(self):
        """Navigate to the group members page"""
        print(f"Attempting to access {self.members_url} without login")
        self.driver.get(self.members_url)
        
        try:
            # Check if we're redirected to login page
            WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.ID, "email"))
            )
            print("Redirected to login page. Facebook requires authentication to view group members.")
            return False
        except TimeoutException:
            # If we're not redirected to login, check if we can see any member content
            try:
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, "//div[@role='listitem']"))
                )
                print("Successfully accessed members page without login")
                return True
            except TimeoutException:
                print("Could not find member elements. Facebook might be blocking unauthenticated access.")
                return False
    
    def try_alternative_approach(self):
        """Try to access public group content that might show some members"""
        print("Trying alternative approach: accessing group's main page")
        self.driver.get(self.group_url)
        
        # Wait to see if we can access any content
        time.sleep(5)
        
        # Check for any visible member content
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        
        # Look for common elements that might contain member information
        # This is speculative and depends on what's publicly visible
        posts = soup.find_all('div', {'role': 'article'})
        
        for post in posts:
            # Try to extract author information from posts
            author_links = post.find_all('a', href=True)
            for link in author_links:
                href = link.get('href', '')
                if '/user/' in href or '/profile.php' in href:
                    # This might be a member profile link
                    name = link.text.strip()
                    if name and not any(m['name'] == name for m in self.members_data):
                        member_id = self.extract_member_id(href)
                        self.members_data.append({
                            'id': member_id,
                            'name': name,
                            'job_info': "",
                            'profile_url': href,
                            'profile_pic': ""
                        })
        
        print(f"Found {len(self.members_data)} members through post authors")
        
        # Try to find any member listings that might be publicly visible
        member_sections = soup.find_all('div', string=lambda text: text and 'member' in text.lower())
        for section in member_sections:
            # Look for nearby profile links
            parent = section.parent
            if parent:
                links = parent.find_all('a', href=True)
                for link in links:
                    href = link.get('href', '')
                    if '/user/' in href or '/profile.php' in href:
                        name = link.text.strip()
                        if name and not any(m['name'] == name for m in self.members_data):
                            member_id = self.extract_member_id(href)
                            self.members_data.append({
                                'id': member_id,
                                'name': name,
                                'job_info': "",
                                'profile_url': href,
                                'profile_pic': ""
                            })
        
        print(f"Total members found: {len(self.members_data)}")
    
    def extract_member_id(self, profile_url):
        """Extract member ID from profile URL"""
        user_id_match = re.search(r'user/(\d+)', profile_url)
        if user_id_match:
            return user_id_match.group(1)
        
        # Alternative pattern if the above doesn't match
        direct_id_match = re.search(r'/(\d+)(?:/|$)', profile_url)
        if direct_id_match:
            return direct_id_match.group(1)
        
        return "unknown_" + str(len(self.members_data))
    
    def extract_from_html_sample(self, html_file=None, html_content=None):
        """Extract member information from a saved HTML file or provided HTML content"""
        if html_file:
            with open(html_file, 'r', encoding='utf-8') as f:
                html_content = f.read()
        
        if html_content:
            soup = BeautifulSoup(html_content, 'html.parser')
            member_elements = soup.find_all('div', {'role': 'listitem'})
            
            print(f"Found {len(member_elements)} member elements in the HTML")
            
            for member in member_elements:
                # Extract member information
                member_link = member.find('a', {'role': 'link', 'tabindex': '0'})
                if not member_link:
                    continue
                    
                member_id = self.extract_member_id(member_link.get('href', ''))
                member_name = member_link.text.strip() if member_link else "Unknown"
                
                # Try to extract job title/workplace if available
                job_info = member.find('span', {'class': 'x193iq5w', 'dir': 'auto'})
                job_title = job_info.text.strip() if job_info else ""
                
                # Extract profile picture URL if available
                profile_pic = member.find('image')
                profile_pic_url = profile_pic.get('xlink:href', '') if profile_pic else ""
                
                self.members_data.append({
                    'id': member_id,
                    'name': member_name,
                    'job_info': job_title,
                    'profile_pic': profile_pic_url,
                    'profile_url': member_link.get('href', '')
                })
            
            print(f"Extracted {len(self.members_data)} members from HTML")
    
    def save_to_csv(self, filename="facebook_group_members.csv"):
        """Save the extracted member data to a CSV file"""
        if not self.members_data:
            print("No data to save")
            return
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'name', 'job_info', 'profile_pic', 'profile_url']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for member in self.members_data:
                writer.writerow(member)
        
        print(f"Saved {len(self.members_data)} members to {filename}")
    
    def run(self):
        """Run the complete scraping process"""
        try:
            self.setup_driver()
            
            # First try accessing members page directly
            access_success = self.navigate_to_members_page()
            
            if not access_success:
                print("Direct access failed. Trying alternative approaches...")
                self.try_alternative_approach()
            
            # If we still don't have data, ask user for HTML
            if not self.members_data:
                print("\nCould not access member data without login.")
                print("Alternative options:")
                print("1. Login to Facebook manually, navigate to the group members page")
                print("2. Save the page HTML (right-click > Save As... > Web Page, Complete)")
                print("3. Run this script with the saved HTML file path as input")
                
                html_path = input("\nIf you have a saved HTML file, enter the path (or press enter to skip): ")
                if html_path:
                    self.extract_from_html_sample(html_file=html_path)
            
            self.save_to_csv()
            
        finally:
            if self.driver:
                self.driver.quit()


if __name__ == "__main__":
    # Replace with the Facebook group URL
    GROUP_URL = "https://www.facebook.com/groups/dcgr.net"
    
    # If you already have HTML content saved from a logged-in session
    SAVED_HTML_PATH = None  # "path/to/saved/facebook_group_members.html"
    
    scraper = FacebookGroupScraper(GROUP_URL)
    scraper.run()
    
    # If you already have HTML content and just want to parse it
    # scraper.extract_from_html_sample(html_file=SAVED_HTML_PATH)
    # scraper.save_to_csv()