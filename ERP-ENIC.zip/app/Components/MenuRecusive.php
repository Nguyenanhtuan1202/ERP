<?php

namespace App\Components;

use App\Models\Menu;

class MenuRecusive {
    

    private $html;

    public function __construct()
    {
        $this->html= "";
    }
    

    public function menuRecusiveAdd($parent_id = 0, $subMark = "")
    {
        $data = Menu::where('parent_id', $parent_id)->get();
        foreach ($data as $value) {
            $this->html .= "<option  value= " . $value->id . ">" . $subMark . $value->name . "</option>";
            $this->menuRecusiveAdd($value->id, $subMark . '--');
        }
        return $this->html;
    }

    public function menuRecusiveEdit($parentIdMenuEdit, $parent_id = 0, $subMark = "")
    {
        $data = Menu::where('parent_id', $parent_id)->get();
        foreach ($data as $value) {
            if ($parentIdMenuEdit == $value->id) {
                $this->html .= "<option selected  value= " . $value->id . ">" . $subMark . $value->name . "</option>";
            } else {
                $this->html .= "<option  value= " . $value->id . ">" . $subMark . $value->name . "</option>";
            }
            $this->menuRecusiveEdit($parentIdMenuEdit, $value->id, $subMark . '--');
        }
        return $this->html;
    }

}