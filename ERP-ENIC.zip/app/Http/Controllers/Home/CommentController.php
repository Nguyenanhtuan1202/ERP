<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

session_start();
class CommentController extends Controller
{
    //

    public function add(Request $request)
    {
        $post_id = $request->post_id;
        $comment_name = $request->comment_name;
        $comment_email = $request->comment_email;
        $comment_content = $request->comment_content;
        Comment::create(
            [
                'comment_content' => $comment_content,
                'comment_name' => $comment_name,
                'comment_email' => $comment_email,
                'post_id' => $post_id,
                'comment_status' => 'unapprove',
                'comment_parent_content' => '',
            ]
        );
    }


    public function show(Request $request)
    {

        $post_id = $request->post_id;
        $comment = Comment::where('post_id', $post_id)->where('comment_parent_content', "")->where("comment_status", "approve")->get();
        $comment_all = Comment::where('post_id', $post_id)->where("comment_status", 'approve')->get();
        $output = "";

        $customer = Customer::all();
        foreach ($comment as $key => $comm) {

            foreach ($customer  as $customer_item) {
                if ($customer_item->email == $comm->comment_email) {
                    $image = $customer_item->image;
                }
            }

            $output .= '
            <li class="comment">
            <div class="comment-2">
                <div class="comment-author-info">
                    <div class="comment-author vcard" style="padding:0px !important ;" >
                        <img style="width:100px ;" alt=""
                            src="/public/uploads/customer/' . $image . '">
                    </div>
                    <div class="comment-content">
                        <div class="meta">
                            <div class="comment-content-top">
                                <div class="comment-actions">
                                    <h6 style ="font-size:14px">' . $comm->comment_name . ' <span
                                    class="separator"> <i class="far fa-clock"></i> </span>
                                <span style ="font-size:12px" class="time">' . $comm->updated_at . '
                                </span>
                                    </h6>
                                    <div class="comment-datetime">  </div> 
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div class="comment-text">
                    <p> ' . $comm->comment_content . '</p>
                </div>
            </div>


        </li>

            ';

            // $output .= '
            // <ol class="children">';

            foreach ($comment_all as $rep_comment) {
                if ($rep_comment->comment_parent_content == $comm->id) {
                    $output .= '
            <li class="comment">
                <div class="comment-reply-wrap">
                    <div class="comment-author-info">
                        <div class="comment-author vcard">
                            <img alt="" style="width:100px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSexenKdKC9wXcFaJaijt7m0qWqSrNiauZ9x2LZnVwX7ZHUP92c73PLTzTeJgdiXu_XyTw&usqp=CAU">
                        </div>
                        <div class="comment-content">
                            <div class="meta">
                                <div class="comment-content-top">
                                    <div class="comment-actions">
                                        <h6> ' . $rep_comment->comment_name . '  <span class="separator"></span> <i class="far fa-clock"></i>  <span  style="font-size:12px"  class="time">   ' . $rep_comment->updated_at . ' </span></h6>
                                        <div class="comment-datetime"></div> 
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                    <div class="comment-text">
                        <p>' . $rep_comment->comment_content . '</p>
                    </div>
                </div>
            </li>
            ';
                }
            }

            $output .= ' </ol>';
        }
        echo $output;
    }
}
