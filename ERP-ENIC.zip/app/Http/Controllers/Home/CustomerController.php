<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\Customer;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

session_start();

class CustomerController extends Controller
{
    //

    public function login()
    {
        $meta_title = "Đăng nhập";
        if (Session::has('name')) {
            return Redirect('/');
        } else {
            return view('frontend.login', compact('meta_title'));
        }
    }
    public function logout()

    {
        Session::forget('name');
        Session::forget('email');
        Session::forget('id');
        Session::forget('image');
        return redirect()->back();
    }
    public function register()
    {
        $meta_title = "Đăng ký";
        if (Session::has('name')) {
            return Redirect('/');
        } else {
            return view('frontend.register', compact('meta_title'));
        }
    }

    public function addCustomer(Request $request)
    {

        $name = ($request->name);
        $email = ($request->email);
        $password = sha1($request->password);

        if ($request->name == "" || $request->email == "" || $request->password == "") {
            return redirect()->back()->with('status', 'Vui lòng điền đầy đủ thông tin các trường!');
        } else {
            $checkEmail = Customer::where('email', $email)->first();
            if ($checkEmail) {
                return redirect()->back()->with('status', 'Email đã tồn tại. Vui lòng kiểm tra lại!');
            } else {
                $customer =  Customer::create(
                    [
                        'name' => $name,
                        'email' => $email,
                        'password' => $password
                    ]
                );
                Session::put('name', $name);
                Session::put('id', $customer->id);
                Session::put('email', $email);
                return redirect()->back();
            }
        }
    }

    public function checkLogin(Request $request)
    {

        $email = $request->email;
        $password = ($request->password);
        if ($email == "" || $password == "") {
            return redirect('/customer-login')->with('status', 'Email hoặc mật khẩu không được bỏ trống');
        } else {
            $email = $request->email;
            $password = sha1($request->password);
            $customer = Customer::where('email', $email)->where('password', $password)->first();
            if ($customer) {
                Session::put('email', $customer->email);
                Session::put('name', $customer->name);
                Session::put('id', $customer->id);
                Session::put('image', $customer->image);
                return redirect()->back();
            } else {
                return redirect('/customer-login')->with('status', 'Email hoặc mật khẩu không chính xác. Vui lòng kiểm tra lại !');
            }
        }
    }


    public function infoCustomer($id)
    {

        if (Session::has('id') == $id) {
            $infoCustomer =  Customer::where('id', $id)->first();
            $meta_title = Session::get('name');
            $email = $infoCustomer->email;
            $customer_comment = Comment::where('comment_email', $email)->orderBy('id', 'desc')->limit(3)->get();
            $post_all = Post::all();
            return view('frontend.customer', compact('infoCustomer', 'customer_comment', 'post_all', 'meta_title'));
        } else {
            return redirect('/customer-login')->with('status', 'Vui lòng đăng nhập !');
        }
    }

    public function updateInfoCustomer(Request $request, $id)
    {
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = $name_image . rand(0, 99999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/customer', $new_image);
            Customer::where('id', $id)->update(
                [
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'image' => $new_image
                ]
            );
            return redirect()->back()->with('status', 'Cập nhật thông tin thành công');
        } else {
            Customer::where('id', $id)->update(
                [
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                ]
            );
            return redirect()->back()->with('status', 'Cập nhật thông tin thành công');
        }
    }

    public function changePassword(Request $request)
    {

        $customer_id = $request->customer_id;


        if ($request->old_pass == "" || $request->old_pass == "" || $request->old_pass == "") {
            echo "Vui lòng điền đầy đủ thông tin";
        } else {
            $oldPassword = sha1($request->old_pass);
            $newPassword = sha1($request->new_pass);
            $rePassword = sha1($request->re_pass);
            $checkCustomer =  Customer::where('password', $oldPassword)->first();
            if ($checkCustomer) {

                if ($newPassword  == $rePassword) {
                    Customer::where('id', $customer_id)->update(
                        [
                            'password' => $newPassword
                        ]
                    );
                    Session::flush();
                    echo '<meta http-equiv="refresh" content="0; url=http://blog.com:81/customer-login" />';
                    echo "Cập nhật mật khẩu thành công vui lòng đăng nhập lại !";
                } else {
                    echo "Nhập lại mật khẩu không chính xác. Vui lòng kiểm tra lại";
                }
            } else {
                echo "Mật khẩu cũ không chính xác. Vui lòng kiểm tra lại ";
            }
        }
    }
}
