<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Menu;
use App\Models\Post;
use App\Models\Post_Category;
use App\Models\Rating;
use App\Models\Tag;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;

class HomeController extends Controller
{
    public function index()
    {

        $data['menu_home'] = Menu::where('status', 1)->where('url', '/')->first();

        $data['url'] = request()->url();
        $data['tips'] = Post::whereHas('category', function ($q) {
            $q->where('url', 'thu-thuat');
        })->with(['category' => function ($q) {
            $q->whereSlug('thu-thuat');
        }])->orderBy('updated_at', 'desc')->get();

        $data['category'] = Category::where('status', 1)->where('parent_id', 0)->get();
        $data['post_news_siderleft'] = Post::where('status', 'publish')->whereNull('deleted_at')->orderBy('updated_at', 'desc')->take(4)->get();

        $data['news'] = Post::where('status', 'publish')->whereNull('deleted_at')->orderBy('updated_at', 'desc')->take(4)->get();

        // Chuyển đổi Collection thành mảng


        $chunks = $data['post_news_siderleft']->chunk(1);

        // Lấy mảng thứ nhất
        $data['post_news_1'] = $chunks->slice(0, 1)->flatten();
        $data['post_news_2'] = $chunks->slice(1)->flatten();
        $ids = $data['post_news_siderleft']->pluck('id');
        $data['siderbarright'] = Post::whereNotIn('id', $ids)->take(5)->get();
        $ids2 = $data['siderbarright']->pluck('id');
        $data['post_news_all'] = Post::where('status', 'publish')->whereNotIn('id', $ids)->whereNotIn('id', $ids2)->whereNull('deleted_at')->orderBy('updated_at', 'desc')->take(8)->get();
        return view("frontend.home", compact('data'));
    }


    /* Danh mục */
    public function category($slug)
    {


        $data['menus'] = Menu::where('status', 1)->where('url', 'danh-muc/' . $slug)->first();

        $data['url'] = request()->url();



        $data['category'] = Category::where('url', $slug)->first();

        $data['post__category'] = Post::whereHas('category', function ($q) use ($slug) {
            $q->where('slug', $slug);
        })->with(['category' => function ($q) use ($slug) {
            $q->whereSlug($slug);
        }])->orderBy('updated_at', 'desc')->paginate(12);


        return view("frontend.category", compact('data'));
    }



    /* Bài viết */
    public function post($slug)
    {

        $data['post'] = Post::with('category')->where('status', 'publish')->where('url', $slug)->first();

        $data['url'] = request()->url();

        $urls = $data['post']->category->pluck('url');

        $data['post_relative'] = Post::whereHas('category', function ($q) use ($urls) {
            $q->whereIn('url', $urls);
        })->whereNotIn('url', [$slug])->limit(8)->get();


        $data['post']->post_view =  $data['post']->post_view + 1;
        $data['post']->save();

        return view('frontend.post', compact('data',));
    }

    public function donate()
    {


        $data['meta_donate'] = Menu::where('status', 1)->where('url', 'donate')->first();

        $data['url'] = request()->url();

        return view('frontend.donate', compact('data'));
    }






    /* Tìm kiếm  */
    public function search(Request $request)
    {

        $keyword = strtolower($request->key);
        $keyword = preg_replace('/([^\pL\d\.\ ]+)/u', '', strip_tags($keyword));
        $url = request()->url();
        $searchByPost =   Post::where('title', 'LIKE', "%$keyword%")->where('meta_seo', 'LIKE', "%$keyword%")->orderBy('post_view', 'asc')->paginate(12)->appends($request->all());
        if ($searchByPost->count() > 0) {
            $searchInfo = $searchByPost;
            return view('frontend.search', compact("searchInfo", 'keyword'));
        } else if ($searchByPost->count() < 1) {
            $searchByCategory = Post::whereHas('category', function ($q) use ($keyword) {
                $q->where('title', 'LIKE', "%$keyword%");
            })->with(['category' => function ($q) use ($keyword) {
                $q->where('title', 'LIKE', "%$keyword%");
            }])->orderBy('post_view', 'asc')->paginate(12)->appends($request->all());
            $searchInfo = $searchByCategory;
            return view('frontend.search', compact("searchInfo", 'keyword'));
        }
    }
}
