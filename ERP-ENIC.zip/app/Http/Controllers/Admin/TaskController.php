<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{
    //

    public function index()
    {
        $data = Task::where('id', Auth::user()->id)->orderBy('id', 'desc')->get();
        return view('tasks.index', compact('data'));
    }

    public function create()
    {
        return view('tasks.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'reminder_time' => 'required|date',
            'description' => 'required',
        ]);


        Task::create(
            [
                'user_id' => Auth::user()->id,
                'title' => $request->title,
                'reminder_time' => $request->reminder_time,
                'description' => $request->description,
            ]
        );
        return redirect()->back()->with('success', 'Công việc đã được thêm.');
    }
}
