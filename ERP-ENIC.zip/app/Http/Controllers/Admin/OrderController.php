<?php

namespace App\Http\Controllers\Admin;

use App\Exports\PurchaseOrderExport;
use App\Http\Controllers\Controller;
use App\Models\DepositPayment;
use App\Models\ForecastProduct;
use App\Models\HistoryPayment;
use App\Models\ImportCost;
use App\Models\Notification;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\User;
use App\Notifications\TelegramNotification;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification as FacadesNotification;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Revolution\Google\Sheets\Facades\Sheets;

class OrderController extends Controller
{
    //



    public function import()
    {
        return view('orders.import');
    }

    // Action xử lý Ajax cho preview
    public function previewAjax(Request $request)
    {
        // Validate yêu cầu: nếu không có file thì bắt buộc có order_data
        $request->validate([
            'order_data' => 'required_without:order_file',
        ], [
            'order_data.required_without' => 'Vui lòng nhập dữ liệu đơn hàng hoặc tải file lên!',
        ]);

        // Nếu có file upload, ưu tiên lấy nội dung file
        if ($request->hasFile('order_file')) {
            $rawData = file_get_contents($request->file('order_file')->getRealPath());
        } else {
            $rawData = $request->input('order_data');
        }

        try {
            // Sử dụng phương thức parseFromText() của model Order để phân tích dữ liệu
            $order = Order::parseFromText($rawData);
            // Render một partial view chứa preview (không cần layout chung)
            $html = view('orders.preview_ajax', compact('order'))->render();
            return response()->json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            // Ghi log lỗi và trả về thông báo lỗi
            Log::error('Lỗi parse Order: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /* Preview Excel Ajax */

    public function removeAccents($str)
    {
        $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
        $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
        $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
        $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
        $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
        $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
        $str = preg_replace("/(đ)/", 'd', $str);
        $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
        $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
        $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
        $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
        $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
        $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
        $str = preg_replace("/(Đ)/", 'D', $str);
        return $str;
    }


    /* Ajax preview order uploads */
    public function previewOrder(Request $request)
    {
        // Lấy dữ liệu từ input (dạng text) chứa dữ liệu đơn hàng
        $rawData = $request->input('order_data');

        // Phân tích dữ liệu để tạo đối tượng Order (bao gồm cả items)
        $order = Order::parseFromText($rawData);

        $list_supplier = Supplier::where('status', 1)->orderBy('id', 'desc')->get();
        // Xử lý từng item: dùng SKU để tìm thông tin sản phẩm và cập nhật lại các thông tin bổ sung
        foreach ($order->items as $item) {
            // Tìm sản phẩm dựa trên SKU
            $product = ForecastProduct::where('sku', $item->sku)->first();
            if ($product) {
                // Cập nhật thông tin sản phẩm từ bảng Product
                // Sử dụng trong logic của bạn
                $item->product_name = $this->removeAccents($product->sale_key);
                $item->image = $product->image;
                $item->price        = $product->price; // Đơn giá từ product
                $item->total        = $item->quantity * $product->price; // Thành tiền = số lượng * đơn giá
                // Lấy thêm các thuộc tính bổ sung
                $item->size = $product->size;
                $item->color = $this->removeAccents($product->color);
            } else {
                // Nếu không tìm thấy sản phẩm, gán giá trị mặc định
                $item->price        = 0;
                $item->total        = 0;
                $item->size     = "";
                $item->color     = "";
            }
        }

        // Tính lại tổng tiền của đơn hàng (subtotal) dựa trên tổng các thành tiền của các item
        $order->subtotal = collect($order->items)->sum('total');
        // Giả sử grand_total = subtotal (bạn có thể cộng thêm thuế, tiền cọc, ...)
        $order->grand_total = $order->subtotal;
        $order->order_date = now();
        try {
            $html = view('orders.preview_purchase_order', compact('order', 'list_supplier'))->render();
            return response()->json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            // Ghi log lỗi và trả về thông báo lỗi
            Log::error('Lỗi parse Order: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }
    /* Xuất FILE PDF Đơn Mua Hàng */
    public function exportPdf(Request $request)
    {

        // Lấy dữ liệu đơn hàng từ query string
        $orderJson = $request->query('order');
        if (!$orderJson) {
            abort(400, 'Không có dữ liệu đơn hàng.');
        }

        $orderData = json_decode($orderJson, true);

        if (!$orderData) {
            abort(400, 'Dữ liệu đơn hàng không hợp lệ.');
        }

        // Xử lý các trường nếu cần
        if (isset($orderData['order_code'])) {
            $orderData['order_code'] = html_entity_decode($orderData['order_code']);
        }
        if (isset($orderData['grand_total'])) {
            $orderData['grand_total'] = str_replace(',', '', $orderData['grand_total']);
        }
        // $orderData['subtotal'] = floatval($orderData['subtotal']);
        $orderData['total_quantity'] = intval($orderData['total_quantity']);
        $orderData['name__company'] = $orderData['company_buyer'];
        $orderData['address__company'] = $this->removeAccents($orderData['address_company']);
        $orderData['supplier'] = Supplier::where('sp_code', $orderData['supplier_code'])->first();

        $orderData['supplier_name'] =  $this->removeAccents($orderData['supplier']->company_name);

        if (isset($orderData['items']) && is_array($orderData['items'])) {
            foreach ($orderData['items'] as &$item) {
                $item['quantity'] = intval($item['quantity']);
                $item['price'] = floatval(str_replace(',', '', $item['price']));
                $item['total'] = $item['quantity'] * $item['price'];
                $item['note'] = $item['noteOrder'];
                $item['unitPrice'] = $item['unit'];
                $item['quantity'] = intval($item['quantity']);
            }

            unset($item);
        } else {
            $orderData['items'] = [];
        }

        try {
            $pdf = Pdf::loadView('orders.export_purchase_order_pdf', ['orderData' => $orderData]);
            return $pdf->stream('purchase_order_' . $orderData['order_code'] . '.pdf');
        } catch (\Exception $e) {
            Log::error('Lỗi xuất PDF: ' . $e->getMessage());
            abort(500, 'Có lỗi xảy ra khi xuất file PDF.');
        }
    }

    /* Thêm mới 1 đơn hàng Purchase Order Create */
    public function orderCreateNew(Request $request)
    {
        // dd($request->all());
        // 1. Nhận và giải mã dữ liệu đơn hàng
        $orderJson = $request->input('order');
        if (!$orderJson) {
            return response()->json(['success' => false, 'message' => 'Không có dữ liệu đơn hàng.']);
        }
        $orderData = json_decode($orderJson, true);
        if (!$orderData) {
            return response()->json(['success' => false, 'message' => 'Dữ liệu đơn hàng không hợp lệ.']);
        }

        // 2. Xử lý các trường đơn hàng
        $orderData['order_code'] = isset($orderData['order_code'])
            ? trim(str_replace(['"', ','], '', html_entity_decode($orderData['order_code']))) : "";

        $orderData['grand_total'] = isset($orderData['grand_total'])
            ? floatval(str_replace(',', '', $orderData['grand_total']))
            : 0;
        $orderData['subtotal'] = isset($orderData['subtotal'])
            ? floatval(str_replace(',', '', $orderData['subtotal']))
            : 0;
        $orderData['total_quantity'] = isset($orderData['total_quantity'])
            ? intval($orderData['total_quantity'])
            : 0;
        $orderData['deposit'] = (isset($orderData['deposit']) && $orderData['deposit'] !== '')
            ? $orderData['deposit']
            : '0';
        $orderData['supplier_code'] = (isset($orderData['supplier_code']) && $orderData['supplier_code'] !== '')
            ? $orderData['supplier_code']
            : '0';

        // 3. Xử lý mảng items: ép kiểu số và tính total cho mỗi item
        if (isset($orderData['items']) && is_array($orderData['items'])) {
            foreach ($orderData['items'] as &$item) {
                $item['quantity'] = isset($item['quantity']) ? intval($item['quantity']) : 0;
                $item['price'] = isset($item['price']) ? floatval(str_replace(',', '', $item['price'])) : 0;
                $item['total'] = $item['quantity'] * $item['price'];
            }
            unset($item);
        } else {
            $orderData['items'] = [];
        }

        // 4. Lưu đơn hàng (Order) vào cơ sở dữ liệu
        try {
            $checkOrder = Order::where('order_code', $orderData['order_code'])->first();
            if ($checkOrder) {
                return response()->json([
                    'success' => false,
                    'message' => 'Mã đơn hàng đã tồn tại! Vui lòng kiểm tra lại !'
                ]);
            }
            $order = Order::create([
                'order_code'     => $orderData['order_code'],
                'order_date'     => $orderData['order_date'] ?? "",
                'total_quantity' => $orderData['total_quantity'],
                'subtotal'       => $orderData['subtotal'],  // Sửa lỗi: dùng subtotal chứ không phải total_quantity
                'grand_total'    => $orderData['grand_total'],
                'deposit'        => $orderData['deposit'],
                'note'           => $orderData['note'] ?? "",
                'user_id' => Auth::user()->id,
                'supplier_id' => $orderData['supplier_code']
            ]);

            // 5. Lưu các sản phẩm (OrderItem)
            foreach ($orderData['items'] as $item) {
                OrderItem::create([
                    'order_id'                => $order->id,
                    'order_code'              => $orderData['order_code'],
                    'sku'                     => $item['sku'] ?? "",
                    'quantity'                => $item['quantity'],
                    'price'                   => $item['price'],
                    'unit'               => $item['unit'] ?? "",
                    'noteOrder'  => $item['noteOrder'] ?? "",
                    'total'                   => $item['total'],
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Lỗi lưu đơn hàng: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi lưu đơn hàng.'
            ]);
        }

        // 6. Cập nhật dữ liệu vào Google Sheets
        // try {
        //     // Tạo note thông báo
        //     $text = "BÁO CÁO ĐƠN HÀNG ĐÃ ĐẶT\n"
        //         . "+ Mã đơn hàng: " . $orderData['order_code'] . "\n"
        //         . "+ Trạng thái: Đã đặt hàng\n"
        //         . "+ Dự kiến xong hàng: ";

        //     // Sheet chính
        //     $spreadsheetId = '1uqcTlB_RWfdEXTus1xU3WCS9do693KYA4da24fMx6EI';
        //     $sheetNameCustom = 'ENIC - THEO DÕI NHẬP HÀNG';
        //     $sheetRowsNews = [];

        //     $existingRows = Sheets::spreadsheet($spreadsheetId)
        //         ->sheet($sheetNameCustom)
        //         ->get();
        //     $insertHeader = empty($existingRows) || (is_array($existingRows[0]) && count(array_filter($existingRows[0])) == 0);
        //     if ($insertHeader) {
        //         $sheetRowsNews[] = [
        //             'Tên Sản Phẩm (Key Chuẩn)',
        //             'SKU',
        //             'Mã Đơn Hàng',
        //             'Số Lượng Đặt Hàng',
        //             'Ngày Dự Kiến Sản Xuất Xong',
        //             'Ngày Đặt Hàng',
        //             'Ghi Chú',
        //             'Người Đặt Hàng'
        //         ];
        //     }

        //     $itemsData = $orderData['items']; // Giả sử items đã có trong orderData
        //     foreach ($itemsData as $item) {
        //         $sheetRowsNews[] = [
        //             $item['product_name'] ?? '',
        //             $item['sku'] ?? '',
        //             $orderData['order_code'] ?? '',
        //             $item['quantity'] ?? '',
        //             '', // Ngày dự kiến sản xuất xong (có thể cập nhật sau)
        //             now()->format('d-m-Y'),
        //             $text,
        //             Auth::user()->name ?? "",
        //         ];
        //     }

        //     Sheets::spreadsheet($spreadsheetId)
        //         ->sheet($sheetNameCustom)
        //         ->append($sheetRowsNews);

        //     // Sheet thứ hai
        //     $sheetNameCustom2 = 'DRAFTED - ENIC DỰ KIẾN NHẬP HÀNG (giữ nguyên)';
        //     $sheetRowsNews2 = [];
        //     $existingRows2 = Sheets::spreadsheet($spreadsheetId)
        //         ->sheet($sheetNameCustom2)
        //         ->get();
        //     $insertHeader2 = empty($existingRows2) || (is_array($existingRows2[0]) && count(array_filter($existingRows2[0])) == 0);
        //     if ($insertHeader2) {
        //         $sheetRowsNews2[] = [
        //             'Mẫu Tự Động Nhập',
        //             'SKU',
        //             'Mã Đơn Hàng',
        //             'Ngày Đặt Hàng',
        //             'Số Lượng Dự Kiến',
        //             'Ngày Dự Kiến Về',
        //             'Ngày Về Dự Kiến Cho Sale',
        //             'Kho Về',
        //             'Người Tạo'
        //         ];
        //     }
        //     foreach ($itemsData as $item) {
        //         $sheetRowsNews2[] = [
        //             $item['product_name'] ?? '',
        //             $item['sku'] ?? '',
        //             $orderData['order_code'] ?? '',
        //             now()->format('d-m-Y'),
        //             $item['quantity'] ?? '',
        //             '', // Ngày dự kiến
        //             '', // Ngày về dự kiến cho sale
        //             'KHO HCM',
        //             Auth::user()->name ?? "",
        //         ];
        //     }

        //     Sheets::spreadsheet($spreadsheetId)
        //         ->sheet($sheetNameCustom2)
        //         ->append($sheetRowsNews2);
        // } catch (\Exception $e) {
        //     Log::error('Lỗi cập nhật Google Sheets: ' . $e->getMessage());
        //     // Không cần trả về lỗi Sheets cho client nếu Order đã được lưu
        // }


        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'create', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Thêm đơn hàng mới thành công!' . " Mã Đơn : " . $orderData['order_code'],
        ]);

        return response()->json(['success' => true, 'message' => 'Thêm đơn hàng thành công!']);
    }


    /* Danh sách order theo user */

    public function getOrdersByUser(Request $request, $status = null)
    {
        // Nếu không có status trong route, kiểm tra trong query parameters
        if ($status === null) {
            $status = $request->status ?? 0; // Mặc định là 0 (chưa hoàn thành)
        }
        // Chuyển đổi sang kiểu số nguyên
        $status = (int) $status;

        // Chuẩn bị query base cho người dùng hiện tại
        $baseQuery = Order::with(['supplier', 'historyPayments'])
            ->where('user_id', Auth::user()->id);

        // Áp dụng các bộ lọc từ request
        $query = $baseQuery->where('status', $status);

        // Lọc theo thanh toán nếu có
        if ($request->filled('is_paid')) {
            $query->where('is_paid', $request->is_paid);
        }

        // Add search functionality
        // Add search functionality here
        if ($request->filled('search')) {
            $searchTerm = $request->search;
            $query->where(function ($q) use ($searchTerm) {
                $q->where('order_code', 'like', "%{$searchTerm}%")
                    ->orWhereHas('supplier', function ($sq) use ($searchTerm) {
                        $sq->where('sp_code', 'like', "%{$searchTerm}%")
                            ->orWhere('company_name', 'like', "%{$searchTerm}%");
                    });
            });
        }
        // Lọc theo ngày đặt hàng nếu có
        if ($request->filled('order_date')) {
            $query->whereDate('order_date', $request->order_date);
        }

        // Lọc theo nhà cung cấp nếu có
        if ($request->filled('supplier')) {
            $query->whereHas('supplier', function ($q) use ($request) {
                $q->where('sp_code', $request->supplier);
            });
        }

        // Lọc theo số tiền tối thiểu nếu có
        if ($request->filled('min_amount')) {
            $query->where('subtotal', '>=', $request->min_amount);
        }

        // Lọc theo số tiền tối đa nếu có
        if ($request->filled('max_amount')) {
            $query->where('subtotal', '<=', $request->max_amount);
        }

        // Sắp xếp
        $query->orderBy('created_at', 'desc');


        $data = $query->paginate(10); // Show 10 items per page

        return view('orders.listOrdersByUser', compact('data'));
    }

    public function detailOrder($id)
    {
        $data['order'] = Order::with('supplier', 'historypayment', 'importCosts')->find($id);
        $data['orderDetail'] =   OrderItem::with('forecastProduct')->where('order_id', $id)->get();
        return view('orders.detailOrder', compact('data'));
    }

    public function deleteDetailOrder($id)
    {
        $order = Order::find($id);
        $order->delete();
        return redirect()->back()->with('success', 'Xóa đơn hàng thành công!');
    }


    /* Cập nhật thông tin ngày về ..... ajax */

    public function updateOrderDetail(Request $request)
    {

        try {
            // Lấy dữ liệu từ request (mảng các order item)
            $data = $request->input('data');

            if (empty($data)) {
                return response()->json(['success' => false, 'message' => 'Không có dữ liệu truyền vào!']);
            }

            // Giả sử tất cả các item thuộc cùng một đơn hàng
            $orderId = $data[0]['order_id'];
            // Xóa hết các dữ liệu cũ trong bảng order_items cho đơn hàng này
            $order = Order::where('id', $orderId)->first();
            OrderItem::where('order_id', $orderId)->delete();

            // Duyệt qua từng item trong mảng dữ liệu
            foreach ($data as $item) {
                // Lấy thông tin sản phẩm từ bảng products theo SKU
                $product = ForecastProduct::where('sku', $item['sku'])->first();
                $price = $product ? $product->price : 0;
                $total = $price * $item['quantity'];

                // Insert bản ghi mới vào bảng order_items
                OrderItem::create([
                    'order_id'           => $item['order_id'],
                    'order_code' => $order->order_code ?? "",
                    'sku'                => $item['sku'],
                    'quantity'           => $item['quantity'],
                    'date_of_manufacture' => $item['date_of_manufacture'],
                    'expected_date'      => $item['date_estimated_arrival'],
                    'date_for_sale'      => $item['date_for_sale'],
                    'ware_housing'       => $item['ware_housing'],
                    'container'          => $item['container'],
                    'price'              => $price,
                    'total'              => $total,
                    'note'                => $item['note'],
                    // Nếu có các trường khác như created_at, updated_at, model tự động cập nhật nếu sử dụng timestamps
                ]);
            }


            Notification::create([
                'user_id' => Auth::id(),
                'type' => 'update', // hoặc 'edit', 'add', 'message', ...
                'message' => 'Tách Load đơn: ' . $order->order_code ?? "" . " thành công",
            ]);

            return response()->json(['success' => true, 'message' => 'Cập nhật đơn hàng thành công!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
        }
    }


    public function updateOrder(Request $request)
    {
        try {
            $data = $request->input('data');

            if (!empty($data)) {
                // Nhóm dữ liệu theo order_id và sku
                $groupedData = [];
                foreach ($data as $item) {
                    // Giả sử mỗi $item chứa các trường: order_id, sku, quantity, date_of_manufacture, date_estimated_arrival, date_for_sale, ware_housing, container
                    $groupedData[$item['order_id']][$item['sku']][] = $item;
                }

                foreach ($groupedData as $orderId => $skuGroup) {
                    foreach ($skuGroup as $sku => $items) {
                        // Lấy các OrderItem hiện có của đơn hàng có order_id và sku, sắp xếp theo id (hoặc theo một tiêu chí nào đó đảm bảo thứ tự)
                        $existingItems = OrderItem::where('order_id', $orderId)
                            ->where('sku', $sku)
                            ->orderBy('id')
                            ->get();

                        $order = Order::where('id', $orderId)->first();

                        // Duyệt qua các bản ghi được gửi lên từ form (có thể có 1 hoặc nhiều do tách load)
                        foreach ($items as $index => $item) {
                            if (isset($existingItems[$index])) {
                                // Nếu có bản ghi hiện có (theo thứ tự index), cập nhật nó
                                $existingItems[$index]->update([
                                    'order_code' => $order->order_code ?? "",
                                    'quantity'           => $item['quantity'],
                                    'date_of_manufacture' => $item['date_of_manufacture'],
                                    'expected_date'      => $item['date_estimated_arrival'],
                                    'date_for_sale'      => $item['date_for_sale'],
                                    'ware_housing'       => $item['ware_housing'],
                                    'container'          => $item['container'],

                                ]);
                            } else {
                                // Nếu số bản ghi gửi lên nhiều hơn số bản ghi hiện có, chèn thêm bản ghi mới
                                OrderItem::create([
                                    'order_id'           => $item['order_id'],
                                    'order_code' => $order->order_code ?? "",
                                    'sku'                => $item['sku'],
                                    'quantity'           => $item['quantity'],
                                    'date_of_manufacture' => $item['date_of_manufacture'],
                                    'expected_date'      => $item['date_estimated_arrival'],
                                    'date_for_sale'      => $item['date_for_sale'],
                                    'ware_housing'       => $item['ware_housing'],
                                    'container'          => $item['container'],
                                ]);
                            }
                        }
                    }
                }
            }
            Notification::create([
                'user_id' => Auth::id(),
                'type' => 'update', // hoặc 'edit', 'add', 'message', ...
                'message' => 'Cập nhật đơn ' . $order->order_code ?? "" . " thành công",
            ]);


            // $message = "Tin nhắn tự động nhắc lịch !";
            // $user = Auth::user();
            // $token_telegram = $user->token_telegram;
            // if ($user && $user->id_telegram) {
            //     FacadesNotification::route('telegram', $user->id_telegram)->notify(new TelegramNotification($message, $user->id_telegram, $token_telegram));
            // }

            return response()->json(['success' => true, 'message' => 'Cập nhật thành công!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
        }
    }



    public function updateStatusOrder(Request $request)
    {
        $id = $request->id;
        $status = $request->status;

        try {
            // Tìm đơn hàng theo id (giả sử model Order đã được import)
            $order = OrderItem::findOrFail($id);
            // Cập nhật trạng thái đơn hàng
            $order->status = $status;
            $order->save();

            // Chuyển hướng trở lại trang trước với thông báo thành công
            Notification::create([
                'user_id' => Auth::id(),
                'type' => 'update', // hoặc 'edit', 'add', 'message', ...
                'message' => 'Cập nhật trạng thái đơn hàng ' . $order->order_code . " | Mã SKU:" . $order->sku . " thành công",
            ]);

            return redirect()->back()->with('success', 'Trạng thái đơn hàng đã được cập nhật!');
        } catch (\Exception $e) {
            // Nếu có lỗi, chuyển hướng trở lại với thông báo lỗi
            return redirect()->back()->with('error', 'Có lỗi xảy ra: ' . $e->getMessage());
        }
    }



    public function checkDateOrder()
    {
        $user = Auth::user();

        // Lấy tất cả các đơn hàng của user với status = 0 (Order)
        $orders = Order::where('user_id', $user->id)
            ->where('status', 0)
            ->with(['items.product']) // eager load OrderItem và sản phẩm của nó
            ->get();

        $now = Carbon::now();

        foreach ($orders as $order) {
            foreach ($order->items as $item) {
                // Chỉ xét các OrderItem có status == 0 (chưa sản xuất xong)
                if ($item->status != 0) {
                    continue;
                }
                // Lấy thông tin chung: mã đơn, sku, tên sản phẩm, số lượng
                $orderCode   = $order->order_code;
                $sku         = $item->sku;
                $productName = $item->product->name ?? 'N/A';
                $quantity    = $item->quantity;

                // Kiểm tra ngày sản xuất nếu có
                if (!empty($item->date_of_manufacture)) {
                    $manufactureDate = Carbon::parse($item->date_of_manufacture);
                    if ($now->lessThanOrEqualTo($manufactureDate) && $now->diffInDays($manufactureDate) <= 2) {
                        $message = "Đơn hàng {$orderCode} (SKU: {$sku}, Sản phẩm: {$productName}, SL: {$quantity}) - Ngày sản xuất xong vào {$manufactureDate->toDateString()} sắp diễn ra trong vòng 2 ngày.";

                        if ($user && $user->id_telegram) {
                            $token_telegram = $user->token_telegram;
                            FacadesNotification::route('telegram', $user->id_telegram)
                                ->notify(new TelegramNotification($message, $user->id_telegram, $token_telegram));
                        }
                    }
                }
                // Kiểm tra ngày dự kiến về nếu có
                if (!empty($item->expected_date)) {
                    $expectedDate = Carbon::parse($item->expected_date);
                    if ($now->lessThanOrEqualTo($expectedDate) && $now->diffInDays($expectedDate) <= 2) {
                        $message = "Đơn hàng {$orderCode} (SKU: {$sku}, Sản phẩm: {$productName}, SL: {$quantity}) - Ngày dự kiến về vào {$expectedDate->toDateString()} sắp diễn ra trong vòng 2 ngày.";

                        if ($user && $user->id_telegram) {
                            $token_telegram = $user->token_telegram;
                            FacadesNotification::route('telegram', $user->id_telegram)
                                ->notify(new TelegramNotification($message, $user->id_telegram, $token_telegram));
                        }
                    }
                }
            }
        }
        return redirect()->back()->with('success', 'Kiểm tra ngày đơn hàng hoàn tất');
    }


    public function confirmDeposit(Request $request)
    {
        // Validate dữ liệu đầu vào: yêu cầu order_id, deposit_amount và payment_amount
        $validatedData = $request->validate([
            'order_id'       => 'required|exists:orders,id',
            'deposit_amount' => 'required|numeric|min:0',
            'payment_amount' => 'required|numeric|min:0',
        ]);

        try {
            // Lấy đơn hàng theo ID
            $order = Order::findOrFail($validatedData['order_id']);

            // Kiểm tra xem đơn hàng đã được thanh toán cọc chưa
            if ($order->deposit_paid) {
                return response()->json([
                    'success' => false,
                    'message' => 'Đơn hàng đã được thanh toán cọc.'
                ]);
            }


            // Bắt đầu transaction để đảm bảo tính toàn vẹn dữ liệu
            DB::beginTransaction();

            // Lưu lịch sử thanh toán cọc vào bảng deposit_payments
            $historypayment = HistoryPayment::create([
                'order_id' => $order->id,
                'amount'   => $validatedData['payment_amount'],
                'paid_at'   => $request->date_payment,
                'note'   => $request->note_payment,
                'user_id' => Auth::user()->id,
            ]);

            // Cập nhật trạng thái đơn hàng: đánh dấu đơn hàng đã thanh toán cọc
            $order->deposit_paid = 1;
            $order->save();
            // Commit transaction
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Thanh toán cọc thành công!'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Lỗi khi xử lý thanh toán cọc: ' . $e->getMessage(), [
                'order_id' => $request->order_id
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi xử lý thanh toán cọc.'
            ], 500);
        }
    }


    public function orderPayment(Request $request)
    {
        // Xác thực dữ liệu đầu vào, bao gồm ngày thanh toán và ghi chú (nếu có)
        $validatedData = $request->validate([
            'order_id'       => 'required|exists:orders,id',
            'payment_amount' => 'required|numeric|min:0',
            'date_payment'   => 'required|date',
            'note_payment'   => 'nullable|string'
        ]);

        try {
            // Lấy đơn hàng theo ID
            $order = Order::findOrFail($validatedData['order_id']);

            // Bắt đầu transaction để đảm bảo tính toàn vẹn dữ liệu
            DB::beginTransaction();

            // Tạo bản ghi lịch sử thanh toán
            HistoryPayment::create([
                'order_id'  => $order->id,
                'amount'    => $validatedData['payment_amount'],
                'paid_at'   => $validatedData['date_payment'],
                'note'      => $validatedData['note_payment'] ?? null,
                'user_id'   => Auth::id(),
            ]);

            // Tính tổng số tiền đã thanh toán của đơn hàng qua quan hệ historyPayments
            $totalPaymentHistory = $order->totalPayment();

            /* Tổng tiền chi phí nhận hàng */
            $totalImportCost = $order->totalImportCost();



            // Nếu tổng số thanh toán >= tổng tiền đơn hàng (subtotal), cập nhật trạng thái đơn hàng
            if ($totalPaymentHistory >= $order->subtotal + $totalImportCost) {
                // Ví dụ: 1 là trạng thái "đã thanh toán"
                $order->is_paid = 1;
                $order->save();
            }

            // Commit transaction
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Thanh toán đơn hàng thành công!'
            ]);
        } catch (\Exception $e) {
            // Rollback nếu có lỗi xảy ra
            DB::rollBack();
            Log::error('Lỗi khi xử lý thanh toán đơn hàng: ' . $e->getMessage(), [
                'order_id' => $request->order_id
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi xử lý thanh toán.'
            ], 500);
        }
    }



    public function importCosts(Request $request)
    {
        // Validate
        $validated = $request->validate([
            'order_id'           => 'required|exists:orders,id',
            'costName'           => 'required|array',
            'costName.*'         => 'required|string|max:255',
            'costValue'          => 'required|array',
            'costValue.*'        => 'required|numeric|min:0',
        ]);

        try {
            DB::beginTransaction();

            // Lặp qua mảng costName[] và costValue[] để tạo bản ghi
            $count = count($validated['costName']); // Số dòng chi phí
            for ($i = 0; $i < $count; $i++) {
                ImportCost::create([
                    'order_id'   => $validated['order_id'],
                    'cost_name'  => $validated['costName'][$i],
                    'cost_value' => $validated['costValue'][$i],
                    'user_id'    => Auth::id(), // Lưu user nếu muốn
                ]);
            }
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Thêm chi phí thành công!'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            // Ghi log nếu cần
            return response()->json([
                'success' => false,
                'message' => 'Lỗi: ' . $e->getMessage()
            ], 500);
        }
    }


    public function updatePaymentHistory(Request $request)
    {
        $payment = HistoryPayment::where('id', $request->id)->where('order_id', $request->orderIdPayment)->first();
        if (!$payment) {
            return response()->json(['success' => false]);
        }

        $order = Order::where('id', $request->orderIdPayment)->first();
        $order->is_paid = 0;
        $order->save();
        $payment->update(
            [
                'amount' => $request->amount,
                'note_updated' => $request->note,
                'user_id' => Auth::id(),
                'date_updated' => now()
            ]
        );
        return response()->json(['success' => true]);
    }



    public function updateImportCost(Request $request)
    {

        $cost = ImportCost::where('id', $request->id)->where('order_id', $request->order_id)->first();

        if (!$cost) {
            return response()->json(['success' => false]);
        }
        $cost->update(
            [
                'cost_name' => $request->cost_name,
                'cost_value' => $request->cost_value,
                'user_id' => Auth::id(),
                'date_updated' => now()
            ]
        );
        return response()->json(['success' => true]);
    }

    public function deleteImportCost(Request $request)
    {
        $cost = ImportCost::find($request->id);
        if (!$cost) {
            return response()->json(['success' => false]);
        }

        $cost->delete();
        return response()->json(['success' => true]);
    }


    public function search(Request $request)
    {
        try {
            $query = $request->input('query');

            // Tìm kiếm trong bảng fore_product theo SKU hoặc tên sản phẩm
            $products = ForecastProduct::where('sku', 'LIKE', "%{$query}%")
                ->orWhere('sale_key', 'LIKE', "%{$query}%")
                ->limit(10)
                ->get();
            $results = [];
            foreach ($products as $product) {
                $imageUrl = null;
                if (!empty($product->image)) {
                    $imageUrl = asset('uploads/forecast_products/' . $product->image);
                }
                $results[] = [
                    'id' => $product->id,
                    'name' => $product->sale_key,
                    'sku' => $product->sku,
                    'price' => $product->price,
                    'image_url' => $imageUrl
                ];
            }

            return response()->json([
                'success' => true,
                'data' => $results
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ], 500);
        }
    }



    /* Thêm sản phẩm vào đơn hàng( đã lên đơn trước đó) */
    public function addProduct(Request $request)
    {
        try {
            // Validate dữ liệu
            $validator = Validator::make($request->all(), [
                'order_id' => 'required|exists:orders,id',
                'sku' => 'required|string|max:100',
                'quantity' => 'required|integer|min:1',
                'price' => 'required|numeric|min:0',
                'product_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation error',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Xử lý upload hình ảnh sản phẩm
            $product = new ForecastProduct();

            $forecastProduct = $product->where('sku', $request->sku)->first();
            $imageName = $forecastProduct->image;
            if ($request->hasFile('product_image')) {
                $image = $request->file('product_image');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('uploads/forecast_products'), $imageName);
            }

            // Cập nhật hình ảnh sản phẩm nếu có

            $product->where('sku', $request->sku)->update([
                'image' => $imageName
            ]);

            // Kiểm tra xem note có chứa cụm từ "tách load" không (không phân biệt hoa thường)
            $hasTachLoad = false;
            if ($request->note && stripos($request->note, "tách load") !== false) {
                $hasTachLoad = true;
            }

            // Mặc định là tạo mới nếu có yêu cầu tách load
            $createNewItem = $hasTachLoad;

            if (!$hasTachLoad) {
                // Nếu không có yêu cầu tách load, kiểm tra xem đã có sản phẩm với SKU này trong đơn hàng chưa
                // và không phải là sản phẩm có note chứa "tách load"
                $existingOrderItem = OrderItem::where('order_id', $request->order_id)
                    ->where('sku', $request->sku)
                    ->where(function ($query) {
                        $query->whereNull('note')
                            ->orWhereRaw('LOWER(note) NOT LIKE ?', ['%tách load%']);
                    })
                    ->first();

                // Nếu không tìm thấy item phù hợp để gộp, tạo mới
                if (!$existingOrderItem) {
                    $createNewItem = true;
                }
            }

            $newQuantity = $request->quantity;
            $newTotal = $request->quantity * $request->price;

            if (!$createNewItem && isset($existingOrderItem)) {
                // Nếu đã tồn tại và không phải tách load, cập nhật số lượng và tổng tiền
                $oldQuantity = $existingOrderItem->quantity;
                $oldTotal = $existingOrderItem->total;

                // Cập nhật số lượng và tổng tiền
                $existingOrderItem->quantity += $newQuantity;
                $existingOrderItem->total += $newTotal;

                // Nếu giá đơn vị đã thay đổi, cập nhật giá mới
                if ($existingOrderItem->price != $request->price) {
                    $existingOrderItem->price = $request->price;
                }

                // Cập nhật ghi chú nếu có và không phải tách load
                if ($request->note && !$hasTachLoad) {
                    $existingOrderItem->note = $request->note;
                }

                $existingOrderItem->save();

                // Lưu lại thông tin để cập nhật tổng đơn hàng
                $orderDetail = $existingOrderItem;
                $addedQuantity = $newQuantity; // Chỉ cập nhật đơn hàng với số lượng mới thêm
            } else {
                // Tạo chi tiết đơn hàng mới nếu có yêu cầu tách load hoặc không tìm thấy SKU phù hợp
                $orderDetail = new OrderItem();
                $orderDetail->order_id = $request->order_id;
                $orderDetail->order_code = $request->order_code;
                $orderDetail->sku = $request->sku;
                $orderDetail->quantity = $request->quantity;
                $orderDetail->price = $request->price;
                $orderDetail->total = $newTotal;
                $orderDetail->noteOrder = $request->noteOrder;
                $orderDetail->unit = $request->unit;
                $orderDetail->save();
                $addedQuantity = $newQuantity;
            }

            // Cập nhật lại thông tin đơn hàng
            $order = Order::find($request->order_id);

            // Cộng dồn tổng số lượng và subtotal với số lượng mới thêm vào
            $order->total_quantity = ($order->total_quantity ?? 0) + $addedQuantity;
            $order->subtotal = ($order->subtotal ?? 0) + $newTotal;

            // Cập nhật grand_total:
            // Kiểm tra xem có phải là sản phẩm đầu tiên không (chưa có sản phẩm nào trước đó)
            $isFirstProduct = OrderItem::where('order_id', $request->order_id)->count() == 1;

            if ($isFirstProduct) {
                // Đây là lần thêm sản phẩm đầu tiên, tính grand_total theo deposit %
                // deposit được lưu dưới dạng phần trăm (ví dụ: 20 cho 20%)
                $depositPercentage = $order->deposit ?? 0;
                $depositAmount = $order->subtotal * ($depositPercentage / 100);
                $order->grand_total = $order->subtotal - $depositAmount;
            } else {
                // Các sản phẩm sau: không tính lại deposit, chỉ cộng thêm tổng của sản phẩm mới
                $order->grand_total = ($order->grand_total ?? 0) + $newTotal;
            }

            $order->save();

            // Trả về kết quả thành công
            return response()->json([
                'success' => true,
                'message' => $createNewItem ? 'Sản phẩm đã được thêm thành công' : 'Sản phẩm đã được cập nhật số lượng',
                'image_url' => $imageName ? asset('uploads/forecast_products/' . $imageName) : null,
                'order_data' => [
                    'total_quantity' => $order->total_quantity,
                    'subtotal' => $order->subtotal,
                    'grand_total' => $order->grand_total
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ], 500);
        }
    }



    /* Lấy thông tin đặt cọc của supplier */

    // app/Http/Controllers/SupplierController.php
    public function getDeposit(Request $request)
    {
        $spCode = $request->input('sp_code');

        // Find the supplier by sp_code
        $supplier = Supplier::where('sp_code', $spCode)->first();
        $deposit = $supplier->deposit;
        if ($deposit != NULL) {
            return response()->json([
                'success' => true,
                'deposit' => $supplier->deposit
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Không tìm thấy thông tin đặt cọc'
            ]);
        }
    }

    public function calendarold()
    {
        // Lấy tất cả order_items có status = 0 (chưa hoàn thành)
        $orderItems = DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.user_id', Auth::user()->id)
            ->where('order_items.status', 0) // Items chưa hoàn thành
            ->select(
                'order_items.id',
                'orders.order_code',
                'order_items.sku',
                'order_items.quantity',
                'order_items.price',
                'order_items.date_of_manufacture', // Ngày đầu tiên (2025-04-06)
                'order_items.expected_date', // Ngày thứ hai (2025-04-26)
                'order_items.date_for_sale' // Ngày thứ hai (2025-04-26)
            )
            ->whereNotNull('order_items.date_of_manufacture')
            ->orWhereNotNull('order_items.expected_date')
            ->orWhereNotNull('order_items.date_for_sale')
            ->get();

        // Chuẩn bị dữ liệu cho view calendar
        $events = [];

        foreach ($orderItems as $item) {
            // Thêm sự kiện cho ngày arrival_date (nếu có)
            if (!is_null($item->date_of_manufacture)) {
                $events[] = [
                    'id' => $item->id,
                    'title' => $item->sku . ' (Ngày sản xuất xong)',
                    'start' => $item->date_of_manufacture,
                    'description' => 'Mã đơn: ' . $item->order_code . ', SL: ' . $item->quantity,
                    'color' => '#4CAF50', // Màu xanh lá
                ];
            }

            // Thêm sự kiện cho ngày expected_delivery_date (nếu có)
            if (!is_null($item->expected_date)) {
                $events[] = [
                    'id' => $item->id,
                    'title' => $item->sku . ' (Dự kiến giao)',
                    'start' => $item->expected_date,
                    'description' => 'Mã đơn: ' . $item->order_code . ', SL: ' . $item->quantity,
                    'color' => '#2196F3', // Màu xanh dương
                ];
            }
        }





        // Convert dữ liệu thành JSON để sử dụng trong FullCalendar
        $eventsJson = json_encode($events);

        // Trả về view calendar với dữ liệu
        return view('orders.calendar', [
            'events' => $eventsJson
        ]);
    }




    public function calendar()
    {

        $orderItems = DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->leftJoin('products', 'products.sku', '=', 'order_items.sku')
            ->where('orders.user_id', Auth::id())
            ->where('order_items.status', 0) // Items chưa hoàn thành
            ->where(function ($query) {
                $query->whereNotNull('order_items.date_of_manufacture')
                    ->orWhereNotNull('order_items.expected_date')
                    ->orWhereNotNull('order_items.date_for_sale');
            })
            ->select(
                'order_items.id',
                'orders.order_code',
                'orders.id as order_id',
                'order_items.sku',
                'products.name as product_name',
                'order_items.quantity',
                'order_items.price',
                'order_items.date_of_manufacture', // Ngày dự kiến sản xuất xong
                'order_items.expected_date', // Ngày dự kiến về hàng
                'order_items.date_for_sale' // Ngày dự kiến về cho sale
            )
            ->get();



        // dd($orderItems);
        // Chuẩn bị dữ liệu cho view calendar
        $events = [];
        // Mảng màu sắc cho các sự kiện khác nhau
        $skuColors = [];
        $colors = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#E91E63', '#3F51B5', '#00BCD4', '#009688'];
        $colorIndex = 0;

        foreach ($orderItems as $item) {


            // Gán màu cho mỗi SKU
            if (!isset($skuColors[$item->sku])) {
                $skuColors[$item->sku] = $colors[$colorIndex % count($colors)];
                $colorIndex++;
            }

            $productTitle =  $item->sku;

            // Thêm sự kiện cho ngày arrival_date (nếu có)
            if (!is_null($item->expected_date)) {
                $events[] = [
                    'id' => 'arrival_' . $item->id,
                    'title' => $productTitle . ' - Ngày về dự kiến',
                    'start' => $item->expected_date,
                    'description' => 'Mã đơn: ' . $item->order_code . '<br>SKU: ' . $item->sku . '<br>Số lượng: ' . $item->quantity . '<br>Giá: ' . number_format($item->price, 0, ',', '.') . ' VND',
                    'color' => $skuColors[$item->sku],
                    'sku' => $item->sku,
                    'order_code' => $item->order_code,
                    'order_id' => $item->order_id,
                    'quantity' => $item->quantity,
                    'price' => $item->price,
                    'type' => 'arrival'
                ];
            }

            // Thêm sự kiện cho ngày expected_delivery_date (nếu có)
            if (!is_null($item->date_of_manufacture)) {
                $events[] = [
                    'id' => 'delivery_' . $item->id,
                    'title' => $productTitle . ' - Dự kiến xưởng sản xuât xong',
                    'start' => $item->date_of_manufacture,
                    'description' => 'Mã đơn: ' . $item->order_code . '<br>SKU: ' . $item->sku . '<br>Số lượng: ' . $item->quantity . '<br>Giá: ' . number_format($item->price, 0, ',', '.') . ' VND',
                    'color' => $this->adjustBrightness($skuColors[$item->sku], 0.8), // Làm tối hơn cho sự kiện giao hàng
                    'sku' => $item->sku,
                    'order_code' => $item->order_code,
                    'order_id' => $item->order_id,
                    'quantity' => $item->quantity,
                    'price' => $item->price,
                    'type' => 'delivery'
                ];
            }
        }

        // Convert dữ liệu thành JSON để sử dụng trong FullCalendar
        $eventsJson = json_encode($events);

        // Lấy danh sách SKU và màu tương ứng cho legend
        $skuLegend = json_encode($skuColors);

        // Trả về view calendar với dữ liệu
        return view('orders.calendar', [
            'events' => $eventsJson,
            'skuLegend' => $skuLegend
        ]);
    }

    // Helper function để điều chỉnh độ sáng của màu
    function adjustBrightness($hex, $factor)
    {
        $hex = ltrim($hex, '#');
        $r = hexdec(substr($hex, 0, 2)) * $factor;
        $g = hexdec(substr($hex, 2, 2)) * $factor;
        $b = hexdec(substr($hex, 4, 2)) * $factor;

        return sprintf(
            "#%02x%02x%02x",
            min(255, max(0, $r)),
            min(255, max(0, $g)),
            min(255, max(0, $b))
        );
    }
}
