<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Partner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PartnerController extends Controller
{
    //

    // Hiển thị danh sách đối tác
    public function index()
    {
        $partners = Partner::get();
        return view('partners.index', compact('partners'));
    }

    // Hiển thị form tạo mới đối tác
    public function create()
    {
        return view('partners.create');
    }

    // Lưu dữ liệu đối tác mới vào database
    public function store(Request $request)
    {
        // Validate các trường bắt buộc. Bạn có thể thêm các rule khác nếu cần, ví dụ: password, phone, address,...
        $validated = $request->validate([
            'name'  => 'required|max:255',
            'email' => 'required|email|unique:partners',
            'role'  => 'required|in:customer,carrier,accountant,customs_officer,warehouse_staff,logistics_agent,admin',
            // Nếu cần validate password, bạn có thể thêm: 'password' => 'required|min:8'
        ]);

        // Tạo đối tác mới
        Partner::create([
            'name'     => $request->name ?? "",
            'email'    => $request->email ?? "",
            'role'     => $request->role ?? "",
            'phone'    => $request->phone ?? "",
            'address'  => $request->address ?? "",
            'active'   => 1,
            // Nếu không có password trong request, sử dụng mật khẩu mặc định "12345678"
            'password' => Hash::make("12345678"),
        ]);

        return redirect()->back()->with('success', 'Đối tác đã được tạo thành công.');
    }

    // Hiển thị thông tin chi tiết của 1 đối tác
    public function show($id)
    {
        $partner = Partner::find($id);
        return view('partners.show', compact('partner'));
    }

    // Hiển thị form chỉnh sửa thông tin đối tác
    public function edit($id)
    {
        $partner = Partner::find($id);
        return view('partners.edit', compact('partner'));
    }

    // Cập nhật thông tin đối tác
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'  => 'required|max:255',
            // Sử dụng "unique:partners,email,'.$id" để bỏ qua đối tác hiện tại khi kiểm tra trùng lặp email
            'email' => 'required|email|unique:partners,email,' . $id,
            'role'  => 'required|in:customer,carrier,accountant,customs_officer,warehouse_staff,logistics_agent,admin',
        ]);

        Partner::where('id', $id)->update([
            'name'    => $request->name,
            'email'   => $request->email,
            'role'    => $request->role,
            'phone'   => $request->phone,
            'address' => $request->address,
        ]);

        return redirect()->back()->with('success', 'Đối tác đã được cập nhật.');
    }


    // Xóa đối tác khỏi hệ thống
    public function delete($id)
    {
        Partner::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Đối tác đã được xóa.');
    }
}
