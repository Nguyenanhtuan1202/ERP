<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DailySale;
use App\Models\ForecastProduct;
use Illuminate\Http\Request;

class DailySaleController extends Controller
{
    //

    // Hiển thị danh sách bản ghi bán hàng hàng ngày
    public function index()
    {
        // Lấy dữ liệu bán hàng kèm theo thông tin sản phẩm (nếu có)
        $dailySales = DailySale::with('product')->orderBy('sale_date', 'desc')->paginate(10);
        return view('daily_sales.index', compact('dailySales'));
    }

    // Hiển thị form tạo bản ghi mới
    public function create()
    {
        // Lấy danh sách sản phẩm để hiển thị trong dropdown
        $products = ForecastProduct::all();
        return view('daily_sales.create', compact('products'));
    }

    // Xử lý lưu bản ghi mới
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'sale_date'   => 'required|date',
            'product_id'  => 'required|exists:products,id',
            'sku'         => 'required|string',
            'quantity'    => 'required|integer|min:1',
            'sale_amount' => 'nullable|numeric',
            'sale_channel' => 'nullable|string',
            'store_id'    => 'nullable|integer',
            'salesperson' => 'nullable|string',
            'note'        => 'nullable|string',
        ]);

        DailySale::create($validatedData);
        return redirect()->back()->with('success', 'Bản ghi bán hàng hàng ngày đã được thêm thành công.');
    }
}
