<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ForecastProduct;
use App\Models\HistoryWarehouse;
use App\Models\Supplier;
use App\Models\User;
use App\Models\WarehouseDraft;
use App\Models\Warehousing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WareHouseController extends Controller
{
    //

    public function index()
    {
        // Lấy các bản ghi trong warehouse_drafts có status = 0 (nháp)
        $drafts = WarehouseDraft::with('supplier')->where('status', 0)
            ->orderBy('created_at', 'desc')
            ->get();

        // Lấy danh sách kho thực tế, tổng hợp theo SKU và tên sản phẩm
        $warehouses = Warehousing::select('sku', 'name', 'warehouse_location', DB::raw('SUM(qty_received) as total_qty'))
            ->groupBy('sku', 'name', 'warehouse_location')
            ->get();

        return view('warehouse.index', compact('drafts', 'warehouses'));
    }

    /**
     * Xác nhận một bản ghi hàng tồn kho nháp và chuyển sang kho chính
     *
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function confirmDraft(Request $request, $id)
    {
        $request->validate([
            'ware_housing' => 'required|string',
        ]);

        $warehouseLocation = $request->input('ware_housing');
        $notes = $request->input('notes');
        // Lấy bản nháp cần xác nhận
        $draft = WarehouseDraft::findOrFail($id);

        // Chuyển sang kho chính bằng cách tạo bản ghi trong bảng warehouses (sử dụng model Warehousing)
        $warehouseItem = Warehousing::create([
            'purchase_order_id'   => $draft->purchase_order_id,
            'sku'                 => $draft->sku,
            'name'                => $draft->name,
            'order_quantity'      => $draft->order_quantity,
            'qty_received'        => $draft->qty_received,
            'qty_more'            => $draft->qty_more,
            'entry_date'          => date('Y-m-d'),
            'date_received'       => now(),
            'supplier_id'         => $draft->supplier_id,
            'notes'      => $notes,
            'warehouse_location'  => $warehouseLocation, // Lưu vị trí kho được chọn
        ]);

        // Cập nhật trạng thái bản nháp thành đã xác nhận (status = 1)
        $draft->update(['status' => 1]);

        // Tạo mảng chi tiết cho bản ghi xác nhận (lưu dưới dạng mảng JSON)
        $detail = [
            'warehouse_id'      => $warehouseItem->id,
            'purchase_order_id' => $draft->purchase_order_id,
            'sku'               => $warehouseItem->sku,
            'product_name'      => $warehouseItem->name,
            'quantity_entered'  => $warehouseItem->qty_received,
            'entry_date'        => date('Y-m-d'),
            'date_received'     => $warehouseItem->date_received,
            'warehouse_location' => $warehouseLocation,
        ];

        HistoryWarehouse::create([
            'warehouse_id' => $warehouseItem->id,
            'user_id'      => auth()->id(),
            'details'      => [$detail],
            'entry_time'   => now(),
            'notes'        => 'Xác nhận nhập kho từ bản nháp: ' . $draft->id,
        ]);

        return redirect()->back()->with('status', 'Sản phẩm đã được chuyển sang kho chính!');
    }



    public function confirmAll(Request $request)
    {
        $request->validate([
            'draft_ids'     => 'required|array',
            'ware_housing'  => 'required|array',
        ]);

        $draftIds = $request->input('draft_ids');
        $locations = $request->input('ware_housing'); // mảng: [draft_id => warehouse_location]
        $notes = $request->input('notes', []); // mảng: [draft_id => note]

        $historyDetails = [];

        foreach ($draftIds as $id) {
            $draft = WarehouseDraft::find($id);
            if (!$draft) {
                continue;
            }
            $warehouseLocation = isset($locations[$id]) ? $locations[$id] : 'DEFAULT';
            $note = isset($notes[$id]) ? $notes[$id] : '';

            // Tạo bản ghi trong kho chính (Warehousing)
            $warehouseItem = Warehousing::create([
                'purchase_order_id'   => $draft->purchase_order_id,
                'sku'                 => $draft->sku,
                'name'                => $draft->name,
                'order_quantity'      => $draft->order_quantity,
                'qty_received'        => $draft->qty_received,
                'qty_more'            => $draft->qty_more,
                'entry_date'          => date('Y-m-d'),
                'date_received'       => now(),
                'supplier_id'         => $draft->supplier_id,
                'notes'      => $note,
                'warehouse_location'  => $warehouseLocation,
            ]);

            // Cập nhật trạng thái của bản ghi nháp
            $draft->update(['status' => 1]);

            // Thêm thông tin chi tiết của lần nhập kho vào mảng history
            $historyDetails[] = [
                'warehouse_id'      => $warehouseItem->id,
                'purchase_order_id' => $draft->purchase_order_id,
                'sku'               => $warehouseItem->sku,
                'product_name'      => $warehouseItem->name,
                'quantity_entered'  => $warehouseItem->qty_received,
                'entry_date'        => date('Y-m-d'),
                'date_received'     => $warehouseItem->date_received,
                'warehouse_location' => $warehouseLocation,
                'note'              => $note,
            ];
        }

        // Lưu một dòng lịch sử nhập kho với cột details chứa danh sách chi tiết nhập kho dưới dạng JSON
        HistoryWarehouse::create([
            'warehouse_id' => $warehouseItem->id, // Nếu không liên kết trực tiếp với 1 kho cụ thể
            'user_id'      => auth()->id(),
            'details'      => $historyDetails,
            'entry_time'   => now(),
            'notes'        => 'Xác nhận nhập kho cho ' . count($historyDetails) . ' bản ghi nháp.',
        ]);

        return redirect()->back()->with('status', 'Tất cả các bản ghi nháp đã được xác nhận và chuyển sang kho chính!');
    }



    public function historyIndex()
    {
        $histories = HistoryWarehouse::with('warehouse', 'user')->orderBy('id', 'desc')->orderBy('created_at', 'desc')->get();


        return view('warehouse.history_content', compact('histories'));
    }




    /* Nhập Hàng Cho Nhân Viên Thu Mua */


    public function listOrder()
    {
        return view('purchaser.list_order');
    }

    public function createOrder()
    {
        $data['list_supplier'] = Supplier::where('status', 1)
            ->select(['sp_code', 'company_name'])
            ->orderBy('id', 'desc')->get();
        $data['list_product'] = ForecastProduct::where('status', 1)->orderBy('id', 'desc')->get();
        $data['list_user'] = User::whereNull('supplier_id')->where('status', 1)->orderBy('purchaser', 'desc')
            ->orderBy('ware_housing', 'desc')
            ->get();
        return view('purchaser.create_order', compact('data'));
    }

    public function searchProducts(Request $request)
    {
        $search = $request->input('search', '');
        $products = ForecastProduct::where('status', 1)
            ->where(function ($query) use ($search) {
                $query->where('sale_key', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%");
            })
            ->select([
                'id',
                'sale_key',
                'sku',
                'image',
                'price',
                'unit'
            ])
            ->limit(10)
            ->orderBy('sale_key', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'products' => $products
        ]);
    }
}
