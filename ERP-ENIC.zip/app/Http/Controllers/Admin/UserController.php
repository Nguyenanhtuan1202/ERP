<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Collection;

class UserController extends Controller
{
    public $user;
    public function __construct(User $user)
    {
        $this->user = $user;
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'user']);
            return $next($request);
        });
    }
    public function add()
    {
        $roles = Role::all();
        return view('backend.user.add', compact('roles'));
    }
    public function list()
    {
        $users = $this->user->latest()->get();
        return view('backend.user.list', compact('users'));
    }

    public function save(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users,email',
                'password' => 'required|string|max:255',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'email' => ':attribute phải là địa chỉ email hợp lệ',
                'unique' => ':attribute đã tồn tại trong hệ thống! Vui lòng chọn địa chỉ email khác',
            ],
            [
                'name' => 'Tên',
                'email' => 'Email',
                'password' => 'Mật khẩu',
            ]
        );
        try {
            DB::beginTransaction();
            $user = $this->user->create(
                [
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                ]
            );
            $list_role = $request->role_id;
            $user->role()->attach($list_role); /* Thêm role_user table */
            DB::commit();
            return redirect()->back()->with('status', 'Thêm thành viên thành công');
        } catch (\Exception $exception) {
            DB::rollBack();
            Log::error("message" . $exception->getMessage() . "---- Line" . $exception->getLine());
        }
    }

    public function edit($id)
    {
        $roles = Role::all();
        $user = User::find($id);
        $rolesOfUser = $user->role;
        return view('backend.user.edit', compact('user', 'roles', 'rolesOfUser'));
    }
    public function delete($id)
    {
        // Tìm user theo id
        $user = User::find($id);

        // Nếu không tìm thấy user thì trả về thông báo lỗi
        if (!$user) {
            return redirect()->back()->with('error', 'Không tìm thấy thành viên!');
        }

        // Nếu user có supplier_id, xóa supplier liên quan
        if (!empty($user->supplier_id)) {
            Supplier::where('id', $user->supplier_id)->delete();
        }

        // Xóa user
        $user->delete();

        return redirect()->back()->with('status', 'Xóa thành viên thành công');
    }

    
    public function update(Request $request, $id)
    {
        try {
            DB::beginTransaction();
            if ($request->password == "") {
                $this->user->find($id)->update(
                    [
                        'name' => $request->name,
                        'email' => $request->email,
                    ]
                );
                $user = $this->user->find($id);
                $list_role = $request->role_id;
                $user->role()->sync($list_role);
                DB::commit();
                return redirect()->back()->with('status', 'Cập nhật thành viên thành công');
            } else {
                $this->user->find($id)->update(
                    [
                        'name' => $request->name,
                        'email' => $request->email,
                        'password' => Hash::make($request->password),
                    ]
                );
                $user = $this->user->find($id);
                $list_role = $request->role_id;
                $user->role()->sync($list_role);
                DB::commit();
                return redirect()->back()->with('status', 'Cập nhật thành viên thành công');
            }
        } catch (\Exception $exception) {
            DB::rollBack();
            Log::error("message" . $exception->getMessage() . "---- Line" . $exception->getLine());
        }
    }
}
