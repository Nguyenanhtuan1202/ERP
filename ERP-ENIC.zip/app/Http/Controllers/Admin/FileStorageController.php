<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\File;
use App\Models\FileShare;
use App\Models\Folder;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class FileStorageController extends Controller
{
    //

    /**
     * Constructor to enforce authentication
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display the file storage system index page
     */
    public function index()
    {
        $userId = Auth::id();

        $folders = Folder::where('user_id', $userId)
            ->where('parent_id', null)
            ->with(['children' => function ($query) use ($userId) {
                $query->where('user_id', $userId);
            }, 'files'])
            ->get();

        $files = File::where('user_id', $userId)
            ->where('folder_id', null)
            ->get();

        $subFolders = Folder::where('user_id', $userId)
            ->where('parent_id', null)
            ->get();


        return view('file-storage.folderManager', compact('folders', 'files', 'subFolders'));
    }

    /**
     * Display contents of a specific folder
     */
    public function folder(Request $request, $path = null)
    {
        $userId = Auth::id();

        // Find current folder and verify ownership
        $folder = Folder::where('path', $path)
            ->where('user_id', $userId)
            ->firstOrFail();

        $currentFolder = $folder->name;
        $currentPath = $folder->path;

        // Get folder tree for sidebar
        $folders = Folder::where('user_id', $userId)
            ->where('parent_id', null)
            ->with(['children' => function ($query) use ($userId) {
                $query->where('user_id', $userId);
            }, 'files'])
            ->get();

        // Get files in current folder
        $files = File::where('folder_id', $folder->id)
            ->where('user_id', $userId)
            ->get();

        // Get subfolders
        $subFolders = Folder::where('parent_id', $folder->id)
            ->where('user_id', $userId)
            ->get();

        return view('file-storage.folderManager', compact(
            'folders',
            'files',
            'subFolders',
            'currentFolder',
            'currentPath',
            'path'
        ));
    }

    /**
     * Create a new folder
     */
    public function createFolder(Request $request)
    {
        $request->validate([
            'folder_name' => 'required|string|max:255',
            'current_path' => 'nullable|string',
        ]);

        $userId = Auth::id();
        $folderName = $request->folder_name;
        $currentPath = $request->current_path;

        // Find parent folder if current_path is provided
        $parentId = null;
        if ($currentPath) {
            $parentFolder = Folder::where('path', $currentPath)
                ->where('user_id', $userId)
                ->first();

            if ($parentFolder) {
                $parentId = $parentFolder->id;
                $path = $currentPath . '/' . $folderName;
            } else {
                $path = $folderName;
            }
        } else {
            $path = $folderName;
        }

        // Create physical folder in user's storage space
        Storage::makeDirectory('users/' . $userId . '/folders/' . $path);

        // Create folder record
        Folder::create([
            'name' => $folderName,
            'path' => $path,
            'parent_id' => $parentId,
            'user_id' => $userId,
        ]);

        return redirect()->back()->with('success', 'Thư mục đã được tạo thành công!');
    }

    /**
     * Upload files to storage
     */
    public function upload(Request $request)
    {
        $request->validate([
            'files' => 'required|array',
            'files.*' => 'file|max:10240', // 10MB max per file
            'current_path' => 'nullable|string',
        ]);

        $userId = Auth::id();
        $currentPath = $request->current_path;
        $folderId = null;

        // Find folder if current_path is provided
        if ($currentPath) {
            $folder = Folder::where('path', $currentPath)
                ->where('user_id', $userId)
                ->first();

            if ($folder) {
                $folderId = $folder->id;
            }
        }

        $uploadPath = $folderId
            ? 'users/' . $userId . '/files/' . $currentPath
            : 'users/' . $userId . '/files';

        foreach ($request->file('files') as $uploadedFile) {
            $fileName = $uploadedFile->getClientOriginalName();
            $fileSize = $uploadedFile->getSize();
            $mimeType = $uploadedFile->getMimeType();

            // Generate unique name to prevent overwriting
            $uniqueName = Str::uuid() . '_' . $fileName;

            // Store file
            $path = $uploadedFile->storeAs($uploadPath, $uniqueName);

            // Create file record
            File::create([
                'name' => $fileName,
                'path' => $path,
                'size' => $fileSize,
                'mime_type' => $mimeType,
                'folder_id' => $folderId,
                'user_id' => $userId,
            ]);
        }

        return redirect()->back()->with('success', 'File đã được tải lên thành công!');
    }

    /**
     * Create a new text file
     */
    public function createFile(Request $request)
    {
        $request->validate([
            'file_name' => 'required|string|max:255',
            'file_extension' => 'required|string|max:10',
            'file_content' => 'nullable|string',
            'current_path' => 'nullable|string',
        ]);

        $userId = Auth::id();
        $fileName = $request->file_name . '.' . $request->file_extension;
        $fileContent = $request->file_content;
        $currentPath = $request->current_path;
        $folderId = null;

        // Find folder if current_path is provided
        if ($currentPath) {
            $folder = Folder::where('path', $currentPath)
                ->where('user_id', $userId)
                ->first();

            if ($folder) {
                $folderId = $folder->id;
            }
        }

        $filePath = $folderId
            ? 'users/' . $userId . '/files/' . $currentPath . '/' . $fileName
            : 'users/' . $userId . '/files/' . $fileName;

        // Store file content
        Storage::put($filePath, $fileContent);

        // Determine MIME type based on extension
        $mimeType = $this->getMimeType($request->file_extension);

        // Create file record
        File::create([
            'name' => $fileName,
            'path' => $filePath,
            'size' => strlen($fileContent),
            'mime_type' => $mimeType,
            'folder_id' => $folderId,
            'user_id' => $userId,
        ]);

        return redirect()->back()->with('success', 'File đã được tạo thành công!');
    }

    /**
     * Delete a file or folder
     */
    public function delete(Request $request)
    {
        $request->validate([
            'item_id' => 'required',
            'item_type' => 'required|in:file,folder',
        ]);

        $userId = Auth::id();
        $itemId = $request->item_id;
        $itemType = $request->item_type;

        if ($itemType === 'file') {
            $file = File::where('id', $itemId)
                ->where('user_id', $userId)
                ->firstOrFail();

            // Delete physical file
            Storage::delete($file->path);

            // Delete record
            $file->delete();

            return redirect()->back()->with('success', 'File đã được xóa thành công!');
        } else {
            $folder = Folder::where('id', $itemId)
                ->where('user_id', $userId)
                ->with(['files', 'children' => function ($query) use ($userId) {
                    $query->where('user_id', $userId)->with('files');
                }])
                ->firstOrFail();

            // Delete all files in folder
            foreach ($folder->files as $file) {
                Storage::delete($file->path);
                $file->delete();
            }

            // Delete subfolder recursively
            $this->deleteSubfolders($folder);

            // Delete physical folder
            Storage::deleteDirectory('users/' . $userId . '/folders/' . $folder->path);

            // Delete record
            $folder->delete();

            return redirect()->back()->with('success', 'Thư mục đã được xóa thành công!');
        }
    }

    /**
     * Preview a file
     */
    public function preview($id)
    {
        $userId = Auth::id();
        $file = File::where('id', $id)
            ->where('user_id', $userId)
            ->firstOrFail();

        if (!Storage::exists($file->path)) {
            abort(404);
        }

        $content = Storage::get($file->path);

        return response($content)->header('Content-Type', $file->mime_type);
    }

    /**
     * Download a file
     */
    public function download($id)
    {
        $userId = Auth::id();
        $file = File::where('id', $id)
            ->where('user_id', $userId)
            ->firstOrFail();

        if (!Storage::exists($file->path)) {
            abort(404);
        }

        return Storage::download($file->path, $file->name);
    }

    /**
     * Helper method to recursively delete subfolders
     */
    private function deleteSubfolders($folder)
    {
        $userId = Auth::id();

        foreach ($folder->children as $childFolder) {
            // Delete all files in subfolder
            foreach ($childFolder->files as $file) {
                Storage::delete($file->path);
                $file->delete();
            }

            // Recursively delete nested subfolders
            if (count($childFolder->children) > 0) {
                $this->deleteSubfolders($childFolder);
            }

            // Delete physical subfolder
            Storage::deleteDirectory('users/' . $userId . '/folders/' . $childFolder->path);

            // Delete record
            $childFolder->delete();
        }
    }

    /**
     * Helper method to get MIME type based on file extension
     */
    private function getMimeType($extension)
    {
        $mimeTypes = [
            'txt' => 'text/plain',
            'md' => 'text/markdown',
            'html' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'csv' => 'text/csv',
        ];

        return $mimeTypes[$extension] ?? 'application/octet-stream';
    }

    /**
     * Rename a file or folder
     */
    public function rename(Request $request)
    {
        $request->validate([
            'item_id' => 'required',
            'item_type' => 'required|in:file,folder',
            'new_name' => 'required|string|max:255',
        ]);

        $userId = Auth::id();
        $itemId = $request->item_id;
        $itemType = $request->item_type;
        $newName = $request->new_name;

        if ($itemType === 'file') {
            $file = File::where('id', $itemId)
                ->where('user_id', $userId)
                ->firstOrFail();

            // Extract file extension
            $extension = pathinfo($file->name, PATHINFO_EXTENSION);
            $newNameWithExtension = pathinfo($newName, PATHINFO_EXTENSION) ? $newName : $newName . '.' . $extension;

            // Update physical file path
            $oldPath = $file->path;
            $newPath = str_replace(basename($oldPath), $newNameWithExtension, $oldPath);

            if (Storage::exists($oldPath)) {
                Storage::move($oldPath, $newPath);
            }

            // Update database record
            $file->name = $newNameWithExtension;
            $file->path = $newPath;
            $file->save();

            return redirect()->back()->with('success', 'File đã được đổi tên thành công!');
        } else {
            $folder = Folder::where('id', $itemId)
                ->where('user_id', $userId)
                ->firstOrFail();

            $oldName = $folder->name;
            $oldPath = $folder->path;

            // Calculate new path
            $newPath = $folder->parent_id
                ? preg_replace('/' . preg_quote($oldName, '/') . '$/', $newName, $oldPath)
                : $newName;

            // Update physical folder
            if (Storage::exists('users/' . $userId . '/folders/' . $oldPath)) {
                Storage::move('users/' . $userId . '/folders/' . $oldPath, 'users/' . $userId . '/folders/' . $newPath);
            }

            // Update folder record
            $folder->name = $newName;
            $folder->path = $newPath;
            $folder->save();

            // Update paths of subfolders and files
            $this->updateSubfolderPaths($folder, $oldPath, $newPath);

            return redirect()->back()->with('success', 'Thư mục đã được đổi tên thành công!');
        }
    }

    /**
     * Update paths of subfolders when parent folder is renamed
     */
    private function updateSubfolderPaths($folder, $oldParentPath, $newParentPath)
    {
        $userId = Auth::id();

        // Get all subfolders
        $subfolders = Folder::where('parent_id', $folder->id)
            ->where('user_id', $userId)
            ->get();

        foreach ($subfolders as $subfolder) {
            $oldPath = $subfolder->path;
            $newPath = str_replace($oldParentPath . '/', $newParentPath . '/', $oldPath);

            // Update subfolder record
            $subfolder->path = $newPath;
            $subfolder->save();

            // Update all files in this subfolder
            $files = File::where('folder_id', $subfolder->id)
                ->where('user_id', $userId)
                ->get();

            foreach ($files as $file) {
                $oldFilePath = $file->path;
                $newFilePath = str_replace($oldParentPath . '/', $newParentPath . '/', $oldFilePath);

                $file->path = $newFilePath;
                $file->save();
            }

            // Recursively update nested subfolders
            $this->updateSubfolderPaths($subfolder, $oldPath, $newPath);
        }
    }

    /**
     * Move a file to a different folder
     */
    public function move(Request $request)
    {
        $request->validate([
            'file_id' => 'required',
            'destination_folder_id' => 'nullable',
        ]);

        $userId = Auth::id();
        $fileId = $request->file_id;
        $destinationFolderId = $request->destination_folder_id ?: null;

        $file = File::where('id', $fileId)
            ->where('user_id', $userId)
            ->firstOrFail();

        $oldFolderId = $file->folder_id;

        // If moving to root
        if ($destinationFolderId === null) {
            $oldPath = $file->path;
            $newPath = 'users/' . $userId . '/files/' . $file->name;

            if (Storage::exists($oldPath)) {
                Storage::move($oldPath, $newPath);
            }

            $file->folder_id = null;
            $file->path = $newPath;
            $file->save();
        } else {
            $destinationFolder = Folder::where('id', $destinationFolderId)
                ->where('user_id', $userId)
                ->firstOrFail();

            $oldPath = $file->path;
            $newPath = 'users/' . $userId . '/files/' . $destinationFolder->path . '/' . $file->name;

            if (Storage::exists($oldPath)) {
                Storage::move($oldPath, $newPath);
            }

            $file->folder_id = $destinationFolder->id;
            $file->path = $newPath;
            $file->save();
        }

        return redirect()->back()->with('success', 'File đã được di chuyển thành công!');
    }

    /**
     * Share a file with others
     */
    public function share(Request $request)
    {
        $request->validate([
            'file_id' => 'required',
            'is_enabled' => 'required|boolean',
            'expiry_hours' => 'nullable|integer',
            'password' => 'nullable|string|max:255',
        ]);

        $userId = Auth::id();
        $fileId = $request->file_id;
        $isEnabled = $request->is_enabled;
        $expiryHours = $request->expiry_hours;
        $password = $request->password;

        $file = File::where('id', $fileId)
            ->where('user_id', $userId)
            ->firstOrFail();

        // Create or update FileShare record
        // This assumes you have a FileShare model to track shared files
        $fileShare = FileShare::updateOrCreate(
            ['file_id' => $fileId],
            [
                'user_id' => $userId,
                'token' => Str::random(32),
                'is_enabled' => $isEnabled,
                'expiry_at' => $expiryHours ? now()->addHours($expiryHours) : null,
                'password' => $password ? bcrypt($password) : null,
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Cài đặt chia sẻ đã được cập nhật!',
            'share_url' => route('file-storage.access-shared', $fileShare->token),
        ]);
    }

    /**
     * Access a shared file
     */
    public function accessSharedFile($token)
    {
    
        // This assumes you have a FileShare model to track shared files
        $fileShare = FileShare::where('token', $token)
            ->where('is_enabled', true)
            ->first();
        if (!$fileShare || ($fileShare->expiry_at && now()->isAfter($fileShare->expiry_at))) {
            abort(404, 'Link chia sẻ không tồn tại hoặc đã hết hạn!');
        }

        $file = File::find($fileShare->file_id);

        if (!$file || !Storage::exists($file->path)) {
            abort(404, 'File không tồn tại!');
        }

        // If password is set, show password form
        if ($fileShare->password) {
            return view('file-storage.shared-file-password', compact('fileShare', 'file'));
        }

        // If no password, directly serve the file
        $content = Storage::get($file->path);
        return response($content)->header('Content-Type', $file->mime_type);
    }

    /**
     * Validate password for shared file
     */
    public function validateSharePassword(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'password' => 'required',
        ]);

        $token = $request->token;
        $password = $request->password;

        $fileShare = FileShare::where('token', $token)->first();

        if (!$fileShare || !Hash::check($password, $fileShare->password)) {
            return back()->withErrors(['password' => 'Mật khẩu không đúng!']);
        }

        $file = File::find($fileShare->file_id);

        if (!$file || !Storage::exists($file->path)) {
            abort(404, 'File không tồn tại!');
        }

        $content = Storage::get($file->path);
        return response($content)->header('Content-Type', $file->mime_type);
    }


    public function updateFileShare(Request $request)
    {   

        $request->validate([
            'file_id' => 'required|integer|exists:files,id',
            'is_enabled' => 'required',
            'expiry_time' => 'required|integer|min:0',
            'password' => 'nullable|string|max:255',
        ]);

        $file = File::findOrFail($request->file_id);

        // Check if user has permission to share this file
        if ($file->user_id != auth()->id()) {
            return response()->json([
                'success' => false,
                'message' => 'Bạn không có quyền chia sẻ file này'
            ], 403);
        }

        // Calculate expiry time
        $expiryAt = null;
        if ($request->expiry_time > 0) {
            $expiryAt = now()->addHours($request->expiry_time);
        }

        // Find existing share or create new one
        $fileShare = FileShare::updateOrCreate(
            ['file_id' => $request->file_id],
            [
                'user_id' => auth()->id(),
                'token' => $request->has('token') && $request->token ? $request->token : Str::random(32),
                'is_enabled' => $request->is_enabled == true ? 1 : 0,
                'expiry_at' => $expiryAt,
                'password' => $request->password ? Hash::make($request->password) : null,
            ]
        );

        // Generate share link using named route
        $shareLink = route('file-storage.access-shared', ['token' => $fileShare->token]);

        return response()->json([
            'success' => true,
            'message' => 'Cập nhật chia sẻ thành công',
            'share_link' => $shareLink,
            'file_share' => $fileShare
        ]);
    }
}
