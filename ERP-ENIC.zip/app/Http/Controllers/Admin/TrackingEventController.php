<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TrackingEvents;
use Illuminate\Http\Request;

class TrackingEventController extends Controller
{
    //
    public function index()
    {
        $events = TrackingEvents::paginate(10);
        return view('tracking_events.index', compact('events'));
    }

    public function create()
    {
        return view('tracking_events.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'shipment_id' => 'required|exists:shipments,id',
            'event_type'  => 'required|in:Khởi hành,Đến cảng,Trên đường,Thông quan,Giao hàng,Trễ hạn',
            'location'    => 'nullable|string',
            'event_time'  => 'nullable|date',
            'description' => 'nullable|string',
        ]);

        TrackingEvents::create($validated);
        return redirect()->route('tracking_events.index')->with('success', 'Sự kiện theo dõi đã được tạo.');
    }

    public function show(TrackingEvents $trackingEvent)
    {
        return view('tracking_events.show', compact('trackingEvent'));
    }

    public function edit(TrackingEvents $trackingEvent)
    {
        return view('tracking_events.edit', compact('trackingEvent'));
    }

    public function update(Request $request, TrackingEvents $trackingEvent)
    {
        $validated = $request->validate([
            'shipment_id' => 'required|exists:shipments,id',
            'event_type'  => 'required|in:Khởi hành,Đến cảng,Trên đường,Thông quan,Giao hàng,Trễ hạn',
            'location'    => 'nullable|string',
            'event_time'  => 'nullable|date',
            'description' => 'nullable|string',
        ]);

        $trackingEvent->update($validated);
        return redirect()->route('tracking_events.index')->with('success', 'Sự kiện theo dõi đã được cập nhật.');
    }

    public function destroy(TrackingEvents $trackingEvent)
    {
        $trackingEvent->delete();
        return redirect()->route('tracking_events.index')->with('success', 'Sự kiện theo dõi đã được xóa.');
    }
}
