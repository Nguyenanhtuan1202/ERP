<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Imports\SupplierImport;
use App\Models\Category;
use App\Models\ForecastProduct;
use App\Models\GeminiChatMessage;
use App\Models\GeminiChatSession;
use App\Models\ModelVersion;
use App\Models\ProductHistory;
use App\Models\ProductVariant;
use App\Models\Supplier;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Str;

class PurchasingManagerController extends Controller
{
    //
    public function index()
    {
        $data = User::where('purchaser', 1)->where('status', 1)->orderBy('id', 'desc')->get();
        return view('purchaser.index', compact('data'));
    }

    public function create()
    {

        return view('purchaser.create');
    }

    public function save(Request $request)
    {
        $request->validate(
            [
                'username' => 'required|string|max:255',
                'email' => 'required|string|max:255',
                'password' => 'required|string|max:255',
                'phone' => 'required|string|max:255',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'username' => 'Họ Và Tên',
                'email' => 'Email',
                'password' => 'Mật Khẩu',
                'phone' => 'Số Điện Thoại',
            ]
        );;


        $checkEmail = User::where('email', $request->email)->first();
        if ($checkEmail) {
            return redirect()->back()->with('error', 'Email đã tồn tại vui lòng kiểm tra lại!');
        }

        User::create(
            [
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
                'password' => Hash::make($request->password ?? ""),
                'purchaser' => 1
            ]
        );
        return redirect()->back()->with('success', 'Thêm thành viên thành công!');
    }

    public function edit($id)
    {
        $data = User::find($id);
        return view('purchaser.edit', compact('data'));
    }
    public function delete($id)
    {

        User::find($id)->delete();
        return redirect()->back()->with('success', 'Xoá user thành công!');
    }
    public function update($id, Request $request)
    {
        if ($request->password == "" || $request->password == NULL) {
            User::where('id', $id)->update([
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
            ]);
        } else {
            User::where('id', $id)->update([
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
                'password' => Hash::make($request->password ?? ""),
            ]);
        }

        return redirect()->back()->with('success', 'Cập nhật dữ liệu thành công!');
    }

    public function view($id)
    {
        $data['user'] = User::find($id);
        $data['history'] = User::find($id)->historyPayment()->orderBy('id', 'desc')->get();
        $data['supplier'] = User::find($id)->supplier()->orderBy('id', 'desc')->get();
        $data['order'] = User::find($id)->order()->orderBy('id', 'desc')->get();


        // Get all suppliers for this user
        $suppliers = $data['user']->supplier()->get();

        // New approach: get all forecast products for these suppliers
        $forecastProductIds = [];
        foreach ($suppliers as $supplier) {
            // Get forecast product IDs for each supplier
            $supplierForecastProducts = ForecastProduct::where('supplier_id', $supplier->sp_code)->get();
            foreach ($supplierForecastProducts as $product) {
                $forecastProductIds[] = $product->id;
            }
        }
        // Now get all the forecast products with these IDs
        $data['forecastProducts'] = ForecastProduct::whereIn('id', $forecastProductIds)->orderBy('id', 'desc')->get();
        return view('purchaser.view', compact('data'));
    }

    public function listSupplier(Request $request)
    {
        $status = $request->status;
        $id = $request->id;
        if ($status != NULL && $id != NULL) {
            Supplier::where('id', $request->id)->update(
                [
                    'status' => $status
                ]
            );
            return redirect()->back()->with('success', 'Cập nhật trạng thái nhà cung cấp thành công');
        } else {
            $suppliers = Supplier::with('user')->where('employer_id', Auth::id())->orderBy('status', 'desc')->orderBy('id', 'desc')->get();
            return view('purchaser.listSupplier', compact('suppliers'));
        }
    }

    public function createSupplier()
    {
        $list_purchaser = User::where('purchaser', 1)->orderBy('id', 'desc')->get();
        $list_forecaster = User::where('forecaster', 1)->orderBy('id', 'desc')->get();
        return view('purchaser.createSupplier', compact('list_purchaser', 'list_forecaster'));
    }

    public function saveSupplier(Request $request)
    {
        $checkSku = Supplier::where('sp_code', $request->sp_code)->first();
        if ($checkSku) {
            return redirect()->back()->with('error', 'Mã sku đã tồn tại. Vui lòng kiểm tra lại');
        } else {
            $request->validate([
                'username' => 'required|string|max:255',
            ]);
            $supplier = Supplier::create([
                'username' => $request->username,
                'phone_number' => $request->phone_number,
                'email' => $request->email,
                'company_name' => $request->input('company_name'),
                'companion_day' => $request->input('companion_day'),
                'website' => $request->website,
                'address' => $request->address,
                'company_tax' => $request->input('company_tax'),
                'employer_id' => $request->employer_id,
                'terms' => $request->terms,
                'status' => $request->status,
                'deposit' => $request->deposit,
                'weight' => 0,
                'payments' => $request->payments,
                'industry' => $request->industry,
                'note' => $request->note,
                'sp_code' => $request->sp_code,
                'holiday_schedule' => $request->holiday_schedule,
                'packaging_specifications' => $request->packaging_specifications,
                'production_time' => $request->production_time,
                'shipping_time' => $request->shipping_time,
                'total_lead_time' => $request->total_lead_time,
                'exclusive_rights' => $request->exclusive_rights,
                'warranty_preorder' => $request->warranty_preorder,
                'warranty_postorder' => $request->warranty_postorder,
                'forecaster_id' => $request->forecaster_id,
                'peak_season' => $request->peak_season,
            ]);

            if ($request->has('bank_accounts')) {
                foreach ($request->bank_accounts as $bankAccount) {
                    $supplier->bankAccounts()->create($bankAccount);
                }
            }
            return redirect()->route('supplierManagement.edit', [$supplier->id])->with('success', 'Thêm Nhà Cung Cấp Thành Công.');
        }
    }

    public function editSupplier($id)
    {
        $list_purchaser = User::where('purchaser', 1)->orderBy('id', 'desc')->get();
        $list_forecaster = User::where('forecaster', 1)->orderBy('id', 'desc')->get();
        $supplier = Supplier::findOrFail($id);
        $productBySupplier = ForecastProduct::where('supplier_id', $supplier->sp_code)->orderBy('id', 'desc')->get();
        $list_bank_accounts = $supplier->bankAccounts;
        return view('purchaser.editSupplier', compact('supplier', 'list_bank_accounts', 'productBySupplier', 'list_purchaser', 'list_forecaster'));
    }


    public function updateSupplier(Request $request, $id)
    {
        $request->validate([
            'username' => 'required|string|max:255',
        ]);

        $supplier = Supplier::findOrFail($id);
        $supplier->update([
            'username' => $request->username,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
            'company_name' => $request->input('company_name'),
            'companion_day' => $request->input('companion_day'),
            'website' => $request->website,
            'address' => $request->address,
            'company_tax' => $request->input('company_tax'),
            'employer_id' => $request->employer_id,
            'terms' => $request->terms,
            'status' => $request->status,
            'deposit' => $request->deposit,
            'weight' => 0,
            'payments' => $request->payments,
            'industry' => $request->industry,
            'note' => $request->note,
            'sp_code' => $request->sp_code,
            'holiday_schedule' => $request->holiday_schedule,
            'packaging_specifications' => $request->packaging_specifications,
            'production_time' => $request->production_time,
            'shipping_time' => $request->shipping_time,
            'total_lead_time' => $request->total_lead_time,
            'exclusive_rights' => $request->exclusive_rights,
            'warranty_preorder' => $request->warranty_preorder,
            'warranty_postorder' => $request->warranty_postorder,
            'forecaster_id' => $request->forecaster_id,
            'peak_season' => $request->peak_season,

        ]);

        if ($request->has('bank_accounts')) {
            foreach ($request->bank_accounts as $bankAccount) {
                $supplier->bankAccounts()->updateOrCreate(
                    ['account_number' => $bankAccount['account_number']],
                    $bankAccount
                );
            }
        } else {
            $supplier->bankAccounts()->delete();
        }
        return redirect()->back()->with('success', 'Cập Nhật Thông Tin Nhà Cung Cấp Thành Công.');
    }

    public function deleteSupplier($id)
    {
        $supplier = Supplier::findOrFail($id);
        $supplier->delete();
        return redirect()->back()->with('success', 'Xoá thông tin nhà cung cấp thành công.');
    }

    public function importExcel()
    {
        return view('purchaser.viewImportExcel');
    }

    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);
        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new SupplierImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON

            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0;           // Số lượng bản ghi mới được thêm
        $existingRecordsCount = 0;      // Số lượng bản ghi đã tồn tại

        // Hàm helper để làm sạch chuỗi
        $clean = function ($value) {
            if (!is_string($value)) {
                return $value;
            }
            $value = trim($value);                     // Loại bỏ khoảng trắng đầu/cuối
            $value = preg_replace('/\s+/', ' ', $value); // Thay thế khoảng trắng liên tục bằng 1 khoảng trắng
            return $value;
        };

        try {
            foreach ($data as $row) {
                // Ép sang mảng nếu không phải
                if (!is_array($row)) {
                    $row = (array) $row;
                }
                // Kiểm tra xem key "sp_code" có tồn tại không
                if (!array_key_exists('sp_code', $row)) {
                    continue;
                }
                $sp_code = $clean($row['sp_code']);
                if (empty($sp_code)) {
                    continue;
                }
                // Kiểm tra nếu sp_code đã tồn tại trong cơ sở dữ liệu
                $existingProduct = Supplier::where('sp_code', $sp_code)->first();
                if ($existingProduct) {
                    $existingRecordsCount++;
                    continue;
                }

                // Tạo bản ghi mới cho Supplier
                $supplier = new Supplier();
                $supplier->sp_code = array_key_exists('sp_code', $row) ? $clean($row['sp_code']) : null;
                $supplier->username = array_key_exists('username', $row) ? $clean($row['username']) : null;
                $supplier->company_name = array_key_exists('company_name', $row) ? $clean($row['company_name']) : null;
                $supplier->address = array_key_exists('address', $row) ? $clean($row['address']) : null;
                $supplier->product_manufacturing = array_key_exists('product_manufacturing', $row) ? $clean($row['product_manufacturing']) : null;
                $supplier->note = array_key_exists('note', $row) ? $clean($row['note']) : null;

                // Xử lý companion_day: chuyển từ "dd/mm/yyyy" sang "Y-m-d"
                $companion_day = null;
                if (array_key_exists('companion_day', $row)) {
                    $rawDate = $clean($row['companion_day']);
                    try {
                        $companion_day = Carbon::createFromFormat('d/m/Y', $rawDate)->format('Y-m-d');
                    } catch (\Exception $e) {
                        // Nếu chuyển đổi thất bại, có thể log lỗi hoặc giữ null
                        $companion_day = null;
                    }
                }
                $supplier->companion_day = $companion_day;

                $supplier->employer = array_key_exists('employer', $row) ? $clean($row['employer']) : null;
                $supplier->sp_code = $sp_code;
                $supplier->save(); // Lưu dữ liệu vào cơ sở dữ liệu

                $newRecordsCount++;
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công {$newRecordsCount} bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại trong cơ sở dữ liệu. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', "Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!");
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }



    /*  Phân Sản Phẩm */

    /* Tạo mới sản phẩm */
    public function createProduct()
    {

        $data['list_supplier'] = Supplier::where('employer_id', Auth::id())->where('status', 1)->orderBy('id', 'desc')->get();

        $supplierCodes = Supplier::where('employer_id', Auth::id())
            ->pluck('sp_code')
            ->toArray();


        // Lấy danh sách các product_name không trùng
        $data['productCategories'] = ForecastProduct::distinct('product_name')
            ->where('product_name', '!=', null)
            // ->whereIn('supplier_id', $supplierCodes)
            ->orderBy('product_name')
            ->pluck('product_name');

        /* Danh Mục Sản Phẩm */
        $data['list_category'] = Category::with('catChild')->where('parent_id', 0)
            ->select(['id', 'title', 'status'])
            ->where('status', 1)->get();

        /* Mẫu Phiên ( Phân Loại) Sản Phẩm */

        $data['list_variant'] = ProductVariant::where('status', 1)
            ->select(['id', 'title', 'status'])->orderBy('id', 'desc')->get();

        /* Phiên Bản ( Model Version) */

        $data['list_model_version'] = ModelVersion::where('status', 1)
            ->select(['id', 'title', 'status'])->orderBy('id', 'desc')->get();



        $data['product_variant'] = ForecastProduct::distinct('product_name')
            ->where('product_variant', '!=', null)
            ->whereIn('supplier_id', $supplierCodes)
            ->orderBy('product_variant')
            ->pluck('product_variant');

        $data['model_version'] = ForecastProduct::distinct('product_name')
            ->where('model_version', '!=', null)
            ->whereIn('supplier_id', $supplierCodes)
            ->orderBy('model_version')
            ->pluck('model_version');

        return view('purchaser.createProduct', compact('data'));
    }



    public function saveProduct(Request $request)
    {
        // Khởi tạo dữ liệu từ request
        $data = $request->all();

        // Xử lý upload ảnh nếu có
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName();
            $name_image = current(explode('.', $get_name_image));
            $new_image = $name_image . rand(0, 99) . '.' . $get_image->getClientOriginalExtension();
            $get_image->move('public/uploads/forecast_products', $new_image);

            // Thêm tên ảnh vào dữ liệu
            $data['image'] = $new_image;
        }
        // Tạo sản phẩm mới
        $product = ForecastProduct::create($data);
        // Redirect với thông báo thành công
        return redirect()->route('productManagement.edit', ['id' => $product->id])
            ->with('success', 'Sản phẩm đã được tạo thành công.');
    }


    public function createSession(Request $request)
    {
        try {
            $sessionId = Session::getId();
            // Sửa lỗi khoảng trắng trong tên cột
            $checkSession = GeminiChatSession::where('session_id', $sessionId)->first();

            if (!$checkSession) {
                $session = GeminiChatSession::create([
                    'session_id'    => $sessionId,
                    'user_id' => intval($request->user_id ?? 0),
                    'user_info'     => json_encode($request->user_info),
                    'last_activity' => Carbon::now(),
                ]);
            } else {
                // Nếu đã có session thì dùng session hiện có
                $session = $checkSession;
            }

            return response()->json([
                'success'    => true,
                'session_id' => $session->session_id
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to create chat session: ' . $e->getMessage());
            dd($e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to create chat session'
            ], 500);
        }
    }

    public function saveMessage(Request $request)
    {
        try {
            // Validate the request
            $request->validate([
                'session_id' => 'required|exists:gemini_chat_sessions',
                'content' => 'required|string',
                'sender_type' => 'required|in:user,bot',
            ]);

            // Save the message
            $message = GeminiChatMessage::create([
                'session_id' => $request->session_id,
                'content' => $request->content,
                'sender_type' => $request->sender_type,
                'role' => $request->sender_type
            ]);

            // Update last activity timestamp on the session
            GeminiChatSession::where('session_id', $request->session_id)
                ->update(['last_activity' => Carbon::now()]);

            return response()->json([
                'success' => true,
                'message_id' => $message->id
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to save chat message: ' . $e->getMessage());

            dd($e->getMessage(), true);
            return response()->json([
                'success' => false,
                'message' => 'Failed to save chat message'

            ], 500);
        }
    }


    public function processAi(Request $request)
    {
        $keyword = $request->keyword;
        $sessionId = $request->session_id;

        // Update last activity for session if provided
        if ($sessionId) {
            // Lấy thông tin session để có user_id
            $currentSession = GeminiChatSession::where('session_id', $sessionId)->first();
            $userId = $currentSession ? $currentSession->user_id : null;

            // Cập nhật thời gian hoạt động
            if ($currentSession) {
                $currentSession->update(['last_activity' => Carbon::now()]);
            }

            // Xây dựng context thông minh
            $contextMessages = null;

            if ($userId) {
                // Cách 1: Lấy số lượng giới hạn tin nhắn gần nhất từ TẤT CẢ các session của user này
                $contextMessages = GeminiChatMessage::whereIn('session_id', function ($query) use ($userId) {
                    $query->select('session_id')
                        ->from('gemini_chat_sessions')
                        ->where('user_id', $userId);
                })
                    ->orderBy('created_at', 'desc')
                    ->limit(50) // Giới hạn số lượng tin nhắn để tránh quá tải
                    ->get()
                    ->sortBy('created_at'); // Sắp xếp lại theo thứ tự thời gian tăng dần
            } else {
                // Nếu không có user_id, chỉ lấy tin nhắn từ session hiện tại
                $contextMessages = GeminiChatMessage::where('session_id', $sessionId)
                    ->orderBy('created_at', 'desc')
                    ->limit(50)
                    ->get()
                    ->sortBy('created_at');
            }

            // Format previous messages for context
            $chatHistory = "";
            foreach ($contextMessages as $message) {
                $content = $message->content;
                $senderType = $message->sender_type;

                if ($senderType == 'user') {
                    $chatHistory .= "User: {$content}\n";
                } else {
                    $chatHistory .= "AI: {$content}\n";
                }
            }

            // Thêm phân tích về keyword hiện tại
            $keywordAnalysis = $this->analyzeKeyword($keyword, $userId);

            // Add chat history and keyword analysis to the prompt
            $step1Prompt = "Lịch sử trò chuyện gần đây:\n{$chatHistory}\n\n";
            if ($keywordAnalysis) {
                $step1Prompt .= "Phân tích từ khóa: {$keywordAnalysis}\n\n";
            }
            $step1Prompt .= "Bạn là một chuyên gia hàng đầu trong lĩnh vực chuyên môn, hãy phân tích chi tiết và chính xác về {$keyword} dựa trên thông tin cung cấp, tránh lan man và tập trung vào trọng tâm vấn đề. Vui lòng sử dụng phong cách trang trọng, lịch sự, và không cần kết luận.";
        } else {
            $step1Prompt = "Bạn là một chuyên gia hàng đầu trong lĩnh vực chuyên môn, hãy phân tích chi tiết và chính xác về {$keyword} dựa trên thông tin cung cấp, tránh lan man và tập trung vào trọng tâm vấn đề. Vui lòng sử dụng phong cách trang trọng, lịch sự, và không cần kết luận.";
        }

        $result2 = $this->processWithGemini($step1Prompt);

        // Save this interaction to the database
        if ($sessionId) {
            // Lưu câu trả lời của AI
            GeminiChatMessage::create([
                'session_id' => $sessionId,
                'role' => 'assistant',
                'content' => $result2,
                'sender_type' => 'bot'
            ]);

            // Lưu câu hỏi của người dùng
            GeminiChatMessage::create([
                'session_id' => $sessionId,
                'role' => 'user',
                'content' => $keyword,
                'sender_type' => 'user'
            ]);
        }

        return response()->json(['success' => true, 'data' => $result2]);
    }

    // Phương thức phân tích từ khóa dựa trên lịch sử
    protected function analyzeKeyword($keyword, $userId = null)
    {
        if (!$userId) return null;

        // Tìm các từ khóa tương tự đã được hỏi trước đó
        $similarQueries = GeminiChatMessage::whereIn('session_id', function ($query) use ($userId) {
            $query->select('session_id')
                ->from('gemini_chat_sessions')
                ->where('user_id', $userId);
        })
            ->where('sender_type', 'user')
            ->where('content', 'like', '%' . $keyword . '%')
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();

        if ($similarQueries->count() > 0) {
            $analysis = "Người dùng đã hỏi về chủ đề tương tự trước đây. ";
            $analysis .= "Các câu hỏi liên quan: ";

            foreach ($similarQueries as $query) {
                $analysis .= "\"{$query->content}\", ";
            }

            return rtrim($analysis, ", ");
        }

        return null;
    }



    private function  processWithGemini($query)
    {
        try {
            $apiKey = env('GOOGLE_GEMINI_API_KEY', 'YOUR_API_KEY');
            $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$apiKey}";

            $payload = [
                "contents" => [
                    [
                        "role" => "user",
                        "parts" => [["text" => $query]]
                    ]
                ],
                "generationConfig" => [
                    "temperature" => 1,
                    "topK" => 40,
                    "topP" => 0.95,
                    "maxOutputTokens" => 8192,
                    "responseMimeType" => "text/plain"
                ]
            ];

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payload),
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_TIMEOUT => 30 // Timeout 30 giây
            ]);

            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                throw new \Exception('cURL Error: ' . curl_error($ch));
            }
            curl_close($ch);

            $decodedResponse = json_decode($response, true);
            if (!empty($decodedResponse['candidates'][0]['content']['parts'])) {
                return $decodedResponse['candidates'][0]['content']['parts'][0]['text'] ?? 'Không có phản hồi từ AI';
            }
            throw new \Exception('Quá tải hệ thống. Vui lòng nhập lại. Thông cảm nhé ^^');
        } catch (\Exception $e) {
            Log::error('Gemini API Error: ' . $e->getMessage(), ['query' => $query]);
            return "Lỗi khi gọi AI: " . $e->getMessage();
        }
    }

    /* Danh sách sản phẩm */
    public function listProduct()
    {

        $data['list_supplier'] = Supplier::where('employer_id', Auth::id())->where('status', 1)->orderBy('id', 'desc')->get();

        $supplierCodes = Supplier::where('employer_id', Auth::id())
            ->pluck('sp_code')
            ->toArray();
        $data['count_supplier'] = count($supplierCodes) ?? 0;
        // Lấy danh sách các product_name không trùng

        $data['product_variant'] = ForecastProduct::distinct('product_name')
            ->where('product_variant', '!=', null)
            ->whereIn('supplier_id', $supplierCodes)
            ->orderBy('product_variant')
            ->pluck('product_variant');



        $data['model_version'] = ForecastProduct::distinct('product_name')
            ->where('model_version', '!=', null)
            ->whereIn('supplier_id', $supplierCodes)
            ->orderBy('model_version')
            ->pluck('model_version');



        // Retrieve suppliers associated with the authenticated user
        $supplierCodes = Supplier::where('employer_id', Auth::id())
            ->pluck('sp_code')
            ->toArray();

        $data['allProducts'] = ForecastProduct::whereIn('supplier_id', $supplierCodes)
            ->orderBy('status', 'desc')
            ->orderBy('id', 'desc')
            ->get();

        // Sản phẩm đang hoat động
        $productActive = ForecastProduct::whereIn('supplier_id', $supplierCodes)
            ->orderBy('id', 'desc')
            ->where('status', 1)
            ->get();
        $data['count_active'] = $productActive->count();

        /* Sản phẩm ngừng hoạt động */
        $productNoActive = ForecastProduct::whereIn('supplier_id', $supplierCodes)
            ->orderBy('id', 'desc')
            ->where('status', 0)
            ->get();
        $data['count_noactive'] = $productNoActive->count();
        // Render the view with forecast products
        return view('purchaser.listProduct', compact('productActive', 'data'));
    }


    public function editProduct($id)
    {
        $list_supplier = Supplier::where('status', 1)->orderBy('id', 'desc')->get();
        $forecastProduct  = ForecastProduct::findOrFail($id);
        // Lấy lịch sử chỉnh sửa, sắp xếp từ mới nhất
        $data['productHistories'] = ProductHistory::where('product_id', $forecastProduct->id)
            ->orderBy('changed_at', 'desc')
            ->with('user', 'product')  // Nếu muốn lấy thông tin người dùng
            ->get();
        // Tổng số lần chỉnh sửa
        $data['totalEdits'] = $data['productHistories']->count();
        // Chỉnh sửa gần nhất
        $data['latestEdit'] = $data['productHistories']->first();
        $data['latestEditTime'] = $data['latestEdit'] ? Carbon::parse($data['latestEdit']->changed_at)->diffForHumans() : null;
        return view('purchaser.editProduct', compact('forecastProduct', 'list_supplier', 'data'));
    }


    public function deleteProduct($id)
    {
        ForecastProduct::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Xoá sản phẩm thành công!');
    }

    public function updateProduct(Request $request, $id)
    {
        // Tìm sản phẩm
        $product = ForecastProduct::findOrFail($id);

        // Lưu các giá trị ban đầu
        $oldAttributes = $product->getOriginal();

        // Xử lý upload ảnh (nếu có)
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName();
            $name_image = current(explode('.', $get_name_image));
            $new_image = $name_image . rand(0, 99) . '.' . $get_image->getClientOriginalExtension();
            $get_image->move('public/uploads/forecast_products', $new_image);

            // Cập nhật tên ảnh
            $updateData = $request->all();
            $updateData['image'] = $new_image;
        } else {
            $updateData = $request->all();
        }

        // Cập nhật sản phẩm
        $product->update($updateData);

        // Lấy thuộc tính mới sau khi cập nhật
        $newAttributes = $product->fresh()->getAttributes();

        // Theo dõi thay đổi chi tiết
        $changeRecords = $product->trackDetailedChanges($oldAttributes, $newAttributes);

        // Lưu lịch sử thay đổi
        if (!empty($changeRecords)) {
            ProductHistory::insert($changeRecords);
        }

        return redirect()->back()->with('success', 'Cập nhật sản phẩm thành công!');
    }


    public function getVariantsByCategory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_id' => 'required|exists:categories,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Danh mục không hợp lệ',
                'errors' => $validator->errors()
            ], 422);
        }
        // Get category ID from request
        $categoryId = $request->input('category_id');
        // Query variants that belong to this category
        $variants = ProductVariant::where('category_id', $categoryId)
            ->where('status', 1)
            ->get();

        // Return JSON response
        return response()->json([
            'success' => true,
            'variants' => $variants
        ]);
    }


    public function getModelsByVariant(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'variant_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Phân loại không hợp lệ',
                'errors' => $validator->errors()
            ], 422);
        }

        // Get variant ID from request
        $product_variant_title = $request->input('variant_id');
        $product_variant = ProductVariant::where('title', $product_variant_title)->first();
        $variantId = $product_variant->id;
        // Query model versions that belong to this variant
        $models = ModelVersion::where('product_variant_id', $variantId)
            ->where('status', 1)
            ->get();
        // Return JSON response
        return response()->json([
            'success' => true,
            'models' => $models
        ]);
    }






    public function storeSupplier(Request $request)
    {


        $checkSpCode = Supplier::where('sp_code', $request->sp_code)->first();

        if ($checkSpCode) {
            return response()->json([
                'success' => false,
                'message' => 'Mã nhà cung cấp đã tồn tại. Vui lòng kiểm tra lại!'
            ]);
        }
        // Validate the request
        $validated = $request->validate([
            'company_name' => 'required|string|max:255',
            'sp_code' => 'required|string|max:50|unique:suppliers,sp_code',
            // Add more validation rules as needed
        ]);

        try {
            // Create the supplier
            $supplier = new Supplier();
            $supplier->company_name = $request->company_name;
            $supplier->sp_code = $request->sp_code;
            $supplier->address = $request->address;

            // If you need to generate a unique code automatically
            if (empty($request->sp_code)) {
                $supplier->sp_code = 'SUP' . Str::random(6);
            }
            // Add more fields as needed
            $supplier->save();
            // Return success response
            return response()->json([
                'success' => true,
                'message' => 'Nhà cung cấp đã được thêm thành công',
                'supplier' => $supplier
            ]);
        } catch (\Exception $e) {
            // Return error response
            return response()->json([
                'success' => false,
                'message' => 'Có lỗi xảy ra: ' . $e->getMessage()
            ], 500);
        }
    }


    public function getDetailSupplier(Request $request)
    {
        $supplierCode = $request->input('sp_code');

        if (!$supplierCode) {
            return response()->json([
                'success' => false,
                'message' => 'Mã nhà cung cấp không tồn tại!'
            ]);
        }

        $supplier = Supplier::where('sp_code', $supplierCode)->first();

        if (!$supplier) {
            return response()->json([
                'success' => false,
                'message' => 'Không tìm thấy nhà cung cấp!'
            ]);
        }

        return response()->json([
            'success' => true,
            'supplier' => $supplier
        ]);
    }

    public function folderManager()
    {
        return view('purchaser.folderManager');
    }


    public function listProductVariants(Request $request)
    {
        $data['categories'] = Category::where('parent_id', 0)
            ->orderBy('weight', 'asc')
            ->orderBy('id', 'desc')
            ->get();

        // Lấy dữ liệu từ request
        $category_id = $request->input('category_id');
        $status = $request->input('status');

        // Truy vấn sản phẩm với điều kiện lọc linh hoạt
        $query = ProductVariant::query();

        // Lọc theo category_id nếu có
        $query->when($category_id, function ($q) use ($category_id) {
            return $q->where('category_id', $category_id);
        });

        // Lọc theo status nếu có
        $query->when(!is_null($status), function ($q) use ($status) {
            return $q->where('status', $status);
        });

        // Lấy danh sách sản phẩm sau khi lọc
        $data['listProductVariants'] = $query->orderBy('id', 'desc')->get();

        return view('purchaser.listProductVariants', compact('data'));
    }


    public function createProductVariants()
    {

        $data['categories'] = Category::where('status', 1)->orderBy('weight', 'asc')->orderBy('id', 'desc')->get();
        return view('purchaser.addProductVariants', compact('data'));
    }

    public function saveProductVariants(Request $request)
    {
        ProductVariant::create($request->all());
        return redirect()->back()->with('success', 'Thêm mới thành công');
    }

    public function deleteProductVariants($id)
    {
        ProductVariant::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Xoá thành công');
    }
    public function editProductVariants($id)
    {
        $data['categories'] = Category::where('status', 1)->orderBy('weight', 'asc')->orderBy('id', 'desc')->get();
        $variant = ProductVariant::find($id);
        return view('purchaser.editProductVariants', compact('variant', 'data'));
    }

    public function updateProductVariants(Request $request, $id)
    {


        // Validate dữ liệu đầu vào
        $validatedData = $request->validate([
            'title'       => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'status'      => 'required|in:0,1',
        ]);

        // Tìm bản ghi cần cập nhật, nếu không tồn tại sẽ trả về lỗi 404
        $variant = ProductVariant::findOrFail($id);
        // Cập nhật dữ liệu
        $variant->update(
            [
                'title' => $request->title,
                'category_id' => $request->category_id,
                'status' => $request->status,
                'description' => $request->description,
            ]
        );
        // Chuyển hướng về trang danh sách với thông báo thành công
        return redirect()->back()
            ->with('success', 'Cập nhật thông tin thành công.');
    }


    public function listModelVersion()
    {
        // Lấy danh sách model versions có liên kết với productVariant (nếu có) và phân trang
        $modelVersions = ModelVersion::orderBy('id', 'desc')->get();
        return view('purchaser.listModelVersion', compact('modelVersions'));
    }

    /**
     * Hiển thị form tạo mới model version.
     */
    public function createModelVersion()
    {
        // Lấy danh sách product variants để hiển thị trong select (nếu cần)
        $productVariants = ProductVariant::where('status', 1)->orderBy('id', 'desc')->get();
        return view('purchaser.addModelVersion', compact('productVariants'));
    }

    /**
     * Lưu dữ liệu tạo mới model version.
     */
    public function saveModelVersion(Request $request)
    {
        // Validate dữ liệu đầu vào
        $request->validate([
            'title'      => 'required|string|max:255',
            'status'      => 'required',
            'product_variant_id' => 'required|exists:product_variants,id',
        ]);

        // Tạo mới model version
        ModelVersion::create($request->all());

        // Chuyển hướng với thông báo thành công
        return redirect()->back()
            ->with('success', 'Thêm mới phiên bản cho sản phẩm thành công.');
    }

    /**
     * Hiển thị form chỉnh sửa model version.
     *
     * @param int $id
     */
    public function editModelVersion($id)
    {
        $modelVersion = ModelVersion::findOrFail($id);
        $productVariants = ProductVariant::where('status', 1)->orderBy('id', 'desc')->get();
        return view('purchaser.editModelVersion', compact('modelVersion', 'productVariants'));
    }

    /**
     * Cập nhật dữ liệu model version.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     */
    public function updateModelVersion(Request $request, $id)
    {
        // Validate dữ liệu đầu vào
        $validatedData = $request->validate([
            'title'      => 'required|string|max:255',
            'product_variant_id' => 'required|exists:product_variants,id',
        ]);

        $modelVersion = ModelVersion::findOrFail($id);
        $modelVersion->update(
            [
                'title' => $request->title,
                'product_variant_id' => $request->product_variant_id,
                'status' => $request->status,
                'description' => $request->description,
            ]
        );

        // Chuyển hướng với thông báo thành công
        return redirect()->back()
            ->with('success', 'Cập nhật phiên bản cho sản phẩm thành công.');
    }
    /**
     * Xóa model version.
     *
     * @param int $id
     */
    public function deleteModelVersion($id)
    {
        $modelVersion = ModelVersion::findOrFail($id);
        $modelVersion->delete();
        // Chuyển hướng với thông báo thành công
        return redirect()->back()
            ->with('success', 'Xoá phiên bản cho sản phẩm thành công.');
    }
}
