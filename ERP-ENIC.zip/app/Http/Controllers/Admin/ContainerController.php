<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Container;
use App\Models\Shipment;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ContainerController extends Controller
{
    //


    public function index()
    {
        $containers = Container::get();
        return view('containers.index', compact('containers'));
    }

    // Hiển thị form tạo Container mới
    public function create()
    {
        $shipments = Shipment::get();
        return view('containers.create', compact('shipments'));
    }

    // Xử lý lưu Container mới
    public function store(Request $request)
    {
        // Validate dữ liệu nhập vào
        $validated = $request->validate([
            'container_number' => 'required|unique:containers,container_number',
            'type'             => 'required|in:20ft,40ft,Reefer,Open Top,Flat Rack',
            'status'           => 'required|in:Đang sử dụng,Rỗng,Bị hỏng',
            'seal_number'      => 'nullable|string|max:255',
            'location'         => 'nullable|string|max:255',
            'weight'           => 'nullable|numeric',
            'dimensions'       => 'nullable|string|max:255',
            'shipment_id'      => 'nullable|exists:shipments,id',
        ]);

        try {
            // Tạo mới Container với dữ liệu đã được validate
            Container::create($validated);
            return redirect()->back()->with('success', 'Container đã được tạo thành công.');
        } catch (Exception $e) {
            Log::error('Error in ContainerController@store: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Có lỗi xảy ra khi tạo Container. Vui lòng thử lại.');
        }
    }

    // Hiển thị chi tiết Container
    public function show($id)
    {
        $container = Container::findOrFail($id);
        return view('containers.show', compact('container'));
    }

    // Hiển thị form chỉnh sửa Container
    public function edit($id)
    {
        $shipments = Shipment::get();
        $container = Container::findOrFail($id);
        return view('containers.edit', compact('container','shipments'));
    }

    // Xử lý cập nhật Container
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'container_number' => 'required|unique:containers,container_number,' . $id,
            'type'             => 'required|in:20ft,40ft,Reefer,Open Top,Flat Rack',
            'status'           => 'required|in:Đang sử dụng,Rỗng,Bị hỏng',
            'seal_number'      => 'nullable|string|max:255',
            'location'         => 'nullable|string|max:255',
            'weight'           => 'nullable|numeric',
            'dimensions'       => 'nullable|string|max:255',
            'shipment_id'      => 'nullable|exists:shipments,id',
        ]);

        try {
            Container::where('id', $id)->update($validated);
            return redirect()->back()->with('success', 'Container đã được cập nhật thành công.');
        } catch (Exception $e) {
            Log::error('Error in ContainerController@update: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Có lỗi xảy ra khi cập nhật Container. Vui lòng thử lại.');
        }
    }

    // Xóa Container
    public function delete($id)
    {
        try {
            Container::destroy($id);
            return redirect()->back()->with('success', 'Container đã được xóa thành công.');
        } catch (Exception $e) {
            Log::error('Error in ContainerController@destroy: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Có lỗi xảy ra khi xóa Container. Vui lòng thử lại.');
        }
    }
}
