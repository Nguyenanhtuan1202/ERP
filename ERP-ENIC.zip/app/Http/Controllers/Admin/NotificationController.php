<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    //


    // Hiển thị danh sách thông báo cho người dùng hiện tại
    public function index()
    {
        $user = Auth::user();
        $notifications = Notification::where('user_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->get();
        return view('notifications.index', compact('notifications'));
    }

    // Đánh dấu thông báo đã đọc
    public function markAsRead(Request $request, $id)
    {
        $notification = Notification::findOrFail($id);
        // (Nếu cần, kiểm tra thông báo thuộc về người dùng hiện tại)
        $notification->update(['is_read' => true]);
        return response()->json(['success' => true, 'message' => 'Thông báo đã được đánh dấu là đã đọc']);
    }

    // Xóa thông báo
    public function destroy(Request $request, $id)
    {
        $notification = Notification::findOrFail($id);
        $notification->delete();
        return response()->json(['success' => true, 'message' => 'Thông báo đã được xóa']);
    }
}
