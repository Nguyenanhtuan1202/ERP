<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class RoleController extends Controller
{



    public function __construct(Role $role, Permission $permission)
    {
        $this->role = $role;
        $this->permission = $permission;
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'role']);
            return $next($request);
        });
    }

    public function add()
    {
        $permissionParent = $this->permission->where('parent_id', 0)->get();
        return view('backend.role.add', compact('permissionParent'));
    }

    public function list()
    {
        $role = $this->role->paginate(10);

        return view('backend.role.list', compact('role'));
    }

    public function save(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'display_name' => 'required|string|max:255',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'name' => 'Tên vai trò',
                'display_name' => 'Mô tả vai trò',
            ]
        );;


        $role = $this->role->create(
            [
                'name' => $request->name,
                'display_name' => $request->display_name
            ]
        );
        $permission = $request->permission_id;
        $role->permission()->attach($permission);
        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'create', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Thêm vai trò ' . $request->display_name . ' thành công.'
        ]);
        return redirect()->back()->with('status', 'Thêm vai trò thành công');
    }

    public function edit($id)
    {
        $permissionParent = $this->permission->where('parent_id', 0)->get();
        $role = Role::find($id);
        $permissionChecked = $role->permission;
        return view('backend.role.edit', compact("role", 'permissionParent', 'permissionChecked'));
    }


    public function update(Request $request, $id)
    {
        $role = $this->role->find($id)->update(
            [
                'name' => $request->name,
                'display_name' => $request->display_name
            ]
        );
        $role = $this->role->find($id);
        $role->permission()->sync($request->permission_id);

        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'update', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Cập nhật vai trò ' . $request->display_name . 'thành công.'
        ]);

        return redirect()->back()->with('status', 'Cập nhật vai trò thành công');
    }

    public function delete($id)
    {
        Role::where('id', $id)->delete();

        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'delete', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Xoá vai trò thành công.'
        ]);

        return redirect()->back()->with('status', 'Xóa vai trò thành công');
    }
}
