<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Components\MenuRecusive;
use App\Models\Category;
use App\Models\Menu;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;

class MenuController extends Controller
{
    //

    public $menu;

    public function __construct(MenuRecusive $menu)
    {

        $this->middleware(function ($request, $next) {
            session(['module_active' => 'menu']);
            return $next($request);
        });



        $this->menu = $menu;
    }

    public function index(Request $request)
    {
        $id = $request->id;
        $status = $request->status;

        $success =   Menu::where('id', $id)->update(
            [
                'status' => $status
            ]
        );
        if ($success) {
            return Redirect::back()->with('status', 'Cập Nhật Trạng Thái Thành Công');
        }

        $data = Menu::orderBy('weight', 'asc')->orderBy('id', 'asc')->get();
        return view('backend.menus.index', compact('data'));
    }

    public function create()
    {
        $optionSelect = $this->menu->menuRecusiveAdd();
        return view('backend.menus.create', compact('optionSelect'));
    }
    public function edit($id)
    {
        $data = Menu::find($id);
        $optionSelect = $this->menu->menuRecusiveEdit($data->parent_id);
        return view('backend.menus.edit', compact('optionSelect', 'data'));
    }


    public function save(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'url' => 'required|string|max:255',
                'meta_seo' => 'required|string|max:255',
                'desc_seo' => 'required|string|max:255',
                'key_seo' => 'required|string|max:255',
                'weight' => 'required',
                'parent_id' => 'required',
                'status' => 'required|not_in:0',
                'image' => 'required|',
              
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống',
            ],
            [
                'name' => 'Tên Menu',
                'url' => 'Đường Link',
                'meta_seo' => 'Tiêu đề seo',
                'desc_seo' => 'Mô tả seo',
                'key_seo' => 'Từ khóa seo',
                'weight' => 'Thứ tự',
                'status' => 'Trạng thái',
                'parent_id' => 'Danh mục cha',
                'image' => 'Hình Ảnh',
               

            ]
        );

        /* Hình ảnh */
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = $name_image . '-' . rand(0, 99999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/menu', $new_image);
        }


        Menu::create(
            [
                'name' => $request->name,
                'alias' => Str::slug($request->name),
                'url' => $request->url,
                'meta_seo' => $request->meta_seo,
                'desc_seo' => $request->desc_seo,
                'key_seo' => $request->key_seo,
                'parent_id' => $request->parent_id,
                'weight' => $request->weight,
                'status' => $request->status,
                'image' => $new_image,
            ]
        );

        return redirect()->back()->with('status', 'Thêm thành công');
    }

    public function update($id, Request $request)

    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'url' => 'required|string|max:255',
                'meta_seo' => 'required|string|max:255',
                'desc_seo' => 'required|string|max:255',
                'key_seo' => 'required|string|max:255',
                'weight' => 'required',
                'parent_id' => 'required',
                'status' => 'required|not_in:0',

            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống'
            ],
            [
                'name' => 'Tên Menu',
                'url' => 'Đường Link',
                'meta_seo' => 'Tiêu đề seo',
                'desc_seo' => 'Mô tả seo',
                'key_seo' => 'Từ khóa seo',
                'weight' => 'Thứ tự',
                'status' => 'Trạng thái',
                'parent_id' => 'Danh mục cha',
            ]
        );


        if ($request->hasFile('image')) {

            // Xoá Tấm Hình Cũ Trước Khi Up tấm hình mới
            // $deleteOldImage = Menu::find($id);
            // unlink('public/uploads/menu/' . $deleteOldImage->image);

            if ($request->hasFile('image')) {
                $get_image = $request->file('image');
                $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
                $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
                $new_image = $name_image . '-' . rand(0, 99999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
                $get_image->move('public/uploads/menu', $new_image);
            }

            Menu::where('id', $id)->update(
                [
                    'name' => $request->name,
                    'alias' => Str::slug($request->name),
                    'url' => $request->url,
                    'meta_seo' => $request->meta_seo,
                    'desc_seo' => $request->desc_seo,
                    'key_seo' => $request->key_seo,
                    'parent_id' => $request->parent_id,
                    'weight' => $request->weight,
                    'status' => $request->status,
                    'image' => $new_image,
                ]
            );
        } else {
            Menu::where('id', $id)->update(
                [
                    'name' => $request->name,
                    'alias' => Str::slug($request->name),
                    'url' => $request->url,
                    'meta_seo' => $request->meta_seo,
                    'desc_seo' => $request->desc_seo,
                    'key_seo' => $request->key_seo,
                    'parent_id' => $request->parent_id,
                    'weight' => $request->weight,
                    'status' => $request->status,
                ]
            );
        }
        return redirect()->back()->with('status', 'Cập nhật thành công');
    }
    public function delete($id)
    {
        // Xoá Tấm Hình Cũ Trước Khi Up tấm hình mới
        $deleteOldImage = Menu::find($id);
        //  unlink('public/uploads/menu/' . $deleteOldImage->image);
        $deleteOldImage->delete();
        return redirect()->back()->with('status', 'Xoá menu thành công');
    }
}
