<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Note;
use Revolution\Google\Sheets\Facades\Sheets;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class NoteController extends Controller
{
    public function index()
    {
        $notes = Note::where('user_id', Auth::id())->orderBy('created_at', 'desc')->get();
        return view('notes.index', compact('notes'));
    }

    public function create()
    {
        return view('notes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'content'      => 'nullable|string|max:50000',
            'image'        => 'nullable|array',
            'image.*'      => 'required_with:image|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'video'        => 'nullable|array',
            'video.*'      => 'required_with:video|file|mimetypes:video/mp4,video/avi,video/mpeg,video/quicktime|max:10240',
            'audio_data'   => 'nullable|string',
            'drawing_data' => 'nullable|string',
        ], [
            'content.max'           => 'Nội dung ghi chú không được vượt quá :max ký tự.',
            'image.*.required_with' => 'Vui lòng chọn ảnh nếu trường ảnh được kích hoạt.',
            'image.*.image'         => 'Mỗi file ảnh phải là định dạng ảnh hợp lệ.',
            'image.*.mimes'         => 'Định dạng ảnh phải là jpeg, png, jpg, gif, hoặc svg.',
            'image.*.max'           => 'Kích thước mỗi ảnh không được vượt quá 2MB.',
            'video.*.required_with' => 'Vui lòng chọn video nếu trường video được kích hoạt.',
            'video.*.file'         => 'Mỗi file video phải là một tệp hợp lệ.',
            'video.*.mimetypes'    => 'Định dạng video phải là mp4, avi, mpeg, hoặc quicktime.',
            'video.*.max'          => 'Kích thước mỗi video không được vượt quá 10MB.',
        ]);

        // Khởi tạo mảng lưu tên file ảnh và video
        $images = [];
        $videos = [];

        // Xử lý upload nhiều ảnh
        if ($request->hasFile('image')) {
            foreach ($request->file('image') as $imageFile) {
                // Kiểm tra kích thước ảnh (2MB = 2 * 1024 * 1024 = 2097152 bytes)
                if ($imageFile->getSize() > 5097152) {
                    return redirect()->back()
                        ->with('error', 'Kích thước mỗi ảnh không vượt quá 5MB');
                } else {
                    $originalName = $imageFile->getClientOriginalName(); // Lấy tên gốc của ảnh
                    $namePart = pathinfo($originalName, PATHINFO_FILENAME); // Lấy phần tên trước dấu chấm
                    // Tạo tên file mới sử dụng thời gian và uniqid để đảm bảo tính duy nhất
                    $newImageName = $namePart . '_' . time() . '_' . uniqid() . '.' . $imageFile->getClientOriginalExtension();
                    // Di chuyển file vào thư mục: public/uploads/note
                    $imageFile->move(public_path('uploads/note'), $newImageName);
                    $images[] = $newImageName;
                }
            }
        }

        // Xử lý upload nhiều video
        if ($request->hasFile('video')) {
            foreach ($request->file('video') as $videoFile) {
                // Kiểm tra kích thước video (10MB = 10 * 1024 * 1024 = 10485760 bytes)
                if ($videoFile->getSize() > 10485760) {
                    return redirect()->back()
                        ->with('error', 'Kích thước mỗi video không vượt quá 10MB');
                } else {
                    $originalName = $videoFile->getClientOriginalName(); // Lấy tên gốc của video
                    $namePart = pathinfo($originalName, PATHINFO_FILENAME); // Lấy phần tên trước dấu chấm
                    $newVideoName = $namePart . '_' . time() . '_' . uniqid() . '.' . $videoFile->getClientOriginalExtension();
                    // Di chuyển file vào thư mục: public/uploads/note (có thể dùng thư mục riêng nếu muốn, ví dụ: uploads/note/videos)
                    $videoFile->move(public_path('uploads/note'), $newVideoName);
                    $videos[] = $newVideoName;
                }
            }
        }

        // Tạo bản ghi Note mới
        $note = new Note();
        $note->user_id = auth()->id();
        $note->content = $request->input('content');
        // Lưu mảng ảnh, video dưới dạng JSON
        $note->images = !empty($images) ? json_encode($images) : null;
        $note->videos = !empty($videos) ? json_encode($videos) : null;
        $note->audio = $request->input('audio_data');    // Lưu URL hoặc chuỗi base64 của audio
        $note->drawing = $request->input('drawing_data');  // Lưu chuỗi base64 của bản vẽ
        $note->save();

        return redirect()->back()->with('success', 'Ghi chú đã được tạo!');
    }


    public function edit($id)
    {
        $note = Note::find($id);
        return view('notes.edit', compact('note'));
    }

    public function update(Request $request, $id)
    {
        $note = Note::find($id);
        // Validate dữ liệu từ form update
        $request->validate([
            'content'      => 'nullable|string|max:10000',
            'image'        => 'nullable|array',
            'image.*'      => 'required_with:image|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'video'        => 'nullable|array',
            'video.*'      => 'required_with:video|file|mimetypes:video/mp4,video/avi,video/mpeg,video/quicktime|max:10240',
            'audio_data'   => 'nullable|string',
            'drawing_data' => 'nullable|string',
        ], [
            'content.max'           => 'Nội dung ghi chú không được vượt quá :max ký tự.',
            'image.*.required_with' => 'Vui lòng chọn ảnh nếu trường ảnh được kích hoạt.',
            'image.*.image'         => 'Mỗi file ảnh phải là định dạng ảnh hợp lệ.',
            'image.*.mimes'         => 'Định dạng ảnh phải là jpeg, png, jpg, gif, hoặc svg.',
            'image.*.max'           => 'Kích thước mỗi ảnh không được vượt quá 2MB.',
            'video.*.required_with' => 'Vui lòng chọn video nếu trường video được kích hoạt.',
            'video.*.file'         => 'Mỗi file video phải là một tệp hợp lệ.',
            'video.*.mimetypes'    => 'Định dạng video phải là mp4, avi, mpeg, hoặc quicktime.',
            'video.*.max'          => 'Kích thước mỗi video không được vượt quá 10MB.',
        ]);

        // Xử lý ảnh:
        // Nếu có upload ảnh mới, thay thế ảnh cũ (nếu có)
        if ($request->hasFile('image')) {
            // Xoá ảnh cũ nếu tồn tại
            if ($note->images) {
                $existingImages = json_decode($note->images, true);
                foreach ($existingImages as $existingImage) {
                    $oldPath = public_path('uploads/note/' . $existingImage);
                    if (file_exists($oldPath)) {
                        unlink($oldPath);
                    }
                }
            }
            $images = [];
            foreach ($request->file('image') as $imageFile) {
                if ($imageFile->getSize() > 5000000) { // 5MB
                    return redirect()->back()
                        ->with('error', 'Kích thước mỗi ảnh không vượt quá 5MB');
                } else {
                    $originalName = $imageFile->getClientOriginalName();
                    $namePart = pathinfo($originalName, PATHINFO_FILENAME);
                    $newImageName = $namePart . '_' . time() . '_' . uniqid() . '.' . $imageFile->getClientOriginalExtension();
                    $imageFile->move(public_path('uploads/note'), $newImageName);
                    $images[] = $newImageName;
                }
            }
            $note->images = !empty($images) ? json_encode($images) : null;
        }

        // Xử lý video:
        // Nếu có upload video mới, thay thế video cũ (nếu có)
        if ($request->hasFile('video')) {
            if ($note->videos) {
                $existingVideos = json_decode($note->videos, true);
                foreach ($existingVideos as $existingVideo) {
                    $oldPath = public_path('uploads/note/' . $existingVideo);
                    if (file_exists($oldPath)) {
                        unlink($oldPath);
                    }
                }
            }
            $videos = [];
            foreach ($request->file('video') as $videoFile) {
                if ($videoFile->getSize() > 10485760) { // 10MB
                    return redirect()->back()
                        ->with('error', 'Kích thước mỗi video không vượt quá 10MB');
                } else {
                    $originalName = $videoFile->getClientOriginalName();
                    $namePart = pathinfo($originalName, PATHINFO_FILENAME);
                    $newVideoName = $namePart . '_' . time() . '_' . uniqid() . '.' . $videoFile->getClientOriginalExtension();
                    $videoFile->move(public_path('uploads/note'), $newVideoName);
                    $videos[] = $newVideoName;
                }
            }
            $note->videos = !empty($videos) ? json_encode($videos) : null;
        }

        // Cập nhật các trường khác
        $note->content = $request->input('content');
        // Nếu có audio_data mới, cập nhật; nếu không, giữ nguyên
        $note->audio = $request->input('audio_data') ?? $note->audio;
        // Nếu có drawing_data mới, cập nhật; nếu không, giữ nguyên
        $note->drawing = $request->input('drawing_data') ?? $note->drawing;

        $note->save();

        return redirect()->back()->with('success', 'Ghi chú đã được cập nhật thành công!');
    }



    public function delete($id)
    {
        $note = Note::find($id);
        // Xoá file ảnh (nếu có)
        if ($note->images) {
            $images = json_decode($note->images, true);
            foreach ($images as $image) {
                $imagePath = public_path('uploads/note/' . $image);
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }
        }
        // Xoá file video (nếu có)
        if ($note->videos) {
            $videos = json_decode($note->videos, true);
            foreach ($videos as $video) {
                $videoPath = public_path('uploads/note/' . $video);
                if (file_exists($videoPath)) {
                    unlink($videoPath);
                }
            }
        }

        // Xoá file audio (nếu lưu dưới dạng file, nếu audio_data là URL tương đối)
        if ($note->audio) {
            $audioPath = public_path($note->audio);
            if (file_exists($audioPath)) {
                unlink($audioPath);
            }
        }

        // Xoá file bản vẽ (nếu lưu dưới dạng file; nếu là chuỗi base64 thì không cần xoá file)
        if ($note->drawing) {
            $drawingPath = public_path($note->drawing);
            if (file_exists($drawingPath)) {
                unlink($drawingPath);
            }
        }
        // Xoá bản ghi ghi chú khỏi cơ sở dữ liệu
        $note->delete();

        return redirect()->back()->with('success', 'Ghi chú đã được xóa thành công!');
    }


    public function googlesheet()
    {

        $data = Sheets::spreadsheet('1uqcTlB_RWfdEXTus1xU3WCS9do693KYA4da24fMx6EI')->sheet('Test')->get();
        $header = $data->pull(0);
        $values = Sheets::collection($header, $data);
        $values->toArray();

        dd($values);
    }
}
