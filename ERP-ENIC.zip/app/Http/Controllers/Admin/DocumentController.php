<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Document;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    //

    public function index()
    {
        $documents = Document::paginate(10);
        return view('documents.index', compact('documents'));
    }

    public function create()
    {
        return view('documents.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'shipment_id'   => 'required|exists:shipments,id',
            'document_type' => 'required|in:B/L,Packing List,Invoice,Certificate of Origin,Other',
            'file_path'     => 'required|string', // Trường hợp này cần xử lý upload file riêng
            'description'   => 'nullable|string',
            'uploaded_at'   => 'nullable|date',
        ]);

        Document::create($validated);
        return redirect()->route('documents.index')->with('success', 'Chứng từ đã được tải lên thành công.');
    }

    public function show(Document $document)
    {
        return view('documents.show', compact('document'));
    }

    public function edit(Document $document)
    {
        return view('documents.edit', compact('document'));
    }

    public function update(Request $request, Document $document)
    {
        $validated = $request->validate([
            'shipment_id'   => 'required|exists:shipments,id',
            'document_type' => 'required|in:B/L,Packing List,Invoice,Certificate of Origin,Other',
            'file_path'     => 'required|string',
            'description'   => 'nullable|string',
            'uploaded_at'   => 'nullable|date',
        ]);

        $document->update($validated);
        return redirect()->route('documents.index')->with('success', 'Chứng từ đã được cập nhật.');
    }

    public function destroy(Document $document)
    {
        $document->delete();
        return redirect()->route('documents.index')->with('success', 'Chứng từ đã được xóa.');
    }
}
