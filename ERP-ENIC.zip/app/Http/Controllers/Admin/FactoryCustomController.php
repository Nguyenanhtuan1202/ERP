<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FactoryCustomController extends Controller
{
    //



    public function add()
    {
        return view('factorycustom.add');
    }
}
