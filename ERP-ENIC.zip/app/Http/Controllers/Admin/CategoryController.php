<?php

namespace App\Http\Controllers\Admin;

use App\Exports\CategoryExport;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

use App\Components\Recusive;
use App\Imports\CategoryImport;
use App\Models\Category_Setting;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;

use Maatwebsite\Excel\Facades\Excel as FacadesExcel;

class CategoryController extends Controller
{
    private $category;
    public function __construct(Category $category)
    {
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'category']);
            return $next($request);
        });
        $this->category = $category;
    }
    public function add()
    {
        $htmlOption = $this->getCategory($parentId = "");
        return view('backend.category.add', compact('htmlOption'));
    }

    public function getCategory($parentId)
    {
        $data = $this->category->all();
        $recusive = new Recusive($data);
        $htmlOption =   $recusive->categoryRecusive($parentId);
        return $htmlOption;
    }

    public function categoryList(Request $request)
    {
        $id = $request->id;
        $status = $request->status;
        $success =   Category::where('id', $id)->update(
            [
                'status' => $status
            ]
        );
        if ($success) {
            return redirect()->back()->with('success', 'Cập Nhật Trạng Thái Thành Công');
        }


        $listCategory = Category::with('catChild')->where('parent_id', 0)->orderBy('weight', 'asc')->orderBy('id', 'desc')->get();

        return view('backend.category.list', compact('listCategory'));
    }

    public function save(Request $request)
    {
        $request->validate(
            [
                'title' => 'required|string|max:255',
                'status' => 'required|not_in:0',
                'parent_id' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống'
            ],
            [
                'title' => 'Tên danh mục',
                'status' => 'Trạng thái hiển thị',
                'parent_id' => 'Danh mục cha',
            ]
        );

        /* Hình ảnh */
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = 'enic-loai-san-pham-' . $name_image . '-' . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/category', $new_image);
        }

        $latestCategory = Category::orderBy('id', 'desc')->first();

        // Lấy SKU mới từ SKU mới nhất trong database
        $newSku = 'DMSP'; // Default SKU if no categories exist yet

        if ($latestCategory && !empty($latestCategory->sku)) {
            // Extract the prefix (letters) and the number part with leading zeros
            if (preg_match('/([A-Za-z]+)(\d+)/', $latestCategory->sku, $matches)) {
                $prefix = $matches[1];
                $numberPart = $matches[2];
                $lastSkuNumber = intval($numberPart);

                // Format the new number with the same number of digits as the original
                $newNumber = $lastSkuNumber + 1;
                $newNumberFormatted = str_pad($newNumber, strlen($numberPart), '0', STR_PAD_LEFT);

                $newSku = $prefix . $newNumberFormatted;
            } else {
                // If SKU doesn't match expected pattern, just use it as prefix and add 001
                $newSku = $latestCategory->sku . '001';
            }
        }
        Category::create([
            'title' => $request->title,
            'content' => $request->content ?? "",
            'weight' => $request->weight ?? 0,
            'status' => $request->status,
            'image' => $new_image,
            'parent_id' => $request->parent_id,
            'sku' => $newSku // Add the new SKU to the creation array
        ]);

        return redirect()->back()->with('success', 'Thêm Danh mục sản phẩm thành công !');
    }


    public function edit(Request $request, $id)
    {
        $category = Category::find($id);
        $htmlOption =   $this->getCategory($category->parent_id);
        return view('backend.category.edit', compact('category', 'htmlOption'));
    }
    public function delete($id)
    {
        Category::where('id', $id)->delete();
        return redirect()->back()->with('status', 'Xóa Danh mục thành công');
    }

    public function update(Request $request, $id)
    {

        $request->validate(
            [
                'title' => 'required|string|max:255',
                'status' => 'required|not_in:0',
                'parent_id' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống'
            ],
            [
                'title' => 'Tên danh mục',
                'status' => 'Trạng thái hiển thị',
                'parent_id' => 'Danh mục cha',
            ]
        );


        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = $name_image . '-' . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/category', $new_image);

            Category::where('id', $id)->update(
                [
                    'title' => $request->title,
                    'content' => $request->content ?? "",
                    'weight' => $request->weight  ?? 0,
                    'status' => $request->status,
                    'image' => $new_image,
                    'sku' => $request->sku ?? "",
                    'parent_id' => $request->parent_id
                ]
            );
        } else {
            Category::where('id', $id)->update(
                [
                    'title' => $request->title,
                    'content' => $request->content ?? "",
                    'weight' => $request->weight  ?? 0,
                    'status' => $request->status,
                    'sku' => $request->sku ?? "",
                    'parent_id' => $request->parent_id
                ]
            );
        }

        return redirect()->back()->with('success', 'Cập nhật danh mục sản phẩm thành công');
    }


    public function importExcel()
    {
        $data = Category::whereBetween('created_at', [
            Carbon::now()->subWeek(), // Ngày cách đây 1 tuần
            Carbon::now()             // Ngày hiện tại
        ])->orderBy('created_at', 'desc')->get();

        return view('backend.category.viewImportExcel', compact('data'));
    }

    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new CategoryImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON
            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }


    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0; // Biến đếm số lượng bản ghi mới được thêm
        $existingRecordsCount = 0; // Biến đếm số lượng bản ghi đã tồn tại

        try {
            foreach ($data as $row) {
                // Kiểm tra nếu SKU đã tồn tại trong cơ sở dữ liệu
                $existingProduct = Category::where('sku', $row['sku'])->first();
                if ($existingProduct) {
                    // SKU đã tồn tại, tăng biến đếm
                    $existingRecordsCount++;
                    continue;
                }
                // Nếu không tồn tại, tạo sản phẩm mới
                $dataDetail = new Category();
                $dataDetail->title = $row['title'];
                $dataDetail->sku = $row['sku'];
                $dataDetail->parent_id = $row['parent_id'];
                $dataDetail->status = $row['status'];
                $dataDetail->weight = $row['weight'];
                $dataDetail->save(); // Lưu dữ liệu vào cơ sở dữ liệu

                $newRecordsCount++; // Tăng biến đếm cho bản ghi mới
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công $newRecordsCount bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại trong cơ sở dữ liệu. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', 'Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!');
            }
        } catch (\Exception $e) {
            return back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }



    public function export()
    {
        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây
        $fileName = "Danh-sach-loai-san-pham-{$currentDate}.xlsx"; // Tạo tên file
        return FacadesExcel::download(new CategoryExport, $fileName);
    }
}
