<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Partner;
use App\Models\Shipment;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ShipmentController extends Controller
{
    //

    public function index()
    {
        $shipments = Shipment::get();
        return view('shipments.index', compact('shipments'));
    }

    public function create()
    {
        $partners = Partner::where('active', 1)->get();
        // Nếu cần, tải danh sách đối tác, container, v.v.
        return view('shipments.create', compact('partners'));
    }

    public function store(Request $request)
    {
        // Validate các trường dữ liệu
        $validated = $request->validate([
            'tracking_number'    => 'required|unique:shipments,tracking_number',
            'customer_id'        => 'required|exists:partners,id',
            'origin_port'        => 'required|string|max:255',
            'destination_port'   => 'required|string|max:255',
            'vessel_name'        => 'nullable|string|max:255',
            'voyage_number'      => 'nullable|string|max:255',
            'departure_date'     => 'nullable|date',
            'estimated_arrival'  => 'nullable|date',
            'actual_arrival'     => 'nullable|date',
            'status'             => 'required|in:Đang xử lý,Đang vận chuyển,Đã đến cảng,Thông quan,Giao hàng thành công',
            'shipment_type'      => 'required|in:FCL,LCL',
            'cargo_description'  => 'nullable|string',
            'total_weight'       => 'nullable|numeric',
            'total_volume'       => 'nullable|numeric',
        ]);

        try {
            // Tạo mới lô hàng với dữ liệu đã được validate
            Shipment::create($validated);
            return redirect()->back()->with('success', 'Lô hàng đã được tạo thành công.');
        } catch (Exception $e) {
            // Ghi log lỗi và chuyển hướng ngược lại với thông báo lỗi
            Log::error("Error in ShipmentController@store: " . $e->getMessage());
            return redirect()->back()->with('error', 'Có lỗi xảy ra trong quá trình tạo lô hàng. Vui lòng thử lại.');
        }
    }

    public function show($id)
    {
        $shipment = Shipment::findOrFail($id);
        return view('shipments.show', compact('shipment'));
    }

    public function edit($id)
    {
        $shipment = Shipment::findOrFail($id);
        $customers = Partner::where('role', 'customer')->get();
        return view('shipments.edit', compact('shipment', 'customers'));
    }

    // Xử lý cập nhật lô hàng
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'tracking_number'    => 'required|unique:shipments,tracking_number,' . $id,
            'customer_id'        => 'required|exists:partners,id',
            'origin_port'        => 'required|string|max:255',
            'destination_port'   => 'required|string|max:255',
            'vessel_name'        => 'nullable|string|max:255',
            'voyage_number'      => 'nullable|string|max:255',
            'departure_date'     => 'nullable|date',
            'estimated_arrival'  => 'nullable|date',
            'actual_arrival'     => 'nullable|date',
            'status'             => 'required|in:Đang xử lý,Đang vận chuyển,Đã đến cảng,Thông quan,Giao hàng thành công',
            'shipment_type'      => 'required|in:FCL,LCL',
            'cargo_description'  => 'nullable|string',
            'total_weight'       => 'nullable|numeric',
            'total_volume'       => 'nullable|numeric',
        ]);

        try {
            // Cập nhật lô hàng dựa trên id
            Shipment::where('id', $id)->update($validated);
            return redirect()->back()->with('success', 'Lô hàng đã được cập nhật thành công.');
        } catch (Exception $e) {
            Log::error("Error in ShipmentController@update: " . $e->getMessage());
            return redirect()->back()->with('error', 'Có lỗi xảy ra trong quá trình cập nhật. Vui lòng thử lại.');
        }
    }

    public function delete($id)
    {
        Shipment::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Lô hàng đã được xóa.');
    }
}
