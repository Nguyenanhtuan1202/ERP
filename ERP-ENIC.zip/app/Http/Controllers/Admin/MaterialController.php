<?php

namespace App\Http\Controllers\Admin;

use App\Exports\MaterialExport;
use App\Exports\MaterialsForProductsExport;
use App\Http\Controllers\Controller;
use App\Imports\MaterialImport;
use App\Models\Material;
use App\Models\MaterialsForProducts;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

use App\Events\NotifyProcessed;
use App\Imports\MaterialsForProductImport;
use App\Models\Material_Category;
use Maatwebsite\Excel\Facades\Excel as FacadesExcel;

class MaterialController extends Controller
{
    //

    public function index()
    {

        $material_list = Material::orderBy('material_categories_id', 'asc')->get();


        return view('material.index', compact('material_list'));
    }
    public function add(Request $request)
    {


        $data['group_tiers'] = Product::select('tier_code', 'tier', DB::raw('COUNT(*) as total')) // Select tier_code, tier, and count rows
            ->groupBy('tier_code', 'tier') // Group by both tier_code and tier fields
            ->orderBy('tier_code', 'asc')->get();

        $data['group_sizes'] = collect([]);
        $data['group_colors'] = collect([]);
        $data['material'] = Material::all();
        return view('material.add', compact('data'));
    }


    public function getSizesByTier(Request $request)
    {
        $tier_code = $request->input('tier_code');

        // Trả về danh sách size theo tier_code
        $sizes = Product::select('size', DB::raw('COUNT(*) as total'))
            ->where('tier_code', $tier_code)
            ->groupBy('size')
            ->orderBy('size', 'asc')
            ->get();

        return response()->json(['sizes' => $sizes]);
    }


    public function getStylesByTierAndSize(Request $request)
    {
        $tier_code = $request->input('tier_code');
        $size = $request->input('size');

        if (!$tier_code || !$size) {
            return response()->json(['error' => 'Missing required parameters: tier_code or size'], 400);
        }

        // Trả về danh sách style theo tier_code và size
        $styles = Product::select('style_code', 'style', DB::raw('COUNT(*) as total'))
            ->where('tier_code', $tier_code)
            ->where('size', $size)
            ->groupBy('style_code', 'style')
            ->orderBy('style_code', 'asc')
            ->get();

        return response()->json(['styles' => $styles]);
    }

    public function getColorsByTierAndSize(Request $request)
    {
        $tier_code = $request->input('tier_code');
        $size = $request->input('size');
        $style = $request->input('style');

        if (!$tier_code || !$size || !$style) {
            return response()->json(['error' => 'Missing required parameters: tier_code, size, or style'], 400);
        }

        // Trả về danh sách color theo tier_code, size và style
        $colors = Product::select('color', DB::raw('COUNT(*) as total'))
            ->where('tier_code', $tier_code)
            ->where('size', $size)
            ->where('style_code', $style)
            ->groupBy('color')
            ->orderBy('color', 'asc')
            ->get();

        return response()->json(['colors' => $colors]);
    }


    public function getProducts(Request $request)
    {
        $tier_code = $request->input('tier_code');
        $size = $request->input('size');
        $color = $request->input('color');
        $style = $request->input('style');

        if (!$tier_code) {
            return response()->json(['error' => 'Missing required parameter: tier_code'], 400);
        }

        // Lấy danh sách sản phẩm dựa trên các điều kiện
        $products = Product::query()
            ->when($tier_code, function ($query) use ($tier_code) {
                return $query->where('tier_code', $tier_code);
            })
            ->when($size, function ($query) use ($size) {
                return $query->where('size', $size);
            })
            ->when($style, function ($query) use ($style) {
                return $query->where('style_code', $style);
            })
            ->when($color, function ($query) use ($color) {
                return $query->where('color', $color);
            })
            ->get();

        return response()->json(['products' => $products]);
    }

    public function getMaterials(Request $request)
    {
        $materials = $request->input('materials'); // Danh sách vật tư được chọn (mảng)

        if (!$materials || count($materials) == 0) {
            return response()->json(['materials' => []]); // Trả về danh sách rỗng nếu không có vật tư nào được chọn
        }

        // Lấy danh sách vật tư từ cơ sở dữ liệu dựa trên tên vật tư được chọn
        $selectedMaterials = Material::whereIn('sku', $materials)
            ->get(); // Chỉ lấy các trường cần thiết

        // Tính thành tiền cho từng vật tư (quantity * price)
        $selectedMaterials->transform(function ($material) {
            $material->total_price = $material->quantity * $material->price;
            return $material;
        });

        return response()->json(['materials' => $selectedMaterials]);
    }




    public function importExcel()
    {
        $data = Material::whereBetween('created_at', [
            Carbon::now()->subWeek(), // Ngày cách đây 1 tuần
            Carbon::now()             // Ngày hiện tại
        ])->orderBy('created_at', 'desc')->get();

        return view('material.viewImportExcel', compact('data'));
    }

    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new MaterialImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON

            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0; // Biến đếm số lượng bản ghi mới được thêm
        $existingRecordsCount = 0; // Biến đếm số lượng bản ghi đã tồn tại

        try {
            foreach ($data as $row) {
                // Kiểm tra nếu SKU đã tồn tại trong cơ sở dữ liệu
                $existingProduct = Material::where('sku', $row['sku'])->first();
                if ($existingProduct) {
                    // SKU đã tồn tại, tăng biến đếm
                    $existingRecordsCount++;
                    continue;
                }
                // Nếu không tồn tại, tạo sản phẩm mới
                $dataDetail = new Material();
                $dataDetail->name = $row['name'];
                $dataDetail->sku = $row['sku'];
                $dataDetail->material_categories_id = $row['material_categories_id'];
                $dataDetail->packaging = $row['packaging'];
                $dataDetail->price_cost = $row['price_cost'];
                $dataDetail->price_in_stock = $row['price_in_stock'];
                $dataDetail->unit = $row['unit'];
                $dataDetail->save(); // Lưu dữ liệu vào cơ sở dữ liệu

                $newRecordsCount++; // Tăng biến đếm cho bản ghi mới
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công $newRecordsCount bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại trong cơ sở dữ liệu. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', 'Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!');
            }
        } catch (\Exception $e) {
            return back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }



    public function export()
    {
        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây
        $fileName = "Danh-sach-vat-tu-san-pham-{$currentDate}.xlsx"; // Tạo tên file
        return FacadesExcel::download(new MaterialExport, $fileName);
    }


    public function save(Request $request)
    {
        $request->validate(
            [
                'tier_code' => 'required|string|max:255',
                'size' => 'required|string|max:255',
                'color' => 'required|string|max:255',

            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống',
            ],
            [
                'tier_code' => 'Loại sản phẩm',
                'size' => 'Kích thước',
                'color' => 'Màu sắc',
            ]
        );


        // dd($request->all());
        $exists = MaterialsForProducts::where('tier_code', $request->tier_code)
            ->where('size', $request->size)
            ->where('color', $request->color)
            ->where('style_code', $request->style)
            ->exists();
        if ($exists) {
            return redirect()->back()->with('error', 'Dữ liệu đã tồn tại trên hệ thống !');
        }
        if (!$exists) {
            foreach ($request->data as $item) {
                MaterialsForProducts::create([
                    'tier_code' => $request->tier_code,
                    'size' => $request->size,
                    'color' => $request->color,
                    'style_code' => $request->style,
                    'name' => $item['name'],
                    'sku' => $item['sku'],
                    'quantity' => $item['quantity'],
                    'total_price' => $item['total_price'],
                ]);
            }
        }
        return redirect()->back()->with('success', 'Thêm dữ liệu thành công');
    }


    public function listMaterialProduct()
    {


        $data['get_tiers']   = Product::select('tier_code', 'tier')->distinct()->get();
        $data['get_styles']  = Product::select('style_code', 'style')->distinct()->get();
        $data['get_colors']  = MaterialsForProducts::select('color')->orderBy('color', 'asc')->distinct()->get();
        $data['get_sizes']   = MaterialsForProducts::select('size')->orderBy('size', 'desc')->distinct()->get();


        
        $data['materialsGrouped'] = MaterialsForProducts::with(['product', 'material'])
            ->select(['tier_code', 'size', 'color', 'sku', 'name', 'quantity', 'total_price', 'style_code'])
            ->orderBy('tier_code') // Sắp xếp theo tier_code trước
            ->orderBy('size') // Sắp xếp theo size để các size giống nhau gần nhau
            ->get()
            ->groupBy('tier_code') // Nhóm lớn theo tier_code
            ->map(function ($groupByTierCode) {
                return [
                    'tier_code' => $groupByTierCode->first()->tier_code,
                    'tier_name' => optional($groupByTierCode->first()->product)->tier, // Lấy tên tier từ bảng products
                    'details' => $groupByTierCode
                        ->sortBy('size') // Sắp xếp size trong nhóm
                        ->groupBy(function ($item) {
                            return $item->size . '_' . $item->color; // Nhóm con theo size và color
                        })
                        ->map(function ($groupBySizeColor) {
                            return [
                                'size' => $groupBySizeColor->first()->size,
                                'color' => $groupBySizeColor->first()->color,
                                'style' => $groupBySizeColor->first()->product->style,
                                'materials' => $groupBySizeColor->map(function ($material) {
                                    return [
                                        'name_material' => $material->name,
                                        'sku_material' => $material->sku,
                                        'qty_material' => $material->quantity,
                                        'total_price_material' => $material->total_price,
                                        'style_code' => $material->style_code,
                                        'unit_material' =>  optional($material->material)->unit, // Lấy đơn vị từ quan hệ
                                    ];
                                })->values(), // Đảm bảo tái lập chỉ mục
                            ];
                        })
                        ->values(), // Đảm bảo tái lập chỉ mục
                ];
            })->values(); // Đảm bảo tái lập chỉ mục



        //  dd($data['materialsGrouped']);

        return view('material.listMaterialForProduct', compact('data'));
    }



    public function edit($id)
    {
        $data['listMaterialCategory'] = Material_Category::all();
        $data['material'] = Material::find($id);
        return view('material.edit', compact('data'));
    }

    public function update($id, Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'sku' => 'required|string|max:255',
                'material_categories_id' => 'required',
                'packaging' => 'required|string|max:255',
                'price_cost' => 'required|string|max:255',
                'price_in_stock' => 'required|string|max:255',
                'unit' => 'required|string|max:255',

            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống',
            ],
            [
                'name' => 'Tên vật liệu',
                'sku' => 'Mã SKU',
                'material_categories_id' => 'Danh mục vật liệu',
                'packaging' => 'Quy cách',
                'price_cost' => 'Giá vốn',
                'price_in_stock' => 'Giá về kho',
                'unit' => 'Đơn vị',
            ]
        );


        Material::where('id', $id)->update(
            [
                'name' => $request->name,
                'sku' => $request->sku,
                'material_categories_id' => $request->material_categories_id,
                'packaging' => $request->packaging,
                'price_cost' => $request->price_cost,
                'price_in_stock' => $request->price_in_stock,
                'unit' => $request->unit,
                'description' => $request->description ?? NULL,
            ]
        );

        return redirect()->back()->with('success', 'Cập nhật dữ liệu thành công');
    }



    public function updateMaterials(Request $request)
    {
        $data = $request->input('data');

        // dd($data);

        if ($data) {
            foreach ($data as $item) {
                MaterialsForProducts::query()
                    ->when(!empty($item['tier_material']), function ($query) use ($item) {
                        return $query->where('tier_code', $item['tier_material']);
                    })
                    ->when(!empty($item['style_material']), function ($query) use ($item) {
                        return $query->where('style_code', $item['style_material']);
                    })
                    ->when(!empty($item['color_material']), function ($query) use ($item) {
                        return $query->where('color', $item['color_material']);
                    })
                    ->when(!empty($item['size_material']), function ($query) use ($item) {
                        return $query->where('size', $item['size_material']);
                    })
                    ->when(!empty($item['sku_material']), function ($query) use ($item) {
                        return $query->where('sku', $item['sku_material']);
                    })
                    ->update([
                        'quantity' => $item['qty_material'],
                        'total_price' => $item['total_price_material'],
                    ]);
            }
        }
        return response()->json(['success' => true, 'message' => 'Cập nhật vật tư thành công!']);
    }



    public function viewImportExcelListMaterial()
    {

        return view('material.viewImportExcelListMaterial');
    }


    public function uploadPreviewListMaterialProduct(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);
        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new MaterialsForProductImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON

            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function ImportFileExcelListMaterialProduct(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request

        $newRecordsCount = 0; // Biến đếm số lượng bản ghi mới được thêm
        $existingRecordsCount = 0; // Biến đếm số lượng bản ghi đã tồn tại

        try {
            foreach ($data as $row) {
                // Kiểm tra nếu SKU đã tồn tại trong cơ sở dữ liệu
                $existingProduct = MaterialsForProducts::where('tier_code', $row['tier_code'])
                    ->where('style_code', $row['style_code'])
                    ->where('size', $row['size'])
                    ->where('color', $row['color'])
                    ->where('sku', $row['sku'])->first();
                if ($existingProduct) {
                    // bảng ghi đã tồn tại, tăng biến đếm
                    $existingRecordsCount++;
                    continue;
                }
                // Nếu không tồn tại, tạo sản phẩm mới
                $dataDetail = new MaterialsForProducts();
                $dataDetail->tier_code = $row['tier_code'];
                $dataDetail->style_code = $row['style_code'];
                $dataDetail->size = $row['size'];
                $dataDetail->color = $row['color'];
                $dataDetail->sku = $row['sku'];
                $dataDetail->name = $row['name'];
                $dataDetail->quantity = $row['quantity'];
                $dataDetail->total_price = $row['total_price'];
                $dataDetail->save(); // Lưu dữ liệu vào cơ sở dữ liệu
                $newRecordsCount++; // Tăng biến đếm cho bản ghi mới
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công $newRecordsCount bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Dữ liệu đã tồn tại. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', 'Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!');
            }
        } catch (\Exception $e) {
            return back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }



    public function filter(Request $request)
    {
        $query = MaterialsForProducts::query();

        // Áp dụng bộ lọc
        if ($request->has('tier') && !empty($request->tier)) {
            $query->where('tier_code', $request->tier);
        }
        if ($request->has('style') && !empty($request->style)) {
            $query->where('style_code', $request->style);
        }
        if ($request->has('size') && !empty($request->size)) {
            $query->where('size', $request->size);
        }
        if ($request->has('color') && !empty($request->color)) {
            $query->where('color', $request->color);
        }

        // Lấy dữ liệu kèm thông tin sản phẩm
        $materials = $query->get()->map(function ($material) {
            $product = Product::where('tier_code', $material->tier_code)
                ->where('style_code', $material->style_code)
                ->first();

            return [
                'tier_code' => $material->tier_code,
                'tier' => $product ? $product->tier : 'N/A',
                'style_code' => $material->style_code,
                'style' => $product ? $product->style : 'N/A',
                'product_name' => $product ? $product->name : 'N/A',
                'size' => $material->size,
                'color' => $material->color,
                'sku' => $material->sku,
                'material_name' => $material->name,
                'quantity' => $material->quantity,
                'total_price' => $material->total_price,
            ];
        });

        return response()->json($materials);
    }

    /* Xuất excel vật tư theo sản phẩm */

    public function exportExcel(Request $request)
    {
        // Lấy bộ lọc từ request (giống như khi lọc dữ liệu trên web)
        $filters = $request->only(['tier_code', 'style_code', 'size', 'color']);

        return Excel::download(new MaterialsForProductsExport($filters), 'Materials.xlsx');
    }
}
