<?php

namespace App\Http\Controllers\Admin;

use App\Events\NotifyEnic;
use App\Events\NotifyProcessed;
use App\Events\NotifyWareHousing;
use App\Exports\DeliveryExport;
use App\Exports\DeliveryRealityExport;
use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\DeliveryDraft;
use App\Models\DeliveryReality;
use App\Models\PurchaseOrderItem;
use App\Models\Supplier;
use App\Models\WarehouseDraft;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Revolution\Google\Sheets\Facades\Sheets;

class DeliveryController extends Controller
{
    //


    public function index(Request $request)
    {

        $date = $request->date;
        if ($date) {
            $data = Delivery::with('purchaseOrder', 'productSku')
                ->whereDate('date_received', $date) // So sánh chỉ phần ngày
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        } else {
            $sevenDaysAgo = Carbon::now()->subDays(7);
            $data = Delivery::with('purchaseOrder', 'productSku')->where('date_received', '>=', $sevenDaysAgo)
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        }
        return view('delivery.index', compact('data'));
    }

    public function orderShip(Request $request)
    {
        $data = $request->input('items');
        $date = $request->input('date');

        if (empty($data)) {
            return redirect()->back()->with('error', 'Dữ liệu không hợp lệ.');
        }

        DB::beginTransaction();
        try {
            foreach ($data as $itemId => $items) {
                // Tìm sản phẩm cần cập nhật
                $item = PurchaseOrderItem::where('purchase_order_id', $items['purchase_order_id'])
                    ->where('sku', $items['sku'])
                    ->first();

                // Kiểm tra xem sản phẩm có tồn tại không
                if (!$item) {
                    throw new \Exception("Không tìm thấy sản phẩm với ID: $itemId");
                }
                // Chuyển đổi số lượng thành số nguyên
                $qtyDelivery = intval($items['qty']);
                $qtyAvailable = intval($item->quantity) - intval($item->qty_delivery);

                // Kiểm tra số lượng hợp lệ
                if ($qtyDelivery <= 0 || $qtyDelivery > $qtyAvailable) {
                    throw new \Exception("Số lượng giao hàng không hợp lệ cho sản phẩm ID: $itemId");
                }

                // Cập nhật số lượng đã giao
                $item->increment('qty_delivery', $qtyDelivery);
                $item->update(['qty_productions' => $item->quantity == $qtyDelivery ? 0 : $item->quantity - $qtyDelivery]);
                $item->update(['date_delivery' => $date]); // Cập nhật ngày giao hàng


                // Thêm lịch sử giao hàng vào bảng `deliveries`
                if (!empty($items['sku'])) {
                    Delivery::create([
                        'purchase_order_id' => $items['purchase_order_id'],
                        'sku' => $items['sku'],
                        'qty' => $qtyDelivery,
                        'date_delivery' => $date,
                    ]);
                }
            }
            // Thông báo cho xưởng
            $notify = "Bạn có đơn hàng giao từ xưởng vào: " . date('d-m-Y | H:i', strtotime($date));;
            event(new NotifyWareHousing($notify));

            DB::commit();
            return redirect()->back()->with('success', 'Giao hàng thành công !');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Có lỗi xảy ra: ' . $e->getMessage());
        }
    }


    public function show()
    {




        $data = DeliveryDraft::with('purchaseOrder', 'productSku')->where('status', 0)->orderBy('id', 'desc')->get()->groupBy('purchase_order_id');

        return view('delivery.show', compact('data'));
    }


    public function showdelivery()
    {
        $data = DeliveryDraft::with('purchaseOrder', 'productSku', 'supplier')->where('status', 0)->where('status_delivery', 0)->orderBy('id', 'asc')->get()->groupBy('purchase_order_id');
        return view('delivery.showWarehousing', compact('data'));
    }



    public function processOrder(Request $request)
    {
        $data = $request->input('data', []);

        DB::beginTransaction();
        try {
            // ======================================================
            // Bước 1: Cập nhật các record Delivery trong 7 ngày gần nhất
            // ======================================================
            $sevenDaysAgo = Carbon::now()->subDays(7);
            $deliveriesToUpdate = Delivery::where('date_received', '>=', $sevenDaysAgo)->get();

            foreach ($deliveriesToUpdate as $delivery) {
                // Nếu số lượng đã giao vượt quá số lượng đặt hàng thì cập nhật lại
                if ($delivery->qty > $delivery->order_quantity) {
                    $excess = $delivery->qty - $delivery->order_quantity;
                    $delivery->update([
                        'qty'      => $delivery->order_quantity,
                        'qty_more' => $delivery->qty_more + $excess,
                    ]);
                }
            }


            /* Cập Nhật Thông Tin Hàng Về Thực Tế Lên GooGle Sheets */

            // Tạo mảng các hàng cho Google Sheet, bắt đầu với dòng header
            $sheetRowsNews = [];
            $sheetRowsNews[] = [
                'Mã Đơn Hàng',
                'Tên Sản Phẩm',
                'SKU',
                'Số Lượng Đặt Hàng',
                'Số Lượng Nhận Hàng',
                'Số Lượng Về Thêm',
                'Ngày Về',
                'Xưởng Sản Xuất'
            ];

            foreach ($data as $items) {
                foreach ($items as $item) {
                    $sheetRowsNews[] = [
                        isset($item['purchase_order_code']) ? $item['purchase_order_code'] : '',
                        isset($item['name']) ? $item['name'] : '',
                        isset($item['sku']) ? $item['sku'] : '',
                        isset($item['order_quantity']) ? $item['order_quantity'] : '',
                        isset($item['qty']) ? $item['qty'] : '',
                        isset($item['qty_more']) ? $item['qty_more'] : '',
                        isset($item['date_delivered']) ? date('d-m-Y', strtotime($item['date_delivered']))  : '',
                        isset($item['supplier_name']) ? $item['supplier_name'] : '',
                    ];

                    /* Thêm vào bảng Hàng Về Thực Tế Nhận Được */
                    DeliveryReality::create(
                        [
                            'name' => $item['name'] ?? "",
                            'purchase_order_id' => $item['purchase_order_id'] ?? "",
                            'order_quantity' => $item['order_quantity'] ?? "",
                            'sku' => $item['sku'] ?? "",
                            'qty' => $item['qty'] ?? "",
                            'qty_more' => $item['qty_more'],
                            'date_delivery' => $item['date_delivered'] ?? "",
                            'date_received' => now(),
                            'delivery_notes' => $item['delivery_notes'] ?? "",
                            'supplier_id' => $item['supplier_id'] ?? "",
                        ]
                    );

                    // ======================================================
                    // Bổ sung: Lưu sản phẩm đã giao hàng vào kho tạm (WarehouseDraft)
                    // ======================================================
                    WarehouseDraft::create([
                        'purchase_order_id' => $item['purchase_order_id'],
                        'sku'               => $item['sku'],
                        'name'              => $item['name'] ?? "",
                        'order_quantity'    => $item['order_quantity'] ?? 0,
                        'qty_received'      => $item['qty'] ?? 0,
                        'qty_more'          => $item['qty_more'] ?? 0,
                        'date_received'     => now(),
                        'delivery_notes'    => $item['delivery_notes'] ?? "",
                        'supplier_id'       => $item['supplier_id'] ?? "",
                        'status'            => 0, // 0: bản nháp chưa được xác nhận
                    ]);
                }
            }
            // ID của spreadsheet và tên sheet bạn muốn cập nhật
            $spreadsheetId = '1uqcTlB_RWfdEXTus1xU3WCS9do693KYA4da24fMx6EI';
            $sheetNameCustom = 'Hàng Về Thực Tế';
            Sheets::spreadsheet($spreadsheetId)
                ->sheet($sheetNameCustom)
                ->append($sheetRowsNews);

            // ======================================================
            // Bước 2: Nhóm dữ liệu gửi lên từ request theo purchase_order_id và sku
            // ======================================================
            $groupedItems = [];
            foreach ($data as $orderId => $orderItems) {
                foreach ($orderItems as $item) {

                    $key = $item['purchase_order_id'] . '-' . $item['sku'];
                    // Nếu nhóm chưa tồn tại, lấy số lượng hiện tại từ DB
                    if (!isset($groupedItems[$key])) {
                        $delivery = Delivery::where('purchase_order_id', $item['purchase_order_id'])
                            ->where('sku', $item['sku'])
                            ->first();
                        $currentQty = $delivery ? (int)$delivery->qty : 0;
                        $groupedItems[$key] = $item;
                        $groupedItems[$key]['current_qty'] = $currentQty;  // Số lượng đã giao hiện có
                        $groupedItems[$key]['submitted_qty'] = 0;           // Sẽ cộng dồn số lượng mới gửi lên
                        $groupedItems[$key]['qty_more'] = 0;
                    }
                    // Cộng dồn số lượng mới gửi lên
                    $groupedItems[$key]['submitted_qty'] += (int)$item['qty'];
                    $orderQuantity = (int)$item['order_quantity'];
                    // Tổng số lượng tính được = current_qty + submitted_qty
                    $totalQty = $groupedItems[$key]['current_qty'] + $groupedItems[$key]['submitted_qty'];
                    if ($totalQty > $orderQuantity) {
                        $groupedItems[$key]['qty'] = $orderQuantity;
                        $groupedItems[$key]['qty_more'] = $totalQty - $orderQuantity;
                    } else {
                        $groupedItems[$key]['qty'] = $totalQty;
                        $groupedItems[$key]['qty_more'] = 0;
                    }
                }
            }

            // ======================================================
            // Bước 3: Cập nhật các bảng: Delivery, DeliveryDraft, PurchaseOrderItem
            // ======================================================
            foreach ($groupedItems as $item) {
                // --- Cập nhật bảng Delivery ---
                $delivery = Delivery::where('purchase_order_id', $item['purchase_order_id'])
                    ->where('sku', $item['sku'])
                    ->first();
                if (!$delivery) {
                    $delivery = Delivery::create([
                        'purchase_order_id' => $item['purchase_order_id'],
                        'sku'               => $item['sku'],
                        'name'              => $item['name'] ?? "",
                        'order_quantity'    => $item['order_quantity'] ?? "",
                        'qty'               => $item['qty'] ?? 0,
                        'qty_more'          => $item['qty_more'] ?? 0,
                        'delivery_notes'    => $item['delivery_notes'] ?? '',
                        'status'            => (!empty($item['is_error']) ? 2 : 1),
                        'date_received'     => now(),
                        'status_delivery'   => 0,
                        'supplier_id'       => $item['supplier_id'] ?? '',
                    ]);
                } else {
                    $delivery->update([
                        'qty'            => $item['qty'],
                        'qty_more'       => $item['qty_more'],
                        'delivery_notes' => $item['delivery_notes'] ?? '',
                        'status'         => (!empty($item['is_error']) ? 2 : 1),
                        'date_received'  => now(),
                    ]);
                }

                // --- Cập nhật bảng DeliveryDraft (nếu có) ---
                $delivery_drafts = DeliveryDraft::where('purchase_order_id', $item['purchase_order_id'])
                    ->where('sku', $item['sku'])
                    ->get();
                foreach ($delivery_drafts as $draft) {
                    $draft->update([
                        'qty'              => $draft->qty + $item['submitted_qty'],
                        'delivery_notes'   => $item['delivery_notes'] ?? '',
                        'status'           => 1,
                        'date_received'    => now(),
                        'status_delivery'  => 1
                    ]);
                }

                // --- Cập nhật bảng PurchaseOrderItem ---
                $purchaseOrderItem = PurchaseOrderItem::with('purchaseOrder')
                    ->where('purchase_order_id', $item['purchase_order_id'])
                    ->where('sku', $item['sku'])
                    ->first();
                if ($purchaseOrderItem) {
                    $newQtyReality = $purchaseOrderItem->qty_reality + $item['submitted_qty'];
                    $newQtyForecasting = max(0, $purchaseOrderItem->quantity - $newQtyReality);
                    $newQtyProductions = ($purchaseOrderItem->qty_productions > 0) ? $newQtyReality : 0;
                    $purchaseOrderItem->update([
                        'qty_delivery'        => $newQtyReality,
                        'qty_reality'         => $newQtyReality,
                        'qty_productions'     => $newQtyProductions,
                        'products_production' => $newQtyReality,
                        'qty_forecasting'     => $newQtyForecasting,
                        'is_delivery' => 0,
                        'delivery_note'       => (!empty($item['is_error']) ? $item['delivery_notes'] : ""),
                    ]);
                    if ($newQtyReality >= $purchaseOrderItem->quantity) {
                        $purchaseOrderItem->update(['delivery_note' => '']);
                    }
                }
            }

            // ====================================================== Cập Nhật Thong Tin Cho xưởng  
            $supplierGrouped = [];
            foreach ($groupedItems as $item) {
                $supplierId = $item['supplier_id'] ?? null;
                if ($supplierId) {
                    if (!isset($supplierGrouped[$supplierId])) {
                        $supplierGrouped[$supplierId] = [
                            'items'    => [],
                            'hasError' => false,
                        ];
                    }
                    $supplierGrouped[$supplierId]['items'][] = $item;
                    if (!empty($item['is_error'])) {
                        $supplierGrouped[$supplierId]['hasError'] = true;
                    }
                }
            }
            foreach ($supplierGrouped as $supplierId => $group) {
                // Lấy thông tin nhà cung cấp từ bảng suppliers
                $supplier = Supplier::find($supplierId);
                $supplierName = $supplier ? $supplier->name : 'N/A';

                if ($group['hasError']) {
                    // Nếu có lỗi, tập hợp các SKU và chi tiết lỗi của nhà cung cấp đó
                    $missingSkus = [];
                    $errorDetails = [];
                    foreach ($group['items'] as $item) {
                        if (!empty($item['is_error'])) {
                            $missingSkus[] = $item['sku'] ?? 'N/A';
                            $errorDetails[] = "SKU: " . ($item['sku'] ?? 'N/A') . " - " . ($item['delivery_notes'] ?? 'Không có ghi chú');
                        }
                    }
                    $notify = "⚠️ Lỗi giao hàng cho nhà cung cấp {$supplierName}: Mã SKU lỗi: "
                        . implode(', ', $missingSkus)
                        . ". Chi tiết lỗi: " . implode(" | ", $errorDetails);
                    // Gửi thông báo cho đúng supplier_id
                    event(new NotifyProcessed($notify, $supplierId));
                    // 6 Gửi thông báo cho bên liên quan
                    event(new NotifyEnic($notify));
                } else {
                    $notify = "🚚 Kho đã nhận đủ mã hàng cho nhà cung cấp {$supplierName}.";
                    $notifyAdmin = "🚚 Kho đã nhận đủ mã hàng cho nhà cung cấp" . $supplierName;
                    // Gửi thông báo cho đúng supplier_id
                    event(new NotifyProcessed($notify, $supplierId));
                    event(new NotifyEnic($notifyAdmin));
                }
            }
            // ======================================================
            // Bước 4: Kiểm tra lại PurchaseOrderItem trong 7 ngày gần nhất, nếu (quantity == qty_reality) => complete_order = 1
            // ======================================================
            $sevenDaysAgoForPO = Carbon::now()->subDays(7);
            $purchaseOrderItems = PurchaseOrderItem::where('updated_at', '>=', $sevenDaysAgoForPO)->get();
            foreach ($purchaseOrderItems as $poItem) {
                if ($poItem->quantity == $poItem->qty_reality) {
                    $poItem->update(['complete_order' => 1]);
                }
            }
            // ======================================================
            // Bước 5: Insert/Update dữ liệu PurchaseOrderItem (chưa về đủ: complete_order = 0) lên Google Sheet (Sheet 'Demo')
            // ======================================================

            // 1️⃣ Lấy dữ liệu từ bảng PurchaseOrderItem với điều kiện complete_order = 0
            $poItems = PurchaseOrderItem::where('complete_order', 0)
                ->with('purchaseOrder')
                ->get();

            // 2️⃣ Nhóm dữ liệu theo purchase_order_id
            $groupedByOrder = $poItems->groupBy('purchase_order_id');

            // 3️⃣ Tạo mảng dữ liệu mới để insert vào Google Sheets
            $sheetRows = [];

            // ✅ Thêm dòng tiêu đề
            $sheetRows[] = [
                'Mã Đơn Hàng',
                'Tổng Số Lượng Đặt Hàng',
                'SKU',
                'Số Lượng Đặt Hàng',
                'Số Lượng Dự Kiến',
                'Số Lượng Thực Tế',
                'Ngày Dự Kiến',
                'Ngày Dự Kiến Cho Sale',

            ];

            // ✅ Lặp qua từng đơn hàng
            foreach ($groupedByOrder as $purchase_order_id => $itemsGroup) {
                $purchaseOrder = $itemsGroup->first()->purchaseOrder;
                $poId = $purchaseOrder ? $purchaseOrder->po_id : $purchase_order_id;

                // Thêm dòng trống trước mỗi đơn hàng để ngăn cách
                $sheetRows[] = ['']; // Dòng trống giữa các đơn hàng

                // Nhóm theo SKU
                $groupedBySku = $itemsGroup->groupBy('sku');

                foreach ($groupedBySku as $sku => $skuItems) {
                    $firstItem = $skuItems->first();
                    $total_qty_order = $firstItem->purchaseOrder->getTotalQuantityAttribute();
                    $orderQty = $firstItem->quantity;
                    $delivered = $skuItems->sum('qty_delivery');
                    $reality   = $skuItems->sum('qty_reality');
                    $forecasting = $skuItems->sum('qty_forecasting');
                    // ✅ Lấy ngày dự kiến và ngày dự kiến cho sale từ bản ghi đầu tiên
                    $date_forecast = date('d-m-Y', strtotime($firstItem->expected_date));
                    $date_sale = date('d-m-Y', strtotime($firstItem->date_sale));
                    $sheetRows[] = [
                        $poId,
                        $total_qty_order,
                        $sku,
                        $orderQty,
                        $forecasting,
                        $reality,
                        $date_forecast,
                        $date_sale
                    ];
                }
            }

            // 4️⃣ Xóa toàn bộ dữ liệu cũ trên Google Sheets (giữ tiêu đề)
            $spreadsheetId = '1uqcTlB_RWfdEXTus1xU3WCS9do693KYA4da24fMx6EI';
            $sheetName = 'Hàng Về Dự Kiến';

            Sheets::spreadsheet($spreadsheetId)
                ->sheet($sheetName)
                ->clear(); // ✅ Xóa toàn bộ dữ liệu cũ

            // 5️⃣ Insert dữ liệu mới vào Google Sheets
            if (!empty($sheetRows)) {
                Sheets::spreadsheet($spreadsheetId)
                    ->sheet($sheetName)
                    ->append($sheetRows, 'RAW'); // ✅ Chèn dữ liệu mới
            }



            DB::commit();
            return redirect()->back()->with('success', 'Dữ liệu đã được cập nhật vào hệ thống!');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Có lỗi xảy ra: ' . $e->getMessage());
        }
    }


    public function orderReceived(Request $request)
    {
        $date = $request->date;
        if ($date) {
            $data = DeliveryReality::with('purchaseOrder', 'productSku', 'supplier')
                ->whereDate('date_received', $date) // So sánh chỉ phần ngày
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        } else {

            $sevenDaysAgo = Carbon::now()->subDays(7);
            $data = DeliveryReality::with('purchaseOrder', 'productSku')->where('date_received', '>=', $sevenDaysAgo)
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        }

        return view('delivery.showOrderReceived', compact('data'));
    }

    public function exportOrders(Request $request)
    {

        $date = $request->query('date');
        $supplier = $request->query('supplier') ?? "";

        if (!$date) {
            return redirect()->back()->with('error', 'Vui lòng chọn ngày trước khi xuất Excel.');
        }

        return Excel::download(new DeliveryRealityExport($date, $supplier), "hang-ve-thuc-te_{$date}.xlsx");
    }
}
