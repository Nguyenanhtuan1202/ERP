<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RepairOrder;
use App\Models\Supplier;
use Illuminate\Http\Request;

class RepairOrderController extends Controller
{
    //


    public function index()
    {

        $data = RepairOrder::orderBy('id', 'desc')->get();


        return view('repairorders.index', compact('data'));
    }



    public function edit($id)
    {
        $order = RepairOrder::find($id);
        $suppliers = Supplier::orderBy('id', 'asc')->get();
        return view('repairorders.edit', compact('order','suppliers'));
    }


    public function create()
    {
        $suppliers = Supplier::orderBy('id', 'asc')->get();
        return view('repairorders.create', compact('suppliers'));
    }

    public function store(Request $request)
    {

        // Xử lý upload hình ảnh (nếu có)
        $arr_picture = []; // Khởi tạo mảng rỗng để chứa tên file hình ảnh
        if ($request->hasFile('arr_picture')) {
            $get_image_gallery = $request->file('arr_picture');
            foreach ($get_image_gallery as $image) {
                // Lấy tên gốc của hình ảnh
                $get_name_image_gallery = $image->getClientOriginalName();
                // Lấy phần tên (không lấy phần đuôi mở rộng)
                $name_gallery_image = current(explode('.', $get_name_image_gallery));
                // Tạo tên file mới với tiền tố "RepairOrder-", tên file gốc và số ngẫu nhiên
                $new_image_gallery = "RepairOrder-" . $name_gallery_image . "-" . rand(0, 999) . '.' . $image->getClientOriginalExtension();
                // Thêm tên file vào mảng
                $arr_picture[] = $new_image_gallery;
                // Di chuyển file vào thư mục public/uploads/RepairOrder
                $image->move(public_path('uploads/RepairOrder'), $new_image_gallery);
            }
        }


        // Tạo mới record trong database
        RepairOrder::create(
            [
                'order_code' => $request->order_code ?? "",
                'customer_name' => $request->customer_name ?? "",
                'customer_phone' => $request->customer_phone ?? "",
                'address' => $request->address ?? "",
                'note' => $request->note ?? "",
                'product_category' => $request->product_category ?? "",
                'sku' => $request->sku ?? "",
                'product_name' => $request->product_name ?? "",
                'quantity' => $request->quantity ?? "",
                'product_type' => $request->product_type ?? "",
                'repair_type' => $request->repair_type ?? "",
                'warranty_date' => $request->warranty_date ?? "",
                'completion_date' => $request->completion_date ?? NULL,
                'is_paid' => $request->is_paid ?? "",
                'arr_picture' => $arr_picture ? serialize($arr_picture) : null,
                'supplier_id' => $request->supplier_id ?? "",
            ]
        );

        return redirect()->back()
            ->with('success', 'Phiếu sửa chữa/bảo hành đã được tạo thành công!');
    }




    public function update(Request $request, $id)
    {
        // Tìm record theo ID, nếu không tìm thấy sẽ trả về lỗi 404
        $order = RepairOrder::findOrFail($id);

        // Xử lý upload hình ảnh (nếu có)
        $arr_picture = []; // Khởi tạo mảng rỗng để chứa tên file hình ảnh mới
        if ($request->hasFile('arr_picture')) {
            $get_image_gallery = $request->file('arr_picture');
            foreach ($get_image_gallery as $image) {
                // Lấy tên gốc của hình ảnh
                $get_name_image_gallery = $image->getClientOriginalName();
                // Lấy phần tên (không lấy phần đuôi mở rộng)
                $name_gallery_image = current(explode('.', $get_name_image_gallery));
                // Tạo tên file mới với tiền tố "RepairOrder-", tên file gốc và số ngẫu nhiên
                $new_image_gallery = "RepairOrder-" . $name_gallery_image . "-" . rand(0, 999) . '.' . $image->getClientOriginalExtension();
                // Thêm tên file vào mảng
                $arr_picture[] = $new_image_gallery;
                // Di chuyển file vào thư mục public/uploads/RepairOrder
                $image->move(public_path('uploads/RepairOrder'), $new_image_gallery);
            }
            // Nếu có file mới upload, cập nhật lại trường arr_picture (serialize mảng)
            $data_arr_picture = !empty($arr_picture) ? serialize($arr_picture) : null;
        } else {
            // Nếu không có file mới, giữ nguyên giá trị cũ của arr_picture
            $data_arr_picture = $order->arr_picture;
        }

        // Cập nhật dữ liệu record
        $order->update([
            'order_code'       => $request->order_code ?? "",
            'customer_name'    => $request->customer_name ?? "",
            'customer_phone'   => $request->customer_phone ?? "",
            'address'          => $request->address ?? "",
            'note'             => $request->note ?? "",
            'product_category' => $request->product_category ?? "",
            'sku'              => $request->sku ?? "",
            'product_name'     => $request->product_name ?? "",
            'quantity'         => $request->quantity ?? "",
            'product_type'     => $request->product_type ?? "",
            'repair_type'      => $request->repair_type ?? "",
            'warranty_date'    => $request->warranty_date ?? "",
            'completion_date'  => $request->completion_date ?? NULL,
            'is_paid'          => $request->is_paid ?? "",
            'arr_picture'      => $data_arr_picture,
            'supplier_id' => $request->supplier_id ?? "",
        ]);

        return redirect()->back()
            ->with('success', 'Phiếu sửa chữa/bảo hành đã được cập nhật thành công!');
    }


    public function delete($id)
    {
        // Tìm record theo ID
        $order = RepairOrder::find($id);

        if ($order) {
            // Nếu record có mảng hình ảnh, xoá các file hình ảnh đó
            if ($order->arr_picture) {
                $images = @unserialize($order->arr_picture);
                if (is_array($images)) {
                    foreach ($images as $image) {
                        $file_path = public_path('uploads/RepairOrder/' . $image);
                        if (file_exists($file_path)) {
                            unlink($file_path);
                        }
                    }
                }
            }
            // Xoá record khỏi database
            $order->delete();
            return redirect()->back()
                ->with('success', 'Phiếu sửa chữa/bảo hành và các hình ảnh liên quan đã được xoá thành công!');
        } else {
            return redirect()->back()
                ->with('error', 'Không tìm thấy phiếu cần xoá!');
        }
    }
}
