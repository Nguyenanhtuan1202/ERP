<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Imports\SupplierImport;
use App\Models\ForecastProduct;
use App\Models\Supplier;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;

class SupplierController extends Controller
{
    // Method to list all suppliers
    public function index(Request $request)
    {

        $status = $request->status;
        $id = $request->id;
        if ($status != NULL && $id != NULL) {
            Supplier::where('id', $request->id)->update(
                [
                    'status' => $status
                ]
            );
            return redirect()->back()->with('success', 'Cập nhật trạng thái nhà cung cấp thành công');
        } else {
            $suppliers = Supplier::with('user')->orderBy('status', 'desc')->orderBy('id', 'desc')->get();
            return view('suppliers.index', compact('suppliers'));
        }
    }

    // Method to show a single supplier
    public function show($id)
    {
        $supplier = Supplier::findOrFail($id);
        return view('suppliers.show', compact('supplier'));
    }

    // Method to show the form for creating a new supplier
    public function create()
    {
        return view('suppliers.create');
    }

    // Method to store a new supplier
    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:255',

        ]);

        $supplier = Supplier::create([
            'username' => $request->username,
            'phone_number' => $request->phone_number ?? "",
            'email' => $request->email ?? "",
            'company_name' => $request->input('company_name'),
            'companion_day' => $request->input('companion_day'),
            'website' => $request->website,
            'address' => $request->address,
            'company_tax' => $request->input('company_tax'),
            'employer' => $request->employer,
            'terms' => $request->terms,
            'status' => 1,
            'weight' => 0,
            'payments' => $request->payments,
            'industry' => $request->industry,
            'note' => $request->note,
            'sp_code' => $request->sp_code,
        ]);

        if ($request->has('bank_accounts')) {
            foreach ($request->bank_accounts as $bankAccount) {
                $supplier->bankAccounts()->create($bankAccount);
            }
        }

        User::create(
            [
                'name' => $request->username,
                'email' => $request->email,
                'password' => Hash::make('12345678'),
                'supplier_id' => $supplier->id,
            ]
        );
        return redirect()->route('supplier.edit', [$supplier->id])->with('success', 'Thêm Nhà Cung Cấp Thành Công.');
    }

    // Method to show the form for editing a supplier
    public function edit($id)
    {
        $list_purchaser = User::where('purchaser', 1)->orderBy('id', 'desc')->get();
        $list_forecaster = User::where('forecaster', 1)->orderBy('id', 'desc')->get();
        $supplier = Supplier::findOrFail($id);
        $productBySupplier = ForecastProduct::where('supplier_id', $supplier->sp_code)->orderBy('id', 'desc')->get();
        $list_bank_accounts = $supplier->bankAccounts;
        return view('suppliers.edit', compact('supplier', 'list_bank_accounts', 'productBySupplier', 'list_purchaser','list_forecaster'));
    }

    // Method to update a supplier
    public function update(Request $request, $id)
    {
        $request->validate([
            'username' => 'required|string|max:255',
        ]);

        $supplier = Supplier::findOrFail($id);
        $supplier->update([
            'username' => $request->username,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
            'company_name' => $request->input('company_name'),
            'companion_day' => $request->input('companion_day'),
            'website' => $request->website,
            'address' => $request->address,
            'company_tax' => $request->input('company_tax'),
            'employer_id' => $request->employer_id,
            'terms' => $request->terms,
            'status' => $request->status,
            'deposit' => $request->deposit,
            'weight' => 0,
            'payments' => $request->payments,
            'industry' => $request->industry,
            'note' => $request->note,
            'sp_code' => $request->sp_code,
            'holiday_schedule' => $request->holiday_schedule,
            'packaging_specifications' => $request->packaging_specifications,
            'production_time' => $request->production_time,
            'shipping_time' => $request->shipping_time,
            'total_lead_time' => $request->total_lead_time,
            'exclusive_rights' => $request->exclusive_rights,
            'warranty_preorder' => $request->warranty_preorder,
            'warranty_postorder' => $request->warranty_postorder,
            'forecaster_id' => $request->forecaster_id,
            'peak_season' => $request->peak_season,

        ]);

        if ($request->has('bank_accounts')) {
            foreach ($request->bank_accounts as $bankAccount) {
                $supplier->bankAccounts()->updateOrCreate(
                    ['account_number' => $bankAccount['account_number']],
                    $bankAccount
                );
            }
        } else {
            $supplier->bankAccounts()->delete();
        }

        return redirect()->back()->with('success', 'Cập Nhật Nhà Cung Cấp Thành Công.');
    }

    // Method to delete a supplier
    public function delete($id)
    {
        $supplier = Supplier::findOrFail($id);
        User::where('supplier_id', $supplier->id)->delete();
        $supplier->delete();
        return redirect()->back()->with('success', 'Xoá thông tin nhà cung cấp thành công.');
    }

    public function importExcel()
    {

        return view('suppliers.viewImportExcel');
    }

    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new SupplierImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON

            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }


    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0;           // Số lượng bản ghi mới được thêm
        $existingRecordsCount = 0;      // Số lượng bản ghi đã tồn tại

        // Hàm helper để làm sạch chuỗi
        $clean = function ($value) {
            if (!is_string($value)) {
                return $value;
            }
            $value = trim($value);                     // Loại bỏ khoảng trắng đầu/cuối
            $value = preg_replace('/\s+/', ' ', $value); // Thay thế khoảng trắng liên tục bằng 1 khoảng trắng
            return $value;
        };

        try {
            foreach ($data as $row) {
                // Ép sang mảng nếu không phải
                if (!is_array($row)) {
                    $row = (array) $row;
                }
                // Kiểm tra xem key "sp_code" có tồn tại không
                if (!array_key_exists('sp_code', $row)) {
                    continue;
                }
                $sp_code = $clean($row['sp_code']);
                if (empty($sp_code)) {
                    continue;
                }
                // Kiểm tra nếu sp_code đã tồn tại trong cơ sở dữ liệu
                $existingProduct = Supplier::where('sp_code', $sp_code)->first();
                if ($existingProduct) {
                    $existingRecordsCount++;
                    continue;
                }

                // Tạo bản ghi mới cho Supplier
                $supplier = new Supplier();
                $supplier->sp_code = array_key_exists('sp_code', $row) ? $clean($row['sp_code']) : null;
                $supplier->username = array_key_exists('username', $row) ? $clean($row['username']) : null;
                $supplier->company_name = array_key_exists('company_name', $row) ? $clean($row['company_name']) : null;
                $supplier->address = array_key_exists('address', $row) ? $clean($row['address']) : null;
                $supplier->product_manufacturing = array_key_exists('product_manufacturing', $row) ? $clean($row['product_manufacturing']) : null;
                $supplier->note = array_key_exists('note', $row) ? $clean($row['note']) : null;

                // Xử lý companion_day: chuyển từ "dd/mm/yyyy" sang "Y-m-d"
                $companion_day = null;
                if (array_key_exists('companion_day', $row)) {
                    $rawDate = $clean($row['companion_day']);
                    try {
                        $companion_day = Carbon::createFromFormat('d/m/Y', $rawDate)->format('Y-m-d');
                    } catch (\Exception $e) {
                        // Nếu chuyển đổi thất bại, có thể log lỗi hoặc giữ null
                        $companion_day = null;
                    }
                }
                $supplier->companion_day = $companion_day;

                $supplier->employer = array_key_exists('employer', $row) ? $clean($row['employer']) : null;
                $supplier->sp_code = $sp_code;
                $supplier->save(); // Lưu dữ liệu vào cơ sở dữ liệu

                $newRecordsCount++;
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công {$newRecordsCount} bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại trong cơ sở dữ liệu. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', "Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!");
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }
}
