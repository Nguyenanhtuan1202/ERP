<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CustomsClearance;
use App\Models\Shipment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CustomsClearanceController extends Controller
{
    //


    public function index()
    {
        $clearances = CustomsClearance::get();
        return view('customs_clearance.index', compact('clearances'));
    }

    public function create()
    {
        $shipments = Shipment::get();
        return view('customs_clearance.create', compact('shipments'));
    }

    public function store(Request $request)
    {
        // Validate dữ liệu nhập vào, bao gồm cả file upload cho chứng từ và (nếu có) trường id_hs
        $validated = $request->validate([
            'declaration_number' => 'required|string|max:255|unique:customs_clearance,declaration_number',
            'clearance_date'     => 'nullable|date',
            'status'             => 'required|in:Chờ duyệt,Thông quan,Bị từ chối',
            'fees'               => 'nullable|numeric',
            'notes'              => 'nullable|string',
            'shipment_id'        => 'required|exists:shipments,id',
            // Nếu bạn muốn sử dụng id_hs để tạo tên file, hãy thêm rule cho nó (có thể là required hoặc nullable)
            'id_hs'              => 'nullable|string',
            'documents'          => 'nullable',
            'documents.*'        => 'nullable|file|mimes:pdf,jpg,jpeg,png,doc,docx|max:5048'
        ]);

        // Xử lý file uploads cho "documents"
        $documentPaths = [];
        if ($request->hasFile('documents')) {
            foreach ($request->file('documents') as $file) {
                // Lấy tên gốc của file, ví dụ: "hopdong.pdf"
                $originalName = $file->getClientOriginalName();
                // Lấy phần tên (không bao gồm đuôi mở rộng)
                $namePart = current(explode('.', $originalName));
                // Nếu có trường id_hs, dùng nó để tạo tên file; nếu không, bỏ qua
                $id_hs = $request->input('id_hs', '');
                if (!empty($id_hs)) {
                    $newFileName = 'chung-tu' . $namePart . '-' . $id_hs . '.' . $file->getClientOriginalExtension();
                } else {
                    $newFileName = 'chung-tu' . $namePart . '.' . $file->getClientOriginalExtension();
                }
                // Di chuyển file vào thư mục public/uploads/customs_clearance
                $file->move(public_path('uploads/customs_clearance'), $newFileName);
                // Lưu tên file mới vào mảng documentPaths
                $documentPaths[] = $newFileName;
            }
        }
        // Lưu file dưới dạng JSON nếu có, nếu không, để null
        $validated['documents'] = !empty($documentPaths) ? json_encode($documentPaths) : null;

        try {
            // Tạo mới hồ sơ hải quan với dữ liệu đã được xử lý
            CustomsClearance::create($validated);
            return redirect()->back()->with('success', 'Hồ sơ hải quan đã được tạo thành công.');
        } catch (\Exception $e) {
            Log::error("Error in CustomsClearanceController@store: " . $e->getMessage());

            dd($e->getMessage());
            // return redirect()->back()->with('error', 'Có lỗi xảy ra khi tạo hồ sơ hải quan. Vui lòng thử lại.');
        }
    }



    public function show(CustomsClearance $customsClearance)
    {
        return view('customs_clearance.show', compact('customsClearance'));
    }

    public function edit(CustomsClearance $customsClearance)
    {
        $shipments = Shipment::get();
        return view('customs_clearance.edit', compact('customsClearance', 'shipments'));
    }

    public function update(Request $request, CustomsClearance $customsClearance)
    {
        $validated = $request->validate([
            'shipment_id'        => 'required|exists:shipments,id',
            'declaration_number' => 'required|unique:customs_clearance,declaration_number,' . $customsClearance->id,
            'clearance_date'     => 'nullable|date',
            'status'             => 'required|in:Chờ duyệt,Thông quan,Bị từ chối',
            'documents'          => 'nullable|json',
            'fees'               => 'nullable|numeric',
            'notes'              => 'nullable|string',
        ]);

        $customsClearance->update($validated);
        return redirect()->route('customs_clearance.index')->with('success', 'Hồ sơ hải quan đã được cập nhật.');
    }

    public function delete(CustomsClearance $customsClearance)
    {
        $customsClearance->delete();
        return redirect()->route('customs_clearance.index')->with('success', 'Hồ sơ hải quan đã được xóa.');
    }
}
