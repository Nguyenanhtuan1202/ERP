<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Tag;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class TagController extends Controller
{

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'tag']);
            return $next($request);
        });
    }


    public function add()
    {
        return view('backend.tag.add');
    }

    public function list(Request $request)
    {
        $id = $request->id;
        $status = $request->status;
        $success =   Tag::where('id', $id)->update(
            [
                'status' => $status
            ]
        );
        if ($success) {
            return redirect()->back()->with('status', 'Cập Nhật Trạng Thái Thành Công');
        }

        $tag = Tag::orderBy('weight', 'desc')->orderBy('id', 'desc')->get();
        return view('backend.tag.list', compact('tag'));
    }


    public function edit($id)
    {
        $tag = Tag::find($id);
        return view('backend.tag.edit', compact('tag'));
    }
    public function save(Request $request)
    {
        $request->validate(
            [
                'title' => 'required|string|max:255',
                'url' => 'required|string|max:255',
                'meta_seo' => 'required|string|max:255',
                'desc_seo' => 'required|string|max:255',
                'key_seo' => 'required|string|max:255',
                'status' => 'required|not_in:0',
                'image' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống'
            ],
            [
                'title' => 'Tên Hashtag',
                'url' => 'Đường Dẫn Thân Thiện',
                'meta_seo' => 'Tiêu đề seo',
                'desc_seo' => 'Mô tả seo',
                'key_seo' => 'Từ khóa seo',
                'status' => 'Trạng thái hiển thị',
                'image' => 'Hình Ảnh',

            ]
        );


        /* Hình ảnh */
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = 'song-thong-minh-' . $name_image . '-' . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/tag', $new_image);
        }


        Tag::create(
            [
                'title' => $request->title,
                'url' => $request->url,
                'meta_seo' => $request->meta_seo,
                'desc_seo' => $request->desc_seo,
                'key_seo' => $request->key_seo,
                'content' => $request->content ?? "",
                'weight' => $request->weight  ?? 0,
                'status' => $request->status,
                'image' => $new_image,
                'slug' => Str::slug($request->title),
                'num_list' => $request->num_list,
                'num_list_orther' => $request->num_list_orther,
            ]
        );
        return redirect()->back()->with('status', 'Thêm Hashtag thành công');
    }

    public function update(Request $request, $id)
    {
        $request->validate(
            [
                'title' => 'required|string|max:255',
                'url' => 'required|string|max:255',
                'meta_seo' => 'required|string|max:255',
                'desc_seo' => 'required|string|max:255',
                'key_seo' => 'required|string|max:255',
                'status' => 'required|not_in:0',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
                'nullable' => ':attribute không được để trống',
                'not_in' => ':attribute không được để trống'
            ],
            [
                'title' => 'Tên Hashtag',
                'url' => 'Đường Dẫn Thân Thiện',
                'meta_seo' => 'Tiêu đề seo',
                'desc_seo' => 'Mô tả seo',
                'key_seo' => 'Từ khóa seo',
                'status' => 'Trạng thái hiển thị',
            ]
        );


        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = $name_image . '-' . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/tag', $new_image);

            Tag::where('id', $id)->update(
                [
                    'title' => $request->title,
                    'url' => $request->url,
                    'meta_seo' => $request->meta_seo,
                    'desc_seo' => $request->desc_seo,
                    'key_seo' => $request->key_seo,
                    'content' => $request->content ?? "",
                    'weight' => $request->weight  ?? 0,
                    'status' => $request->status,
                    'image' => $new_image,
                    'slug' => Str::slug($request->title),
                    'num_list' => $request->num_list,
                    'num_list_orther' => $request->num_list_orther,
                ]
            );
        } else {
            Tag::where('id', $id)->update(
                [
                    'title' => $request->title,
                    'url' => $request->url,
                    'meta_seo' => $request->meta_seo,
                    'desc_seo' => $request->desc_seo,
                    'key_seo' => $request->key_seo,
                    'content' => $request->content ?? "",
                    'weight' => $request->weight  ?? 0,
                    'status' => $request->status,
                    'slug' => Str::slug($request->title),
                    'num_list' => $request->num_list,
                    'num_list_orther' => $request->num_list_orther,
                ]
            );
        }


        return redirect()->back()->with('status', 'Cập nhật Hashtag thành công');
    }

    public function delete($id)
    {
        Tag::where('id', $id)->delete();
        return redirect()->back()->with('status', 'Xóa Hashtag thành công');
    }




}
