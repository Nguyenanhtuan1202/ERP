<?php

namespace App\Http\Controllers\Admin;

use App\Components\Recusive;
use App\Exports\ProductExport;
use App\Http\Controllers\Controller;
use App\Imports\ProductImport;
use App\Models\Attribute;
use App\Models\Category;
use App\Models\Product;
use Carbon\Carbon;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

class ProductController extends Controller
{
    //

    private $category;
    public function __construct(Category $category)
    {

        $this->middleware(function ($request, $next) {
            session(['module_active' => 'product']);
            return $next($request);
        });
        $this->category = $category;
    }


    public function listProducts(Request $request)
    {
        $sku = $request->query('sku');
        $products = Product::where('sku', 'like', '%' . $sku . '%')->get();
        return response()->json($products);
    }

    public function add()
    {

        $htmlOption = $this->getCategory($parentId = "");
        $attributes = Attribute::with('values')->get();
        return view('product.add', compact('htmlOption', 'attributes'));
    }



    public function getCategory($parentId)
    {
        $data = $this->category->where('status', 1)->get();
        $recusive = new Recusive($data);
        $htmlOption =   $recusive->categoryRecusive($parentId);
        return $htmlOption;
    }
    public function list()
    {

        $data = Product::orderBy('updated_at', 'desc')->get();
        return view('product.list', compact('data'));
    }

    public function edit($id)
    {
        $data = Product::find($id);
        return view('product.edit', compact('data'));
    }

    public function save(Request $request)
    {

        if ($request->hasFile('images')) {
            $get_image = $request->file('images');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = 'appkimvn' . $name_image . '-' . rand(0, 999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/product', $new_image);
        }

        Product::create(
            [
                'name' => $request->name,
                'description' => $request->description,
                'images' => $new_image,
                'price' => $request->price,
                'unit' => $request->unit,
            ]
        );

        return redirect()->back()->with('status', 'Thêm sản phẩm thành công');
    }
    public function update(Request $request, $id)
    {
        $data =  Product::find($id);
        if ($request->hasFile('images')) {
            $get_image = $request->file('images');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = 'enic' . $name_image . '-' . rand(0, 999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/product', $new_image);
        } else {
            $new_image = $data->images;
        }


        Product::where('id', $id)->update(
            [
                'name' => $request->name,
                'images' => $new_image,
            ]
        );

        return redirect()->back()->with('status', 'Cập nhật sản phẩm thành công');
    }

    public function delete($id)
    {
        Product::where('id', $id)->delete();
        return redirect()->back()->with('status', 'Xoá sản phẩm thành công');
    }



    public function importExcel()
    {
        $data = Product::whereBetween('created_at', [
            Carbon::now()->subWeek(), // Ngày cách đây 1 tuần
            Carbon::now()             // Ngày hiện tại
        ])->orderBy('created_at', 'desc')->get();

        return view('product.viewImportExcel', compact('data'));
    }



    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new ProductImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên

            // Trả về dữ liệu JSON
            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }


    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0; // Biến đếm số lượng bản ghi mới được thêm
        $existingRecordsCount = 0; // Biến đếm số lượng bản ghi đã tồn tại

        if (empty($data) || !is_array($data)) {
            return redirect()->back()->with('error', 'Dữ liệu không hợp lệ hoặc trống.');
        }

        try {
            foreach ($data as $row) {
                if (empty($row['sku'])) {
                    continue; // Bỏ qua nếu SKU rỗng
                }

                // Kiểm tra nếu SKU đã tồn tại trong cơ sở dữ liệu
                $existingProduct = Product::where('sku', $row['sku'])->first();
                if ($existingProduct) {
                    $existingRecordsCount++; // SKU đã tồn tại, tăng biến đếm
                    continue;
                }

                // Nếu không tồn tại, tạo sản phẩm mới
                $dataDetail = new Product();
                $dataDetail->name = $row['name'] ?? '';
                $dataDetail->sku = $row['sku'] ?? '';
                $dataDetail->color = $row['color'] ?? '';
                $dataDetail->size = $row['size'] ?? '';
                $dataDetail->type = $row['type'] ?? '';
                $dataDetail->type2 = $row['type2'] ?? '';
                $dataDetail->material = $row['material'] ?? '';
                $dataDetail->tier = $row['tier'] ?? '';
                $dataDetail->tier_code = $row['tier_code'] ?? '';
                $dataDetail->style = $row['style'] ?? '';
                $dataDetail->style_code = $row['style_code'] ?? '';
                $dataDetail->weight = isset($row['weight']) && is_numeric($row['weight']) ? $row['weight'] : null;
                $dataDetail->price = isset($row['price']) && is_numeric($row['price']) ? $row['price'] : 0;
                $dataDetail->save(); // Lưu dữ liệu vào cơ sở dữ liệu
                $newRecordsCount++; // Tăng biến đếm cho bản ghi mới
            }

            // Xử lý thông báo kết quả
            if ($newRecordsCount > 0 && $existingRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm $newRecordsCount sản phẩm mới. Có $existingRecordsCount sản phẩm đã tồn tại!");
            } elseif ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công $newRecordsCount sản phẩm mới!");
            } elseif ($existingRecordsCount > 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', 'Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!');
            }
        } catch (\Exception $e) {
            // Ghi log lỗi (tùy chọn)
            Log::error('Lỗi khi lưu dữ liệu: ' . $e->getMessage());

            return back()->with('error', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }

    public function export()
    {
        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây
        $fileName = "Danh-sach-san-pham-{$currentDate}.xlsx"; // Tạo tên file
        return Excel::download(new ProductExport, $fileName);
    }
}
