<?php

namespace App\Http\Controllers\Admin;

use App\Exports\ForecastProductExport;
use App\Http\Controllers\Controller;
use App\Imports\ForecastProductImport;
use App\Models\ForecastProduct;
use App\Models\Notification;
use App\Models\ProductHistory;
use App\Models\Supplier;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

class ForecastProductController extends Controller
{
    //
    // Hiển thị danh sách ForecastProduct
    public function index()
    {
        // Lấy danh sách dự báo sản phẩm, kèm supplier nếu có, sắp xếp giảm dần theo ID và phân trang
        $forecastProducts = ForecastProduct::with('supplier')
            ->select([
                'id',
                'supplier_id',
                'product_name',
                'product_variant',
                'model_version',
                'sale_key',
                'sku',
                'price',
                'status'
            ])
            ->orderBy('status', 'desc')
            ->orderBy('id', 'asc')
            ->get();
        return view('forecast_products.index', compact('forecastProducts'));
    }

    // Hiển thị form thêm ForecastProduct mới
    public function create()
    {
        // Lấy danh sách supplier để hiển thị trong dropdown (nếu có)
        $suppliers = Supplier::all();
        return view('forecast_products.create', compact('suppliers'));
    }

    // Xử lý lưu dữ liệu ForecastProduct mới
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'product_name'      => 'required|string|max:255',
            'product_variant'   => 'nullable|string|max:255',
            'model_version'     => 'nullable|string|max:255',
            'color'             => 'nullable|string|max:100',
            'size'              => 'nullable|string|max:100',
            'sale_key'          => 'nullable|string|max:100',
            'sku'               => 'required|string|max:100|unique:forecast_product,sku',
            'supplier_id'       => 'nullable|exists:suppliers,id',
            'product_note'      => 'nullable|string',
            'sale_note'         => 'nullable|string',
            'image'             => 'nullable|url'
        ]);

        ForecastProduct::create($validatedData);

        return redirect()->route('forecast_products.index')
            ->with('success', 'Forecast product record created successfully.');
    }



    public function importExcel()
    {
        $data = ForecastProduct::whereBetween('created_at', [
            Carbon::now()->subWeek(), // Ngày cách đây 1 tuần
            Carbon::now()             // Ngày hiện tại
        ])->orderBy('created_at', 'desc')->get();

        return view('forecast_products.viewImportExcel', compact('data'));
    }

    public function uploadPreview(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);
        try {
            // Đọc dữ liệu từ file Excel
            $data = Excel::toArray(new ForecastProductImport, $request->file('file'));
            $rows = $data[0]; // Lấy sheet đầu tiên
            // Trả về dữ liệu JSON

            return response()->json(['success' => true, 'data' => $rows]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function ImportFileExcel(Request $request)
    {
        $data = $request->input('data'); // Dữ liệu từ request
        $newRecordsCount = 0; // Biến đếm số lượng bản ghi mới được thêm
        $existingRecordsCount = 0; // Biến đếm số lượng bản ghi đã tồn tại

        try {
            foreach ($data as $row) {
                // Kiểm tra nếu SKU\ đã tồn tại trong cơ sở dữ liệu
                $existingProduct = ForecastProduct::where('sku', $row['sku'])->first();
                if ($existingProduct) {
                    // SKU đã tồn tại, tăng biến đếm
                    $existingRecordsCount++;
                    continue;
                }
                // Nếu không tồn tại, tạo sản phẩm mới
                $dataDetail = new ForecastProduct();
                $dataDetail->supplier_id = $row['supplier_id'];
                $dataDetail->product_name = $row['product_name'];
                $dataDetail->product_variant = $row['product_variant'];
                $dataDetail->model_version = $row['model_version'];
                $dataDetail->color = $row['color'];
                $dataDetail->size = $row['size'];
                $dataDetail->sale_key = $row['sale_key'];
                $dataDetail->sku = $row['sku'];
                $dataDetail->product_note = $row['product_note'];
                $dataDetail->sale_note = $row['sale_note'];
                $dataDetail->image = $row['image'];
                $dataDetail->unit = $row['unit'];
                $dataDetail->price = $row['price'];
                $dataDetail->price_vn = $row['price_vn'];
                $dataDetail->length_cm = $row['length_cm'];
                $dataDetail->width_cm = $row['width_cm'];
                $dataDetail->height_cm = $row['height_cm'];
                $dataDetail->quantity_per_carton = $row['quantity_per_carton'];
                $dataDetail->cbm_per_ctn = $row['cbm_per_ctn'];
                $dataDetail->quantity_per_container = $row['quantity_per_container'];
                $dataDetail->freight_cost_per_cubic_meter = $row['freight_cost_per_cubic_meter'];
                $dataDetail->import_tax = $row['import_tax'];
                $dataDetail->additional_costs = $row['additional_costs'];
                $dataDetail->warehouse_price = $row['warehouse_price'];
                $dataDetail->selling_price = $row['selling_price'];
                $dataDetail->save(); // Lưu dữ liệu vào cơ sở dữ liệu
                $newRecordsCount++; // Tăng biến đếm cho bản ghi mới
            }

            if ($newRecordsCount > 0) {
                return redirect()->back()->with('success', "Đã thêm thành công $newRecordsCount bản ghi mới!");
            } elseif ($existingRecordsCount > 0 && $newRecordsCount === 0) {
                return redirect()->back()->with('success', "Tất cả sản phẩm đã tồn tại trong cơ sở dữ liệu. Không có bản ghi mới nào được thêm!");
            } else {
                return redirect()->back()->with('success', 'Dữ liệu không hợp lệ hoặc không có sản phẩm nào để thêm!');
            }
        } catch (\Exception $e) {

            dd($e->getMessage());

            return back()->with('success', 'Lỗi khi lưu dữ liệu: ' . $e->getMessage());
        }
    }

    public function export()
    {
        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây
        $fileName = "Danh-sach-san-pham-{$currentDate}.xlsx"; // Tạo tên file
        return Excel::download(new ForecastProductExport, $fileName);
    }


    public function updateStatus(Request $request)
    {
        $id = $request->id;
        $status = $request->status;

        try {
            // Tìm đơn hàng theo id (giả sử model Order đã được import)
            $forecastProduct = ForecastProduct::findOrFail($id);
            // Cập nhật trạng thái đơn hàng
            $forecastProduct->status = $status;
            $forecastProduct->save();

            // Chuyển hướng trở lại trang trước với thông báo thành công
            Notification::create([
                'user_id' => Auth::id(),
                'type' => 'update', // hoặc 'edit', 'add', 'message', ...
                'message' => 'Cập nhật trạng thái sản phẩm ' . $forecastProduct->sale_key  . " thành công",
            ]);
            return redirect()->back()->with('success', 'Trạng thái sản phẩm đã được cập nhật!');
        } catch (\Exception $e) {
            // Nếu có lỗi, chuyển hướng trở lại với thông báo lỗi
            return redirect()->back()->with('error', 'Có lỗi xảy ra: ' . $e->getMessage());
        }
    }


    public function edit($id)
    {
     
        $list_supplier = Supplier::where('status', 1)->orderBy('id', 'desc')->get();
        $forecastProduct  = ForecastProduct::findOrFail($id);
        // Lấy lịch sử chỉnh sửa, sắp xếp từ mới nhất
        $data['productHistories'] = ProductHistory::where('product_id', $forecastProduct->id)
            ->orderBy('changed_at', 'desc')
            ->with('user', 'product')  // Nếu muốn lấy thông tin người dùng
            ->get();
        // Tổng số lần chỉnh sửa
        $data['totalEdits'] = $data['productHistories']->count();
        // Chỉnh sửa gần nhất
        $data['latestEdit'] = $data['productHistories']->first();
        $data['latestEditTime'] = $data['latestEdit'] ? Carbon::parse($data['latestEdit']->changed_at)->diffForHumans() : null;
        return view('forecast_products.edit', compact('forecastProduct', 'list_supplier', 'data'));
    }


    public function update(Request $request, $id)
    {
        // Tìm sản phẩm
        $product = ForecastProduct::findOrFail($id);

        // Lưu các giá trị ban đầu
        $oldAttributes = $product->getOriginal();

        // Xử lý upload ảnh (nếu có)
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName();
            $name_image = current(explode('.', $get_name_image));
            $new_image = $name_image . rand(0, 99) . '.' . $get_image->getClientOriginalExtension();
            $get_image->move('public/uploads/forecast_products', $new_image);

            // Cập nhật tên ảnh
            $updateData = $request->all();
            $updateData['image'] = $new_image;
        } else {
            $updateData = $request->all();
        }

        // Cập nhật sản phẩm
        $product->update($updateData);

        // Lấy thuộc tính mới sau khi cập nhật
        $newAttributes = $product->fresh()->getAttributes();

        // Theo dõi thay đổi chi tiết
        $changeRecords = $product->trackDetailedChanges($oldAttributes, $newAttributes);

        // Lưu lịch sử thay đổi
        if (!empty($changeRecords)) {
            ProductHistory::insert($changeRecords);
        }

        return redirect()->back()->with('success', 'Cập nhật sản phẩm thành công!');
    }
}
