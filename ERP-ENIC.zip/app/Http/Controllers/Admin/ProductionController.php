<?php

namespace App\Http\Controllers\Admin;

use App\Events\NotifyEnic;
use App\Events\NotifyWareHousing;
use App\Http\Controllers\Controller;
use App\Models\CompletedProduct;
use App\Models\Delivery;
use App\Models\DeliveryDraft;
use App\Models\DeliveryReality;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use App\Models\SupplierDeliveryHistory;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Storage;

class ProductionController extends Controller
{
    //

    public function index(Request $request)
    {
        $status = $request->status;
        $id = $request->id;
        // ✅ Xác định ngày 7 ngày trước
        $sevenDaysAgo = Carbon::now()->subDays(7);


        // Lấy dữ liệu sản xuất trong ngày, tuần, tháng, năm
        $dayData = DeliveryReality::selectRaw('name, SUM(qty) as total_quantity')
            ->whereDate('created_at', Carbon::today())
            ->groupBy('name')
            ->get();

        $weekData = DeliveryReality::selectRaw('name, SUM(qty) as total_quantity')
            ->whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])
            ->groupBy('name')
            ->get();

        $monthData = DeliveryReality::selectRaw('name, SUM(qty) as total_quantity')
            ->whereMonth('created_at', Carbon::now()->month)
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('name')
            ->get();

        $yearData = DeliveryReality::selectRaw('name, SUM(qty) as total_quantity')
            ->whereYear('created_at', Carbon::now()->year)
            ->groupBy('name')
            ->get();


        // ✅ Tìm tất cả `purchase_order_id` đủ điều kiện (tất cả `quantity == qty_reality`)
        $ordersToUpdate = DB::table('purchase_order_items')
            ->select('purchase_order_id')
            ->groupBy('purchase_order_id')
            ->havingRaw('SUM(CASE WHEN quantity = qty_reality THEN 1 ELSE 0 END) = COUNT(*)') // Kiểm tra đủ số lượng
            ->pluck('purchase_order_id');

        // ✅ Cập nhật trạng thái `is_complete = 1` cho đơn hàng hợp lệ trong 7 ngày gần nhất
        DB::table('purchase_orders')
            ->whereIn('id', $ordersToUpdate)
            ->where('created_at', '>=', $sevenDaysAgo)
            ->update(['is_complete' => 1]);

        // ✅ Kiểm tra xác nhận sản xuất
        if ($status == 1 && $id) {
            $data = PurchaseOrder::find($id);

            if ($data) {
                PurchaseOrder::where('id', $id)->update([
                    'viewed' => 1,
                    'status' => 1,
                    'date_production' => Carbon::now()
                ]);

                // 🔔 Gửi thông báo xác nhận
                $notify = "Đơn hàng {$data->po_id} đã xác nhận sản xuất";
                event(new NotifyEnic($notify));

                return redirect()->back()->with('success', 'Xác nhận sản xuất thành công.');
            } else {
                return redirect()->back()->with('error', 'Không tìm thấy đơn hàng.');
            }
        }

        // ✅ Lấy danh sách đơn hàng của nhà cung cấp
        $purchaseOrders = PurchaseOrder::where('supplier_id', Auth::user()->supplier_id)
            ->orderBy('is_complete', 'asc')
            ->orderBy('prioritize', 'desc')
            ->orderBy('id', 'desc')
            ->get();
        return view('productions.index', compact('purchaseOrders', 'dayData', 'weekData', 'monthData', 'yearData'));
    }

    public function startProduction(Request $request)
    {
        // Validate the request data

        // Process each SKU and quantity
        foreach ($request->sku as $sku) {
            $quantity = $request->quantity[$sku];
            // Find the purchase order item by SKU
            $purchaseOrderItem = PurchaseOrderItem::where('sku', $sku)->where('purchase_order_id', $request->input('po_id'))->first();
            if ($purchaseOrderItem) {

                $purchaseOrderItem->production_date = $request->input('production_date');
                if ($purchaseOrderItem->products_production <= $purchaseOrderItem->quantity) {
                    $purchaseOrderItem->products_production += $quantity;
                }
                $purchaseOrderItem->status = 'Đang sản xuất';
                $purchaseOrderItem->save();

                // Tìm key_process hiện tại
                CompletedProduct::create([
                    'purchase_order_id' => $request->po_id,
                    'sku' => $sku,
                    'quantity_production' => $quantity,
                    'note' => '',
                    'quantity_completed' =>  0,
                    'status_delivery' =>  0,
                    'production_date' => $request->production_date,
                    'purchase_order_item_id' => $purchaseOrderItem->id
                ]);
            }
        }

        return redirect()->back()->with('success', 'Sản xuất đã được bắt đầu.');
    }




    public function updateQuantity(Request $request)
    {
        $productProduction = CompletedProduct::where('id', $request->c_id)->first();

        // Assuming you have a way to identify the specific SKU or item to update
        $sku = $request->input('sku'); // Adjust this according to your form data
        $quantity = $request->input('products_production');

        // Find the purchase order item by SKU
        $purchaseOrderItem = PurchaseOrderItem::where('sku', $sku)->where('purchase_order_id', $request->po_id)->first();

        if ($purchaseOrderItem) {
            // Update the quantity
            $purchaseOrderItem->qty_forecasting =  $purchaseOrderItem->quantity - $purchaseOrderItem->qty_reality - $quantity;
            $purchaseOrderItem->qty_reality =  $purchaseOrderItem->qty_reality + $quantity;


            if ($purchaseOrderItem->products_production > 0) {
                $purchaseOrderItem->products_production = $purchaseOrderItem->products_production -  $quantity;
            }


            $purchaseOrderItem->save();

            CompletedProduct::where('id', $request->c_id)->update([
                'quantity_completed' => $productProduction->quantity_completed + $quantity,
                'quantity_production' => $productProduction->quantity_production - $quantity,
                'completion_time' => now(),
                'note' => $request->note ?? ""
            ]);
            return  redirect()->back()->with('messageSuccess', 'Cập nhật thông tin thành công');
        }
    }



    /**
     * Cập nhật trạng thái viewed = 1 khi người dùng xem đơn hàng.
     */


    public function show($id, Request $request)
    {
        $sku = $request->sku;
        $purchaseOrderNew = PurchaseOrder::find($id);
        $data = PurchaseOrderItem::where('sku', $sku)->where('purchase_order_id', $id)->first();
        $purchaseOrder = PurchaseOrderItem::where('purchase_order_id', $id)->get();
        foreach ($purchaseOrder as $item) {
            if ($item->qty_forecasting == 0) {
                $item->status = "Đã hoàn thành";
                $item->save();
            }
        }
        $data_history_delivery = SupplierDeliveryHistory::with('purchaseOrder')->where('supplier_id', Auth::user()->supplier_id)->orderBy('id', 'desc')->get();

        return view('productions.show', compact('purchaseOrder', 'purchaseOrderNew', 'data_history_delivery'));
    }




    public function previewPDF($id, Request $request)
    {
        $purchaseOrderNew = PurchaseOrder::findOrFail($id);
        $purchaseOrder = PurchaseOrderItem::where('purchase_order_id', $id)->get();
        $data_history_delivery = SupplierDeliveryHistory::with('purchaseOrder')
            ->where('supplier_id', Auth::user()->supplier_id)
            ->orderBy('id', 'desc')
            ->get();

        // Tạo PDF từ view
        $pdf = Pdf::loadView('pdf.purchase_order', compact('purchaseOrder', 'purchaseOrderNew', 'data_history_delivery'));

        // Hiển thị file PDF trong trình duyệt (chọn Print hoặc Save)
        return $pdf->stream('Don-Hang-' . ($purchaseOrderNew->total_quantity ?? "") . '.pdf');
    }


    /* Xử lý giao hàng từ xưởng qua kho tối ưu trong 1 bước */
    public function factoryDelivery(Request $request)
    {



        $supplier_id =    Auth::user()->supplier_id;
        $supplier_name = Auth::user()->name;

        // Khai báo mảng tích lũy các item giao hàng của supplier (cho lịch sử)
        $supplierDeliveryItems = [];

        // --- Xử lý lưu ảnh dưới dạng file --- //
        $uploadedImages = [];
        // 1. Xử lý file ảnh từ input "images[]" (nhiều ảnh)
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                // Lấy tên gốc của file và tách phần tên (không bao gồm extension)
                $originalName = $file->getClientOriginalName();
                $name = pathinfo($originalName, PATHINFO_FILENAME);
                $extension = $file->getClientOriginalExtension();
                // Tạo tên file mới với tiền tố 'enic' và một số ngẫu nhiên
                $newImageName = 'enic' . $name . '-' . rand(0, 9999) . '.' . $extension;
                // Di chuyển file ảnh vào thư mục public/uploads/delivery
                $file->move(public_path('uploads/delivery'), $newImageName);
                // Lưu đường dẫn tương đối
                $uploadedImages[] = 'uploads/delivery/' . $newImageName;
            }
        }

        // 2. Xử lý ảnh từ camera (nếu có, dạng base64)
        if ($request->filled('imageData')) {
            $imageData = $request->input('imageData');
            // Loại bỏ tiền tố "data:image/png;base64," nếu có
            if (strpos($imageData, 'base64,') !== false) {
                $imageData = explode('base64,', $imageData)[1];
            }
            $decodedImage = base64_decode($imageData);
            $newFileName = 'enic-' . rand(0, 99) . uniqid() . '.png';
            // Lưu file vào thư mục public/uploads/delivery sử dụng file_put_contents
            file_put_contents(public_path('uploads/delivery/') . $newFileName, $decodedImage);
            $uploadedImages[] = 'uploads/delivery/' . $newFileName;
        }

        // Chuyển mảng ảnh thành chuỗi JSON (nếu có ảnh)
        $imagesPaths = !empty($uploadedImages) ? json_encode($uploadedImages, JSON_UNESCAPED_SLASHES) : null;

        // --- 3 Xử lý phần giao bổ sung (additional_data) ---
        $additionalData = $request->input('additional_data', []);
        if ($additionalData) {
            $completeAdditionalData = array_filter($additionalData, function ($item) {
                return isset($item['purchase_order_id'], $item['sku'], $item['qty_product_delivery'])
                    && !empty($item['purchase_order_id'])
                    && !empty($item['sku'])
                    && !empty($item['qty_product_delivery']);
            });
            foreach ($completeAdditionalData as $data) {
                $data_product = Product::where('sku', $data['sku'])->first();
                // Tìm DeliveryDraft với sku được chuyển thành chữ hoa
                $deliveryDraft = DeliveryDraft::where('purchase_order_id', $data['purchase_order_id'])
                    ->where('sku', strtoupper($data['sku']))
                    ->first();
                if ($deliveryDraft) {

                    $deliveryDraft->update([
                        'status_delivery' => 1
                    ]);
                    // Nếu đã tồn tại, cập nhật status_delivery
                    DeliveryDraft::create([
                        'purchase_order_id' => $data['purchase_order_id'],
                        'sku'               => strtoupper($data['sku']),
                        'name'              => $data_product->name ?? "",
                        'qty_more'          => $data['qty_product_delivery'],
                        'note'              => $data['note'] ?? null,
                        'important_note'    => "Xưởng giao thêm",
                        'date_delivery'     => now(),
                        'status'            => 0,
                        'status_delivery'   => 0,
                        'images'            => $imagesPaths,
                        'supplier_id'       => $supplier_id
                    ]);
                } else {
                    // Nếu chưa tồn tại, tạo mới
                    DeliveryDraft::create([
                        'purchase_order_id' => $data['purchase_order_id'],
                        'sku'               => strtoupper($data['sku']),
                        'name'              => $data_product->name ?? "",
                        'qty_more'          => $data['qty_product_delivery'],
                        'note'              => $data['note'] ?? null,
                        'important_note'    => "Xưởng giao thêm| Bổ sung",
                        'date_delivery'     => now(),
                        'status'            => 0,
                        'status_delivery'   => 0,
                        'images'            => $imagesPaths,
                        'supplier_id'       => $supplier_id
                    ]);
                }

                // Lưu thông tin giao hàng bổ sung vào mảng lịch sử
                $supplierDeliveryItems[] = [
                    'purchase_order_id' => $data['purchase_order_id'],
                    'sku'               => strtoupper($data['sku']),
                    'delivered_qty'     => (int) $data['qty_product_delivery'],
                    'note'              => $data['note'] ?? null,
                    'important_note'    => "Xưởng giao thêm",
                ];
            }
        }

        // --- 4 Xử lý phần giao hàng chính (data) ---
        $dataMain = $request->input('data', []);
        if (empty($dataMain)) {
            return redirect()->back()->with('error', 'Không có dữ liệu giao hàng để cập nhật.');
        }

        DB::beginTransaction();
        try {
            foreach ($dataMain as $sku => $item) {
                if (!is_null($item['qty_product_delivery']) && trim($item['qty_product_delivery']) !== '') {
                    $deliveryDraft = DeliveryDraft::where('purchase_order_id', $item['purchase_order_id'])
                        ->where('sku', strtoupper($item['sku']))
                        ->first();

                    /* Cập nhật trạng thái các sản phẩm đang giao ( các sản phẩm đang giao từ xưởng qua kho sẽ có is_delivery == 1) */
                    $production_delivery = PurchaseOrderItem::where('purchase_order_id', $item['purchase_order_id'])
                        ->where('sku', strtoupper($item['sku']))
                        ->first();
                    if ($production_delivery) {
                        $production_delivery->update([
                            'is_delivery' => 1
                        ]);
                    }

                    if ($deliveryDraft) {
                        $deliveryDraft->update([
                            'status_delivery' => 1
                        ]);
                        DeliveryDraft::create([
                            'name'              => $item['name'],
                            'order_quantity'    => $item['order_quantity'],
                            'purchase_order_id' => $item['purchase_order_id'],
                            'qty'               => $item['qty_product_delivery'],
                            'sku'               => strtoupper($item['sku']),
                            'date_delivery'     => now(),
                            'status'            => 0,
                            'status_delivery'   => 0,
                            'images'            => $imagesPaths,
                            'supplier_id'       => $supplier_id
                        ]);
                    } else {
                        DeliveryDraft::create([
                            'name'              => $item['name'],
                            'order_quantity'    => $item['order_quantity'],
                            'purchase_order_id' => $item['purchase_order_id'],
                            'qty'               => $item['qty_product_delivery'],
                            'sku'               => strtoupper($item['sku']),
                            'date_delivery'     => now(),
                            'status'            => 0,
                            'status_delivery'   => 0,
                            'images'            => $imagesPaths,
                            'supplier_id'       => $supplier_id
                        ]);
                    }

                    // Lưu thông tin giao hàng chính vào mảng lịch sử
                    $supplierDeliveryItems[] = [
                        'purchase_order_id' => $item['purchase_order_id'],
                        'sku'               => strtoupper($item['sku']),
                        'delivered_qty'     => (int) $item['qty_product_delivery'],
                        'name'              => $item['name'],
                    ];
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Có lỗi xảy ra: ' . $e->getMessage());
        }



        // --- 4. Tạo lịch sử giao hàng cho supplier --- //
        // Tính tổng số lượng giao hàng
        $totalDeliveredQty = array_reduce($supplierDeliveryItems, function ($carry, $item) {
            return $carry + $item['delivered_qty'];
        }, 0);
        // Lấy purchase_order_id đầu tiên (nếu có)
        $firstPurchaseOrderId = isset($supplierDeliveryItems[0]['purchase_order_id']) ? $supplierDeliveryItems[0]['purchase_order_id'] : null;

        SupplierDeliveryHistory::create([
            'supplier_id'       => $supplier_id,
            'purchase_order_id' => $firstPurchaseOrderId,
            'sku_details'       => json_encode($supplierDeliveryItems, JSON_UNESCAPED_SLASHES),
            'total_qty'         => $totalDeliveredQty,
            'notes'             => "Đơn hàng giao từ xưởng {$supplier_name} vào lúc: " . now()->format('d-m-Y | H:i'),
        ]);

        // 5 Gửi thông báo cho kho
        $notifyWareHousing = "Bạn có đơn hàng giao từ xưởng : " . $supplier_name  . " " . date('d-m-Y | H:i', strtotime(now()));
        event(new NotifyWareHousing($notifyWareHousing));

        // 6 Gửi thông báo cho bên liên quan
        $notifyEnic = "Xưởng " . $supplier_name . " vừa xuất Đơn Hàng vào lúc: " . date('d-m-Y | H:i', strtotime(now()));
        event(new NotifyEnic($notifyEnic));

        return redirect()->back()->with('success', 'Đã gửi thông tin xuất hàng thành công!');
    }



    public function delivery(Request $request)
    {
        $date = $request->date;
        if ($date) {
            $data = DeliveryReality::with('purchaseOrder', 'productSku', 'supplier')
                ->whereDate('date_received', $date) // So sánh chỉ phần ngày
                ->where('supplier_id', Auth::user()->supplier_id)
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        } else {

            $sevenDaysAgo = Carbon::now()->subDays(7);
            $data = DeliveryReality::with('purchaseOrder', 'productSku', 'supplier')->where('supplier_id', Auth::user()->supplier_id)->where('date_received', '>=', $sevenDaysAgo)
                ->orderBy('id', 'asc')
                ->get()
                ->groupBy('purchase_order_id');
        }
        return view('productions.delivery', compact('data'));
    }
}
