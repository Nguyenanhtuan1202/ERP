<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\WarehousingManager;
use App\Models\Warehouse;
use Illuminate\Support\Facades\Hash;

class WarehousingManagerController extends Controller
{
    //


    public function index()
    {
        $data = User::where('ware_housing', 1)->orderBy('id', 'desc')->get();
        return view('warehousingManager.index', compact('data'));
    }

    public function create()
    {

        return view('warehousingManager.create');
    }

    public function save(Request $request)
    {

        $request->validate(
            [
                'username' => 'required|string|max:255',
                'email' => 'required|string|max:255',
                'password' => 'required|string|max:255',
                'phone' => 'required|string|max:255',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'username' => 'Họ Và Tên',
                'email' => 'Email',
                'password' => 'Mật Khẩu',
                'phone' => 'Số Điện Thoại',
            ]
        );;


        $checkEmail = User::where('email', $request->email)->first();
        if ($checkEmail) {
            return redirect()->back()->with('error', 'Email đã tồn tại vui lòng kiểm tra lại!');
        }

        User::create(
            [
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
                'password' => Hash::make($request->password ?? ""),
                'ware_housing' => 1
            ]
        );
        return redirect()->back()->with('success', 'Thêm thành viên thành công!');
    }

    public function edit($id)
    {
        $data = User::find($id);
        return view('warehousingManager.edit', compact('data'));
    }
    public function delete($id)
    {

        User::find($id)->delete();
        return redirect()->back()->with('success', 'Xoá user thành công!');
    }

    public function update($id, Request $request)
    {

        if ($request->password == "" || $request->password == NULL) {
            User::where('id', $id)->update([
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
            ]);
        } else {
            User::where('id', $id)->update([
                'name' => $request->username ?? "",
                'email' => $request->email ?? "",
                'phone' => $request->phone ?? "",
                'password' => Hash::make($request->password ?? ""),
            ]);
        }

        return redirect()->back()->with('success', 'Cập nhật dữ liệu thành công!');
    }
}
