<?php



namespace App\Http\Controllers\Admin;



use App\Http\Controllers\Controller;

use App\Models\ListExpert;

use Carbon\Carbon;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Exports\ExcelExport;

use App\Exports\ListCancelExpertExport;

use App\Exports\ListExpertExport;

use App\Models\Attendance;

use App\Models\LearningProcess;

use Excel;

use Maatwebsite\Excel\Facades\Excel as FacadesExcel;



class ExpertController extends Controller

{

    //





    public function __construct()

    {



        $this->middleware(function ($request, $next) {

            session(['module_active' => 'expert']);

            return $next($request);

        });

    }





    public function add()

    {

        return view('expert.add');

    }





    public function list()

    {



        $data['list_expert'] = ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'admin_approve' => 1])->orderBy('id_hs', 'asc')->get();

        $maleCount = ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'admin_approve' => 1])

            ->where('gender', 1)

            ->count();



        $femaleCount = ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'admin_approve' => 1])

            ->where('gender', 2)

            ->count();





        $data['male'] = $maleCount;

        $data['female'] = $femaleCount;



        $data['list_expert_basic'] =  ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'level' => 1, 'admin_approve' => 1])->orderBy('updated_at', 'desc')->get();



        $data['list_expert_basic_count'] = $data['list_expert_basic']->count();





        $data['list_expert_advance'] =  ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'level' => 2, 'admin_approve' => 1])->orderBy('updated_at', 'desc')->get();



        $data['list_expert_advance_count'] = $data['list_expert_advance']->count();





        $data['list_expert_diamond'] =  ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'level' => 3, 'admin_approve' => 1])->orderBy('updated_at', 'desc')->get();



        $data['list_expert_diamond_count'] = $data['list_expert_diamond']->count();







        return view('expert.list', compact('data'));

    }



    public function edit($id)

    {

        $data = ListExpert::find($id);

        return view('expert.edit', compact('data'));

    }



    public function show($id)

    {

        $data =  ListExpert::find($id);



        foreach ($data->attendances as $attendance) {

            $attendance->formatted_date = Carbon::parse($attendance->checkin)

                ->locale('vi')

                ->isoFormat('dddd, DD-MM-YYYY, HH:mm:ss');

        }





        $data['listLearningProcess'] = "";



        if ($data->learningprocess->count() > 0) {



            $data['listLearningProcess'] = $data->learningprocess;

        }



        return view('expert.show', compact('data'));

    }





    public function save(Request $request)

    {

        if ($request->hasFile('cccd_front')) {

            $get_image = $request->file('cccd_front');

            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */

            $new_image = 'kimvnhome' . $name_image . '-' . rand(0, 999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image->move('public/uploads/expert', $new_image);

        }



        if ($request->hasFile('cccd_back')) {

            $get_image1 = $request->file('cccd_back');

            $get_name_image1 = $get_image1->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image1 = current(explode('.', $get_name_image1)); /* Tách chuỗi */

            $new_image1 = 'kimvnhome' . $name_image1 . '-' . rand(0, 999) . '.' . $get_image1->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image1->move('public/uploads/expert', $new_image1);

        }



        if ($request->hasFile('profile_picture')) {

            $get_image2 = $request->file('profile_picture');

            $get_name_image2 = $get_image2->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image2 = current(explode('.', $get_name_image2)); /* Tách chuỗi */

            $new_image2 = 'kimvnhome' . $name_image2 . '-' . rand(0, 999) . '.' . $get_image2->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image2->move('public/uploads/expert', $new_image2);

        }







        if ($request->hasFile('file_contract')) {

            $get_filedoc = $request->file('file_contract');

            $get_name_filedoc = $get_filedoc->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_filedoc = current(explode('.', $get_name_filedoc)); /* Tách chuỗi */

            $new_filedoc = 'appquanly' . $name_filedoc . '-' . $request->id_hs . '.' . $get_filedoc->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_filedoc->move('public/uploads/expert', $new_filedoc);

        }



        $request->validate([



            'id_hs' => 'required', // Giả sử bạn có thêm trường id_hs

        ]);



        // Kiểm tra điều kiện tùy chỉnh

        $check_id_hs = $request->id_hs;

        $count_id_hs = ListExpert::where('id_hs', $check_id_hs)->count();



        if ($count_id_hs > 0) {

            return redirect()->back()->with('error', 'Mã học viên đã bị trùng vui lòng kiểm tra lại !!!');

        }



        ListExpert::create(



            [

                'id_hs' => $request->id_hs,

                'fullname' => $request->fullname,

                'class' => $request->class,

                'phone' => $request->phone,

                'email' => $request->email,

                'address' => $request->address,

                'cccd' => $request->cccd,

                'date_cccd' => $request->date_cccd,

                'issued_by' => $request->issued_by,

                'dob' => $request->dob,

                'bank_name' => $request->bank_name,

                'bank_account' => $request->bank_account,

                'bank_name_account' => $request->bank_name_account,

                'introducer' => $request->introducer,

                'cccd_front' => $new_image,

                'cccd_back' => $new_image1,

                'profile_picture' => $new_image2,

                'level' => $request->level,

                'date_join' => $request->date_join,

                'vest' => $request->vest,

                'file_contract' => $new_filedoc  ?? "",

                'date_approve' => now(),

                'status' => 1,

                'book1' => $request->book1 ?? "0",

                'book2' => $request->book2 ?? "0",

                'book3' => $request->book3 ?? "0",

                'book4' => $request->book4 ?? "0",

                'water' => $request->water ?? "0",

                'uniform' => $request->uniform ?? "0",

                'brochure' => $request->brochure ?? "0",

                'user_admin' => Auth::user()->name . '-Time:' . now(),

                'gender' => $request->gender,

                'admin_approve' => Auth::user()->role[0]->id  == 11 ? 0 : 1,

            ]

        );





        if (Auth::user()->role[0]->id == 11) {

            return redirect()->back()->with('status', 'Thông tin đang được duyệt');

        } else {

            return redirect()->back()->with('status', 'Đã cập nhật thông tin thành công vào hệ thống');

        }

    }



    public function update(Request $request, $id)

    {

        $data =  ListExpert::find($id);



        if ($request->hasFile('cccd_front')) {

            $get_image = $request->file('cccd_front');

            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */

            $new_image = 'kimvnhome' . $name_image . '-' . rand(0, 999) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image->move('public/uploads/expert', $new_image);

        } else {

            $new_image = $data->cccd_front;

        }



        if ($request->hasFile('cccd_back')) {

            $get_image1 = $request->file('cccd_back');

            $get_name_image1 = $get_image1->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image1 = current(explode('.', $get_name_image1)); /* Tách chuỗi */

            $new_image1 = 'kimvnhome' . $name_image1 . '-' . rand(0, 999) . '.' . $get_image1->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image1->move('public/uploads/expert', $new_image1);

        } else {

            $new_image1 = $data->cccd_back;

        }



        if ($request->hasFile('profile_picture')) {

            $get_image2 = $request->file('profile_picture');

            $get_name_image2 = $get_image2->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image2 = current(explode('.', $get_name_image2)); /* Tách chuỗi */

            $new_image2 = 'kimvnhome' . $name_image2 . '-' . rand(0, 999) . '.' . $get_image2->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image2->move('public/uploads/expert', $new_image2);

        } else {

            $new_image2 = $data->profile_picture;

        }







        if ($request->hasFile('file_contract')) {

            $get_filedoc = $request->file('file_contract');

            $get_name_filedoc = $get_filedoc->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_filedoc = current(explode('.', $get_name_filedoc)); /* Tách chuỗi */

            $new_filedoc = 'appkimvnhome-' . $name_filedoc . '-' . $request->id_hs . '.' . $get_filedoc->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_filedoc->move('public/uploads/expert', $new_filedoc);

        } else {

            $new_filedoc = $data->file_contract;

        }





        // $check_id_hs = $request->id_hs;

        // $count_id_hs = ListExpert::where('id_hs', $check_id_hs)->count();



        // if ($count_id_hs > 0) {

        //     return redirect()->back()->with('error', 'Mã học viên đã bị trùng vui lòng kiểm tra lại !!!');

        // }









        ListExpert::where('id', $id)->update(

            [

                'id_hs' => $request->id_hs,

                'fullname' => $request->fullname,

                'class' => $request->class,

                'phone' => $request->phone,

                'email' => $request->email,

                'address' => $request->address,

                'cccd' => $request->cccd,

                'date_cccd' => $request->date_cccd,

                'issued_by' => $request->issued_by,

                'dob' => $request->dob,

                'bank_name' => $request->bank_name,

                'bank_account' => $request->bank_account,

                'bank_name_account' => $request->bank_name_account,

                'introducer' => $request->introducer,

                'cccd_front' => $new_image,

                'cccd_back' => $new_image1,

                'profile_picture' => $new_image2,

                'level' => $request->level,

                'date_join' => $request->date_join,

                'vest' => $request->vest,

                'file_contract' => $new_filedoc,

                'date_approve' => $data->date_approve ??  now(),

                'status' => 1,

                'book1' => $request->book1 ?? "0",

                'book2' => $request->book2 ?? "0",

                'book3' => $request->book3 ?? "0",

                'book4' => $request->book4 ?? "0",

                'water' => $request->water ?? "0",

                'uniform' => $request->uniform ?? "0",

                'brochure' => $request->brochure ?? "0",

                'user_admin' => $data->user_admin . ' | ' . Auth::user()->name . '-Time:' . now(),

                'gender' => $request->gender,

                'admin_approve' => Auth::user()->role[0]->id  == 11 ? 0 : 1,

            ]

        );



        if (Auth::user()->role[0]->id == 11) {

            return redirect()->back()->with('status', 'Thông tin đang được duyệt');

        } else {

            return redirect()->back()->with('status', 'Đã cập nhật thông tin thành công vào hệ thống');

        }

    }





    public function cancel($id)

    {





        ListExpert::where('id', $id)->update(

            [

                'cancel_contract' => 1,

                'date_cancel_contract' => now()

            ]

        );



        return redirect()->back()->with('status', 'Đã chuyển vào danh sách huỷ hợp đồng');

    }





    public function listCancel()

    {

        $data = ListExpert::where(['status' => 1, 'cancel_contract' => 1, 'admin_approve' => 1])->orderBy('updated_at', 'desc')->get();

        return view('expert.listCancel', compact('data'));

    }





    public function restore($id)

    {

        ListExpert::where('id', $id)->update(

            [

                'cancel_contract' => 0,

                'date_cancel_contract' => Null

            ]

        );



        return redirect()->back()->with('status', 'Đã khôi phục hồ sơ. Và chuyển về danh sách chuyên gia.');

    }







    public function delete($id)

    {

        $data = ListExpert::find($id);

        Attendance::where('id_hs', $data->id_hs)->delete();

        LearningProcess::where('id_hs', $data->id_hs)->delete();

        ListExpert::where('id', $id)->delete();

        return redirect()->back()->with('status', 'Xoá thành công hồ sơ.');

    }





    public function formRegister()

    {

        return view('expert.formRegister');

    }



    public function SaveFormRegister(Request $request)

    {

        if ($request->hasFile('cccd_front')) {

            $get_image = $request->file('cccd_front');

            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */

            $new_image = 'appkimvnhome-' . $name_image . '-' . rand(0, 9) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image->move('public/uploads/expert', $new_image);

        }



        if ($request->hasFile('cccd_back')) {

            $get_image1 = $request->file('cccd_back');

            $get_name_image1 = $get_image1->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image1 = current(explode('.', $get_name_image1)); /* Tách chuỗi */

            $new_image1 = 'appkimvnhome-' . $name_image1 . '-' . rand(0, 9) . '.' . $get_image1->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image1->move('public/uploads/expert', $new_image1);

        }



        if ($request->hasFile('profile_picture')) {

            $get_image2 = $request->file('profile_picture');

            $get_name_image2 = $get_image2->getClientOriginalName(); /* Lấy tên của hình ảnh */

            $name_image2 = current(explode('.', $get_name_image2)); /* Tách chuỗi */

            $new_image2 = 'appkimvnhome-' . $name_image2 . '-' . rand(0, 9) . '.' . $get_image2->getClientOriginalExtension(); /* Đuôi mở rộng */

            $get_image2->move('public/uploads/expert', $new_image2);

        }





        ListExpert::create(

            [

                'fullname' => $request->fullname,

                'phone' => $request->phone,

                'email' => $request->email,

                'address' => $request->address,

                'cccd' => $request->cccd,

                'date_cccd' => $request->date_cccd,

                'dob' => $request->dob,

                'bank_name' => $request->bank_name,

                'bank_account' => $request->bank_account,

                'bank_name_account' => $request->bank_name_account,

                'introducer' => $request->introducer,

                'cccd_front' => $new_image,

                'cccd_back' => $new_image1,

                'profile_picture' => $new_image2,

                'status' => 1,

                'date_join' => now()->format('Y-m-d'),

                'gender' => 1,



            ]

        );

        return view('expert.Success');

    }





    public function updateId(Request $request, $id)

    {



        // Kiểm tra điều kiện tùy chỉnh

        $check_id_hs = $request->id_hs;

        $count_id_hs = ListExpert::where('id_hs', $check_id_hs)->count();



        if ($count_id_hs > 0) {

            return redirect()->back()->with('error', 'Mã học viên đã bị trùng vui lòng kiểm tra lại !!!');

        } else {



            ListExpert::where('id', $id)->update(

                [

                    'id_hs' => $request->id_hs

                ]

            );

            return redirect()->back()->with('status', 'Cập Nhật ID Chuyên Gia Thành Công. ');

        }

    }



    public function export()

    {

        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây

        $fileName = "Danh-sach-chuyen-gia-ngay-{$currentDate}.xlsx"; // Tạo tên file

        return FacadesExcel::download(new ListExpertExport, $fileName);

    }



    public function cancelExport()

    {

        $currentDate = date('d-m-Y_H-i'); // Định dạng ngày giờ hiện tại: ngày-tháng-năm_giờ-phút-giây

        $fileName = "Danh-sach-chuyen-gia-huy-hop-dong-ngay-{$currentDate}.xlsx"; // Tạo tên file

        return FacadesExcel::download(new ListCancelExpertExport, $fileName);

    }





    public function saveProcessLearn(Request $request)

    {

        // Lấy và làm sạch dữ liệu từ request

        $studentId = $this->sanitize($request->input('id_hs'));

        $name = $this->sanitize($request->input('fullname'));



        // Chuyển đổi tên học viên thành chữ thường và loại bỏ dấu

        $normalizedStudentName = $this->normalizeString($name);



        // Kiểm tra học sinh tồn tại

        $student = ListExpert::where('id_hs', $studentId)->first();



        if (!$student) {

            return redirect()->back()->with('error', 'Mã học viên không tồn tại !!!');

        }



        // Kiểm tra tên học viên có khớp không

        if ($this->normalizeString($student->fullname) != $normalizedStudentName) {

            return redirect()->back()->with('error', 'Tên học viên không khớp với mã học viên !!!');

        }



        // Lưu quá trình học tập

        LearningProcess::create([

            'fullname' => $name,

            'id_hs' => $studentId,

            'test' => $request->input('test'),

            'test_date' => $request->input('test_date'),

            'test_score' => $request->input('test_score'),

            'note' => $request->input('note'),

        ]);



        return redirect()->back()->with('status', 'Thêm quá trình học tập thành công.');

    }



    // Hàm làm sạch dữ liệu

    private function sanitize($input)

    {

        // Loại bỏ khoảng trắng thừa và các ký tự đặc biệt

        $input = trim($input); // Loại bỏ khoảng trắng ở đầu và cuối

        return $input;

    }



    // Hàm chuẩn hóa chuỗi

    private function normalizeString($string)

    {

        // Chuyển đổi thành chữ thường và loại bỏ dấu

        $string = mb_strtolower($string, 'UTF-8');

        $string = preg_replace('/\p{Mn}/u', '', $string); // Loại bỏ dấu

        return $string;

    }







    public function approve($id)

    {

        ListExpert::where('id', $id)->update(

            [

                'admin_approve' => 1,

            ]

        );

        return redirect()->back()->with('status', 'Đã duyệt thành công hồ sơ');

    }

}

