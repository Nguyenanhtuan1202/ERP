<?php

namespace App\Http\Controllers\Admin;

use App\Events\NotifyProcessed;
use App\Exports\PurchaseOrderItemExport;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use App\Models\Supplier;
use Carbon\Carbon;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Notification;
use App\Notifications\TelegramNotification;
use Illuminate\Support\Facades\Notification as FacadesNotification;

class PurchaseOrderController extends Controller
{
    //




    // Thêm phương thức này vào PurchaseOrderController
    public function calculateExpectedDate(Request $request)
    {
        try {
            // Validate dữ liệu đầu vào
            $validated = $request->validate([
                'factory_capacity' => 'required|integer|min:1',
                'current_order_quantity' => 'required|integer|min:1',
                'prioritize' => 'boolean'
            ]);

            $factoryCapacity = $validated['factory_capacity']; // Công suất xưởng (sản phẩm/ngày)
            $currentOrderQuantity = $validated['current_order_quantity']; // Số lượng sản phẩm trong đơn hàng hiện tại
            $isPrioritized = $validated['prioritize'] == 1; // Có phải đơn hàng ưu tiên hay không

            // 1. Lấy tất cả các đơn hàng chưa hoàn thành (is_complete = false)
            $pendingOrders = PurchaseOrder::where('is_complete', 0)
                ->orderBy('expected_date', 'asc') // Ưu tiên đơn hàng cần về sớm
                ->with(['items' => function ($query) {
                    $query->selectRaw('purchase_order_id, SUM(quantity) as total_quantity, SUM(qty_reality) as total_reality');
                    $query->groupBy('purchase_order_id');
                }])
                ->get();

            // 2. Tính tổng số lượng sản phẩm cần sản xuất
            $totalRemainingQuantity = 0;
            $detailedInfo = [];

            foreach ($pendingOrders as $order) {
                if (!$order->items->isEmpty()) {
                    $orderQuantity = $order->items->sum('total_quantity');
                    $orderReality = $order->items->sum('total_reality') ?? 0;
                    $remaining = $orderQuantity - $orderReality;

                    if ($remaining > 0) {
                        $totalRemainingQuantity += $remaining;
                        $detailedInfo[] = [
                            'po_id' => $order->po_id,
                            'expected_date' => $order->expected_date,
                            'remaining' => $remaining
                        ];
                    }
                }
            }

            // 3. Tính số ngày cần để hoàn thành các đơn hàng trong hàng đợi
            $daysNeeded = ceil($totalRemainingQuantity / $factoryCapacity);

            // 4. Nếu là đơn hàng ưu tiên, giảm 1/3 thời gian chờ (tối thiểu 1 ngày)
            if ($isPrioritized) {
                $daysNeeded = max(1, ceil($daysNeeded * 2 / 3));
            }

            // 5. Tính số ngày cần để sản xuất đơn hàng hiện tại
            $currentOrderDays = ceil($currentOrderQuantity / $factoryCapacity);

            // 6. Tính tổng số ngày cần
            $totalDays = $daysNeeded + $currentOrderDays;

            // 7. Tính ngày dự kiến hoàn thành
            $expectedDate = Carbon::now()->addDays($totalDays)->format('Y-m-d');

            // Chuẩn bị thông điệp chi tiết
            $messageDetails = "Hiện có " . count($detailedInfo) . " đơn hàng chưa hoàn thành với tổng " .
                number_format($totalRemainingQuantity) . " sản phẩm cần sản xuất. ";
            $messageDetails .= "Với công suất " . number_format($factoryCapacity) . " sản phẩm/ngày, ";
            $messageDetails .= "đơn hàng của bạn sẽ được hoàn thành trong khoảng " . $totalDays . " ngày.";

            return response()->json([
                'success' => true,
                'expected_date' => $expectedDate,
                'message' => $messageDetails
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }





    /* Tổng Đơn Hàng Đặt Hàng */

    public function showOrderItems()
    {
        // Lấy tất cả các đơn hàng chưa hoàn thành (is_complete == 0)
        // Ví dụ: Lấy tất cả đơn hàng chưa hoàn thành và eager load các items
        $orders = PurchaseOrder::with('items.purchaseOrder')->orderBy('is_complete', 'asc')->get();
        // Nếu bạn muốn lấy tất cả các order items từ các đơn hàng này:
        $orderItems = $orders->pluck('items')->flatten();
        return view('purchase_orders.allitems', compact('orderItems'));
    }


    public function filter(Request $request)
    {
        $filter = $request->input('filter', 'all');
        $month = $request->input('month', null);

        if ($filter === 'custom_month' && !empty($month)) {
            // Lọc đơn hàng theo tháng được chọn trong năm hiện tại (hoặc thêm year nếu cần)
            $orders = PurchaseOrder::with('items')
                ->whereMonth('created_at', $month)
                ->orderBy('is_complete', 'asc')
                ->get();
        } else {
            // Xử lý các bộ lọc khác
            $query = PurchaseOrder::with('items')->orderBy('is_complete', 'asc')->orderBy('expected_date', 'desc');

            switch ($filter) {
                case 'day':
                    $query->whereDate('created_at', Carbon::today());
                    break;
                case 'week':
                    $query->whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()]);
                    break;
                case 'month':
                    $query->whereBetween('created_at', [Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth()]);
                    break;
                default:
                    // Tất cả đơn hàng, không cần thêm điều kiện
                    break;
            }
            $orders = $query->get();
        }

        // Lấy tất cả order items từ các đơn hàng
        $orderItems = $orders->pluck('items')->flatten();

        // Trả về view partial hiển thị bảng order items

        // Render view con chứa table (có thể là một view riêng ví dụ: orders/partials/items_table.blade.php)
        return view('purchase_orders.items_table', compact('orderItems'));
    }




    public function index()
    {
        // 1. Tổng số đơn hàng theo tuần/tháng
        $data['weeklyOrders'] = PurchaseOrder::selectRaw('YEARWEEK(created_at, 1) as week, COUNT(id) as total_orders')
            ->groupBy('week')
            ->orderBy('week')
            ->get();

        $data['monthlyOrders'] = PurchaseOrder::selectRaw('YEAR(created_at) as year, MONTH(created_at) as month, COUNT(id) as total_orders')
            ->groupBy('year', 'month')
            ->orderBy('year')
            ->orderBy('month')
            ->get();


        // Ví dụ query trong Controller
        $data['topProducts'] = PurchaseOrderItem::selectRaw('
    sku,
    YEAR(purchase_orders.created_at) as year,
    MONTH(purchase_orders.created_at) as month,
    SUM(quantity) as total_quantity
')
            ->join('purchase_orders', 'purchase_order_items.purchase_order_id', '=', 'purchase_orders.id')
            ->groupBy('sku', DB::raw('YEAR(purchase_orders.created_at)'), DB::raw('MONTH(purchase_orders.created_at)'))
            ->orderByDesc('total_quantity')
            ->get();

        // 3. Tổng số lượng sản phẩm đặt hàng theo từng nhà cung cấp
        $data['supplierTotalQuantity'] = PurchaseOrderItem::join('purchase_orders', 'purchase_order_items.purchase_order_id', '=', 'purchase_orders.id')
            ->join('suppliers', 'purchase_orders.supplier_id', '=', 'suppliers.id') // Kết nối với bảng suppliers
            ->selectRaw('suppliers.username as supplier_name, SUM(purchase_order_items.quantity) as total_quantity')
            ->groupBy('suppliers.id', 'suppliers.username') // Group theo nhà cung cấp
            ->orderByDesc('total_quantity')
            ->get();


        // 4. Nhà cung cấp nào có nhiều đơn hàng nhất?
        $data['topSuppliersByOrders'] = PurchaseOrder::selectRaw('suppliers.username as supplier_name, COUNT(purchase_orders.id) as total_orders')
            ->join('suppliers', 'purchase_orders.supplier_id', '=', 'suppliers.id') // Kết nối bảng suppliers
            ->groupBy('suppliers.id', 'suppliers.username') // Group theo nhà cung cấp
            ->orderByDesc('total_orders')
            ->get();


        // 5. Mức độ phân tán đơn hàng giữa các nhà cung cấp (Nhà cung cấp nào chiếm tỷ lệ đơn hàng cao nhất?)
        $data['supplierOrderDistribution'] = PurchaseOrder::join('suppliers', 'purchase_orders.supplier_id', '=', 'suppliers.id') // Kết nối bảng suppliers
            ->selectRaw('
            suppliers.username as supplier_name, 
            COUNT(purchase_orders.id) as total_orders, 
            (COUNT(purchase_orders.id) * 100 / (SELECT COUNT(*) FROM purchase_orders)) as order_percentage
        ')
            ->groupBy('suppliers.id', 'suppliers.username') // Group theo nhà cung cấp
            ->orderByDesc('order_percentage')
            ->get();

        // Lấy năm hiện tại (hoặc bạn có thể dùng tham số lọc từ request)
        $currentYear = Carbon::now()->year;

        // Truy vấn dữ liệu tổng số SKU theo tháng cho năm hiện tại
        $monthlySkuData = PurchaseOrderItem::selectRaw('
        MONTH(purchase_orders.created_at) as month,
        SUM(purchase_order_items.quantity) as total_quantity
    ')
            ->join('purchase_orders', 'purchase_order_items.purchase_order_id', '=', 'purchase_orders.id')
            ->whereYear('purchase_orders.created_at', $currentYear)
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        // Tạo mảng 12 phần tử cho 12 tháng, mặc định là 0
        $dataForYear = array_fill(0, 12, 0);
        foreach ($monthlySkuData as $item) {
            // Chú ý: tháng trong DB từ 1 đến 12, nên index = month - 1
            $dataForYear[$item->month - 1] = $item->total_quantity;
        }

        // Tính tỉ lệ tăng trưởng theo tháng: chỉ tính từ tháng 2 trở đi (index 1 trở đi)
        $growthRates = array_fill(0, 12, null);
        for ($i = 1; $i < 12; $i++) {
            if ($dataForYear[$i - 1] > 0) {
                $growthRates[$i] = round((($dataForYear[$i] - $dataForYear[$i - 1]) / $dataForYear[$i - 1]) * 100, 2);
            } else {
                $growthRates[$i] = null;
            }
        }
        // Với tháng đầu tiên, không có dữ liệu tháng trước nên giữ null hoặc có thể đặt 0
        $growthRates[0] = null;

        // Tạo dataset cho tổng số SKU (vẽ dạng cột/bar)
        $datasetTotalSku = [
            'label' => "Tổng SKU $currentYear",
            'data' => $dataForYear,
            'backgroundColor' => "rgba(54, 162, 235, 0.5)",
            'borderColor' => "rgba(54, 162, 235, 1)",
            'borderWidth' => 1,
            'type' => 'bar'
        ];

        // Tạo dataset cho tỉ lệ tăng trưởng (vẽ dạng đường/line)
        $datasetGrowthRate = [
            'label' => "Tỉ lệ tăng trưởng (%)",
            'data' => $growthRates,
            'backgroundColor' => "rgba(255, 99, 132, 0.5)",
            'borderColor' => "rgba(255, 99, 132, 1)",
            'borderWidth' => 2,
            'type' => 'line',
            'fill' => false,
            'yAxisID' => 'growthRate'
        ];

        // Tạo cấu trúc dữ liệu dạng pivot: trục X là các tháng từ 1 đến 12
        $pivotData = [
            'labels' => range(1, 12),
            'datasets' => [$datasetTotalSku, $datasetGrowthRate]
        ];

        // Truyền dữ liệu ra view
        $data['monthlySkuGrowth'] = $pivotData;



        $sevenDaysAgo = Carbon::now()->subDays(7);

        // Lấy danh sách các đơn hàng có đầy đủ số lượng
        $ordersToUpdate = DB::table('purchase_order_items')
            ->select('purchase_order_id')
            ->groupBy('purchase_order_id')
            ->havingRaw('SUM(CASE WHEN quantity = qty_reality THEN 1 ELSE 0 END) = COUNT(*)') // Kiểm tra tất cả item đều đủ số lượng
            ->pluck('purchase_order_id');

        // Cập nhật trạng thái `is_complete = 1`
        DB::table('purchase_orders')
            ->whereIn('id', $ordersToUpdate) // Chỉ cập nhật đơn hàng đủ điều kiện
            ->where('created_at', '>=', $sevenDaysAgo) // Giới hạn trong 7 ngày gần nhất
            ->update(['is_complete' => 1]);

        // Lấy danh sách đơn hàng
        $purchaseOrders = PurchaseOrder::with('supplier')->orderBy('is_complete', 'asc')->orderBy('prioritize', 'asc')->orderBy('expected_date', 'asc')->get();
        // Lấy ngày hiện tại (không tính giờ)
        $today = Carbon::today();

        // Lấy tất cả các đơn hàng chưa hoàn thành (is_complete == 0)
        $orders = PurchaseOrder::where('is_complete', 0)->get();

        foreach ($orders as $order) {
            // Chuyển expected_date sang đối tượng Carbon
            $expectedDate = Carbon::parse($order->expected_date);
            // Tính số ngày chênh lệch giữa ngày hiện tại và ngày dự kiến
            $difference = $today->diffInDays($expectedDate, false);

            // Nếu số ngày chênh lệch nằm trong khoảng từ 0 đến 2 (tức là 2, 1, hoặc 0 ngày)
            if ($difference <= 2 && $difference >= 0) {
                // Tạo nội dung thông báo, bao gồm mã đơn (po_id) và ngày dự kiến
                $notificationMessage = 'Đơn hàng ' . $order->po_id . ' với ngày dự kiến ' . date('d-m-Y', strtotime($order->expected_date))  . ' gần đến, vui lòng kiểm tra!';

                // Kiểm tra nếu thông báo đã tồn tại cho user hiện tại để tránh tạo trùng lặp
                $notificationExists = Notification::where('user_id', Auth::id())
                    ->where('type', 'update')
                    ->where('message', $notificationMessage)
                    ->exists();

                if (!$notificationExists) {
                    Notification::create([
                        'user_id' => Auth::id(),
                        'type'    => 'update', // hoặc 'edit', 'add', 'message', ...
                        'message' => $notificationMessage,
                    ]);
                }
                // $message = 'Đơn hàng ' . $order->po_id . ' với ngày dự kiến ' . $order->expected_date . ' gần đến, vui lòng kiểm tra!';
                // $user = Auth::user();
                // if ($user && $user->id_telegram) {
                //     $token_telegram = $user->token_telegram;
                //     FacadesNotification::route('telegram', $user->id_telegram)
                //         ->notify(new TelegramNotification($message, $user->id_telegram, $token_telegram));
                // }
            }
        }

        return view('purchase_orders.index', compact('purchaseOrders', 'data'));
    }


    public function search(Request $request)
    {
        $query = $request->get('query');
        $suppliers = Supplier::where('username', 'LIKE', "%{$query}%")
            ->orWhere('email', 'LIKE', "%{$query}%")
            ->orWhere('company_tax', 'LIKE', "%{$query}%")
            ->orWhere('sp_code', 'LIKE', "%{$query}%")
            ->get();
        return response()->json($suppliers);
    }

    // Hiển thị form thêm mới
    public function create()
    {
        $suppliers = Supplier::all(); // Lấy danh sách nhà cung cấp
        $list_products = Product::where('status', 1)->orderBy('id', 'asc')->get(); // Lấy danh sách sản phẩm
        return view('purchase_orders.create', compact('suppliers', 'list_products'));
    }


    /* CHECK MÃ SKU */
    public function checkSkus(Request $request)
    {
        $skus = $request->input('skus');
        $quantities = $request->input('quantities');

        $results = [];
        foreach ($skus as $index => $sku) {
            $product = Product::where('sku', $sku)->first();
            if ($product) {
                $results[] = [
                    'id' =>  $product->id ?? "",
                    'sku' => $sku,
                    'name' => $product->name,
                    'quantity' => $quantities[$index],
                    'price' => $product->price,
                ];
            } else {
                $results[] = [
                    'id' =>  $product->id ?? "",
                    'sku' => $sku,
                    'name' => $product->name,
                    'quantity' => $quantities[$index],
                    'price' => 'Không tìm thấy sản phẩm',
                ];
            }
        }

        return response()->json($results);
    }


    // Lưu Purchase Order mới
    public function store(Request $request)
    {
        $checkPo = PurchaseOrder::where('po_id', $request->po_id ?? "")->first();
        if ($checkPo) {

            return redirect()->back()->with('error', 'Purchase Order đã tồn tại!');
        }

        $request->validate([
            'supplier_id' => 'required|exists:suppliers,id',
            'order_date' => 'required|date',
            'notes' => 'nullable|string|max:255',
        ]);

        // Tạo link public hoặc nội dung cho QR code
        // $link = url('google.com.vn');

        // Tạo mã QR Code và chuyển sang Base64
        // $qrCode = base64_encode(QrCode::format('png')->size(200)->generate($link));
        $purchaseOrder = PurchaseOrder::create([
            'po_id' => $request->po_id,
            'supplier_id' => $request->supplier_id,
            'order_date' => $request->order_date,
            'expected_date' => $request->expected_date,
            'total_amount' => $request->total,
            'notes' => $request->note,
            'date_sale' => $request->date_sale,
            'status' => 0,
            'qr_code' => '',
            'user_id' => Auth::user()->id,
            'ware_housing' => $request->ware_housing,
            'prioritize' => $request->prioritize ?? 0,
            'factory_capacity' => $request->factory_capacity ?? 0,
        ]);

        foreach ($request->products as $product) {
            PurchaseOrderItem::create([
                'purchase_order_id' => $purchaseOrder->id,
                'product_id' => $product['id'],
                'sku' => $product['sku'],
                'qty_forecasting' => $product['quantity'],
                'quantity' => $product['quantity'],
                'qty_reality' => 0,
                'status' => 'Đang sản xuất',
                'ware_housing' => $request->ware_housing,
                'date_sale' => $request->date_sale,
                'expected_date' => $request->expected_date,
                'unit_price' => $product['price'],
                'tax' => $product['tax'],
                'subtotal' => $product['total'],
            ]);
        }


        $supplier = Supplier::find($request->supplier_id);
        if ($supplier) {
            $notify = "Bạn có đơn hàng mới: " . $purchaseOrder->po_id;
            event(new NotifyProcessed($notify, $supplier->id)); // Gửi cả supplier_id
        }


        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'add', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Thêm đơn hàng ' . $purchaseOrder->po_id . ' thành công!',
        ]);



        return redirect()->back()->with('success', 'Purchase Order đã được thêm mới thành công.');
    }

    // Hiển thị chi tiết một Purchase Order
    public function show($id)
    {
        $purchaseOrder = PurchaseOrder::with('supplier')->findOrFail($id);
        return view('purchase_orders.show', compact('purchaseOrder'));
    }

    // Hiển thị form chỉnh sửa
    public function edit($id)
    {
        $purchaseOrder = PurchaseOrder::findOrFail($id);
        $suppliers = Supplier::all();
        return view('purchase_orders.edit', compact('purchaseOrder', 'suppliers'));
    }

    // Cập nhật Purchase Order
    public function update(Request $request, $id)
    {
        $purchaseOrder = PurchaseOrder::findOrFail($id);
        $purchaseOrder->update(
            [
                'expected_date' => $request->expected_date,
                'date_sale' => $request->date_sale,
                'prioritize' => $request->prioritize ?? 0
            ]
        );

        PurchaseOrderItem::where('purchase_order_id', $id)->update(
            [
                'expected_date' => $request->expected_date,
                'date_sale' => $request->date_sale
            ]
        );

        Notification::create([
            'user_id' => Auth::id(),
            'type' => 'update', // hoặc 'edit', 'add', 'message', ...
            'message' => 'Cập nhật thông tin đơn hàng ' . $purchaseOrder->po_id . ' thành công!',
        ]);


        return redirect()->back()->with('success', 'Purchase Order đã được cập nhật.');
    }

    // Xóa Purchase Order
    public function destroy($id)
    {
        $purchaseOrder = PurchaseOrder::findOrFail($id);
        $purchaseOrder->delete();

        return redirect()->back()->with('success', 'Purchase Order đã được xóa.');
    }


    public function export($id)
    {
        $data = PurchaseOrder::findOrFail($id);
        // Kiểm tra nếu $id không hợp lệ
        if (!$id || !is_numeric($id)) {
            return response()->json(['error' => 'Invalid purchase order ID'], 400);
        }

        $currentDate = date('d-m-Y_H-i'); // Lấy ngày giờ hiện tại
        $fileName = "Danh-sach-san-pham-PO-{$data->po_id}-{$currentDate}.xlsx"; // Tạo tên file theo ID

        return Excel::download(new PurchaseOrderItemExport($id), $fileName);
    }

    public function delete($id)
    {
        PurchaseOrder::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Purchase Order đã được xóa.');
    }
}
