<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmbedHtml;
use App\Models\Theme;
use Illuminate\Http\Request;

class SystemController extends Controller
{
    //


    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'system']);
            return $next($request);
        });
    }



    public function index()
    {
        return view('backend.system.index');
    }


    /* Cấu hình trang chủ */

    /* Nhúng website */
    public function embedhtml()
    {

        $data = EmbedHtml::first();
        return view('backend.system.embedhtml', compact('data'));
    }
    public function updateEmbedhtml(Request $request, $id)
    {
        EmbedHtml::where('id', $id)->update(
            [
                'embedcode_head_begin' => $request->embedcode_head_begin ?? "",
                'embedcode_head' => $request->embedcode_head ?? "",
                'embedcode_body_begin' => $request->embedcode_body_begin ?? "",
                'embedcode_body' => $request->embedcode_body ?? "",
            ]
        );

        return redirect()->back()->with('status', 'Cập nhật thành công');
    }


    public function theme()
    {
        $data = Theme::first();
        return view('backend.system.theme', compact('data'));
    }


    public function updateTheme(Request $request, $id)
    {
        Theme::where('id', $id)->update(
            [
                'html' => $request->html ?? "",
                'css' => $request->css ?? "",
                'javascript' => $request->javascript ?? "",
            ]
        );
        return redirect()->back()->with('status', 'Cập nhật thành công');
    }
}

