<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\InventoryLog;
use App\Models\Product;
use App\Models\ProductInventory;
use App\Models\Stock;
use App\Models\Warehouse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class StockController extends Controller
{
    //
    public function __construct()
    {

        $this->middleware(function ($request, $next) {
            session(['module_active' => 'stock']);
            return $next($request);
        });
    }


    public function add()
    {

        $data['warehouse'] = Warehouse::orderBy('updated_at', 'desc')->get();
        $data['product'] = Product::orderBy('updated_at', 'desc')->get();
        return view('stock.add', compact('data'));
    }



    // public function list()
    // {
    //     // Sắp xếp theo ngày nhập kho (entry_date) giảm dần
    //     $data['inventories'] = ProductInventory::with('product', 'warehouse')
    //         ->orderByDesc('total_quantity')
    //         ->get();

    //     // Sắp xếp theo ngày nhập kho (entry_date) giảm dần
    //     $data['stock'] = Stock::orderByDesc('updated_at')->orderByDesc('entry_date')->get();

    //     // Sắp xếp theo ngày xuất kho (date_expert) giảm dần
    //     $data['inventory_logs'] = InventoryLog::orderByDesc('updated_at')->orderByDesc('date_expert')->get();

    //     return view('stock.listNew', compact('data'));
    // }


    public function list()
    {
        // Lấy tất cả tồn kho, sắp xếp theo tổng số lượng giảm dần
        $data['inventories'] = ProductInventory::with('product', 'warehouse')
            ->orderByDesc('total_quantity')
            ->get();

        // Lấy tất cả nhập kho, sắp xếp theo ngày nhập kho giảm dần
        $data['stock'] = Stock::orderByDesc('entry_date')->orderByDesc('updated_at')->get();

        // Lấy tất cả xuất kho, sắp xếp theo ngày xuất kho giảm dần
        $data['inventory_logs'] = InventoryLog::orderByDesc('date_expert')->orderByDesc('updated_at')->get();

        // Tính tổng số lượng nhập kho theo ngày
        $dailyStockTotals = [];
        foreach ($data['stock'] as $item) {
            // Đảm bảo entry_date là đối tượng Carbon
            $date = Carbon::parse($item->entry_date)->format('Y-m-d');
            if (!isset($dailyStockTotals[$date])) {
                $dailyStockTotals[$date] = ['total_in' => 0];
            }
            $dailyStockTotals[$date]['total_in'] += $item->quantity;
        }

        // Tính tổng số lượng xuất kho theo ngày
        $dailyInventoryLogTotals = [];
        foreach ($data['inventory_logs'] as $log) {
            // Đảm bảo date_expert là đối tượng Carbon
            $date = Carbon::parse($log->date_expert)->format('Y-m-d');
            if (!isset($dailyInventoryLogTotals[$date])) {
                $dailyInventoryLogTotals[$date] = ['total_out' => 0];
            }
            $dailyInventoryLogTotals[$date]['total_out'] += $log->quantity_change;
        }

        // Kết hợp tổng số lượng nhập và xuất theo ngày
        foreach ($dailyStockTotals as $date => $totals) {
            if (isset($dailyInventoryLogTotals[$date])) {
                $dailyStockTotals[$date]['total_out'] = $dailyInventoryLogTotals[$date]['total_out'];
            } else {
                $dailyStockTotals[$date]['total_out'] = 0;
            }
        }

        foreach ($dailyInventoryLogTotals as $date => $totals) {
            if (!isset($dailyStockTotals[$date])) {
                $dailyStockTotals[$date]['total_in'] = 0;
                $dailyStockTotals[$date]['total_out'] = $totals['total_out'];
            }
        }

        // Tính tổng số lượng nhập kho theo tháng
        $monthlyStockTotals = [];
        foreach ($data['stock'] as $item) {
            // Đảm bảo entry_date là đối tượng Carbon
            $month = Carbon::parse($item->entry_date)->format('m-Y');
            if (!isset($monthlyStockTotals[$month])) {
                $monthlyStockTotals[$month] = ['total_in' => 0];
            }
            $monthlyStockTotals[$month]['total_in'] += $item->quantity;
        }

        // Tính tổng số lượng xuất kho theo tháng
        $monthlyInventoryLogTotals = [];
        foreach ($data['inventory_logs'] as $log) {
            // Đảm bảo date_expert là đối tượng Carbon
            $month = Carbon::parse($log->date_expert)->format('m-Y');
            if (!isset($monthlyInventoryLogTotals[$month])) {
                $monthlyInventoryLogTotals[$month] = ['total_out' => 0];
            }
            $monthlyInventoryLogTotals[$month]['total_out'] += $log->quantity_change;
        }

        // Kết hợp tổng số lượng nhập và xuất theo tháng
        foreach ($monthlyStockTotals as $month => $totals) {
            if (isset($monthlyInventoryLogTotals[$month])) {
                $monthlyStockTotals[$month]['total_out'] = $monthlyInventoryLogTotals[$month]['total_out'];
            } else {
                $monthlyStockTotals[$month]['total_out'] = 0;
            }
        }

        foreach ($monthlyInventoryLogTotals as $month => $totals) {
            if (!isset($monthlyStockTotals[$month])) {
                $monthlyStockTotals[$month]['total_in'] = 0;
                $monthlyStockTotals[$month]['total_out'] = $totals['total_out'];
            }
        }

        // Lưu kết quả vào biến dữ liệu để truyền vào view
        $data['daily_stock_totals'] = $dailyStockTotals;
        $data['monthly_stock_totals'] = $monthlyStockTotals;

        return view('stock.listNew', compact('data'));
    }


    public function listOld()
    {
        $data['inventories'] = ProductInventory::with('product', 'warehouse')->get();
        $data['stock'] = Stock::all();
        $data['inventory_logs'] = InventoryLog::all();
        return view('stock.list', compact('data'));
    }

    public function save(Request $request)
    {
        // Thêm bản ghi mới vào bảng stock
        Stock::create([
            'warehouse_id' => $request->input('warehouse_id'),
            'product_id' => $request->input('product_id'),
            'quantity' => $request->input('quantity'),
            'entry_date' => $request->input('entry_date'),
            'note' => $request->input('note'),
            'added_by' => Auth::user()->name . '- Ngày Thêm:' . now(),
        ]);

        // Lấy ID kho và ID sản phẩm từ yêu cầu
        $warehouseId = $request->input('warehouse_id');
        $productId = $request->input('product_id');
        $newQuantity = $request->input('quantity');

        // Lấy tổng số lượng hiện tại từ bảng ProductInventory
        $currentInventory = ProductInventory::where('warehouse_id', $warehouseId)
            ->where('product_id', $productId)
            ->first();

        if ($currentInventory) {
            // Nếu bản ghi tồn tại, cập nhật tổng số lượng
            $currentInventory->total_quantity += $newQuantity;
            $currentInventory->save();
        } else {
            // Nếu bản ghi không tồn tại, tạo bản ghi mới
            ProductInventory::create([
                'warehouse_id' => $warehouseId,
                'product_id' => $productId,
                'total_quantity' => $newQuantity,
            ]);
        }

        return redirect()->back()->with('status', 'Thêm thành công.');
    }



    public function update(Request $request, $id)
    {



        // Tìm tồn kho dựa trên ID
        $inventory = ProductInventory::findOrFail($id);

        // Xác thực dữ liệu đầu vào
        $request->validate([
            'quantity' => 'required|numeric',
            'note' => 'nullable|string|max:255',
            'date_expert' => 'required|date', // Xác thực ngày xuất kho
        ]);


        $request_total_quantity = $request->input('total_quantity');
        // Tính toán số lượng thay đổi
        $quantityChange = $request->input('quantity');

        // Tính toán tổng số lượng mới
        $newTotalQuantity = $request_total_quantity + $quantityChange;

        // Cập nhật số lượng tồn kho
        $inventory->total_quantity = $newTotalQuantity;
        $inventory->save();

        // Lưu ghi chú vào bảng inventory_logs
        InventoryLog::create([
            'inventory_id' => $inventory->id,
            'quantity_change' => $quantityChange,
            'note' => $request->input('note', ''),
            'updated_by' => Auth::user()->name . ' - Ngày Cập Nhật: ' . now(),
            'date_expert' => $request->input('date_expert'),
        ]);

        // // Cập nhật tổng số lượng trong kho
        // $this->updateTotalQuantity($inventory->warehouse_id, $inventory->product_id);

        // Trả về thông báo thành công
        return redirect()->back()->with('status', 'Cập nhật tồn kho thành công.');
    }



    private function updateTotalQuantity($warehouseId, $productId)
    {
        // Tính toán tổng số lượng hàng tồn kho hiện tại cho sản phẩm trong kho
        $currentQuantity = Stock::where('warehouse_id', $warehouseId)
            ->where('product_id', $productId)
            ->sum('quantity');

        // Cập nhật hoặc thêm bản ghi trong bảng product_inventory
        ProductInventory::updateOrCreate(
            [
                'warehouse_id' => $warehouseId,
                'product_id' => $productId,
            ],
            ['total_quantity' => $currentQuantity]
        );
    }



    public function editStock($id)
    {
        $inventory = ProductInventory::findOrFail($id);

        // dd($inventory);
        $products = Product::all();
        $warehouses = Warehouse::all();
        return view('stock.edit', compact('inventory', 'products', 'warehouses'));
    }





    public function delete($id)
    {
        // Tìm tồn kho bằng ID
        $inventory = ProductInventory::findOrFail($id);

        // Xóa các bản ghi liên quan trong bảng inventory_logs
        InventoryLog::where('inventory_id', $id)->delete();

        // Xóa các bản ghi liên quan trong bảng stocks
        Stock::where(['warehouse_id' => $inventory->warehouse_id, 'product_id' => $inventory->product_id])->delete();

        // Xóa bản ghi tồn kho
        $inventory->delete();

        // Trả về thông báo thành công
        return redirect()->back()->with('status', 'Tồn kho đã được xóa thành công.');
    }
}
