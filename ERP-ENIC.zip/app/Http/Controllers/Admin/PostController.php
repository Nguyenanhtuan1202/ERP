<?php


namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Post;
use App\Models\Post_Category;
use App\Models\Post_Tag;
use App\Models\Tag;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\support\Facades\Redirect;

session_start();

class PostController extends Controller
{
    //


    private $post;
    public function __construct(Post $post)
    {
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'post']);
            return $next($request);
        });


        $this->post = $post;
    }


    public function show(Request $request, $id)
    {
        // $post = Post::find($id);
        // if ($request->user()->can('view', $post)) {
        //     return view('backend.post.show', compact('post'));
        // } else {
        //     abort(403);
        // }

        $post = Post::find($id);
        return view('backend.post.show', compact('post'));
    }





    public function add()
    {
        $tag = Tag::where('status', 1)->orderBy('weight', 'desc')->get();
        $category = Category::where('status', 1)->orderBy('weight', 'desc')->get();
        return view('backend.post.add', compact('category', 'tag'));
    }
    public function edit($id)
    {
        $tag = Tag::where('status', 1)->orderBy('weight', 'desc')->get();
        $category = Category::where('status', 1)->orderBy('weight', 'desc')->get();
        $post = Post::find($id);
        $catOfPost = $post->category;
        $tagOfPost = $post->tag;
        return view('backend.post.edit', compact('category', 'tag', 'post', 'catOfPost', 'tagOfPost'));
    }
    public function list(Request $request)
    {
        $status_post = $request->input('status_post');
        if ($status_post == 'public') {
            $list_act = [
                'draft' => 'Draft',
                'delete' => 'Xóa tạm thời',
            ];

            $count_publish = Post::where('status', '=', 'publish')->count();
            $count_trash = Post::onlyTrashed()->count();
            $count_draft = Post::where('status', '=', 'draft')->count();
            $count = [$count_publish, $count_draft, $count_trash];
            $keyword = "";
            if ($request->input('keyword')) {
                $keyword = $request->input('keyword');
            }
            $post = Post::where('title', 'LIKE', "%$keyword%")->where('meta_seo', 'LIKE', "%$keyword%")->where('status', 'publish')->latest()->paginate(20);;
            $post->appends($request->all());
            return view('backend.post.list', compact('post', 'count', 'list_act', 'status_post'));
        } else if ($status_post == 'draft') {
            $list_act = [
                'publish' => 'Publish',
                'delete' => 'Xóa tạm thời',
            ];

            $count_publish = Post::where('status', '=', 'publish')->count();
            $count_trash = Post::onlyTrashed()->count();
            $count_draft = Post::where('status', '=', 'draft')->count();
            $count = [$count_publish, $count_draft, $count_trash];
            $keyword = "";
            if ($request->input('keyword')) {
                $keyword = $request->input('keyword');
            }
            $post = Post::where('title', 'LIKE', "%$keyword%")->where('meta_seo', 'LIKE', "%$keyword%")->where('status', 'draft')->latest()->paginate(20);
            $post->appends($request->all());
            return view('backend.post.list', compact('post', 'count', 'list_act', 'status_post'));
        } else if ($status_post == 'trash') {
            $list_act = [
                'restore' => 'Khôi phục',
                'destroy' => 'Xóa Vĩnh Viễn',
            ];

            $count_publish = Post::where('status', '=', 'publish')->count();
            $count_trash = Post::onlyTrashed()->count();
            $count_draft = Post::where('status', '=', 'draft')->count();
            $count = [$count_publish, $count_draft, $count_trash];
            $keyword = "";
            if ($request->input('keyword')) {
                $keyword = $request->input('keyword');
            }
            $post = Post::onlyTrashed()->paginate(20);
            $post->appends($request->all());
            return view('backend.post.list', compact('post', 'count', 'list_act', 'status_post'));
        } else {

            $list_act = [
                'publish' => 'Publish',
                'draft' => 'Draft',
                'delete' => 'Xóa tạm thời',
                'destroy' => 'Xóa Vĩnh Viễn',

            ];
            $count_publish = Post::where('status', '=', 'publish')->count();
            $count_trash = Post::onlyTrashed()->count();
            $count_draft = Post::where('status', '=', 'draft')->count();
            $count = [$count_publish, $count_draft, $count_trash];

            $keyword = "";
            if ($request->input('keyword')) {
                $keyword = $request->input('keyword');
            }
            $post = Post::where('title', 'LIKE', "%$keyword%")->where('meta_seo', 'LIKE', "%$keyword%")->latest()->paginate(20);;
            $post->appends($request->all());
            return view('backend.post.list', compact('post', 'count', 'list_act', 'status_post'));
        }
    }


    public function copy($id)
    {
        $page = Post::find($id);
        $duplicatePage = $page->replicate();
        $duplicatePage->title = $page->title .' Copy of ' . rand(0, 100);
        $duplicatePage->url = $page->url . '-' . rand(0, 999);
        $duplicatePage->save();
        return redirect()->back()->with('status','Copy thành công');
        
    }




    public function save(Request $request)
    {
        $list_category = $request->category;
        $user_id = Auth::id();
        $request->validate(
            [
                'title' => 'required|string|max:255',
                'meta_seo' => 'required',
                'url' => 'required',
                'key_seo' => 'required',
                'desc_seo' => 'required',
                'category' => 'required|not_in:0',
                'desc' => 'required',
                'content' => 'required',
                'image' => 'required',
                'status' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'title' => 'Tên bài viết',
                'desc' => 'Mô tả',
                'content' => 'Nội dung',
                'url' => 'Đường dẫn thân thiện',
                'image' => 'Hình Ảnh',
                'meta_seo' => "Tiêu đề trang không được để trống",
                'key_seo' => "Từ khoá trang không được để trống",
                'desc_seo' => "Mô tả trang không được để trống",
                'category' => 'Danh Mục',
                'status' => 'Trạng thái'
            ]
        );

        $data = $request->all();
        $markupFixer  = new \TOC\MarkupFixer();
        $contentWithMenu = $markupFixer->fix($data['content']);


        if ($request->hasFile('image')) {
            $file = $request->image;
            $size = $file->getSize();
            if ($size > 5000000) {
                return redirect('/admin/post/add')->with('error', 'Kích thước ảnh không vượt quá 5MB');
            } else {
                $get_image = $request->file('image');
                $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
                $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
                $new_image = $name_image . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
                $get_image->move('public/uploads/post', $new_image);
            }
        }

        $post =  $this->post->create([
            'title' => $request->input('title'),
            'meta_seo' => $request->input('meta_seo'),
            'desc_seo' => $request->input('desc_seo'),
            'key_seo' => $request->input('key_seo'),
            'url' => $request->url ?? "",
            'weight' => $request->input('weight') ?? 0,
            'slug' =>  Str::slug($request->input('title')),
            'desc' =>  $request->input('desc'),
            'content' =>  $contentWithMenu,
            'status' =>  $request->input('status'),
            'user_id' => $user_id,
            'image' => $new_image,
            'link_youtube'=>$request->link_youtube
        ]);

        // foreach ($list_tag as $key => $value) {
        //     Post_Tag::create(
        //         [
        //             'post_id' => $post->id,
        //             'tag_id' => $value
        //         ]
        //     );
        // }

        foreach ($list_category as $key => $cat) {
            Post_Category::create(
                [
                    'post_id' => $post->id,
                    'category_id' => $cat
                ]
            );
        }
        return redirect()->back()->with('status', 'Thêm bài viết thành công');
    }

    public function update(Request $request, $id)
    {
        $list_category = $request->category;
        $user_id = Auth::id();
        $list_tag = $request->tags;
        $request->validate(
            [
                'title' => 'required|string|max:255',
                'meta_seo' => 'required',
                'url' => 'required',
                'key_seo' => 'required',
                'desc_seo' => 'required',
                'category' => 'required|not_in:0',
                'desc' => 'required',
                'content' => 'required',
                'status' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'title' => 'Tên bài viết',
                'desc' => 'Mô tả',
                'content' => 'Nội dung',
                'url' => 'Đường dẫn thân thiện',
                'meta_seo' => "Tiêu đề trang không được để trống",
                'key_seo' => "Từ khoá trang không được để trống",
                'desc_seo' => "Mô tả trang không được để trống",
                'tags' => 'Tag',
                'category' => 'Danh Mục',
                'status' => 'Trạng thái'
            ]
        );

        if (!empty($list_category)) {
            Post_Category::where('post_id', $id)->delete();
            foreach ($list_category as $key => $cat) {
                Post_Category::create(
                    [
                        'post_id' => $id,
                        'category_id' => $cat
                    ]
                );
            }
        }
     
        $post = Post::find($id);
        $data = $request->all();
        $markupFixer  = new \TOC\MarkupFixer();
        $contentWithMenu = $markupFixer->fix($data['content']);
        if ($request->hasFile('image')) {
            $get_image = $request->file('image');
            $get_name_image = $get_image->getClientOriginalName(); /* Lấy tên của hình ảnh */
            $name_image = current(explode('.', $get_name_image)); /* Tách chuỗi */
            $new_image = $name_image . rand(0, 99) . '.' . $get_image->getClientOriginalExtension(); /* Đuôi mở rộng */
            $get_image->move('public/uploads/post', $new_image);
            Post::where('id', $id)->update(
                [
                    'title' => $request->input('title'),
                    'meta_seo' => $request->input('meta_seo'),
                    'desc_seo' => $request->input('desc_seo'),
                    'key_seo' => $request->input('key_seo'),
                    'url' => $request->url ?? "",
                    'weight' => $request->input('weight') ?? 0,
                    'slug' =>  Str::slug($request->input('title')),
                    'desc' =>  $request->input('desc'),
                    'content' =>  $contentWithMenu,
                    'status' =>  $request->input('status'),
                    'user_id' => $user_id,
                    'image' => $new_image,
                    'link_youtube'=>$request->link_youtube
                ]
            );
            return redirect()->back()->with('status', 'Cập nhật bài viết thành công');
        } else {
            Post::where('id', $id)->update(
                [
                    'title' => $request->input('title'),
                    'meta_seo' => $request->input('meta_seo'),
                    'desc_seo' => $request->input('desc_seo'),
                    'key_seo' => $request->input('key_seo'),
                    'url' => $request->url ?? "",
                    'weight' => $request->input('weight') ?? 0,
                    'slug' =>  Str::slug($request->input('title')),
                    'desc' =>  $request->input('desc'),
                    'content' =>  $contentWithMenu,
                    'status' =>  $request->input('status'),
                    'user_id' => $user_id,
                    'link_youtube'=>$request->link_youtube
                ]
            );
            return redirect()->back()->with('status', 'Cập nhật bài viết thành công');
        }
    }

    public function delete($id)
    {
        Post::where('id', $id)->delete();
        return redirect()->back()->with('status', 'Đã đưa bài viết vào thùng rác');
    }


    public function action(Request $request)
    {
        $list_check = $request->input('list_check');



        if (!empty($list_check)) {
            $act = $request->input('act');
            if ($act == 'delete') {
                Post::destroy($list_check);
                return redirect('admin/post/list')->with('status', 'Đã xóa bài viếtthành công');
            }
            if ($act == 'restore') {
                Post::withTrashed()->whereIn('id', $list_check)->restore();
                return redirect('admin/post/list')->with('status', 'Khôi phục bài viết thành công');
            }
            if ($act == 'destroy') {
                Post::whereIn('id', $list_check)->forceDelete();
                return redirect('admin/post/list')->with('status', 'Đã xóa bài viết ra khỏi hệ thống');
            }

            if ($act == 'publish') {
                foreach ($list_check as $value) {
                    Post::where('id', $value)->update(
                        ['status' => 'publish']
                    );
                }
                return redirect('admin/post/list')->with('status', 'Cập nhật trạng thái thành công');
            }
            if ($act == 'draft') {
                foreach ($list_check as $value) {

                    Post::where('id', $value)->update(
                        ['status' => 'draft']
                    );
                }
                return redirect('admin/post/list')->with('status', 'Cập nhật trạng thái thành công');
            }
            return redirect('admin/post/list')->with('status', 'Bạn cần chọn chức năng để thực thi');
        } else {
            return redirect('admin/post/list')->with('status', 'Bạn cần chọn phần tử để thực thi');
        }
    }
}
