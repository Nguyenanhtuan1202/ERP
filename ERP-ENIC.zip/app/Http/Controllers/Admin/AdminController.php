<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\ListExpert;
use App\Models\Post;
use App\Models\Rating;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module_active' => 'dashboard']);
            return $next($request);
        });
    }


    public function dashboard(Request $request) {
        if (!Auth::check()) {
            return redirect('/login');
        }
    
        $user = Auth::user();
    
        if ($user->ware_housing == 1) {
            return view('backend.dashboard_warehousing');
        }
    
        if ($user->purchaser == 1) {
            return view('backend.dashboard_purchaser');
        }
    
        if ($user->supplier_id !== null && $user->supplier_id !== "") {
            return view('backend.dashboard_factory');
        }
    
        return view('backend.dashboard');
    }
    public function infoUser()
    {
        return view('backend.admin.info');
    }
    public function update(Request $request, $id)
    {
        if ($request->name == "") {
            return redirect('admin/user/info')->with('status', 'Vui lòng điền thông tin cần thay đổi');
        } else {
            if ($request->password == "") {
                $password = Auth::user()->password;
                User::where('id', $id)->update(
                    [
                        'name' => $request->name,
                        'password' => $password
                    ]
                );
                return redirect('admin/user/info')->with('status', 'Cập nhật thông tin thành công');
            } else {
                User::where('id', $id)->update(
                    [
                        'name' => $request->name,
                        'password' => Hash::make($request->password)
                    ]
                );
                return redirect('admin/user/info')->with('status', 'Cập nhật thông tin thành công');
            }
        }
    }


    public function adminApprove()
    {
        $data['list_expert'] = ListExpert::where(['status' => 1, 'cancel_contract' => 0, 'admin_approve' => 0])->orderBy('id_hs', 'asc')->get();

        return view('approve.index', compact('data'));
    }
}
