<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    //

    public function index()
    {
        $invoices = Invoice::paginate(10);
        return view('invoices.index', compact('invoices'));
    }

    public function create()
    {
        return view('invoices.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'shipment_id'    => 'required|exists:shipments,id',
            'invoice_number' => 'required|unique:invoices',
            'amount'         => 'required|numeric',
            'currency'       => 'required|string|max:10',
            'status'         => 'required|in:Chưa thanh toán,Đã thanh toán,Quá hạn',
            'issued_date'    => 'required|date',
            'due_date'       => 'required|date',
            'payment_date'   => 'nullable|date',
            'taxes'          => 'nullable|numeric',
            'fees'           => 'nullable|numeric',
        ]);

        Invoice::create($validated);
        return redirect()->route('invoices.index')->with('success', 'Hóa đơn đã được tạo thành công.');
    }

    public function show(Invoice $invoice)
    {
        return view('invoices.show', compact('invoice'));
    }

    public function edit(Invoice $invoice)
    {
        return view('invoices.edit', compact('invoice'));
    }

    public function update(Request $request, Invoice $invoice)
    {
        $validated = $request->validate([
            'shipment_id'    => 'required|exists:shipments,id',
            'invoice_number' => 'required|unique:invoices,invoice_number,'.$invoice->id,
            'amount'         => 'required|numeric',
            'currency'       => 'required|string|max:10',
            'status'         => 'required|in:Chưa thanh toán,Đã thanh toán,Quá hạn',
            'issued_date'    => 'required|date',
            'due_date'       => 'required|date',
            'payment_date'   => 'nullable|date',
            'taxes'          => 'nullable|numeric',
            'fees'           => 'nullable|numeric',
        ]);

        $invoice->update($validated);
        return redirect()->route('invoices.index')->with('success', 'Hóa đơn đã được cập nhật.');
    }

    public function destroy(Invoice $invoice)
    {
        $invoice->delete();
        return redirect()->route('invoices.index')->with('success', 'Hóa đơn đã được xóa.');
    }
}
