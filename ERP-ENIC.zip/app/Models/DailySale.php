<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailySale extends Model
{
    use HasFactory;


    protected $fillable = [
        'sale_date',
        'product_id',
        'sku',
        'quantity',
        'sale_amount',
        'sale_channel',
        'store_id',
        'salesperson',
        'note',
    ];

    public function forecastProduct()
    {
        return $this->belongsTo(ForecastProduct::class);
    }
}
