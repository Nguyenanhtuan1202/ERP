<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InventoryLog extends Model
{
    use HasFactory;


    protected $table = 'inventory_logs';

    protected $fillable = [
        'inventory_id',
        'quantity_change',
        'note',
        'updated_by',
        'date_expert'
    ];

}
