<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shipment extends Model
{
    use HasFactory;

    protected $fillable = [
        'tracking_number',
        'customer_id',
        'carrier_id',
        'vessel_name',
        'voyage_number',
        'origin_port',
        'destination_port',
        'departure_date',
        'estimated_arrival',
        'actual_arrival',
        'status',         // Đang xử lý, Đang vận chuyển, Đã đến cảng, Thông quan, Giao hàng thành công
        'shipment_type',  // FCL, LCL
        'cargo_description',
        'total_weight',
        'total_volume',
    ];

    // Đối tác khách hàng
    public function customer()
    {
        return $this->belongsTo(Partner::class, 'customer_id');
    }

    // Hãng tàu vận chuyển
    public function carrier()
    {
        return $this->belongsTo(Partner::class, 'carrier_id');
    }

    // Liên kết với container
    public function containers()
    {
        return $this->hasMany(Container::class);
    }

    // Liên kết với hồ sơ hải quan
    public function customsClearance()
    {
        return $this->hasOne(CustomsClearance::class);
    }

    // Liên kết với hóa đơn
    public function invoice()
    {
        return $this->hasOne(Invoice::class);
    }

    // Liên kết với các sự kiện tracking
    public function trackingEvents()
    {
        return $this->hasMany(TrackingEvents::class);
    }

    // Liên kết với chứng từ
    public function documents()
    {
        return $this->hasMany(Document::class);
    }
}
