<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistoryPayment extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'amount',
        'paid_at',
        'user_id',
        'due_date',
        'note',
        'date_updated',
        'note_updated',
    ];
    // Thiết lập quan hệ với model Order (nếu cần)
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
