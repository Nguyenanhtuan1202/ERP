<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    use HasFactory;

    protected $fillable = [
        'shipment_id',
        'document_type',  // B/L, Packing List, Invoice, Certificate of Origin, Other
        'file_path',
        'description',
        'uploaded_at',
    ];

    // Liên kết với lô hàng (shipment)
    public function shipment()
    {
        return $this->belongsTo(Shipment::class);
    }
}
