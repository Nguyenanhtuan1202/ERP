<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductionData extends Model
{
    use HasFactory;

    // Dữ liệu sản xuất hàng hoá
    protected $table = 'production_data';

    protected $fillable = [
        'supplier_id',
        'product_name',
        'variant',
        'model_version',
        'color',
        'size',
        'sale_key',
        'sku',
        'product_note',
        'sale_note',
        'image',
        'shipping_time',
        'total_warehouse_time',
        'stock_in_warehouse',
        'goods_in_transit',
        'goods_ordered_stored',
        'turnover',
        'customer_orders',
        'reserved_stock',
        'avg_daily_sales_cycle',
        'avg_daily_sales_recent_week',
        'forecast_daily_sales_to_end_T3',
        'preorder_daily_tracking_forecast',
    ];
}
