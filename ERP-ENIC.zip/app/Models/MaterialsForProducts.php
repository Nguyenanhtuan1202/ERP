<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MaterialsForProducts extends Model
{
    use HasFactory;

    protected $fillable = ['tier_code', 'size', 'color', 'sku', 'name', 'quantity', 'total_price','style_code'];

    public function product()
    {
        return $this->belongsTo(Product::class, 'tier_code', 'tier_code');
    }

    public function material()
    {
        return $this->belongsTo(Material::class, 'sku', 'sku'); // Kết nối bằng cột sku
    }


   
}
