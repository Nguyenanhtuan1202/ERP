<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Warehousing extends Model
{
    use HasFactory;

    protected $fillable = [
        'purchase_order_id',
        'sku',
        'name',
        'order_quantity',
        'qty_received',
        'qty_more',
        'entry_date',
        'date_received',
        'supplier_id',
        'notes',
        'warehouse_location'
    ];

}
