<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    use HasFactory;

    protected $appends = ['total_quantity'];
    protected $fillable = ['supplier_id', 'qr_code', 'order_date', 'status', 'total_amount', 'notes', 'po_id', 'expected_date', 'user_id', 'date_sale', 'ware_housing', 'date_production', 'prioritize', 'is_complete','factory_capacity'];

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function items()
    {
        return $this->hasMany(PurchaseOrderItem::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getTotalQuantityAttribute()
    {
        return $this->items->sum('quantity');
    }
    public function getTotalQtyReality()
    {
        return $this->items()->sum('qty_reality');
    }

    public function getTotalQtyProduction()
    {
        return $this->items()->sum('products_production');
    }
}
