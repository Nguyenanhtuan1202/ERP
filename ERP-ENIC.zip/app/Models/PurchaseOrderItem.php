<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrderItem extends Model
{
    use HasFactory;

    protected $fillable = ['purchase_order_id', 'tax', 'product_id', 'sku', 'quantity', 'unit_price', 'subtotal', 'qty_forecasting', 'qty_reality', 'date_sale', 'ware_housing', 'expected_date', 'status', 'production_date', 'production_date_complete', 'products_production', 'date_delivery', 'qty_productions', 'qty_delivery', 'delivery_note', 'complete_order', 'is_delivery'];

    public function purchaseOrder()
    {
        return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'sku', 'sku');
    }
}
