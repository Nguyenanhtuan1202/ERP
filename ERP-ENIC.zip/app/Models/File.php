<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class File extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'path',
        'size',
        'mime_type',
        'folder_id',
        'user_id',
    ];

    /**
     * Get the folder that owns the file
     */
    public function folder()
    {
        return $this->belongsTo(Folder::class);
    }

    /**
     * Get the user that owns the file
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Format file size for display
     */
    public function formatSize()
    {
        $bytes = $this->size;

        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' bytes';
        }
    }

    /**
     * Get CSS class for file icon based on mime type
     */
    public function getFileIconClass()
    {
        if (strpos($this->mime_type, 'image') !== false) {
            return 'image fa-file-image';
        } elseif (strpos($this->mime_type, 'pdf') !== false) {
            return 'pdf fa-file-pdf';
        } elseif (
            strpos($this->mime_type, 'word') !== false ||
            strpos($this->mime_type, 'document') !== false
        ) {
            return 'doc fa-file-word';
        } elseif (
            strpos($this->mime_type, 'excel') !== false ||
            strpos($this->mime_type, 'spreadsheet') !== false
        ) {
            return 'doc fa-file-excel';
        } elseif (
            strpos($this->mime_type, 'text') !== false ||
            strpos($this->mime_type, 'json') !== false ||
            strpos($this->mime_type, 'javascript') !== false
        ) {
            return 'doc fa-file-code';
        } else {
            return 'fa-file';
        }
    }
}
