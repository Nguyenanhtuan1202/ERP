<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FileShare extends Model
{
    use HasFactory;

   
    protected $fillable = [
        'file_id',
        'user_id',
        'token',
        'is_enabled',
        'expiry_at',
        'password',
    ];

    protected $casts = [
        'is_enabled' => 'boolean',
        'expiry_at' => 'datetime',
    ];

   
    public function file()
    {
        return $this->belongsTo(File::class);
    }

  
    public function user()
    {
        return $this->belongsTo(User::class);
    }

   
    public function isValid()
    {
        // Kiểm tra nếu chia sẻ đã bị vô hiệu hóa
        if (!$this->is_enabled) {
            return false;
        }

        // Kiểm tra nếu đã hết hạn
        if ($this->expiry_at && now()->isAfter($this->expiry_at)) {
            return false;
        }

        return true;
    }
}
