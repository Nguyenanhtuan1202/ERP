<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RepairOrder extends Model
{
    use HasFactory;


    protected $fillable = [
        'order_code',
        'customer_name',
        'customer_phone',
        'sku',
        'product_name',
        'quantity',
        'product_type',
        'product_category',
        'repair_type',
        'warranty_date',
        'completion_date',
        'is_paid',
        'arr_picture',
        'address',
        'note',
        'status',
        'date_delivery',
        'supplier_id'
    ];
}
