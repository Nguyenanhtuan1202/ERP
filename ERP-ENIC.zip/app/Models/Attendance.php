<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{

    protected $guarded = [];
    use HasFactory;
    protected $table = 'expert_attendance';

    protected $fillable = [
        'id_hs', 'checkin', 'fullname', 'image','note'
    ];

    protected static function boot()
    {
        parent::boot();

        // Cập nhật trường checkin mỗi khi bản ghi được tạo
        static::creating(function ($model) {
            $model->checkin = Carbon::now();
        });
    }

    public function listExpert()
    {
        return $this->belongsTo(ListExpert::class, 'id_hs', 'id_hs');
    }
}
