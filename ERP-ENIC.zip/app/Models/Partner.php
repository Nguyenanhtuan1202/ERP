<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Partner extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'password', // Nếu cần sử dụng authentication, có thể mã hóa và ẩn nó đi
        'role',     // customer, carrier, accountant, customs_officer, warehouse_staff, logistics_agent, admin
        'phone',
        'address',
        'active',
    ];

    protected $hidden = [
        'password',
    ];

    // Các mối quan hệ:
    // Các lô hàng mà đối tác này là khách hàng
    public function shipmentsAsCustomer()
    {
        return $this->hasMany(Shipment::class, 'customer_id');
    }

    // Các lô hàng mà đối tác này là hãng tàu
    public function shipmentsAsCarrier()
    {
        return $this->hasMany(Shipment::class, 'carrier_id');
    }
}
