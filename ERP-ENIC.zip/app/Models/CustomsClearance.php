<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomsClearance extends Model
{
  
    use HasFactory;
    protected $table = 'customs_clearance';
    protected $fillable = [
        'shipment_id',
        'declaration_number',
        'clearance_date',
        'status',       // Chờ duyệt, Thông quan, Bị từ chối
        'documents',    // Lưu trữ dạng JSON
        'fees',
        'notes',
    ];

    // Liên kết với lô hàng (shipment)
    public function shipment()
    {
        return $this->belongsTo(Shipment::class);
    }
}
