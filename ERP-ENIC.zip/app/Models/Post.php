<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
    use HasFactory;
    use SoftDeletes;


    protected $dates = [
        'created_at',
        'updated_at',
        // Add any other date attributes here if needed
    ];
    
    protected $fillable = [
        'id',
        'title',
        'user_id',
        'meta_seo',
        'desc_seo',
        'key_seo',
        'url',
        'weight',
        'slug',
        'desc',
        'content',
        'link_youtube',
        'status',
        'image',
        'post_view',
        'deleted_at'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function category()
    {
        return $this->belongsToMany(Category::class, 'post__categories', 'post_id', 'category_id');
    }
    public function tag()
    {
        return $this->belongsToMany(Tag::class, 'post__tags','post_id','tag_id');
    }
}
