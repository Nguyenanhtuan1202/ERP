<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmbedHtml extends Model
{
    use HasFactory;

    protected $fillable = ['embedcode_head_begin','embedcode_head', 'embedcode_body_begin', 'embedcode_body'];
}
