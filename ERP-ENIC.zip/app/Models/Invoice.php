<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;


    protected $fillable = [
        'shipment_id',
        'invoice_number',
        'amount',
        'currency',
        'status',       // Chưa thanh toán, Đã thanh toán, Quá hạn
        'issued_date',
        'due_date',
        'payment_date',
        'taxes',
        'fees',
    ];

    // Liên kết với lô hàng (shipment)
    public function shipment()
    {
        return $this->belongsTo(Shipment::class);
    }
}
