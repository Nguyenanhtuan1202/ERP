<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'order_code',
        'total_quantity',
        'order_date',
        'note',
        'subtotal',
        'grand_total',
        'deposit',
        'user_id',
        'status',
        'supplier_id',
        'payment',
        'deposit_paid',
        'is_paid'
    ];

    /**
     * Quan hệ 1 - N: Một đơn hàng có nhiều OrderItem.
     */
    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Phân tích dữ liệu thô (text) và tạo đối tượng Order kèm theo OrderItems.
     *
     * Dữ liệu đầu vào mẫu:
     *
     * DHTO19022501
     * Tổng SL: 420
     *
     * Lavabo 2T 60 Đen        20
     * Kệ Đá 2T Đen 60        20
     * Lavabo 2T 80 Đen        28
     * ...
     *
     * Nếu SKU không có (chỉ có 2 phần: tên sản phẩm và số lượng), SKU sẽ là chuỗi rỗng.
     *
     * @param string $text
     * @return Order
     * @throws \Exception Nếu dữ liệu không hợp lệ
     */
    public static function parseFromText($text)
    {
        // Tách các dòng dựa trên ký tự xuống dòng, loại bỏ khoảng trắng đầu/cuối và các dòng trống
        $lines = array_filter(array_map('trim', preg_split('/\r\n|\n|\r/', $text)));

        if (count($lines) < 2) {
            throw new \Exception('Dữ liệu không hợp lệ: phải có ít nhất 2 dòng (mã đơn hàng và tổng số lượng).');
        }

        // Dòng đầu tiên: mã đơn hàng
        $order_code = array_shift($lines);

        // Dòng thứ hai: chứa "Tổng SL" và số lượng
        $totalLine = array_shift($lines);
        if (!preg_match('/\d+/', $totalLine, $matches)) {
            throw new \Exception('Không tìm thấy tổng số lượng trong dữ liệu.');
        }
        $total_quantity = (int)$matches[0];

        // Tạo đối tượng Order (chưa lưu vào CSDL)
        $order = new self([
            'order_code' => $order_code,
            'total_quantity' => $total_quantity,
        ]);

        $items = [];
        // Các dòng còn lại: dữ liệu sản phẩm
        foreach ($lines as $line) {
            // Tách dòng dựa trên tab hoặc 2 khoảng trắng trở lên
            $parts = preg_split('/\t+|\s{2,}/', $line);
            // Nếu dòng không có đủ thông tin (ít nhất 2 phần: tên và số lượng)
            if (count($parts) < 2) {
                continue; // bỏ qua dòng không hợp lệ
            }

            // Nếu có 3 phần, giả định: [0]=tên sản phẩm, [1]=SKU, [2]=số lượng
            // Nếu chỉ có 2 phần, giả định: [0]=tên sản phẩm, [1]=số lượng, SKU sẽ là chuỗi rỗng.
            if (count($parts) >= 3) {
                $product_name = trim($parts[0]);
                $sku = trim($parts[1]);
                $quantity = (int) trim($parts[2]);
            } else { // count($parts) == 2
                $product_name = trim($parts[0]);
                $sku = ''; // không có SKU
                $quantity = (int) trim($parts[1]);
            }

            $items[] = new OrderItem([
                'product_name' => $product_name,
                'sku' => $sku,
                'quantity' => $quantity,
            ]);
        }
        // Gắn collection các OrderItem vào quan hệ items của Order
        $order->setRelation('items', collect($items));

        return $order;
    }


    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'supplier_id', 'sp_code');
    }


    public function depositpayment()
    {
        return $this->hasMany(DepositPayment::class, 'order_id', 'id');
    }


    public function historypayment()
    {
        return $this->hasMany(HistoryPayment::class, 'order_id', 'id');
    }

    public function historyPayments()
    {
        return $this->hasMany(HistoryPayment::class, 'order_id');
    }


    public function totalPayment()
    {
        return $this->historyPayments()->sum('amount');
    }


    public function importCosts()
    {
        return $this->hasMany(ImportCost::class, 'order_id', 'id');
    }




    public function totalImportCost()
    {
        return $this->importCosts()->sum('cost_value');
    }
}
