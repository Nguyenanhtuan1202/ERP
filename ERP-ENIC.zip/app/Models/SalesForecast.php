<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SalesForecast extends Model
{
    use HasFactory;
    protected $fillable = [
        'product_id',                          // Khóa ngoại liên kết với Product
        'turnover',                            // Luân chuyển (số lần/chu kỳ)
        'customer_orders',                     // Khách đã đặt
        'avg_daily_sales_cycle',               // SL bán trong 1 chu kỳ/ngày
        'avg_daily_sales_recent_week',         // SL bán trong 1 tuần gần nhất/ngày
        'forecast_daily_sales_to_end',        // Dự toán SL bán được/ngày (today đến hết T3)
        'preorder_daily_tracking_forecast',      // Dự toán theo dõi/ngày (trước khi đặt)
        'sku'
    ];

    /**
     * Một bản ghi dự báo thuộc về một sản phẩm.
     */
    public function forcastProduct()
    {
        return $this->belongsTo(ForecastProduct::class);
    }
}
