<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    use HasFactory;


    protected $fillable = [
        'product_id',            // Khóa ngoại liên kết với Product
        'shipping_time',         // Thời gian vận chuyển (số ngày)
        'total_warehouse_time',  // Tổng thời gian hàng về kho (số ngày)
        'stock_in_warehouse',    // Tồn trong kho
        'goods_in_transit',      // Hàng đang load về
        'goods_ordered_stored',  // Hàng đang đặt+lưu kho
        'reserved_stock',        // SL hàng giữ tồn kho
        'sku'
    ];


    /**
     * Thông tin tồn kho thuộc về một sản phẩm.
     */
    public function forcastProduct()
    {
        return $this->belongsTo(ForecastProduct::class);
    }
}
