<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Folder extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'path',
        'parent_id',
        'user_id',
    ];
    
    /**
     * Get the parent folder
     */
    public function parent()
    {
        return $this->belongsTo(Folder::class, 'parent_id');
    }
    
    /**
     * Get child folders
     */
    public function children()
    {
        return $this->hasMany(Folder::class, 'parent_id');
    }
    
    /**
     * Get files in this folder
     */
    public function files()
    {
        return $this->hasMany(File::class);
    }
    
    /**
     * Get the user that owns the folder
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
