<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryReality extends Model
{
    use HasFactory;
    protected $fillable = [
        'purchase_order_id',
        'sku',
        'qty',
        'date_delivery',
        'delivery_notes',
        'date_received',
        'status',
        'order_quantity',
        'name',
        'qty_more',
        'supplier_id'
    ];

    public function purchaseOrder()
    {
        return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function productSku()
    {
        return $this->belongsTo(Product::class, 'sku', 'sku');
    }
    public function supplier()
    {
        return $this->belongsTo(Supplier::class,'supplier_id');
    }
}
