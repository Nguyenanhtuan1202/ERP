<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'supplier_id',
        'phone',
        'ware_housing',
        'purchaser',
        'forecaster',
        'status'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    public function role()
    {
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id');
    }

    public function checkPermissionAccess($permissionCheck)
    {

        /* Lấy tất các các quyền của user đang login */
        $roles = auth()->user()->role;
        foreach ($roles as $role) {
            $permission = $role->permission;
            if ($permission->contains('key_code', $permissionCheck)) {  /* So sánh các quyền  */
                return true;
            }
        }
        return false;
    }


    public function post()
    {
        return $this->hasMany(Post::class);
    }

    public function historyPayment()
    {
        return $this->hasMany(HistoryPayment::class, 'user_id', 'id');
    }
    public function supplier()
    {
        return $this->hasMany(Supplier::class, 'employer_id', 'id');
    }
    public function order()
    {
        return $this->hasMany(Order::class, 'user_id', 'id');
    }

    public function files()
    {
        return $this->hasMany(File::class);
    }

    /**
     * Get all folders for the user
     */
    public function folders()
    {
        return $this->hasMany(Folder::class);
    }
}
