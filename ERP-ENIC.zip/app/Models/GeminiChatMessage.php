<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeminiChatMessage extends Model
{

    use HasFactory;

    // Đặt tên bảng nếu không theo quy tắc mặc định
    protected $table = 'gemini_chat_messages';

    // Các thuộc tính có thể gán giá trị mass assignment
    protected $fillable = [
        'session_id',
        'role',
        'content',
        'sender_type'
    ];

    /**
     * Lấy thông tin phiên chat liên quan.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function session()
    {
        return $this->belongsTo(GeminiChatSession::class, 'session_id', 'session_id');
    }

    public function children()
    {
        return $this->hasMany(GeminiChatMessage::class, 'parent_content_id', 'id');
    }
}
