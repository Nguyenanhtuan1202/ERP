<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeminiChatSession extends Model
{
    // Đặt tên bảng nếu không theo quy tắc tên mặc định
    protected $table = 'gemini_chat_sessions';

    // Khóa chính là session_id (kiểu string)
    protected $primaryKey = 'session_id';
    public $incrementing = false;
    protected $keyType = 'string';

    // Các thuộc tính có thể gán giá trị mass assignment
    protected $fillable = [
        'session_id',
        'title',
        'user_id',
        'user_info',
        'last_activity'
    ];

    /**
     * Lấy tất cả tin nhắn trong phiên chat này.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function messages()
    {
        return $this->hasMany(GeminiChatMessage::class, 'session_id', 'session_id');
    }
}
