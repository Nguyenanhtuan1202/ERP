<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Container extends Model
{
    use HasFactory;

    protected $fillable = [
        'container_number',
        'type',          // 20ft, 40ft, Reefer, Open Top, Flat Rack
        'status',        // Đang sử dụng, Rỗng, Bị hỏng
        'seal_number',
        'location',
        'weight',
        'dimensions',
        'shipment_id',
    ];

    // Liên kết với lô hàng (shipment)
    public function shipment()
    {
        return $this->belongsTo(Shipment::class);
    }
}
