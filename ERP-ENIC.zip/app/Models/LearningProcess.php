<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LearningProcess extends Model
{
    use HasFactory;


    protected $fillable = [
        'id_hs',
        'fullname',
        'test',
        'test_date',
        'test_score',
        'note'
    ];


    public function listLearningProcess()
    {
        return $this->belongsTo(ListExpert::class, 'id_hs', 'id_hs');
    }
}
