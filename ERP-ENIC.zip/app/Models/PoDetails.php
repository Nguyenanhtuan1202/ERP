<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PoDetails extends Model
{
    use HasFactory;

    protected $fillable = [
        'po',
        'code_po',
        'sku',
        'name',
        'primary_qty',
        'forecast_qty',
        'actual_qty',
        'remain_qty',
        'date_forecast',
        'date_forecast_by_sale',
        'warehousing',
    ];
    
}
