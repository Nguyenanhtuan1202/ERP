<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'sku',
        'content',
        'image',
        'parent_id',
        'status',
        'weight',
    ];

    public function post()
    {
        return $this->belongsToMany(Post::class, 'post__categories', 'category_id ', 'post_id');
    }

    public function catChild()
    {
        return $this->hasMany(Category::class, 'parent_id', 'id')->orderBy('weight', 'asc');
    }

    public function productVariants()
    {
        return $this->hasMany(ProductVariant::class);
    }
}
