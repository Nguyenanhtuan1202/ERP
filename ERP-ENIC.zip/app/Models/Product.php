<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'sku',
        'description',
        'price',
        'unit',
        'images',
        'color',
        'size',
        'type',
        'type2',
        'material',
        'weight',
        'cat_id',
        'status',
        'tier',
        'tier_code',
        'style',
        'style_code'
    ];

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function purchaseOrderItems()
    {
        return $this->hasMany(PurchaseOrderItem::class);
    }

    public function attributeValues()
    {
        return $this->belongsToMany(AttributeValue::class, 'product_attribute_values', 'product_id', 'attribute_value_id')
            ->withTimestamps();
    }

    public function materialsForProducts()
    {
        return $this->hasMany(MaterialsForProducts::class, 'tier_code', 'tier_code');
    }


}
