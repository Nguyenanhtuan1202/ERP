<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory;
    protected $fillable = [
        'title',
        'meta_seo',
        'key_seo',
        'desc_seo',
        'content',
        'image',
        'num_list',
        'num_list_orther',
        'slug',
        'url',
        'status',
        'weight',
    ];

    public function post()
    {
        return $this->belongsToMany(Post::class,'post__tags');
    }
    
}
