<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    use HasFactory;

    protected $fillable = [
        'username',
        'phone_number',
        'email',
        'company_name',
        'companion_day',
        'website',
        'address',
        'company_tax',
        'employer',
        'terms',
        'payments',
        'industry',
        'note',
        'weight',
        'status',
        'sp_code',
        'product_manufacturing',
        'employer_id',
        'holiday_schedule',
        'packaging_specifications',
        'production_time',
        'shipping_time',
        'total_lead_time',
        'exclusive_rights',
        'warranty_preorder',
        'warranty_postorder',
        'deposit',
        'peak_season',
        'forecaster_id',
        'logistics_staff_id'
    ];

    public function purchaseOrders()
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    public function bankAccounts()
    {
        return $this->hasMany(BankAccount::class);
    }



    // public static function boot()
    // {
    //     parent::boot();

    //     static::creating(function ($supplier) {
    //         $supplier->sp_code = self::generateSpCode();
    //     });
    // }

    // private static function generateSpCode()
    // {
    //     $sequence = SpCodeSequence::first();
    //     if (!$sequence) {
    //         $sequence = SpCodeSequence::create();
    //     }

    //     $sequence->last_sp_code += 1;
    //     $sequence->save();

    //     $prefix = 'SUPN';
    //     return $prefix . $sequence->last_sp_code;
    // }


    public function forecastProducts()
    {
        return $this->hasMany(ForecastProduct::class, 'supplier_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'employer_id', 'id');
    }
}
