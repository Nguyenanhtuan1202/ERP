<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImportCost extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'cost_name',
        'cost_value',
        'user_id',
    ];

    // Nếu cần quan hệ với Order
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
