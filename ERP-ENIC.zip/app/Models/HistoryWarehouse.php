<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistoryWarehouse extends Model
{
    use HasFactory;

    protected $fillable = [
        'warehouse_id',
        'user_id',
        'details', // lưu dữ liệu JSON
        'entry_time',
        'notes',
    ];


    // Để tự động ép kiểu của cột JSON thành mảng
    protected $casts = [
        'details' => 'array',
    ];

    public function warehouse()
    {
        return $this->belongsTo(Warehousing::class, 'warehouse_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
