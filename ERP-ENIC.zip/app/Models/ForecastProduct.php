<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class ForecastProduct extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_name',
        'product_variant',
        'model_version',
        'color',
        'size',
        'sale_key',
        'sku',
        'supplier_id',
        'product_note',
        'sale_note',
        'image',
        'price',
        'status',
        'unit',
        'price_vn',
        'length_cm',
        'width_cm',
        'height_cm',
        'quantity_per_carton',
        'cbm_per_ctn',
        'quantity_per_container',
        'freight_cost_per_cubic_meter',
        'import_tax',
        'additional_costs',
        'warehouse_price',
        'selling_price'

    ];

    /**
     * Một sản phẩm thuộc về một nhà cung cấp.
     */
    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    /**
     * Một sản phẩm có thông tin tồn kho (hoặc nhiều bản ghi tồn kho nếu theo dõi lịch sử).
     */
    public function inventory()
    {
        return $this->hasOne(Inventory::class);
    }
    /**
     * Một sản phẩm có thể có nhiều bản ghi bán hàng/dự báo.
     */
    public function salesForecasts()
    {
        return $this->hasMany(SalesForecast::class);
    }



    // Relationship with product history
    public function productHistories()
    {
        return $this->hasMany(ProductHistory::class, 'product_id');
    }

    // Method to track changes
    public function trackDetailedChanges($oldAttributes, $newAttributes)
    {
        $changes = [];

        foreach ($this->fillable as $attribute) {
            // Kiểm tra giá trị cũ và mới của từng thuộc tính
            $oldValue = $oldAttributes[$attribute] ?? null;
            $newValue = $newAttributes[$attribute] ?? null;

            // So sánh giá trị, bao gồm cả trường hợp null
            if ($oldValue !== $newValue) {
                $changes[] = [
                    'product_id' => $this->id,
                    'user_id' => Auth::id() ?? null,
                    'field_changed' => $attribute,
                    'old_value' => is_array($oldValue) || is_object($oldValue)
                        ? json_encode($oldValue)
                        : $oldValue,
                    'new_value' => is_array($newValue) || is_object($newValue)
                        ? json_encode($newValue)
                        : $newValue,
                    'changed_at' => now(),
                    'created_at' => now(),
                    'updated_at' => now()
                ];
            }
        }
        return $changes;
    }
}
