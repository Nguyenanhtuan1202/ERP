<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListExpert extends Model
{

    protected $guarded = [];
    use HasFactory;
    protected $table = 'list_register_expert';

    protected $fillable = [
        'id_hs',
        'fullname',
        'phone',
        'email',
        'address',
        'cccd',
        'dob',
        'bank_account',
        'bank_name',
        'bank_name_account',
        'cccd_front',
        'cccd_back',
        'profile_picture',
        'date_cccd',
        'introducer',
        'status',
        'created_at',
        'updated_at',
        'date_approve',
        'file_contract',
        'level',
        'date_join',
        'issued_by',
        'cancel_contract',
        'class',
        'book1',
        'book2',
        'book3',
        'book4',
        'water',
        'uniform',
        'brochure',
        'user_admin',
        'vest',
        'date_cancel_contract',
        'gender',
        'admin_approve'
    ];

    protected static function boot()
    {
        parent::boot();

        // Cập nhật trường date_approve mỗi khi bản ghi được cập nhật
        static::updating(function ($model) {
            $model->date_approve = $model->updated_at;
        });
    }

    public function attendances()
    {
        return $this->hasMany(Attendance::class, 'id_hs', 'id_hs');
    }


    public function learningprocess()
    {
        return $this->hasMany(LearningProcess::class, 'id_hs', 'id_hs');
    }
}
