<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SpCodeSequence extends Model
{
    use HasFactory;
    protected $fillable = ['last_sp_code'];
}
