<?php

namespace App\Models;

use Google\Service\ShoppingContent\Warehouse;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WarehouseDraft extends Model
{
    use HasFactory;

    protected $fillable = [
        'purchase_order_id',
        'sku',
        'name',
        'order_quantity',
        'qty_received',
        'qty_more',
        'date_received',
        'delivery_notes',
        'supplier_id',
        'status'
    ];

    public function confirm()
    {
        // Ví dụ: Tạo bản ghi trong bảng kho chính (model Warehouse)
        $warehouseItem = Warehousing::create([
            'purchase_order_id' => $this->purchase_order_id,
            'sku'               => $this->sku,
            'name'              => $this->name,
            'order_quantity'    => $this->order_quantity,
            'qty_received'      => $this->qty_received,
            'qty_more'          => $this->qty_more,
            'date_received'     => $this->date_received,
            'delivery_notes'    => $this->delivery_notes,
            'supplier_id'       => $this->supplier_id,
        ]);

        // Cập nhật trạng thái bản nháp thành đã xác nhận (1)
        $this->update(['status' => 1]);

        return $warehouseItem;
    }


    public function supplier()
    {
        return $this->belongsTo(Supplier::class,'supplier_id');
    }
}
