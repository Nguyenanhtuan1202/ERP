<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    // Nếu tên bảng là "order_items", không cần khai báo lại $table
    protected $fillable = [
        'order_id',
        'order_code',
        'sku',
        'quantity',
        'price',
        'product_specifications',
        'packaging',
        'total',
        'date_of_manufacture',
        'expected_date',
        'date_for_sale',
        'note',
        'status',
        'ware_housing',
        'container',
        'noteOrder',
        'unit'
    ];
    /**
     * Quan hệ ngược lại: Một OrderItem thuộc về một Order.
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'sku', 'sku');
    }
    public function forecastProduct()
    {
        return $this->belongsTo(ForecastProduct::class, 'sku', 'sku');
    }


}
