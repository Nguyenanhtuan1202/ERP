<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\EmbedHtml;
use App\Models\Menu;
use App\Models\Theme;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Session;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer(
            '*',
            function ($view) {
                $cat_all_home = Category::where('parent_id', '0')->get();
                $menus_home = Menu::where('status', 1)->orderBy('weight', 'asc')->get();
                $cat_child = Category::whereNotIn('parent_id', ['0'])->get();
                $embedhtml = EmbedHtml::first();
                $theme = Theme::first();
                $view->with('cat_all_home', $cat_all_home)->with('cat_child', $cat_child)->with('menus_home', $menus_home)->with('embedhtml',$embedhtml)->with('theme', $theme);
            }
        );
    }
}
