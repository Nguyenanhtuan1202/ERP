<?php

namespace App\Providers;

use App\Models\Post;
use App\Models\User;
use App\Policies\PostPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
        Post::class => PostPolicy::class
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        /* Post */
        Gate::define('add_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_post'));
        });
        Gate::define('list_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_post'));
        });
        Gate::define('edit_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_post'));
        });
        Gate::define('delete_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_post'));
        });


        Gate::define('cancel_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.cancel_post'));
        });
        Gate::define('view_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.view_post'));
        });
        Gate::define('excel_expert_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.excel_expert_post'));
        });
        Gate::define('excel_cancel_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.excel_cancel_post'));
        });

        Gate::define('restore_post', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.restore_post'));
        });
        Gate::define('list_cancel', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_cancel'));
        });



        Gate::define('list_learning_process', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_learning_process'));
        });
        Gate::define('add_learning_process', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_learning_process'));
        });


        Gate::define('delete_learning_process', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_learning_process'));
        });


        /* User */
        Gate::define('add_user', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_user'));
        });
        Gate::define('list_user', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_user'));
        });
        Gate::define('edit_user', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_user'));
        });
        Gate::define('delete_user', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_user'));
        });

        /* Role */

        Gate::define('add_role', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_role'));
        });
        Gate::define('list_role', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_role'));
        });
        Gate::define('edit_role', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_role'));
        });
        Gate::define('delete_role', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_role'));
        });


        /* Đại Lý */

        Gate::define('add_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_agent'));
        });
        Gate::define('edit_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_agent'));
        });
        Gate::define('delete_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_agent'));
        });
        Gate::define('list_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_agent'));
        });

        Gate::define('view_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.view_agent'));
        });



        Gate::define('excel_expert_agent', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.excel_expert_agent'));
        });


        /* Warehouse */


        Gate::define('add_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_warehouse'));
        });

        Gate::define('edit_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_warehouse'));
        });
        Gate::define('delete_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_warehouse'));
        });
        Gate::define('list_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_warehouse'));
        });
        Gate::define('view_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.view_warehouse'));
        });
        Gate::define('excel_warehouse', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.excel_warehouse'));
        });


        /* Sản Phẩm */


        Gate::define('add_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_product'));
        });

        Gate::define('edit_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_product'));
        });

        Gate::define('delete_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_product'));
        });

        Gate::define('list_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_product'));
        });


        /* Mua Hàng */


        Gate::define('add_purchase', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_purchase'));
        });

        Gate::define('edit_purchase', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_purchase'));
        });

        Gate::define('list_purchase', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_purchase'));
        });

        Gate::define('delete_purchase', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_purchase'));
        });

        Gate::define('excel_purchase', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.excel_purchase'));
        });

        /* Quản Lý Nhà Cung Cấp
        */
        Gate::define('add_supplier', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_supplier'));
        });
        Gate::define('edit_supplier', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_supplier'));
        });
        Gate::define('list_supplier', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_supplier'));
        });
        Gate::define('delete_supplier', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_supplier'));
        });


        /* Quản Lý Sản Xuất
        */
        Gate::define('add_production', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_production'));
        });
        Gate::define('edit_production', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.edit_production'));
        });
        Gate::define('list_production', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_production'));
        });
        Gate::define('delete_production', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_production'));
        });



        /* Quản Lý Giao Nhận Hàng */


        Gate::define('list_delivery', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_delivery'));
        });
        Gate::define('process_delivery', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.process_delivery'));
        });
        Gate::define('export_excel_delivery', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.export_excel_delivery'));
        });


        /* Quản Lý Sản Phẩm */


        Gate::define('list_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_product'));
        });
        Gate::define('import_excel_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.import_excel_product'));
        });
        Gate::define('export_excel_product', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.export_excel_product'));
        });


        /* Quản lý vật tư */

        Gate::define('add_material', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_material'));
        });
        Gate::define('list_material', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_material'));
        });
        Gate::define('update_material', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.update_material'));
        });
        Gate::define('delete_material', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_material'));
        });
        Gate::define('import_export_material', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.import_export_material'));
        });


        /* Quản lý nhân viên kho */

        Gate::define('add_employee', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_employee'));
        });
        Gate::define('update_employee', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.update_employee'));
        });
        Gate::define('list_employee', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.list_employee'));
        });
        Gate::define('delete_employee', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.delete_employee'));
        });


        /* Quản lý đơn hàng đặt xưởng trung*/

        Gate::define('add_order', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.add_order'));
        });
        Gate::define('update_order', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.update_order'));
        });
        Gate::define('check_auto_order', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.check_auto_order'));
        });
        Gate::define('detail_order', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.detail_order'));
        });
        Gate::define('process_order', function (User $user) {
            return  $user->checkPermissionAccess(config('permissions.access.process_order'));
        });
    }
}
