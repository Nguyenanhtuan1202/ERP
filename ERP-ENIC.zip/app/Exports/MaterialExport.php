<?php

namespace App\Exports;

use App\Models\Material;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class MaterialExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */



    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $material_list = Material::select(
            'name',
            'sku',
            'material_categories_id',
            'packaging',
            'price_cost',
            'price_in_stock',
            'unit'

        )->orderBy('updated_at', 'desc')->get();
        $materialWithSTT = $material_list->map(function ($data, $key) {
            return [
                'stt' => $key + 1,
                'name' => $data->name,
                'sku' => $data->sku,
                'material_categories_id' =>  $this->getMaterialCategory($data->material_categories_id),
                'packaging' => $data->packaging,
                'price_cost' => $data->price_cost,
                'price_in_stock' => $data->price_in_stock,
                'unit' => $data->unit,
            ];
        });

        return $materialWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',
            'Tên Vật Liệu',
            'SKU',
            'Hạng Mục Vật Tư',
            'Quy Cách Đóng Gói',
            'Giá Vốn',
            'Giá Về Kho',
            'Đơn Vị'
        ];
    }


    private function getMaterialCategory($var)
    {
        switch ($var) {
            case 1:
                return 'NGUYÊN LIỆU SẢN XUẤT';
            case 2:
                return 'VẬT TƯ SẢN XUẤT';
            case 3:
                return 'VẬT TƯ LẮP ĐẶT';
            case 4:
                return 'VẬT TƯ ĐÓNG GÓI';
            case 5:
                return 'VẬT TƯ LED';
            default:
                return 'Không xác định';
        }
    }
}
