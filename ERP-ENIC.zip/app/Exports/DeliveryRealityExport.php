<?php

namespace App\Exports;

use App\Models\DeliveryReality;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class DeliveryRealityExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    protected $date;
    protected $supplier;
    public function __construct($date, $supplier)
    {
        $this->date = $date;
        $this->supplier = $supplier;
    }

    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $deliverylist = DeliveryReality::with('purchaseOrder', 'supplier')
            ->whereDate('date_received', $this->date)
            ->when(!empty($this->supplier), function ($query) {
                return $query->where('supplier_id', $this->supplier);
            })
            ->select(
                'purchase_order_id',
                'order_quantity',
                'name',
                'sku',
                'qty',
                'qty_more',
                'date_delivery',
                'date_received',
                'delivery_notes',
                'supplier_id'
            )
            // Sắp xếp theo purchase_order_id để các đơn cùng purchase order nằm gần nhau
            ->orderBy('purchase_order_id', 'asc')
            // Nếu cần sắp xếp phụ theo thời gian cập nhật
            ->orderBy('updated_at', 'desc')
            ->get();

        $deliveryWithSTT = $deliverylist->map(function ($data, $key) {
            return [
                'stt' => $key + 1,
                'purchase_order_id' => $data->purchaseOrder->po_id,
                'name' => $data->name,
                'sku' => $data->sku,
                'order_quantity' => $data->order_quantity,
                'qty' => $data->qty,
                'qty_more' => $data->qty_more,
                'date_delivery' => $data->date_delivery,
                'date_received' => $data->date_received,
                'delivery_notes' => $data->delivery_notes,
                'supplier_id' => $data->supplier->username ?? "",
            ];
        });

        return $deliveryWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',
            'Mã Đơn Hàng',
            'Tên Sản Phẩm',
            'Mã SKU',
            'Số Lượng Đặt Hàng',
            'Số Lượng Giao Hàng',
            'Số Lượng Giao Thêm',
            'Ngày Giao Hàng',
            'Ngày Nhận Hàng',
            'Ghi Chú',
            'Xưởng Sản Xuất',
        ];
    }
}
