<?php

namespace App\Exports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ProductExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */


    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $product_list = Product::select(
            'name',
            'sku',
            'price',
            'color',
            'size',
            'type',
            'type2',
            'material',
            'weight',
            'tier',
            'tier_code',
            'style',
            'style_code',

        )->orderBy('weight', 'desc')->get();

        $productWithSTT = $product_list->map(function ($data, $key) {
            return [
                'name' => $data->name,
                'sku' => $data->sku,
                'price' => $data->price,
                'color' => $data->color,
                'size' => $data->size,
                'type' => $data->type,
                'type2' => $data->type2,
                'material' => $data->material,
                'weight' => $data->weight,
                'tier' => $data->tier,
                'tier_code' => $data->tier_code,
                'style' => $data->style,
                'style_code' => $data->style_code,
            ];
        });

        return $productWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'name',
            'sku',
            'price',
            'color',
            'size',
            'type',
            'type2',
            'material',
            'weight',
            'tier',
            'tier_code',
            'style',
            'style_code'
        ];
    }
}
