<?php

namespace App\Exports;

use App\Models\Agent;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;



class ListAgentExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $agents = Agent::select(
            'name',
            'phone',
            'email',
            'address',
            'created_at',
            'updated_at',

        )->orderBy('updated_at', 'desc')->get();


        $agentWithSTT = $agents->map(function ($agent, $key) {
            return [
                'stt' => $key + 1,
                'name' => $agent->name,
                'phone' => $agent->phone,
                'email' => $agent->email,
                'address' => $agent->address,
                'created_at' => $agent->created_at,
                'updated_at' => $agent->updated_at,
            ];
        });

        return $agentWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',          // STT
            'Họ và Tên',          // name
            'Số Điện Thoại',      // phone
            'Email',              // email
            'Địa Chỉ',            // address
            'Ngày Tạo',           // created_at
            'Ngày Cập Nhật',      // updated_at
        ];
    }
}
