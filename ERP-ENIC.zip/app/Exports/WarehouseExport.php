<?php

namespace App\Exports;

use App\Models\Warehouse;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class WarehouseExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return Warehouse::with('agent')->get()->map(function ($warehouse) {
            return [
                'name' => $warehouse->name,
                'location' => $warehouse->location,
                'capacity' => $warehouse->capacity,
                'agent_name' => $warehouse->agent->name ?? '',
                'created_at' => $warehouse->created_at,
            ];
        });
    }

    public function headings(): array
    {
        return [
            'Tên kho',
            'Vị trí',
            'Sức chứa (diện tích)',
            'Tên đại lý',
            'Ngày tạo',
        ];
    }
}
