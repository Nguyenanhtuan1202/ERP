<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\FromCollection;

class PurchaseOrderExport implements FromView
{
    protected $orderData;

    public function __construct(array $orderData)
    {
        $this->orderData = $orderData;
    }

    public function view(): View
    {
        // Truyền tất cả dữ liệu đơn hàng vào view export
        return view('orders.export_purchase_order', $this->orderData);
    }
}
