<?php

namespace App\Exports;

use App\Models\ForecastProduct;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ForecastProductExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $product_list = ForecastProduct::select(
            'supplier_id',
            'product_name',
            'product_variant',
            'model_version',
            'color',
            'size',
            'sale_key',
            'sku',
            'product_note',
            'sale_note',
        )->orderBy('id', 'asc')->get();

        $productWithSTT = $product_list->map(function ($data, $key) {
            return [
                'supplier_id' => $data->supplier_id,
                'product_name' => $data->product_name,
                'product_variant' => $data->product_variant,
                'model_version' => $data->model_version,
                'color' => $data->color,
                'size' => $data->size,
                'sale_key' => $data->sale_key,
                'sku' => $data->sku,
                'product_note' => $data->product_note,
                'sale_note' => $data->sale_note,
            ];
        });
        return $productWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Nhà Cung Cấp',
            'Sản Phẩm',
            'Mẫu ( Phân Loại)',
            'Phiên Bản ( Model)',
            'Màu Sắc',
            'Kích Thước',
            'Key Sale',
            'Sku',
            'Note( Sản Phẩm)',
            'Note( Bán Hàng)',
        ];
    }
}
