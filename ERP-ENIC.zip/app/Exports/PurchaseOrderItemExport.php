<?php

namespace App\Exports;

use App\Models\PurchaseOrderItem;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class PurchaseOrderItemExport implements FromCollection, WithHeadings
{
    protected $purchaseOrderId;
    public function __construct($purchaseOrderId)
    {
        $this->purchaseOrderId = $purchaseOrderId;
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        $product_list = PurchaseOrderItem::with('product')->select(
            'sku',
            'quantity',
            'unit_price',
            'expected_date',
            'date_sale'
        )->orderBy('id', 'asc')
            ->where('purchase_order_id', $this->purchaseOrderId)
            ->get();

        $productWithSTT = $product_list->map(function ($data, $key) {
            return [
                'sku'           => $data->sku,
                'name'          => optional($data->product)->name, // Lấy tên từ bảng products thông qua relationship
                'quantity'      => $data->quantity,
                'unit_price'    => $data->unit_price,
                'expected_date' => $data->expected_date,
                'date_sale'     => $data->date_sale,
            ];
        });

        return $productWithSTT;
    }
    
    public function headings(): array
    {
        return [
            'Sku',
            'Key Chuẩn',
            'số Lượng',
            'Đơn Giá',
            'Ngày Dự Kiến Giao Hàng',
            'Ngày Giao Cho Sale',
        ];
    }
}
