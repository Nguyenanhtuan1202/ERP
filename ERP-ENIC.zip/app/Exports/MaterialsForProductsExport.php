<?php

namespace App\Exports;

use App\Models\MaterialsForProducts;
use App\Models\Product;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class MaterialsForProductsExport implements FromCollection, WithHeadings
{
    protected $filters;

    public function __construct($filters)
    {
        $this->filters = $filters;
    }

    public function collection()
    {
        $query = MaterialsForProducts::query();

        if (isset($this->filters['tier_code']) && !empty($this->filters['tier_code'])) {
            $query->where('tier_code', $this->filters['tier_code']);
        }
        if (isset($this->filters['style_code']) && !empty($this->filters['style_code'])) {
            $query->where('style_code', $this->filters['style_code']);
        }
        if (isset($this->filters['size']) && !empty($this->filters['size'])) {
            $query->where('size', $this->filters['size']);
        }
        if (isset($this->filters['color']) && !empty($this->filters['color'])) {
            $query->where('color', $this->filters['color']);
        }

        $materials = $query->get()->map(function ($material) {
            $product = Product::where('tier_code', $material->tier_code)
                ->where('style_code', $material->style_code)
                ->first();

            return [
                'tier_code'    => $material->tier_code,
                'tier' => $product ? $product->tier : 'N/A',
                'style_code'   => $material->style_code,
                'style' => $product ? $product->style : 'N/A',
                'product_name' => $product ? $product->name : 'N/A',
                'size'         => $material->size,
                'color'        => $material->color,
                'sku'          => $material->sku,
                'material_name' => $material->name,
                'quantity'     => $material->quantity,
                'total_price'  => $material->total_price,
            ];
        });

        return $materials;
    }




    public function headings(): array
    {
        return ['Tier Code', 'Tier', 'Style Code', 'Style', 'Sản phẩm', 'Size', 'Color', 'SKU', 'Vật liệu', 'Số lượng', 'Giá tổng'];
    }
}
