<?php

namespace App\Exports;

use App\Models\Delivery;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class DeliveryExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */



    protected $date;

    public function __construct($date)
    {
        $this->date = $date;
    }

    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $deliverylist = Delivery::with('purchaseOrder')->whereDate('date_received', $this->date)->select(
            'purchase_order_id',
            'order_quantity',
            'name',
            'sku',
            'qty',
            'qty_more',
            'date_delivery',
            'date_received',
            'delivery_notes',
        )->orderBy('updated_at', 'desc')->get();

        $deliveryWithSTT = $deliverylist->map(function ($data, $key) {
            return [
                'stt' => $key + 1,
                'purchase_order_id' => $data->purchaseOrder->po_id,
                'name' => $data->name,
                'sku' => $data->sku,
                'order_quantity' => $data->order_quantity,
                'qty' => $data->qty,
                'qty_more' => $data->qty_more,
                'date_delivery' => $data->date_delivery,
                'date_received' => $data->date_received,
                'delivery_notes' => $data->delivery_notes,
            ];
        });

        return $deliveryWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',
            'Mã Đơn Hàng',
            'Tên Sản Phẩm',
            'Mã SKU',
            'Số Lượng Đặt Hàng',
            'Số Lượng Giao Hàng',
            'Số Lượng Giao Thêm',
            'Ngày Giao Hàng',
            'Ngày Nhận Hàng',
            'Ghi Chú',
        ];
    }
}
