<?php

namespace App\Exports;

use App\Models\ListExpert;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ListCancelExpertExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $experts = ListExpert::select(
            'id_hs',
            'fullname',
            'phone',
            'email',
            'address',
            'cccd',
            'dob',
            'bank_account',
            'bank_name',
            'bank_name_account',
            'cccd_front',
            'cccd_back',
            'profile_picture',
            'date_cccd',
            'introducer',
            'status',
            'created_at',
            'updated_at',
            'date_approve',
            'file_contract',
            'level',
            'date_join',
            'issued_by',
            'cancel_contract',
            'class',
            'book1',
            'book2',
            'book3',
            'book4',
            'water',
            'uniform',
            'brochure',
            'vest',
            'user_admin',
            'date_cancel_contract'
        )->where('cancel_contract', 1)->where('status', 1)->where('admin_approve', 1)->orderBy('id_hs', 'asc')->get();

        $expertsWithSTT = $experts->map(function ($expert, $key) {
            return [
                'stt' => $key + 1,
                'id_hs' => $expert->id_hs,
                'fullname' => $expert->fullname,
                'phone' => $expert->phone,
                'email' => $expert->email,
                'address' => $expert->address,
                'cccd' => $expert->cccd,
                'dob' => $expert->dob,
                'bank_account' => $expert->bank_account,
                'bank_name' => $expert->bank_name,
                'bank_name_account' => $expert->bank_name_account,
                'cccd_front' => $expert->cccd_front,
                'cccd_back' => $expert->cccd_back,
                'profile_picture' => $expert->profile_picture,
                'date_cccd' => $expert->date_cccd,
                'introducer' => $expert->introducer,
                'status' => $expert->status == 1 ? 'Đã được duyệt' : 'Chưa duyệt',
                'created_at' => $expert->created_at,
                'updated_at' => $expert->updated_at,
                'date_approve' => $expert->date_approve,
                'file_contract' => $expert->file_contract,
                'level' => $this->getLevelDescription($expert->level), // Chuyển đổi level thành mô tả
                'date_join' => $expert->date_join,
                'issued_by' => $expert->issued_by,
                'cancel_contract' => $expert->cancel_contract == 1 ? 'Đã huỷ' : 'Chưa huỷ',
                'class' => $expert->class,
                'book1' => $expert->book1 == 1 ? 'Đã nhận' : 'Chưa nhận',
                'book2' => $expert->book2 == 1 ? 'Đã nhận' : 'Chưa nhận',
                'book3' => $expert->book3 == 1 ? 'Đã nhận' : 'Chưa nhận',
                'book4' => $expert->book4 == 1 ? 'Đã nhận' : 'Chưa nhận',
                'water' => $expert->water == 1 ? 'Đã nhận' : 'Chưa nhận',
                'uniform' => $expert->uniform == 1 ? 'Đã nhận' : 'Chưa nhận',
                'brochure' => $expert->brochure == 1 ? 'Đã nhận' : 'Chưa nhận',
                'vest' => $expert->vest == 1 ? 'Đã May' : 'Chưa May',
                'user_admin' => $expert->user_admin,
                'date_cancel_contract' => $expert->date_cancel_contract,

            ];
        });

        return $expertsWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',          // STT
            'Mã Số Chuyên Gia',        // id_hs
            'Họ và Tên',          // fullname
            'Số Điện Thoại',      // phone
            'Email',              // email
            'Địa Chỉ',            // address
            'CCCD',               // cccd
            'Ngày Sinh',          // dob
            'Tài Khoản Ngân Hàng', // bank_account
            'Tên Ngân Hàng',      // bank_name
            'Chủ Tài Khoản',      // bank_name_account
            'Mặt Trước CCCD',     // cccd_front
            'Mặt Sau CCCD',       // cccd_back
            'Ảnh Đại Diện',       // profile_picture
            'Ngày Cấp CCCD',      // date_cccd
            'Người Giới Thiệu',   // introducer
            'Trạng Thái',         // status
            'Ngày Tạo',           // created_at
            'Ngày Cập Nhật',      // updated_at
            'Ngày Duyệt',         // date_approve
            'Tên File Hợp Đồng',           // file_contract
            'Cấp Độ Chuyên Gia',             // level
            'Ngày Tham Gia',      // date_join
            'Nơi Cấp',            // issued_by
            'Hủy Hợp Đồng',       // cancel_contract
            'Lớp Chuyên Gia',                // class
            'Sách Pháp Lý',             // book1
            'Sách Cơ Bản',             // book2
            'Sách Nâng Cao',             // book3
            '1 Bộ 3 Quyển Sách',             // book4
            '1 Thùng Nước',               // water
            'Đồng Phục',          // uniform
            'Sổ Tay',             // brochure
            'Áo Vest',            // vest
            'Người Quản Trị',     // user_admin
            'Ngày Huỷ Hợp Đồng'

        ];
    }



    private function getLevelDescription($level)
    {
        switch ($level) {
            case 1:
                return 'Chuyên gia cơ bản';
            case 2:
                return 'Chuyên gia nâng cao';
            case 3:
                return 'Chuyên gia cao cấp';
            default:
                return 'Không xác định';
        }
    }


}
