<?php

namespace App\Exports;

use App\Models\Category;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CategoryExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */


    public function collection()
    {
        // Lấy dữ liệu từ model với các cột được chỉ định
        $category_list = Category::select(
            'title',
            'sku',
            'status',

        )->orderBy('updated_at', 'desc')->get();


        $categoryWithSTT = $category_list->map(function ($data, $key) {
            return [
                'stt' => $key + 1,
                'title' => $data->title,
                'sku' => $data->sku,
                'status' => $data->status,
            ];
        });

        return $categoryWithSTT;
    }

    /**
     * Thêm tên cột tùy chỉnh cho file Excel
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Số Thứ Tự',
            'Tên Loại Sản Phẩm',
            'SKU',
            'Trạng Thái',
        ];
    }
}
