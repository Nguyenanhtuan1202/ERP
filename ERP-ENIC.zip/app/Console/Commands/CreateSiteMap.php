<?php

namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Models\Category;
use App\Models\Post;
use App\Models\Menu;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use App;

class CreateSiteMap extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sitemap:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {        
       
        $sitemap = App::make("sitemap");
        $sitemap->add(URL::to('/'), Carbon::now("Asia/Ho_Chi_Minh"), '1.0', 'daily');
        $sitemap->add(env('APP_URL'). 'donate', Carbon::now("Asia/Ho_Chi_Minh"), '0.8', 'daily');
        $categories = Category::where('status',1)->orderBy('id', 'desc')->get();
      
        $news = Post::where('status', 'publish')->whereNull('deleted_at')->orderBy('updated_at', 'desc')->get();
        
        
        foreach ($categories as $category)
        {
            $sitemap->add(env('APP_URL'). 'danh-muc/'. $category->url, $category->created_at, '0.9', 'daily');
        }
        foreach ($news as $item)
        {
            $sitemap->add(env('APP_URL'). $item->url, $item->updated_at, '1', 'daily');
        }

        $sitemap->store('xml', 'sitemap');

        if(File::exists(base_path().'/sitemap.xml'))
        {
            File::copy(public_path('sitemap.xml'), base_path('sitemap.xml'));
        }
  
    }
}