<?php

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

if (!function_exists('formatDate')) {
    function formatDate($date, string $format = 'Y/m/d')
    {
        if ($date instanceof \Carbon\Carbon) {
            return $date->format($format);
        }

        return $date;
    }
}


if (!function_exists('get_youtube_code')) {
    function get_youtube_code($url)
    {
        global $ims;
        $output = '';
        $pic_code = '';
        $tmp = explode('?', $url);
        if (!isset($tmp[1])) {
            return $output;
        }
        $tmp = explode('&', $tmp[1]);
        foreach ($tmp as $tmp_v) {
            $tmp1 = explode('=', $tmp_v);
            if ($tmp1[0] === 'v' || $tmp1[0] === 'V') {
                if (isset($tmp1[1])) {
                    $pic_code = $tmp1[1];
                }
            }
        }
        return $pic_code;
    }
}


if (!function_exists('format_phone_number')) {
    function format_phone_number($phone)
    {
        // Kiểm tra xem chuỗi có phải là số và có độ dài chính xác
        if (preg_match("/^\d{10}$/", $phone)) {
            // Sử dụng Str::substr để cắt chuỗi và nối lại với dấu chấm
            return Str::substr($phone, 0, 4) . '.' . Str::substr($phone, 4, 3) . '.' . Str::substr($phone, 7, 3);

            // Hoặc sử dụng Regular Expression để định dạng lại số điện thoại
            // return preg_replace("/(\d{4})(\d{3})(\d{3})/", "$1.$2.$3", $phone);
        } else {
            // Trả về số điện thoại gốc hoặc thông báo lỗi nếu không hợp lệ
            return $phone;
            // Hoặc: return 'Invalid phone number format';
        }
    }
}


if (!function_exists('get_image_category_name')) {
    function get_image_category_name($category_id)
    {
        // Kiểm tra xem tham số có phải là số nguyên hay không
        if (($category_id)) {
            switch ($category_id) {
                case 1:
                    return 'Hình ảnh học viên';
                case 2:
                    return 'Hình ảnh lớp học';
                case 3:
                    return 'Hình ảnh ký hợp đồng';
                case 4:
                    return 'Hình ảnh trải nghiệm';
                default:
                    return 'Danh mục không tồn tại';
            }
        } else {
            // Trả về thông báo lỗi nếu tham số không hợp lệ
            return 'Tham số không hợp lệ';
        }
    }
}



if (!function_exists('')) {
    function level_expert($id)
    {
        // Kiểm tra xem tham số có phải là số nguyên hay không
        if (($id)) {
            switch ($id) {
                case 0:
                    return 'Chưa cập nhật';
                case 1:
                    return 'Chuyên gia cơ bản';
                case 2:
                    return 'Chuyên gia nâng cao';
                case 3:
                    return 'Chuyên gia cao cấp';
                default:
                    return 'Chưa cập nhật';
            }
        } else {
            // Trả về thông báo lỗi nếu tham số không hợp lệ
            return 'Tham số không hợp lệ';
        }
    }
}



if (!function_exists('')) {
    function get_kimvn($id)
    {
        // Kiểm tra xem tham số có phải là số nguyên hay không
        if (($id)) {
            switch ($id) {
                case 0:
                    return 'Chưa Nhận';
                case 1:
                    return 'Đã Nhận';
                case 2:
                    return 'Đã Trả';
                default:
                    return 'Chưa cập nhật';
            }
        } else {
            // Trả về thông báo lỗi nếu tham số không hợp lệ
            return 'Chưa Nhận';
        }
    }
}



if (!function_exists('list_terms')) {
    function list_terms()
    {
        return [
            '1' => '7 ngày',
            '2' => '15 ngày',
            '3' => '21 ngày',
            '4' => '30 ngày',
            '5' => '45 ngày',
            '6' => 'Thanh Toán Cuối Tháng',
            '7' => 'Khác',
        ];
    }
}


if (!function_exists('MaterialCategory')) {

    function MaterialCategory($var)
    {
        switch ($var) {
            case 1:
                return 'NGUYÊN LIỆU SẢN XUẤT';
            case 2:
                return 'VẬT TƯ SẢN XUẤT';
            case 3:
                return 'VẬT TƯ LẮP ĐẶT';
            case 4:
                return 'VẬT TƯ ĐÓNG GÓI';
            case 5:
                return 'VẬT TƯ LED';
            default:
                return 'Không xác định';
        }
    }
}


